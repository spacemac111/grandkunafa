<?php 

ini_set('max_execution_time', 600);

 //echo  serialize(array('en_US' => 'English', 'ta_IN' => 'Tamil', 'ar_EG' => 'Arabic'));
$dir = dirname(__FILE__).'/themes/pos/'; 
//$dir = dirname(__FILE__).'/includes/'; 
	global $results; 
	$lang = 'ta_IN';
	$results =  array();
	KvscanDir($dir);
	//var_dump($results);
	//exit;
$translate_str = '';
if(!file_exists('./lang/'.$lang.'/LC_MESSAGES/'.$lang.'.po')) {
	//print_r($results);
	$translate_str .= 'msgid ""
msgstr ""
"Project-Id-Version: \n"
"Report-Msgid-Bugs-To: \n"
"POT-Creation-Date: '.date('Y-m-d h:i a').'\n"
"PO-Revision-Date: '.date('Y-m-d h:i a').'\n"
"MIME-Version: 1.0\n"
"Content-Type: text/plain; charset=UTF-8\n"
"Content-Transfer-Encoding: 8bit\n"
"Language-Team: \n"
"X-Generator: Poedit 1.8.7\n"
"Last-Translator: Varadha <admin@spacemac.us>\n"
"Plural-Forms: nplurals=2; plural=(n != 1);\n"
"Language: '.$lang.'\n"

';

}

$dir = '.';
//$dir =  dirname(dirname(dirname(__FILE__)));
if(file_exists('./lang/'.$lang.'/LC_MESSAGES/'.$lang.'.po')){
	$language_content = file_get_contents('./lang/'.$lang.'/LC_MESSAGES/'.$lang.'.po'); 
	// $existing_string = '';
	// if(file_exists('./FA/lang/'.$lang.'/LC_MESSAGES/'.$lang.'-2.4.1-3.po')){
	// 	$existing_string .= file_get_contents('./FA/lang/'.$lang.'/LC_MESSAGES/'.$lang.'-2.4.1-3.po'); 
	// }
	foreach($results as $single){
        $start_pos = strpos($language_content, $single); 
        if ($start_pos !== false)
            continue;
		if($single != '' && $single !=  null && (strpos($translate_str, trim($single)) === false)){

			/*if($existing_string != '' && (strpos($existing_string, trim($single)) !== false))  {
				$start = strpos($existing_string, trim($single));
				$truncated_str = substr($existing_string, $start);
				$start = strpos($truncated_str, 'msgstr "')+8;
				$truncated_str = substr($truncated_str, $start);
				$end = strpos($truncated_str, '"');
				$trans_str = substr($truncated_str, $start, $end);
			} else */
				$trans_str = '';

			$translate_str .= 'msgid "'.trim($single).'" 
msgstr "'.$trans_str.'" 

';
		}		
	}
}

echo $translate_str;
	$file = $dir.'/lang/'.$lang.'/LC_MESSAGES/'.$lang.'.po';
	if(!file_exists($file)){	
		if(!is_file($file)){   
			//$ourFileHandle = fopen($file, 'w') or die("can't open file");
			if (!file_exists($dir.'/lang/')) {
				mkdir($dir.'/lang/', 0777, true);
			} 
			if (!file_exists($dir.'/lang/'.$lang.'/')) {
				mkdir($dir.'/lang/'.$lang.'/', 0777, true);
			}
			if (!file_exists($dir.'/lang/'.$lang.'/LC_MESSAGES/')) {
				mkdir($dir.'/lang/'.$lang.'/LC_MESSAGES/', 0777, true);
			}
			file_put_contents($file, $translate_str);
			echo "file created successfully";
		}
	}else {
		//file_put_contents($file, "");
		file_put_contents($file, $translate_str.PHP_EOL , FILE_APPEND | LOCK_EX);
		echo "file updated successfully";
	}
	
function KvscanDir($dir) { 
		$ffs = scandir($dir);

		unset($ffs[array_search('.', $ffs, true)]);
		unset($ffs[array_search('..', $ffs, true)]);
			
		foreach ($ffs as $file) { 
			
			if(!is_dir($dir.'/'.$file)) {

				if(basename($file) != 'findgettext.php' && basename($file) != 'lang' && /*basename($file) != 'readme.html' && basename($file) != '.htaccess' && basename($file) != 'apid.php' && basename($file) != 'Rest.inc.php' && */basename($file) != 'style.css' && basename($file) != 'docs' && basename($file) != 'backups' && basename($file) != '_init' && basename($file) != 'images'  ){
				$content = file_get_contents($dir.'/'.$file); 
				//if($file == 'Inventory.php') // || $file == '404.php' || $file == 'ajax.php')
				GetAllStrings($content);
				//echo $file.'<br>';
				echo basename($file).'<br>';
			}
			}elseif(basename($file) != 'css' && basename($file) != 'js'  && basename($file) != 'morris' && basename($file) != 'xtra_file'  && basename($file) != 'fonts' && basename($file) != 'images'  && basename($file) != 'fpdi' && basename($file) != 'taxes'  ){
				//echo $file.'<br>';
				KvscanDir($dir.'/'.$file);
			}	
			//echo $file.'<br>';
		}
	}

function GetAllStrings($content, $start_pos=true){
	global $results; 
	if($start_pos){
		$string = '_("';
		$start_pos = strpos($content, $string); 
	}
	if ($start_pos !== false){ 
		$content = substr($content, $start_pos+3);
		$string2 = '")'; 
		$end_pos = strpos($content, $string2); 
		if($end_pos !== false) {
			$new_word = substr($content, 0, $end_pos);
			if(!in_array($new_word, $results))
				$results[] = $new_word;
		}
		$string = '_("';
		$next_start_pos = strpos($content, $string);		
		if ($next_start_pos !== false)
			GetAllStrings($content, $next_start_pos );
	}

	if($start_pos){
		$string = "_('";
		$start_pos = strpos($content, $string); 
	}
	if ($start_pos !== false){ 
		$content = substr($content, $start_pos+3);
		$string2 = "')"; 
		$end_pos = strpos($content, $string2); 
		if($end_pos !== false) {
			$new_word = substr($content, 0, $end_pos);
			if(!in_array($new_word, $results))
				$results[] = $new_word;
		}
		$string = "_('";
		$next_start_pos = strpos($content, $string);		
		if ($next_start_pos !== false)
			GetAllStrings($content, $next_start_pos );
	}
} 