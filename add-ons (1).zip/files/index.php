<?php 

// Slience is golden 

?>