<?php




$def_coy = 0;

$tb_pref_counter = 1;

$db_connections = array (
  0 => 
  array (
    'name' => 'KOT Testing',
    'host' => 'localhost',
    'port' => '',
    'dbname' => 'grandkun_kvcodes_kot',
    'collation' => 'utf8_xx',
    'tbpref' => '0_',
    'dbuser' => 'grandkun_main',
    'dbpassword' => 'Space1987!!',
  ),
      1 => 
  array (
    'name' => 'Nasr-City',
    'host' => 'localhost',
    'port' => '',
    'dbname' => 'grandkun_nasrr',
    'collation' => 'utf8_xx',
    'tbpref' => '3_',
    'dbuser' => 'grandkun_main',
    'dbpassword' => 'Space1987!!',
  ),
        2 => 
  array (
    'name' => 'kots',
    'host' => 'localhost',
    'port' => '',
    'dbname' => 'grandkun_kots',
    'collation' => 'utf8_xx',
    'tbpref' => '0_',
    'dbuser' => 'grandkun_main',
    'dbpassword' => 'Space1987!!',
  ),
);
