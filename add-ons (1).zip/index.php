<?php 

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('includes/functions.php');

$query_string =  $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

$is_apache = ( strpos( $_SERVER['SERVER_SOFTWARE'], 'Apache' ) !== false || strpos( $_SERVER['SERVER_SOFTWARE'], 'LiteSpeed' ) !== false );


if( !$is_apache )
	$_GET['p'] = GetPageSlug($query_string);
$get_active_theme = get_active_theme();
if($get_active_theme != ''){
	$homepage= 'no';
		if(isset($_GET['p'])){
			$q = get_a_page($_GET['p']);			
		} else { 					
			$q = get_home_page();
			if(file_exists('themes/'.$get_active_theme.'/front-page.php'))
			require('themes/'.$get_active_theme.'/front-page.php');
			$homepage= 'yes';			
		} 
		if(($q  != false || $q !=  '') ) { 			
			if($q['template'] != ''&& file_exists('themes/'.$get_active_theme.'/'.$q['template']))
				require('themes/'.$get_active_theme.'/'.$q['template']);
			elseif($q['template'] != ''&& file_exists('includes/compact/'.$q['template']))
				require('includes/compact/'.$q['template']);
			elseif(file_exists('themes/'.$get_active_theme.'/index.php') && $homepage == 'no')
				require('themes/'.$get_active_theme.'/index.php');
		}else {

			require('themes/'.$get_active_theme.'/404.php');
		}
} else{	
	require('includes/compact/index.php');
} ?>