<?php 

/*-------------------------------------------------------+
| Kvcodes POS 
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

ob_start();
session_start();

// db properties

    define('DBHOST','localhost');
    define('DBUSER','grandkun_main');
    define('DBPASS','Space1987!!');
    define('DBNAME','grandkun_kvcodes_kot');
    define('TB_PREF','kot1_');

    define('ABSPATH', dirname(__FILE__) . '/' );

    define('FA_PATH', ABSPATH.'FA/');

    define('NEEM_UPLOADS', 'files');
    
    define('included', 1); //define include checker

    define('DEBUGGING', 1);   // 0-Normal Mode, 1- Debugging Mode

    define('ENCODING', 'UTF-8');    //site encoding

    define('DEFAULT_LANG', 'en_US');  // Site Translation Purpose

?>