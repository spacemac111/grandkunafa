<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
login_required();

get_admin_header('Appearance', 'tv', null, "no"); 

$current_theme = ''; 
if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['change_theme'])) {

	$current_template = $_POST['template'];
	$current_option_id = get_site_option_id('template');
	if($current_option_id)
		Update('settings', array("ID" => $current_option_id), array("option_value" => $current_template )  );
	else
		Insert('settings', array("option_value" => $current_template , "option_name" => 'template')); 
	$theme_updated = 'success';	
	header("Refresh:0");
} 

$current_theme = get_active_theme(); 
 if(isset($theme_updated)){

				$styleFile = '../themes/'.$current_theme.'/style.css';
				$all_lines = file($styleFile);//file in to an array

				$curr_theme_name = 'Theme Name';
				$cur_theme_n = array_filter($all_lines, function($var) use ($curr_theme_name) { return preg_match("/\b$curr_theme_name\b/i", $var); });

				$cur_theme_nam=  implode('', $cur_theme_n);
				$cur_positio = strpos($cur_theme_nam, ':');

				$cur_theme_fullname =trim(substr($cur_theme_nam, $cur_positio+1));

				echo '<div class="success"> "<b>'.$cur_theme_fullname.'</b>" Theme Activated Successfully. <a href="'.get_url().'" > Visit Site </a> </div>';
} ?>
	
	<div id="tabs" class="c-tabs">
        <div class="c-tabs-nav">
          <a href="#" class="c-tabs-nav__link is-active">
            <i class="fa fa-home"></i>
            <span><?php echo _("Themes"); ?></span>
          </a>
          <a href="#" class="c-tabs-nav__link">
            <i class="fa fa-key"></i>
            <span><?php echo _("Menus"); ?></span>
          </a>
         
        </div>
        <div class="c-tab is-active">
          <div class="c-tab__content"> <!-- Themes -->
			<div class="row">
			<p><?php echo _("You can select and modify your website current and active themes. Glad to provide you few more themes."); ?></p>
			</div>
			<div class="row"> 
				<?php foreach(glob('../themes/*', GLOB_ONLYDIR) as $dir) {
				    $dirname = basename($dir);
				    foreach(glob('../themes/'.$dirname, GLOB_ONLYDIR) as $single) {
				    	$theme_folder = basename($single);
				    	//echo '../themes/'.$theme_folder.'/index.php'; 
				    	if(file_exists('../themes/'.$theme_folder.'/index.php') && file_exists('../themes/'.$theme_folder.'/functions.php') && file_exists('../themes/'.$theme_folder.'/style.css')){
				    		$myFile = '../themes/'.$theme_folder.'/style.css';
							$lines = file($myFile);//file in to an array

							$theme_name = 'Theme Name';
							$theme_n = array_filter($lines, function($var) use ($theme_name){ return preg_match("/\b$theme_name\b/i", $var); });

							$theme_nam=  implode('', $theme_n);
							$positio = strpos($theme_nam, ':');

							$theme_uri = 'Theme URI';
							$theme_ur = array_filter($lines, function($var) use ($theme_uri) { return preg_match("/\b$theme_uri\b/i", $var); });

							$theme_ur_fnl=  implode('', $theme_ur);
							$theme_ur_fnl_pos = strpos($theme_ur_fnl, ':');

							echo '<div class="4u 12u$(mobile) themeGallery">
								<form method="post" action="" > 
								<article class="item '; 
								if($current_theme == $theme_folder)
									echo 'curent_theme_neem' ;
								else
									echo 'themes_neem';
								echo '" >
									<a href="" class="image fit ">';
									if(get_active_theme() != $theme_folder)
											echo '<span><input type="submit" name="change_theme" value="'._("Activate").'" ></span>';
										echo '<img src="';
										if(file_exists('../themes/'.$theme_folder.'/screenshot.png')){
											echo '../themes/'.$theme_folder.'/screenshot.png';
										}else
											echo 'assets/css/images/default-template.png';
									$theme_fullname =trim(substr($theme_nam, $positio+1)); 
									echo '" alt="" /></a>
										<header>
											 <h3 style="display:inline; line-height: 40px;">';  //<a href="'.trim(substr($theme_ur_fnl, $theme_ur_fnl_pos+1)).'" >
											if($theme_fullname != '' || $theme_fullname != null)
												echo $theme_fullname;
											else
												echo 'No Name';
											$theme_name = 'Author';
											$theme_n = array_filter($lines, function($var) use ($theme_name) { return preg_match("/\b$theme_name\b/i", $var); });
											//var_dump($theme_n);
											$theme_nam=  implode('', $theme_n);
											$positio = strpos($theme_nam, ':');

											$theme_uri = 'Author URI';
											$theme_ur = array_filter($lines, function($var) use ($theme_uri) { return preg_match("/\b$theme_uri\b/i", $var); });

											$theme_ur_fnl=  implode('', $theme_ur);
											$theme_ur_fnl_pos = strpos($theme_ur_fnl, ':');
											$final_url_author= trim(substr($theme_ur_fnl, $theme_ur_fnl_pos+1)); 
											//echo trim(substr($theme_nam, $positio+1));
									//echo '<a href="'.$final_url_author.'" ><h4>'.trim(substr($theme_nam, $positio+1)).'</h4> </a>
									echo '</h3><input type="hidden" name="template" value="'.$theme_folder.'"> ';
									
									//echo '<input style="float:right;" type="submit" name="change_theme" value="Activate" >';
								echo '</header>
								</article>	
							</form>								
							</div>'; 
						}
				    }				    
				} ?>								
			</div>
	</div>
	</div>
	 <div class="c-tab">  <!-- Menus -->
          <div class="neem_menu_tab c-tab__content">
          <div class="row" > 
          	 <div  class="12u 12u$(mobile)" > 
          	 	<div class="success" > Your Menu Has been Saved Successfully. </div>
          	 </div>
          <div  class="4u 12u$(mobile)" >          

			<div class="item">								
				<header><h4> <?php echo _("Pages"); ?></h4></header>
				<form>
					<ul class="pages_list_menu">
					<?php $pages_list = get_all_pages();
						if($pages_list){
							foreach ($pages_list as $value) {
								echo '<li> <label href="'.get_url().$value['slug'].'"> <input class="page_link" type="checkbox" data-id="'.$value['ID'].'" name="'.$value['pageTitle'].'"  value="'.get_url().$value['slug'].'" > '.$value['pageTitle'].'</label></li>'; 
							}
						} ?>
					</ul>	
					<header style="text-align: right;"><input type="button"  id="add_page_link" name="submit_page" value="<?php echo _("Submit"); ?>"></header>		
				</form>
			</div>

			<div class="item custom_link">								
				<header><h4> <?php echo _("Custom"); ?></h4></header>
				<form >
					<label style="padding-left: 8px; padding-right: 8px;"> <?php echo _("Label"); ?> : <input type="text" name="label" id="custom_label" > </label>
					<label style="padding-left: 8px; padding-right: 8px;"> URL : <input type="text" name="url" id="custom_link_url" value="<?php echo get_url(); ?>" > </label>
				
				<header style="text-align: right;"><input type="button"  name="submit
				-url" value="<?php echo _("Submit"); ?>" id="add_custom_link" ></header>	
				</form>								
			</div>

          </div>
          <div class="8u 12u$(mobile)" > 
          	<div class="menu_selector item" > 
          		<header>
          		<div class="12u 12u$(mobile)" >  <h4><?php echo _("Select or Create Menu"); ?></h4> </div>          			
          		</header>
          		<form> 
          			<div class="row" > 
          				
          				<div class="4u 12u$(mobile)" >  
          				<?php echo get_menus_dropdown(); ?>
          				</div>  
          				<div class="4u 12u$(mobile)" > 
          					<input type="text" name="new_menu_neem" id="new_menu_neem" value="" placeholder="Enter a Menu Name"></div>
          				<div class="4u 12u$(mobile)" > 
          					<input type="button" id="submit_selected_menu" name="submit_selected_menu" value="<?php echo _("Go"); ?>" >
          				</div>
          				</div>
          			</form>
          		<div class='menu_nester' >
		        <div class="dd" id="nestable">
		            <ol class="dd-list main_list_items"></ol>
		        </div>
		       
		        </div>
				 <header style="text-align: right;"> 
		        	<input type="button" name="delete_this_menu" id="delete_this_menu" value="<?php echo _("Delete"); ?>" >
		        	<input type="button" name="submit_added_menu_items" id="submit_added_menu_items" value="<?php echo _("Save");?>" >
		        </header>
		        </div>

		        <input type="hidden" id="nestable-output">

          </div></div>
          </div>
          </div>
	</div>
	</div>

	<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/tabbed.css" />
	<style>
	article.item.themes_neem{border:1px solid #c1c3d1;}
	article.item.curent_theme_neem{border:1px solid #2196F3;}
	article.item:hover {border:1px solid #2196F3;}
	.pages_list_menu{margin-bottom: 0px;}
	.item header{	background-color: #f7f7f7;}
	article img{opacity:1;}
	article img:hover{opacity: 1;}
	#main section.cover{padding-bottom: 80px;}
	.menu_selector .row > * {padding:5px 0 0 5px;}
	.menu_nester {border-left: 1px solid #e5e5e5;border-right: 1px solid #e5e5e5;border-bottom: 1px solid #e5e5e5;padding:5px;}
	.custom_link{border-left: 1px solid #e5e5e5;border-right: 1px solid #e5e5e5;}
	.neem_menu_tab form input[type="text"], .neem_menu_tab form select{	padding:10px;}
	.neem_menu_tab  input[type="submit"], .neem_menu_tab input[type="reset"], .neem_menu_tab input[type="button"],.neem_menu_tab .button{line-height: 25px;}
	.neem_menu_tab input, .neem_menu_tab textarea, .neem_menu_tab select{font-size:15px;}
	.neem_menu_tab label {font-size:16px; }
	.dd-item > button#remove{ float:right; }
	.dd-item > button#remove:before{content: 'x';}
	.themeGallery { position:relative; float:left;  }
	.themeGallery a.image span { display:none;
   /* background-image: url('http://www.jankoatwarpspeed.com/wp-content/uploads/examples/zoom_icon/zoom.png');
    background-repeat: no-repeat;*/
    width: 100%;
    height: 100%;
    position: absolute;
    background: rgba(239, 241, 240, 0.53);
 	}
 	.themeGallery a.image span input[type="submit"]{    left: 35%;  top: 40%;}
        .themeGallery a.image:hover span { display:block; }
        .themeGallery a.image:hover img { opacity: 1;}
	</style>
	<script src="<?php echo get_url("admin");?>assets/js/tabs.js"></script>
	<script src="<?php echo get_url("admin");?>assets/js/jquery.nestable.js"></script>
	<script>
	  ajax_url = '<?php echo get_url('includes'); ?>kv-ajax.php'; 
	  var myTabs = tabs({
	    el: '#tabs',
	    tabNavigationLinks: '.c-tabs-nav__link',
	    tabContentContainers: '.c-tab'
	  });

	  total_menus = new Array();
	  menu_change = 0; 
	  myTabs.init();
	$(document).ready(function(){
	   	 Menu_Items = new Array();	
	   	 $('.success').hide();
	   	 
	     //	 Menu_array =new Array();
	   	 // Final_array .push(GetMenuItems($(this)));	
	   $('li[data-id]').each(function() {
		    Menu_Items.push($(this).attr('data-id'));
		});
	   if (Menu_Items.length === 0) {
	   		page_name = 0;
	   }else{
	   		page_name =  Math.max.apply(Math,Menu_Items); 
	   }
	   
		$("#add_page_link").on("click", function(e){
			e.preventDefault();		
			$('.page_link:checkbox:checked').each(function () {	
				page_name++;			
			   sThisVal = (this.checked ? $(this).val() : "");
			   sThisName = (this.checked ? $(this).attr('name') : "");
			   sThisId = (this.checked ? $(this).data('id') : "");
			   $("ol.main_list_items").append(' <li class="dd-item" db_id="0" data-id="'+page_name+'"><button data-action="close" type="button" id="remove">x</button>  <div class="dd-handle" data-url="'+sThisVal+'">'+sThisName+'</div></li>');			   
			   updateOutput($('#nestable').data('output', $('#nestable-output')));
			   menu_change++;
			});			
		});
		$("#nestable").on("click", '#remove', function(e){
			//alert('srserser');
			$(this).parent().remove();
			menu_change++;
		})
		$('#add_custom_link').on("click", function(e){
			page_name++;
			e.preventDefault();				
			 sThisLabel = $("#custom_label").val();
			 sThisUrl = $("#custom_link_url").val();
			  $("ol.main_list_items").append('<li class="dd-item" db_id="0" data-id="'+page_name+'"><button data-action="close" type="button" id="remove">x</button> <div class="dd-handle" data-url="'+sThisUrl+'">'+sThisLabel+'</div></li>');			  
			updateOutput($('#nestable').data('output', $('#nestable-output')));
			menu_change++;
		});
		
		$("#submit_selected_menu").on("click", function(e){
			e.preventDefault();
			var New_menu_text = $("#new_menu_neem").val().trim();
			if($("#neem_menus option[value='"+New_menu_text+"']").length > 0){ 
				alert("Menu Name Already Exist"); 
			} else {
				if(New_menu_text == undefined || New_menu_text == ''|| New_menu_text == null){ } else{ 
					$("#neem_menus").append("<option selected value='"+New_menu_text+"' > "+New_menu_text+" </option>");
					$("#new_menu_neem").val('');
					$("#neem_menus").trigger('change');
				}
			}			
		});
		function KvGetMenu(res){
			//alert(JSON.stringify(res));
			var list_builder = '';
			$.each(res, function (index, value) {	
				exit_page_name++; //console.log(value['ID']);
				list_builder += '<li class="dd-item" db_id="'+value['ID']+'" data-id="'+exit_page_name+'">';
				if (typeof value['sub_items'] !== 'undefined' && value['sub_items'] !== null) {
					list_builder += '<button data-action="collapse" type="button">Collapse</button><button data-action="expand" type="button" style="display: none;">Expand</button>';
				}
				
				list_builder += '<button data-action="close" type="button" id="remove">x</button> <!--<button class="icon fa-angle-down ShowExtraClass" style=" padding: 5px; font-size: 14px;"> </button> --> <div class="dd-handle" data-url="'+value['pageContent']+'">'+value['pageTitle']+'   <div class="dd-extra" style=" display: none;"></div></div>';	
				if (typeof value['sub_items'] !== 'undefined' && value['sub_items'] !== null) {
					list_builder += '<ol class="dd-list">' ;
					list_builder += KvGetMenu(value['sub_items']);
					list_builder += '</ol>';
				}
				list_builder += '</li>';			  
				updateOutput($('#nestable').data('output', $('#nestable-output')));
			});
			return list_builder;
		}
		$("#neem_menus").on("click", ".ShowExtraClass", function(e){
			alert("srgserhgser");
			$(this).next().show();
		});
		$("#neem_menus").on("change", function(){
			var selected_menuu = $('#neem_menus').val();
				request = $.ajax({
			        url: ajax_url+'?action=menu_change',
			        type: "get",
			        data: { menu_name : selected_menuu} 
			    });
				exit_page_name = page_name; 
			    request.done(function (response, textStatus, jqXHR){		        
			        //alert(response);
			        res = $.parseJSON(response);
					var two_fields = res ; 
					if(menu_change == 0){
						$('ol.main_list_items').empty();
						// here calling function 
						var final_menu = KvGetMenu(res);
						$("ol.main_list_items").append(final_menu);
					}
					else{
						if(confirm("Are you sure you want to change this. You have some unsaved changes?")){
					        $('ol.main_list_items').empty();
					        //page_name = exit_page_name;
							$.each(res, function (index, value) {	
								exit_page_name++;
								//console.log(value['ID']);
								 $("ol.main_list_items").append('<li class="dd-item" db_id="'+value['ID']+'" data-id="'+exit_page_name+'"><button data-action="close" type="button" id="remove">x</button> <div class="dd-handle" data-url="'+value['pageContent']+'">'+value['pageTitle']+'</div></li>');			  
								updateOutput($('#nestable').data('output', $('#nestable-output')));
							});
					    }
					    else{
					        return false;
					    }
						
					}
					
			    });

			    request.fail(function (jqXHR, textStatus, errorThrown){
			        console.error("The following error occurred: "+textStatus, errorThrown);
			    });
		});

		var length = $('#neem_menus > option').length;

	   	 if(length>1){
	   	 	// $("#neem_menus").prop("selectedIndex", 3).change();
	   	 	 $('#neem_menus option:eq(1)').prop('selected', true).change();
	   	 	//$("#neem_menus").val($("#neem_menus option:eq(1)").val()).change();
	   	 //	$("#neem_menus").trigger('change');
	   	 }
	   	 
        var updateOutput = function(e){
            var list   = e.length ? e : $(e.target),
                output = list.data('output');
            if (window.JSON) {
                output.val(window.JSON.stringify(list.nestable('serialize')));
            } else {
                output.val('JSON browser support required for this demo.');
            } 
        };
        $('#nestable').nestable({ group: 1 });         
        $('#nestable').on('change', updateOutput);
        updateOutput($('#nestable').data('output', $('#nestable-output')));

        $("#submit_added_menu_items").on("click", function(e){
			e.preventDefault();	
			selected_menu = $("#neem_menus option:selected").val();	
			if(selected_menu == -1){
				alert("You have not Created Any menu name");
				$("#new_menu_neem").focus();
			}else{
				total_menus = Array();
				$(".main_list_items > li").each(function(e){
					GetItemsList($(this), 0, selected_menu);					
				});
				//alert(selected_menu);
				menu_change = 0;
				request = $.ajax({
			        url: ajax_url+'?action=menu_save',
			        type: "get",
			        data: { menuss : JSON.stringify(total_menus), menu_nam : selected_menu} 
			    });

			    request.done(function (response, textStatus, jqXHR){
			        console.log("Hooray, it worked!");
			        $(".success").show();
			        console.log(response);
			    });

			    request.fail(function (jqXHR, textStatus, errorThrown){
			        console.error("The following error occurred: "+textStatus, errorThrown);
			    });
			}	
		});
    });


function GetItemsList(obj, parent, menu_name){

	var db_id = obj.attr('db_id');
	var data_id = obj.data('id');
	var data_url = obj.children("div.dd-handle").data('url');
	var data_text = obj.children("div.dd-handle").text();
	//alert(data_url);
	var first_array = [{data_id: data_id, menu: menu_name, db_id: db_id, data_url: data_url, data_text: data_text, parent_id : parent }]; 
	total_menus.push(first_array);
	if(obj.children("ol").length){
		obj.children("ol").children().each(function(e){
			GetItemsList($(this), data_id, menu_name);
		});		
	}
}
	function GetMenuItems(elemnt){
		menuArray = new Array();
		Final_arr = new Array();
		var elementHtml = elemnt.children('.dd-handle').html();
		var elementUrl = elemnt.children('.dd-handle').attr('data-url'); 
		//alert(elementUrl);
		if(elemnt.children('ol.dd-list').length){
			Final_arr = new Array();			
			elemnt.children('ol.dd-list li').each(function(){	
				alert(JSON.stringify(Final_arr));			
				Final_arr.push(GetMenuItems($(this)));
			});
			//console.log(Final_arr);
		}
		if (Final_arr.length === 0) {
			SingleRow = [elementHtml, elementUrl];
		}else{
			SingleRow = [elementHtml, elementUrl, Final_arr];
		}
		menuArray.push( SingleRow);
		return menuArray;
	}
	</script>
	<?php    

//get_main_body();
get_admin_footer();
?>