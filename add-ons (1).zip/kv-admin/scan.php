<?php

require_once('../config.php' );
require('../includes/db-functions.php');

$dir = '../'.NEEM_UPLOADS;


function get_All_attachments($id = null){
	if($id != null)
		return GetAll('pages', array('ID' => $id, 'page_type' => 'media'), array('ID' => 'DESC'));
	else
		return GetAll('pages', array('page_type' => 'media'), array('ID' => 'DESC'));
}

function scan($dir){
	$files = array();

	$attachments = get_All_attachments();

	foreach($attachments as $f) {
		
		if(file_exists($dir.'/'.$f['slug'])){

				// It is a file
			$files[] = array(
					"name" => $f['pageTitle'],
					"type" => "file",
					"path" => $dir . '/' . $f['slug'],
					"size" => filesize($dir.'/'.$f['slug']), // Gets the size of this file
					"id"   => $f['ID']
			);	
					
		}	
	}
	return $files;
}

$response = scan($dir);

// Output the directory listing as JSON
//print_r($response);

header('Content-type: application/json');

echo json_encode(array(
	"name" => "files",
	"type" => "folder",
	"path" => $dir,
	"items" => $response
)); ?>
