<?php 

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

global $db_connections, $current_user;


$edit_arr['ID'] = $edit_arr['module'] = $edit_arr['description'] = ''; 

if(isset($_GET['add-new'])){
	$title = _("Add New Permission");
	$button_text = _("Add New Permission");
}elseif(isset($_GET['edit_id'])){ 
	$title = _("Edit Permission");

	$edit_arr = GetRow("permission", array("ID" => $_GET['edit_id']));
	// print_r($edit_arr);
	$button_text = _("Update Permission");
}

$kv_errors= array();
if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['module_submit'])){
	$module_arr = array('pageName' => $_POST['pageName']);
	if(!empty($_POST['module_id'])){
			Update('modulepage', array("id" => $_POST["module_id"]), $module_arr  );
			kv_direct('permissions.php?status=Updated');
		}else{			
			$userId = Insert('modulepage', $module_arr );
			if($userId){				
				kv_direct('permissions.php?status=Added');
			}			
		}
}
if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['user_submit'])) {
	$fields = array('page_permit', 'module_name','module_no', 'description');

	foreach ($fields as $field) {
		if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
	}
	if ($posted['page_permit'] == null)
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter the Permission.', 'neem'));
	
	if ($posted['module_no'] == null)
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter the Module Name.', 'neem'));
		
	$errors = array_filter($kv_errors);

	if (empty($errors)) { 
		$users_Arr = array("page_permit" => $posted["page_permit"],	"module" => $posted["module_name"],"module_no" =>$posted["module_no"],"description" => $posted["description"]);

		if(!empty($_POST['id'])){
			Update('permission', array("ID" => $_POST["id"]), $users_Arr);
			kv_direct('permissions.php?status=Updated');
		}else{	
			$userId = Insert('permission', $users_Arr );
			if($userId){				
				kv_direct('permissions.php?status=Added');
			}			
		}
	}
}?>
<section id="top" class="one dark cover">
	<div class="container">
		<header><h3 class="alt"><span class="icon fa-ban"> </span> <?php echo $title; ?> </h3></header>
		<?php if(!empty($errors)) {
				echo '<div class="error">';
				foreach ($kv_errors as $error) {
					echo '<p>'.$error.'</p>';
				}
				echo '</div>';
			} ?>
		<div class="row">
			
			<div class="5u 12u$(mobile)" >
			  <form method="post" action="">
				<div class="row">				
					<div class="4u 12u$(mobile)" > <?php echo _("Permission"); ?>  </div>
					<div class="8u 12u$(mobile)" > <input type="text" name="page_permit" placeholder="" value="<?php echo $edit_arr['page_permit']; ?>" />
					</div>

					<div class="4u 12u$(mobile)" > <?php echo _("Module"); ?>  </div>
					<div class="8u 12u$(mobile)">
						<?php
						 $page_name = array();
						 $checked = '';
						$array_list = GetDataFilter('modulepage', array('id', 'pageName'));
						foreach ($array_list as $value) {	
										
							$page_name[$value['id']] = $value['pageName'];
						}
						echo select_options_list('module_no', $page_name, $edit_arr['module_no'], 'no', null, null, 'module_List'); ?>
 						<input type="hidden" name="module_name" id="module_name" value="<?php echo $edit_arr['module'] ?>">
					</div>
					<div class="4u 12u$(mobile)"><?php echo _('Description'); ?> </div>
					<div class="8u 12u$(mobile)"><input type="text" name="description" value="<?php echo $edit_arr['description']; ?>">
					</div>
				<div class="12u$">
					<input type="hidden" name="user_submit" value="yes">
					<input type="hidden" name="id" value="<?php echo $edit_arr['ID']; ?>" >
					<input type="submit" name="submit" value="<?php echo _('Submit') ?>">
				</div>
			</div>
			</form>
		</div>
		<div class="5u 12u$(mobile)" >
			  <form method="post" action="">
				<div class="row">				
					<div class="4u 12u$(mobile)" > <?php echo _("New Page Module Name"); ?>  </div>
					<div class="8u 12u$(mobile)" > <input type="text" name="pageName" placeholder="<?php echo _('Enter new page name') ?>" value="" />
					</div>
				<div class="12u$">
					<!-- <input type="hidden" name="module_submit" value="yes"> -->
					<input type="hidden" name="module_id" value="" >
					<input type="submit" name="module_submit" value="<?php echo _('Submit'); ?>">
				</div>
			</div>
			</form>
		</div>
		
		
	</div>
</section>
</div>
<style>
.page_header { display: none; }
</style>
<script type="text/javascript">
$(document).ready(function(){
	$('#module_List').on('change', function(e){
		var id = $(this).val();
		$.ajax({
			url: '<?php echo get_url(); ?>includes/kv-ajax.php?moduleNO='+id,
             type: 'post',
             dataType: 'json',
             success:function(response){
             	console.log(response);
             	$('#module_name').val(response.name);
             }
		})

	})
})
</script>
