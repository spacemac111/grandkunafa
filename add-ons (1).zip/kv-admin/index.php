<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 
require_once(FA_PATH.'config_db.php');global $db_connections;
if(isset($_GET['action']) && $_GET['action'] == 'login' || $_GET['action'] == 'forgot_password' || $_GET['action'] == 'register' || isset($_GET['reset_password']) ){
	require('login.php'); 

}else {
	//make sure user is logged in, function will redirect use if not logged in

	login_required();

	//if logout has been clicked run the logout function which will destroy any active sessions and redirect to the login page
	if(isset($_GET['logout'])){
		logout();
	}

	//run if a page deletion has been requested
	if(is_admin() || is_auditor()){

	get_admin_header('Dashboard', 'th-large');  ?>
	<section id="dashboard" class="two">
						<div class="container">

						<div class="row">
							<div class="12u 12u$(mobile) " >
							<div class="welcome_container item" > 
							<h3> <?php echo _("Welcome to s POS"); ?> </h3>
							<p> A Warm Welcome to POS POS Dashboard. It's lite weight POS for ERP.</p>
							</div>
							</div>
								<div class="6u 12u$(mobile)">
									<article class="item">								
										<header>
											<h3><span class="icon fa-clone"></span> <?php echo _("General"); ?></h3>
										</header>
										<ul>
											<li> <a href="<?php echo get_url('admin'); ?>pages.php" > Total <?php echo count($db_connections); ?> FA Companies </a> </li>
											<li> <a href="<?php echo get_url('admin'); ?>pages.php" ><a href="#" >Published <?php echo neem_count('pages', array('status','Published', 'page_type', 'page')); ?> Pages</a> </li>
											<li> <a href="<?php echo get_url('admin'); ?>pages.php" >Pending <?php echo neem_count('pages', array('status','Draft',  'page_type', 'page')); ?> Pages</a> </li>											
										</ul>										
									</article>
									
								</div>
								<div class="6u 12u$(mobile) dashboard-users">
									<article class="item">								
										<header>
											<h3><span class="icon fa-users"></span> <?php echo _("Users"); ?></h3>
										</header>
										<ul class="row">
											<li > <a href="<?php echo get_url('admin'); ?>users.php" > Total <?php echo neem_count('users'); ?> Users </a> </li>
											<li> <a href="<?php echo get_url('admin'); ?>users.php" ><a href="<?php echo get_url('admin'); ?>/users.php" > Administrator <?php echo neem_count('users', array('role','Administrator')); ?> Users</a> </li>
											<li> <a href="<?php echo get_url('admin'); ?>users.php" >Active <?php echo neem_count('users',  array('status','Active')); ?> Users</a> </li>
											<li > <a href="<?php echo get_url('admin'); ?>users.php" >Salesman <?php echo neem_count('users',  array('role','Salesman')); ?> Users</a> </li>
											<li > <a href="<?php echo get_url('admin'); ?>users.php" >Inactive <?php echo neem_count('users',  array('status','Inactive')); ?> Users</a> </li>											
										</ul>
									</article>									
								</div>								
							</div>
						<!--</div> -->
					</section>
				</div>
			<style>
			.welcome_container{	padding:25px;	}
			.dashboard-users .row > * {padding: 0 0 0 15px;	}
			.dashboard-users li {width: 50%;}
			h3 span.icon { font-size:20px; }
			</style><?php 
	} else{
		get_admin_header('404 - Page not Found ', 'th-large');
		kv_die(" Sorry, the page you are looking is not Found");
	}
	get_admin_footer();
}
?>