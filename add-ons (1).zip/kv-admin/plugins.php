<?php
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
login_required();

if(isset($_GET['add-new'])){	
	require_once('add-on-new.php');
	exit;
}

get_admin_header('Plugins', 'plug', 'plugins.php?add-new=yes', "no"); 
$activePlugins = get_site_option('active_plugins');
//	print_r($activedPlugins);
?>

<div class="row">
	<div class="12u 12u$(mobile)">
	<p style="padding-bottom: 2%;">You can install additional Plugins to enhance the features. Glad to provide you few more Plugins.</p>
	<table class="plugins_list" > 
	<thead> 
	<th  style="width: 25%"> <?php echo _("Plugins"); ?>  </th>
	<th style="max-width: 55%"> <?php echo _("Description"); ?> </th>
	</thead>
	<tbody> 
	<?php 

	if(isset($_GET['activate']) && trim($_GET['activate']) != null){
		$activate = trim($_GET['activate']);
		$activedPlugins = get_site_option('active_plugins');
		if(empty($activedPlugins)){
			$activedPlugins = array();
		}
		if(!in_array($activate, $activedPlugins)){
			$activedPlugins[] = $activate;
			$activatedPlgns = serialize($activedPlugins);
			$current_option_id = get_site_option_id('active_plugins');
			if($current_option_id)
				Update('settings', array( "ID" => $current_option_id), array( "option_value" => array($activatedPlgns, 'noesc') ));	
			else
				 Insert('settings', array( "option_name" => "active_plugins", "option_value" => array($activatedPlgns, 'noesc') ));
			header("Refresh:0");
		}

		//header('Location: '.$_SERVER['REQUEST_URI']);
			//echo '<script type="text/javascript">location.reload(true);</script>';
	}
	if(isset($_GET['deactivate']) && trim($_GET['deactivate']) != null){
		$deactivate = trim($_GET['deactivate']);
		$activeddPlugins = get_site_option('active_plugins');
		if(empty($activeddPlugins)){
			$activeddPlugins = array();
		}
		$key = array_search($deactivate, $activeddPlugins);
		//echo $key; 
		if ($key !== false) {
			
		    unset($activeddPlugins[$key]);
		    $activatedPlgns = serialize($activeddPlugins);
			$current_option_id = get_site_option_id('active_plugins');
			Update('settings', array( "ID" => $current_option_id), array( "option_value" => array($activatedPlgns, 'noesc') ));	
			header("Refresh:0");
		}		
	}
	if(isset($_GET['Delete'])&& trim($_GET['Delete']) != null){
		$Delete = trim($_GET['Delete']);
		$activedPlugins = get_site_option('active_plugins');
		if(empty($activedPlugins)){
			$activedPlugins = array();
		}
		if ($key = array_search($Delete, $activedPlugins) !== false) {
		    unset($activedPlugins[$key]);
		    $activatedPlgns = serialize($activedPlugins);
			$current_option_id = get_site_option_id('active_plugins');
			Update('settings', array( "ID" => $current_option_id), array( "option_value" => array($activatedPlgns, 'noesc') ));	
		}
		if (strpos($Delete, '/') !== false) {
				$poss = strpos($Delete, '/');
				$folder_name = substr($Delete, 0, $poss);
				//echo get_plugin_abs_path().$folder_name.'/*';
				array_map('unlink', glob(get_plugin_abs_path().$folder_name.'/*'));
				rmdir(get_plugin_abs_path().$folder_name);
			}else{
				array_map('unlink', glob(get_plugin_abs_path().$Delete));
			}
		//array_map('unlink', glob(get_plugin_abs_path()));
			kv_direct(get_url('admin').'plugins.php?Deleted='.$Delete);
			//header("Refresh:0");
	}

	$path    = '../add-ons';
	$FilesAndFolders = array_diff(scandir($path), array('.', '..'));
	$plugins_array = array();
	$activePlugins = get_site_option('active_plugins');
	foreach ($FilesAndFolders as $single) {		
        if (is_dir($path .'/'. $single)) { 
            $subFilesAndFolders  = array_diff(scandir($path. '/' . $single), array('.', '..'));
            foreach ($subFilesAndFolders as $subSingle) {		
		         if (is_dir($path .'/'.$single.'/'. $subSingle)) { }  else { 
		         	$extensin = pathinfo($path .'/'.$single.'/'. $subSingle);
			        if($extensin['extension'] == 'php')
		            	$plugins_array[] = $path .'/'.$single.'/'. $subSingle; 
		         } 
		    }
        }  else { 
         	$extensn = pathinfo($path .'/'.$single);
		    if($extensn['extension'] == 'php')
            	$plugins_array[] = $path .'/'.$single; 
        }     
    }

    foreach ($plugins_array as $plugin) {	
    	$plugin_file = basename($plugin);    
    	if(basename(dirname($plugin)) != 'add-ons'){
    		$plugin_folder = basename(dirname($plugin)).'/';
    	}else
    		$plugin_folder = '';
     	
         $lines = file($plugin); //file in to an array

		$addon_name = 'Addon Name';
		$addon_n = array_filter($lines, function($var) use ($addon_name) { return preg_match("/\b$addon_name\b/i", $var); });
		$addon_nam=  implode('', $addon_n);
		$positio = strpos($addon_nam, ':');
		$plugin_fullname =trim(substr($addon_nam, $positio+1));

		$addon_uri = 'Addon URI';
		$addon_ur = array_filter($lines, function($var) use ($addon_uri) { return preg_match("/\b$addon_uri\b/i", $var); });
		$addon_ur_fnl=  implode('', $addon_ur);
		$addon_ur_fnl_pos = strpos($addon_ur_fnl, ':');
		$plugin_url = trim(substr($addon_ur_fnl, $addon_ur_fnl_pos+1));

		$addon_version = 'Version';
		$addon_vern = array_filter($lines, function($var) use ($addon_version) { return preg_match("/\b$addon_version\b/i", $var); });
		$addon_vern_val=  implode('', $addon_vern);
		$addon_vern_val_pos = strpos($addon_vern_val, ':');
		$plugin_version = trim(substr($addon_vern_val, $addon_vern_val_pos+1));

		$addon_description = 'Description';
		$addon_desc = array_filter($lines, function($var) use ($addon_description){ return preg_match("/\b$addon_description\b/i", $var);});
		$addon_desc_val=  implode('', $addon_desc);
		$addon_desc_val_pos = strpos($addon_desc_val, ':');
		$plugin_description = trim(substr($addon_desc_val, $addon_desc_val_pos+1));

		$addon_author = 'Author';
		$addon_athr = array_filter($lines, function($var) use ($addon_author) { return preg_match("/\b$addon_author\b/i", $var); });
		$addon_athr_val=  implode('', $addon_athr);
		$addon_athr_val_pos = strpos($addon_athr_val, ':');
		$plugin_author = trim(substr($addon_athr_val, $addon_athr_val_pos+1));

		if($plugin_fullname != null && $plugin_description != null){
			if(empty($activePlugins)){
				$activePlugins = array();
			}
			$plugin_check = $plugin_folder.$plugin_file; 
			
			if(in_array($plugin_check, $activePlugins)){
				echo '<tr> <td> <h4 style="font-weight:700;">'.$plugin_fullname. '</h4> <p>';
			}else{
				echo '<tr> <td> <h4>'.$plugin_fullname. '</h4> <p>';
			}
			
			//var_dump($activePlugins);
			
			if(in_array($plugin_check, $activePlugins)){
				echo '<a href="'.get_url('admin').'plugins.php?deactivate='.$plugin_folder.$plugin_file.'" > '._("Deactivate").' </a> ';
				//if()
				//	echo ' | <a href="#" > Settings </a> '; 
			}else {
				echo '<a href="'.get_url('admin').'plugins.php?activate='.$plugin_folder.$plugin_file.'" > '._("Activate").' </a>';
			}	


			echo '| <a href="'.get_url('admin').'plugins.php?Delete='.$plugin_folder.$plugin_file.'" class="delete_addon" > '._("Delete").' </a> </p>	</td> <td> <p>'. $plugin_description .'</p> <p style="font-size:12px;"> Version  '. $plugin_version;
			if($plugin_author != null ){
				echo ' | '.$plugin_author;
			}
			echo '</p></td> </tr>';				
		}
    }  

	//print_r($result);
	?>		
	</tbody>
	</table>						
</div>
</div>
</div>
<style> 
th { color: rgba(0,0,0,0.75); }
p a { font-size: 15px; }
h4 { line-height: 1.5em; }
a { cursor: pointer; }
</style>
<script type="text/javascript">
	$('.delete_addon').click(function(){
	var checkstr =  confirm('are you sure you want to delete this?');
	if(checkstr == true){
	  // do your code
	}else{
	return false;
	}
	});

</script>
<?php 
get_admin_footer(); ?>