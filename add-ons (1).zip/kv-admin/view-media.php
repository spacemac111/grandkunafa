<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/font-awesome.min.css" />
	<script src="<?php echo get_url("admin");?>assets/js/jquery.min.js"></script>

	<script src="<?php echo get_url("admin");?>assets/js/jquery.magnific-popup.min.js"></script>
	<script> site_url = '<?php echo get_url(); ?>'; </script>
	<div class="view_attachment" >
	<div class="view_header" > <h3>  <span class="fa fa-clone"></span> View Media </h3>
		<span class="pull-right" >

		<ul> <li> <a href="#" id="view_previous"> <span class="fa fa-chevron-left"></span></a> </li>
		<li><a href="#" id="view_next" > <span class="fa fa-chevron-right "></span></a> </li>
		<li> <a href="#" id="view_popup_close"><span class="fa fa-close"></span></a> </li> 
		</ul> </span> <div style="clear:both" > </div></div>

		<div class="content_image" > 
			<div class="success"> Selected Media Deleted Successfully ! </div>
			<div class="errors"> Selected Media Not Deleted! </div>
			<div class="media_image">
				<img src="<?php echo get_attachment_url($_GET['view_id']); ?>" >
			</div>
			<div class="media_details" >			
			<?php $filename =  get_attachment_name($_GET['view_id']); 
				$attachment_base_url = ABSPATH.NEEM_UPLOADS."/".get_attachment_string($_GET['view_id']); 
				$image_Detail = getimagesize($attachment_base_url) ; ?>
				<div class="filename"><strong>File name:</strong>  <?php echo $filename; ?></div>
				<div class="filename"><strong>File type:</strong> <?php echo $image_Detail ['mime']; ?></div>
				<div class="uploaded"><strong>Uploaded on:</strong> <?php echo get_attachment_date($_GET['view_id']); ?> </div>
				<div class="file-size"><strong>File size:</strong> <?php echo formatSizeUnits(filesize($attachment_base_url)); ?> </div>
				<div class="dimensions"><strong>Dimensions:</strong> <?php echo $image_Detail[0].' X '.$image_Detail[1]; ?></div>
				<div class="filename">
				<a href="<?php echo get_url('ajax').'?action=delete_page'; ?>" class="delete_this_image" media_id="<?php echo $_GET['view_id']; ?>"> Delete Permanently</a>
				</div>
			</div>
			<div style="clear:both;"></div>
		</div>

  	</div>
	</div> 
	<style>
	body { margin:0; }
	a{ text-decoration: none; cursor: pointer;}
	ul { list-style: none; width: 102px; float: right; margin: 0;}
	li { display: inline;}
	li a { padding: 10px; }
	.success { 	background-color: #BBF6E2;border: 1px solid #6ADE95;margin:20px auto; padding:10px;border-radius:5px;}
	.mfp-close { display: none; }
	a.button {  display: none; }
	.view_attachment{ max-width:100%; text-align:center; margin: 0 ;padding: 0; } 
	.view_attachment img { border:1px solid #c5c5c5; border-radius:4px; margin:2% auto; max-width: 80%; max-height: 90%; }
	.view_attachment img:hover { border:1px solid #e5e5e5; } 
	#view_popup_close, li a{ float:left; border: 1px solid #eee; box-shadow:0 1px 3px rgba(0, 0, 0, 0.05); background: #fcfcfc; -webkit-font-smoothing: subpixel-antialiased; }
	.view_header { -webkit-box-shadow: 0 5px 15px rgba(0,0,0,.7);  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.16); background: #fcfcfc; -webkit-font-smoothing: subpixel-antialiased; border: 1px solid #eee;}
	.view_header h3 { color: #353535; padding: 8px; float:left; width: 60%; margin: 0; text-align: left;} 
	.media_image{ width: 68%; float: left; border-right: 1px solid #afadac; height: 80%;}
	.media_details{ width: 28%; float: left; text-align:left; padding-top: 2%; padding-left: 2%;  line-height: 24px;}
	
	</style> 
	<script> 
		$(document).ready(function () {
			var ajax_url = "<?php echo get_url('ajax'); ?>";
			$('.success').hide();
			$('.errors').hide();
			$(".delete_this_image").on('click', function(e){	
				e.preventDefault();
			    var media_id = $(this).attr('media_id'); 
			    var delete_url = $(this).attr('href'); 
			    var elem = $(this);
			    $.ajax({
			    	url: delete_url,
			    	data: {'media_id' : media_id},
			    	type: "post", 
			    	success: function(daata){
			    		//alert(daata);
			    		dataf = daata.trim();
			    		if(dataf == 'success'){
			    			//$(".success").show().delay(5000).fadeOut();
			    			$(".success").show().delay(2000).queue(function(n) {
			    				$(".success").hide('slow');
			    				parent.kv_filemanager();
							 	//parent.$.magnificPopup.close();	
							 	//$(".mfp-iframe").src="http://localhost/cms/kv-admin/medias.php?view_id=79";
							 	//var urls = document.getElementsByClassName("mfp-iframe").contentWindow.location.href;
							 	//var urls = $(".mfp-iframe").attr('src');   
							 //	alert(urls);
							 	location.href = "http://localhost/cms/kv-admin/medias.php?view_id=94";
        						//return false;						 
							});
			    		}else{
			    			$(".errors").show().delay(2000);
			    			$(".errors").hide('slow');
			    		}	
			    	}
			    });
			});
			$("#view_next").on("click", function(){
				var this_media_id = $(".delete_this_image").attr('media_id');
				$.ajax({
			    	url: ajax_url+'?action=next_media',
			    	data: {'media_id' : this_media_id},
			    	type: "post", 
			    	success: function(daata){
			    		//alert(daata+'----'+this_media_id);
			    		dataf = daata.trim();
			    		if(dataf != 'failure')
			    			location.href = dataf;			    		
			    	}
			    });
				//alert("sgaww");			
			});

			$("#view_previous").on("click", function(){
				var this_media_id = $(".delete_this_image").attr('media_id');
				$.ajax({
			    	url: ajax_url+'?action=prev_media',
			    	data: {'media_id' : this_media_id},
			    	type: "post", 
			    	success: function(daata){
			    		//alert(daata+'----'+this_media_id);
			    		dataf = daata.trim();
			    		if(dataf != 'failure')
			    			location.href = dataf;			    		
			    	}
			    });		
			});

			$("#view_popup_close").on("click", function(){
				parent.kv_filemanager();
				parent.$.magnificPopup.close();				
			});

			parent.$.magnificPopup.instance.close = function () {
			    parent.kv_filemanager();
			    parent.$.magnificPopup.proto.close.call(this);
			};

		});
	</script>