<?php
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

//make sure user is logged in, function will redirect use if not logged in

get_admin_header('New Add-on', 'plus', '', "no"); ?>

<div class="row">

zsrdfghjrf

</div>
</div> 

<?php 
get_admin_footer(); ?>