<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/ 
require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
login_required();

get_admin_header('Permissions', 'permission', 'permissions.php?add-new=yes', "no");

if(isset($_GET['add-new']) || isset($_GET['edit_id'])){
	require_once("add-edit-permission.php");
}
elseif(isset($_GET['delete_id'])){
	$deleted = Delete("permission",array('ID'=> $_GET['delete_id']));
	kv_direct(get_url("admin").'add-edit-permission.php?status=deleted');
} else {

	if(isset($_GET['status'])) {
		if($_GET['status'] == 'Added')
			echo '<div class="success"> '._("A New Permission Added Successfully"). '</div>'; 
		elseif($_GET['status'] == 'Updated') 
			echo '<div class="success"> '._("Selected Permission Updated Successfully").'</div>'; 
	}
?>
	<table id="neem_pagination_Table">
			<thead> 
			<tr>
				<th width="5%"><strong><?php echo _("ID"); ?> </strong></th>
				<th width="35%"><strong><?php echo _("Option"); ?> </strong></th>				
				<th width="30%"><strong><?php echo _("Module"); ?> </strong></th>
				<th width="30%"><strong><?php echo _('Description');  ?></strong></th>
			</tr>
		</thead><tbody>		</tbody>
	</table>
	</div>
</section>

<script>
<?php 
if(isset($_GET['role'])){
	echo "ajax_url = 'permissions=yes&role=".$_GET['role']."';";
} else
	echo "ajax_url = 'permissions=yes';"; ?>
 type='permissions';
</script>
<style> 
#Roles {  display: inline-block;  float: left;}
#Roles ul li {    display: inline;    padding-left: 10px;}
#Roles ul {	margin: 1em 0 ;}
#Roles a { font-size: 16px; }
</style>
<?php 
}
//get_main_body();
get_admin_footer();
?>