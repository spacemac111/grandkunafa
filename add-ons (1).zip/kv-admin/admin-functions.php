<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('../includes/functions.php'); 

function get_admin_header($page_title, $icon=null, $add_url=null, $permission=null, $media=null){	
	$favicon = get_site_option('favicon'); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html class="">
<head>
<title><?php echo _($page_title). ' | '. get_site_title(); ?> </title>
		<meta charset="<?php echo get_encoding(); ?>" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
		 <META NAME="ROBOTS" CONTENT="NOINDEX, FOLLOW">
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		
		<link href="<?php echo get_url("admin");?>assets/css/dataTables.bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo get_url("admin");?>assets/css/responsive.bootstrap.min.css" rel="stylesheet">

		<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/datatables.min.css" />
		
		<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/magnific-popup.css" />

		<?php if($favicon && file_exists(ABSPATH.'themes/pos/images/'.$favicon)) { ?>			<link rel="shortcut icon" type="image/png" href="<?php echo get_url();?>themes/pos/images/<?php echo $favicon; ?>"/>		<?php } else { ?>			<link rel="shortcut icon" type="image/png" href="<?php echo get_url("admin");?>assets/css/images/icon.png"/>		<?php } ?>

		<link href="<?php echo get_url("admin");?>assets/css/square/blue.css" rel="stylesheet">

		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->

		<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/main.css" />
		<link href="https://fonts.googleapis.com/css?family=Lato|Open+Sans|PT+Sans|Roboto|Roboto+Slab|Titillium+Web" rel="stylesheet">


		<script src="<?php echo get_url("admin");?>assets/js/jquery.min.js"></script>
		<script src="<?php echo get_url("admin");?>assets/js/icheck.js"></script>

		<script src="<?php echo get_url("admin");?>assets/js/jquery.magnific-popup.min.js"></script>

		<script>
		$(document).ready(function(){
		  $('input').iCheck({
		    checkboxClass: 'icheckbox_square-blue',
		    radioClass: 'iradio_square',
		    increaseArea: '20%' // optional
		  });
		});
		</script>
		</head>
<body>

<div class="wrapper">
	<div class="sidebar" id="sidebar">
		<div class="sidebar-wrapper">
			<div class="logo">
				<a href="<?php echo get_url(); ?>" > <?php 							if($favicon && file_exists(ABSPATH.'themes/pos/images/'.$favicon))												echo '<img src="'.get_url().'themes/pos/images/'.$favicon.'" > ';									else											echo '<img src="'.get_url("admin").'assets/css/images/icon.jpg" > ';					?>																				</a>
				<?php $current_user = kv_get_current_user(); 
						echo '<a class="simple-text" style="color: #bbf6e2;" href="'.get_url("admin").'users.php?edit_id='.$current_user['ID'].'" > '.($current_user['full_name'] != null ? $current_user['full_name'] : $current_user['username'] ).'</a>'; ?>
			</div>
			<?php admin_function_for_menu(); ?>

			<div class="bottom" id="footer" style="background: transparent !important;">

			<!-- Social Icons -->
				<ul class="icons">
					<li><a href="http://twitter.com/" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
					<li><a href="http://facebook.com/" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
					<li><a href="http://github.com/" class="icon fa-github"><span class="label">Github</span></a></li>
					<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
					<li><a href="mail-to:admin@spacemac.us" class="icon fa-envelope"><span class="label">Email</span></a></li>
				</ul>
			</div>
		</div>
	</div>
		
		<!-- Main -->
		<div class="main-panel" id="main-panel">
		<div class="navbar">
			<div class="container-fluid">
			<a href="#header" onclick="toggleMenu();" class="toggle">
				<span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></a> 
			<span class="left" > <?php 
						if($icon != null)
							echo '<span class="icon fa-'.$icon.' green"> </span> '; 
						echo _($page_title); 

						if($add_url != null && $media == null)
							echo ' <a class="button" href="'.get_url("admin").$add_url.'" > '._('Add New'). ' </a>';
						if($media == 'add_media')	
							echo ' <a class="button add_media_item" href="'.$add_url.'" > '._('Add New'). ' </a>';?> </span>
			<a class="right" href="<?php echo get_url('admin').'?logout'; ?>" > <span class="icon fa-power-off"> <span class="desktop-oly" ><?php echo _("Logout"); ?></span> </span></a>
			</div>
		</div>
		<div class="content"> 	<?php
			if($permission != null)
				user_permission(); 		
}


function get_admin_footer($media=null){ ?>
	

			<footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul> <li> Powered By <a href="http://www.spacemac.us" target="_blank"> Kvcodes</a> </li> </ul>
                </nav>
                <p class="copyright pull-right">
                    <?php echo _("Copyrights"); ?> &copy; <?php echo date('Y'); ?> <a href="http://www.spacemac.us" target="_blank"><?php echo _("Kvcodes POS"); ?></a> 
                </p>
            </div>
        </footer>
	</div>
</div>
		<!-- Scripts -->
			
			<script src="<?php echo get_url("admin");?>assets/js/skel.min.js"></script>
			<script src="<?php echo get_url("admin");?>assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="<?php echo get_url("admin");?>assets/js/main.js"></script>
			<script src="<?php echo get_url("admin");?>assets/js/datatables.min.js"></script>

			<script src="<?php echo get_url("admin");?>assets/js/dataTables.bootstrap.min.js"></script>
			<script src="<?php echo get_url("admin");?>assets/js/dataTables.responsive.min.js"></script>
			<script src="<?php echo get_url("admin");?>assets/js/responsive.bootstrap.min.js"></script>

			<script type="text/javascript">
				var toggleMenu = function(){
				    var m = document.getElementById('sidebar'),
				        c = m.className;
					    m.className = c.match( ' active' ) ? c.replace( ' active', '' ) : c + ' active';

					    var m = document.getElementById('main-panel'),
				        c = m.className;
					    m.className = c.match( ' active' ) ? c.replace( ' active', '' ) : c + ' active';
				}

				var kv_file_loc = window.location.pathname;
				kv_path_to_the_file = kv_file_loc.substring(0, kv_file_loc.lastIndexOf('/'));
				kv_path_to_the_file = kv_path_to_the_file.substring(0, kv_path_to_the_file.lastIndexOf('/'));
				if(typeof ajax_url != 'undefined'){
					url_final = kv_path_to_the_file+'/includes/kv-ajax.php?'+ajax_url;
			 
			 
			 $.fn.dataTableExt.oApi.fnStandingRedraw = function(oSettings) {

				if(oSettings.oFeatures.bServerSide === false){
					var before = oSettings._iDisplayStart;
					oSettings.oApi._fnReDraw(oSettings);       
					oSettings._iDisplayStart = before;
					oSettings.oApi._fnCalculateEnd(oSettings);
				} 
				oSettings.oApi._fnDraw(oSettings);
			};
					$(document).ready(function () {
						if(typeof type != 'undefined' && type == 'users'){
						
							Neem_Pagination_table=$('#neem_pagination_Table').dataTable({
								"processing": true,
								"serverSide": true,
								"responsive": true,
								"destroy": true,
								"columnDefs": [{ width: '3%', targets: 0 }],
								dom : 'l<"#Roles">frtip', 
								"ajax": url_final						
							});
							$select = $('<ul/>').appendTo('#Roles');
							$('<li/>').html('<a href="<?php echo get_url('admin');?>users.php" > <?php  echo 'All ('.neem_count('users').')'; ?> </a>').appendTo($select);
							<?php $userRoles = get_user_roles(); 
							//print_r ($userRoles);
								foreach($userRoles as $role){ ?>
										$('<li/>').html('<a href="<?php echo get_url('admin');?>users.php?role=<?php  echo $role; ?>" > <?php  echo $role.'('.neem_count('users', array('role', $role)).')'; ?> </a>').appendTo($select);
							<?php } ?>
						} else { 
							Neem_Pagination_table=$('#neem_pagination_Table').dataTable({
								"processing": true,
								"serverSide": true,
								"responsive": true,
								"destroy": true,
								"ajax": url_final						
							});
						}
						/*$("#Company_name").on("change", function(){
							customerID = $(this).val();
							Neem_ClientUploads_table=$('#neem_ClientUploads_Table').dataTable({
								"processing": true,
								"serverSide": true,
								"responsive": true,
								"destroy": true,
								"order": [[ 0, "desc" ]],
								"columnDefs": [{ width: '7%', targets: 0 }, { width: '35%', targets: 1 },{width: '30%', targets: 2 },  {width: '20%', targets: 3},{width: '8%', targets: 4 }],
								fixedColumns: true, 
								dom : 'l<"#Company_name">frtip', 
								"ajax": '<?php echo get_url(); ?>ajax?uploads=yes&backend=yes'+'&customerId='+customerID								
							});
						});
						
						
						$("#Company_name").trigger("change");	*/
						Neem_Page_table=$('#neem_page_Table').dataTable({
							"processing": true,
							"serverSide": true,
							"destroy": true,							
							"responsive": true,
							"order": [ [0, "dsc"]  ], 
							"ajax": url_final,
							 "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
						        switch(aData[4]){
						            case 'Published':
						                $(nRow).css('color', '#222629')
						                break;
						            case 'Trashed':
						                $(nRow).css('color', '#daaaaa')
						                break;
						            case 'Draft':
						                $(nRow).css('color', '#E8A90E')
						                break;
						        }
						    }
						});
						
						<?php if($media == 'add_media'){ ?>
						
						
						$("#neem_page_Table").on('click', '#view_media_img', function(){		
							//e.preventDefault();		
							//alert(	$(this).attr('href'));
							$.magnificPopup.open({
							  items: {              
								src: $(this).attr('src'),          
								type: 'iframe'
							   }
							});
						});
						
						<?php } ?>
						
						/*$("#neem_page_Table").on('click', '#view_media', function(e){		
							e.preventDefault();		
							//alert(	$(this).attr('href'));
							$.magnificPopup.open({								
							  items: {              
								src: $(this).attr('href'),          
								type: 'iframe'
							   }
							});
						});*/
					});
				}
			
		</script>
		<?php if(isset($_GET['page']) && $_GET['page'] == 'client-uploads'){  ?>
		<!--   ########## Modal for pdf ===========   -->
    <div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="UploadTitle">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa window-close-o" >X</i></button>
            <h4 class="modal-title" id="ViewUploadTitle"> View PDF</h4>
          </div>
          <div class="modal-body" style="min-height:400px; max-height: 100%;">          
              <div class="iframe-container">  <iframe src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF"></iframe>  </div>
              <div class="row" id="DisplayUploadNote">
              </div>
          </div>
          <div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div>
        </div>
      </div>
    </div>	
	<?php } ?>
	</body>
</html>
<?php 
}

function admin_function_for_menu(){ 
	global $default_menu_items;	
	$current_user = kv_get_current_user(); 		
	$sorted_array = ksort($default_menu_items);
	echo '<nav id="nav"><ul class="nav">';
	foreach($default_menu_items as $menu => $item){
		$current_url =  "http://".$_SERVER["SERVER_NAME"].$_SERVER['REQUEST_URI'];
		if (in_array($current_user['role'], $item[4])) {
			echo '<li ><a href="'.(strpos($item[0], 'kv-admin') !== false ? $item[0] : get_url("admin").'admin.php?page='.$item[0]).'" class="skel-layers-ignoreHref ';
			
			$current_url_len =  strlen($current_url);
			$forwarding_url = (strpos($item[0], 'kv-admin') !== false ? $item[0] : get_url("admin").'admin.php?page='.$item[0]); 
			$forwarding_url_len =  strlen($forwarding_url).' ';			

			if((strpos($current_url, $item[0]) !== false) && ($forwarding_url_len == $current_url_len) ){
				 echo 'active' ;
				}else{
					if(strpos($current_url, '.php')){
						if(strpos($current_url, 'admin.php')){
						 //echo 'active';
						} else{
							//echo 'active';
						}
					}else{
						//echo 'active';
					}
				}				
			echo '"><span class="icon fa-'.$item[1].'">'._($item[2]).'</span></a></li>';
		}				
	}			
	echo '</ul></nav>';

}?>