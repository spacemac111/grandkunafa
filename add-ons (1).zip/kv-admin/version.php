<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/ 
require('admin-functions.php'); 
global $version;

$version = '1.1';

//make sure user is logged in, function will redirect use if not logged in
login_required();

get_admin_header('Software Update', 'user', null, "no"); ?>

<section id="dashboard" class="two">
	<div class="container">
		<div class="row">
			<div class="6u 12u$(mobile)">
				<article class="item">								
					<header>
						<h3><span class="icon fa-clone"></span> <a href="https://www.spacemac.us/clients/products/client/item_details/pos-for-frontaccounting" > Current Version - <?php echo $version; ?> </a></h3>
					</header>															
				</article>									
			</div>	

			<!--<div class="12u 12u$(mobile) ">
				<div class="welcome_container item"> 
					<iframe src="https://www.spacemac.us/clients/products/client/item_details/pos-for-frontaccounting" > " width="100%" height="300px;"></iframe>
				</div>
			</div>	
		</div> --><!--</div> -->
	</div>
</section>
<style>
	.welcome_container{	padding:25px;	}
	.dashboard-users .row > * {padding: 0 0 0 15px;	}
	.dashboard-users li {width: 50%;}
	h3 span.icon { font-size:20px; }
</style>
<?php 
get_admin_footer();
?>