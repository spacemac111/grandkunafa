<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
//require(dirname(dirname(__FILE__)).'/includes/KvNeemOptions.php');
login_required();

get_admin_header('Settings','gear', null, "no");
global $db_connections;
$kv_errors= array();
if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['user_submit'])) {
	$fields = array(
				'site_title',
				'site_url',
				'admin_email',
				'isRoot',
				'Default_Language',
				'table_no',
				'allow_user_registration',
				'captcha_login',
				'google_site_key',
				'google_secret_key',
				'login_timeout',
				'login_retries_allowed'
	);
	
	foreach ($fields as $field) {
		if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
	}
	if ($posted['site_title'] == null)
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Site title is Important.', 'neem'));
	if ($posted['site_url'] == null)
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Site Url is Important.', 'neem'));
	if ($posted['admin_email'] == null)
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Site Admin Email is necessary.', 'neem'));
	$errors = array_filter($kv_errors);
	if (empty($errors)) { 
		foreach ($fields as $field) {
			if($posted[$field] != '' || $posted[$field] != null){
				$current_option_id = get_site_option_id($field);
				if($current_option_id)
					Update('settings', array("ID" => $current_option_id), array("option_value" => $posted[$field] )  );	
				else
					Insert('settings', array("option_name" => $field, "option_value" => $posted[$field] )  );	
				if($field == 'isRoot')
					UpdateRoot($posted['isRoot']);
			}			
		} 

	if(is_array($_POST['pusher']) && !empty($_POST['pusher'])){
		if(isset($_POST['pusher']['allow_pusher']))
			$_POST['pusher']['allow_pusher'] =1; 
		Update('settings', array('option_name' => 'pusher'), array('option_value' => serialize($_POST['pusher']))); 
	}

	//$image_logo= get_site_option('logo');
	//if($image_logo){
		//Update('settings', array('option_name' => 'logo'), array('option_value' => $image_save));

	//}else{
		if(isset($_FILES["logo"])){
			if($_FILES["logo"]["error"] > 0){
				//echo "Error: ".$_FILES["logo"]["error"]; 
			 }else {
				 
				$filename = $_FILES["logo"]["name"];
				$allowed = array( 'jpg', 'jpeg', 'gif', 'png', 'bmp');
				$ext = pathinfo($filename, PATHINFO_EXTENSION); 
				if(in_array($ext, $allowed)) {	
				    $uploads_dir = ABSPATH."/themes/pos/images/"; 
					if(!file_exists($uploads_dir. $_FILES["logo"]["name"])){
						$res = move_uploaded_file($_FILES["logo"]["tmp_name"], $uploads_dir. $_FILES["logo"]["name"]); 
						if($res)
							echo "true";
						$image_save = $_FILES["logo"]["name"];
						Update('settings', array('option_name' => 'logo'), array('option_value' => $image_save));
					}
				 }
			 }
		} 
	//}
	//$image_favicon = get_site_option('favicon');
	//if($image_favicon){
		//Update('settings', array('option_name' => 'favicon'), array('option_value' => $_FILES["favicon"]["name"]));					
	//}else{
		
		if(isset($_FILES["favicon"])){
			 if($_FILES["favicon"]["error"] > 0){
				//echo "Error: ".$_FILES["favicon"]["error"]; 
			 }else {
				 $filename = $_FILES["favicon"]["name"];
				$allowed = array( 'jpg', 'jpeg', 'gif', 'png', 'bmp');
				$ext = pathinfo($filename, PATHINFO_EXTENSION); 
				if(in_array($ext, $allowed)) {
				   $uploads_dir = ABSPATH."/themes/pos/images/"; 
					if(!file_exists($uploads_dir. $_FILES["favicon"]["name"])){
						move_uploaded_file($_FILES["favicon"]["tmp_name"], $uploads_dir. $_FILES["favicon"]["name"]); 	
						Update('settings', array('option_name' => 'favicon'), array('option_value' => $_FILES["favicon"]["name"]));					
					}
				 }
			 }
		}
	//} 
		//require_once(FA_PATH."config_db.php");
		//var_dump($db_connections);
		foreach($_POST as $key => $posted){
			if(strpos($key, 'table_no')  !== false){
				$cid = substr($key, 9);
				$sql = "SELECT value FROM ".$db_connections[$cid]['dbname'].'.'.$db_connections[$cid]['tbpref']."sys_prefs WHERE name ='table_no';";
				$res = db_query($sql, "");

				if(db_num_rows($res)> 0 ){

					$sql = "UPDATE ".$db_connections[$cid]['dbname'].'.'.$db_connections[$cid]['tbpref']."sys_prefs SET value='".$posted."' WHERE name='table_no'";
					$res = db_query($sql, "");
				}else {
					$sql = "INSERT INTO ".$db_connections[$cid]['dbname'].'.'.$db_connections[$cid]['tbpref']."sys_prefs (`name`, `value`) VALUES ('table_no', '".$posted."')";
					$res = db_query($sql, "");
				}
			}
		}
		
		echo '<div class="success" > '._('Site Options Updated'). ' </div>';
	}
}

?>
<style>
header{ margin-bottom: 0 !important; }
.downloadXML{ padding-left: 5%; }
</style>
<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/tabbed.css" />
<br>
<form method="post" action="" enctype="multipart/form-data">
	
    <div id="tabs" class="c-tabs">
        <div class="c-tabs-nav">
        <a href="#general" class="c-tabs-nav__link is-active"><i class="fa fa-home"></i> <span><?php echo _("General"); ?></span></a>
        <a href="#login" class="c-tabs-nav__link"><i class="fa fa-key"></i> <span><?php echo _("Login"); ?></span></a>          
        <a href="#Pusher" class="c-tabs-nav__link"><i class="fa fa-globe"></i> <span><?php echo _("Pusher"); ?></span></a>          
        </div>
        <div class="c-tab is-active" id="general">
          <div class="c-tab__content">
          <div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("POS Title"); ?> </label></div>
				<div class="8u 12u$(mobile)"><input type="text" name="site_title" placeholder="Site Title" value="<?php echo get_site_option(); ?>" /></div>
			</div>
			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("POS URL"); ?> </label></div>
				<div class="8u 12u$(mobile)"><input type="text" name="site_url" placeholder="Site URL" value="<?php echo get_site_option('site_url'); ?>" /></div>
			</div>
			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Logo"); ?> </label></div>
				<div class="8u 12u$(mobile)"><input type="file" name="logo" placeholder="POS Logo" value="<?php echo get_site_option('logo'); ?>" /></div>
			</div>
			
			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Favicon"); ?> </label></div>
				<div class="8u 12u$(mobile)"><input type="file" name="favicon" placeholder="Favicon" value="<?php echo get_site_option('favicon'); ?>" /></div>
			</div>
			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Admin Email"); ?> </label></div>
				<div class="8u 12u$(mobile)"><input type="email" name="admin_email" placeholder="Admin E-mail" value="<?php echo get_site_option('admin_email'); ?>" /></div>
			</div>
			
			<!--<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php //echo _("Front Page/Home Page"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php //$frnt_page = get_frontpage(); echo select_options_list('isRoot', 'pages', $frnt_page);  ?></div> 
			</div>	-->

			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Language"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php $language_ar = GetLanguagesList(); $selected_language = get_site_option('Default_Language'); echo select_options_list('Default_Language', $language_ar, $selected_language, 'no');  ?>
				</div> 					
			</div>
			<div class="row">
				<div class="4u 12u$(mobile)"> <h4><?php echo _("No Of Tables"); ?> </h4></div>
			</div>
				<?php if(!empty($db_connections)) {
					//var_dump($db_connections);
					foreach($db_connections as $key => $conn){
						echo '<div class="row"><div class="4u 12u$(mobile)"><label>'.$conn['name'].' </label></div><div class="8u 12u$(mobile)">'.GetTablelist($key).'</div></div>';
					}
				}?>
			

        </div>
        </div>
        <div class="c-tab" id="login">
          <div class="c-tab__content">
          <?php //$form->build_form(); ?>
          <div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Allow User Registration"); ?></label></div>
				<div class="8u 12u$(mobile)"><input type="checkbox" <?php if(get_site_option('allow_user_registration') == 1) echo 'checked'; ?> name="allow_user_registration" value="1" /></div>
			</div>

          <div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Timeout For Login"); ?> </label></div>
				<div class="8u 12u$(mobile)">
					<select name="login_timeout" > 
					<?php $timeout = get_site_option('login_timeout'); ?> 
						<option value="300" <?php if($timeout == 300) echo 'selected'; ?> > 5 minutes </option> 
						<option value="900" <?php if($timeout == 900) echo 'selected'; ?> > 15 minutes </option> 
						<option value="1800" <?php if($timeout == 1800) echo 'selected'; ?> > 30 minutes </option> 
						<option value="3600" <?php if($timeout == 3600) echo 'selected'; ?> > 1 hour </option> 
						<option value="-1" <?php if($timeout == -1) echo 'selected'; ?> > Never Expire </option> 
					</select> 
				</div>
			</div>

			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Maximum Allowed Login Retries"); ?></label></div>
				<div class="8u 12u$(mobile)">
				<select name="login_retries_allowed" > 
					<?php $login_retries_allowed = get_site_option('login_retries_allowed'); ?> 
						<option value="3" <?php if($login_retries_allowed == 3) echo 'selected'; ?> > 3 </option> 
						<option value="5" <?php if($login_retries_allowed == 5) echo 'selected'; ?> > 5 </option> 
						<option value="8" <?php if($login_retries_allowed == 8) echo 'selected'; ?> > 8 </option> 
						<option value="10" <?php if($login_retries_allowed == 10) echo 'selected'; ?> > 10 </option> 
					</select> 
				</div>
			</div>
			
			<div class="row">
				<div class="4u 12u$(mobile)"><label> <?php echo _("Captcha For Login"); ?>: </label></div>
				<div class="8u 12u$(mobile)">
					<select name="captcha_login" > 
					<?php $captcha_login = get_site_option('captcha_login'); ?> 
						<option value="no" <?php if($captcha_login == 'no') echo 'selected'; ?> > No </option> 
						<option value="yes" <?php if($captcha_login == 'yes') echo 'selected'; ?> > Yes </option> 
					</select> 
				</div>
			</div>

			<div class="row"> 
				<h4> Google reCaptcha Key's </h4>				
			</div>
			<div class="row" > 
				<div class="4u 12u$(mobile)" > <label> <?php  echo _("Site Key"); ?> </label> </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="google_site_key" placeholder="Site Key" value="<?php echo get_site_option('google_site_key'); ?>" /></div>
          </div>
          <div class="row" > 
				<div class="4u 12u$(mobile)" > <label> <?php echo _("Secret Key"); ?> </label> </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="google_secret_key" placeholder="Secret Key" value="<?php echo get_site_option('google_secret_key'); ?>" /></div>
          </div>
        </div>
        </div>
       
        <div class="c-tab" id="Pusher">
        	<?php $pusher_keys = get_site_option('pusher'); 
        	//print_r($pusher_keys);
        //	echo $pusher_keys['app_id']; ?>
          <div class="c-tab__content">
          	 <div class="row" > 
				<div class="4u 12u$(mobile)" > <label> <?php echo _("Your App ID"); ?> </label> </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="pusher[app_id]" placeholder="YOUR APP ID" value="<?php echo (isset($pusher_keys['app_id']) ? $pusher_keys['app_id'] : '' ); ?>" /></div>

				<div class="4u 12u$(mobile)" > <label> <?php echo _("Your App Key"); ?> </label> </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="pusher[app_key]" placeholder="YOUR APP Key" value="<?php echo (isset($pusher_keys['app_key']) ? $pusher_keys['app_key'] : '' ); ?>" /></div>


				<div class="4u 12u$(mobile)" > <label> <?php echo _("Your App ID"); ?> </label> </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="pusher[app_secret_id]" placeholder="YOUR APP Secret ID" value="<?php echo (isset($pusher_keys['app_secret_id']) ? $pusher_keys['app_secret_id'] : '' ); ?>" /></div>

				<div class="4u 12u$(mobile)" > <label> <?php echo _("Your Cluster"); ?> </label> </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="pusher[app_cluster]" placeholder="YOUR Cluster" value="<?php echo (isset($pusher_keys['app_cluster']) ? $pusher_keys['app_cluster'] : '' ); ?>" /></div>

				<div class="4u 12u$(mobile)"><label> <?php echo _("Enable Pusher "); ?></label></div>
				<div class="8u 12u$(mobile)"><input type="checkbox" <?php echo (isset($pusher_keys['allow_pusher']) && $pusher_keys['allow_pusher']== 1 ? 'checked' : '' ); ?> name="pusher[allow_pusher]" value="1" /></div>
			</div>
          </div>

          </div>
        </div>
      </div>
    
		<div style="clear:both;" > </div>
		<div class="12u$" style="padding-left:5px;">
			<br>
			<input type="hidden" name="user_submit" value="yes">
					
			<input type="submit" name="submit" value="<?php echo _("Update Options"); ?>" />
		</div>


</form>	
	</div>
<script src="<?php echo get_url("admin");?>assets/js/tabs.js"></script>
<script type="text/javascript">
	var myTabs = tabs({
    el: '#tabs',
    tabNavigationLinks: '.c-tabs-nav__link',
    tabContentContainers: '.c-tab'
  });
	myTabs.init();
</script>
<?php get_admin_footer(); ?>