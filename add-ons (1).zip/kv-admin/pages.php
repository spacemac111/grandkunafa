<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
login_required();

get_admin_header('Pages', 'clone', 'pages.php?add-new=yes', "no");

if(isset($_GET['add-new']) || isset($_GET['edit_id']) || isset($_GET['delete_id'])){
	require_once("add-edit-pages.php");
}
else {
	if(isset($_GET['status'])){
		if($_GET['status'] == 'deleted')
			echo '<div class="error"> '._("The Selected Page Deleted Successfully").' </div>';
		if($_GET['status'] == 'added')
			echo '<div class="success"> '._("A New Page added Successfully").' </div>';
		if($_GET['status'] == 'updated')
			echo '<div class="success"> '._("The Selected Page Updated Successfully").' </div>';
	}
	
	?>
	
	<table id="neem_page_Table">
			
		<thead> 
			<tr>
				<th width="0%"><strong>ID</strong></th>
				<th width="50%"><strong><?php echo _("Title"); ?></strong></th>
				<th width="25%"><strong><?php echo _("Author"); ?></strong></th>
				<th width="15%"><strong><?php echo _("Date"); ?></strong></th>				
				<th width="20%"><strong><?php echo _("Status"); ?></strong></th>
			</tr>
		</thead>
		<tbody>	</tbody>
	</table>
	</div>
</section>
<script> ajax_url = 'pages=page'; </script>
<?php 
}
//get_main_body();
get_admin_footer();
?>