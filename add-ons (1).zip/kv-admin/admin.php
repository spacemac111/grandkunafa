<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 


if(isset($_GET['action']) && $_GET['action'] == 'login' || $_GET['action'] == 'forgot_password' || $_GET['action'] == 'register' || isset($_GET['reset_password']) ){
	require('login.php'); 

}else {
	//make sure user is logged in, function will redirect use if not logged in

	login_required();

	//if logout has been clicked run the logout function which will destroy any active sessions and redirect to the login page
	if(isset($_GET['logout'])){
		logout();
	}

	//run if a page deletion has been requested

	global $default_menu_items;

	//print_r($default_menu_items);
	$page_not_found = 0;
	$current_function = null;
	if(isset($_GET['page'])){
		foreach ($default_menu_items as $key => $value) {# code...		
			if(strpos($value[0], 'kv-admin') !== false){} else{

				if($_GET['page'] == $value[0]){
					$current_function = $value[3]; 
					if(function_exists($value[3])){	
						$page_not_found = 1;				
						$title =$value[2];
						$icon = $value[1]; 
					}else {
						$page_not_found = 0; 
						$title = '404- Function Not Found' ; 
						$icon = ''; 
					}
				}
			}
		}
	}else{
		$page_not_found = 0; 
		$title = '404- Page Not Found' ; 
		$icon = ''; 
	}
	
	//if(empty($_GET) || $page_not_found == 0){
		get_admin_header($title, $icon);
	//} ?>
	<section id="dashboard" class="two">
		<div class="container">						
			<?php if(isset($_GET['page']) ){
			//if($permission != null)
				user_permission();				
					if(function_exists($current_function)){
						$current_function();						
					} 
				} ?>
		</div> 
	</section>
</div><?php 
	
	get_admin_footer();
}
?>