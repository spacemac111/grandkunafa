<?php 

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

if(isset($_GET['delete_id'])){
	$deleted = Delete("pages",array('ID'=> db_escape($_GET['delete_id'])));
	kv_direct(get_url("admin").'pages.php?status=deleted');
} else {
	$edit_arr['pageTitle'] = $edit_arr['pageContent']= $edit_arr['status'] = ''; 
	$edit_arr['isRoot'] = 1;
	if(isset($_GET['add-new'])){
		$title = _("Add New Page");
		$button_text = _("Publish");
	}elseif(isset($_GET['edit_id'])){ 
		$title = _("Edit Page");
		unset($edit_arr["pageTitle"]);
		unset($edit_arr["pageContent"]);
		unset($edit_arr["ID"]);
		unset($edit_arr["status"]);
		$edit_arr = GetRow("pages", array("ID" => $_GET['edit_id']));
		//print_r($edit_arr);
		$button_text = _("Update");
	}

	$kv_errors= array();
	if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['page_submit'])) {
		$fields = array(
					'pageTitle',
					'pageContent',
					'authorID',
					'templates',
					'status'
		);

		foreach ($fields as $field) {
			if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
		}
		if ($posted['pageTitle'] == null)
			array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Page Title.', 'neem'));
		if ($posted['pageContent'] == null)
			array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the Page Content.', 'neem'));

		$errors = array_filter($kv_errors);

		if (empty($errors)) { 
			$pageSlug = seoUrl($posted["pageTitle"]);

			global $db;
			if(isset($_POST['page_id'])){				
				kv_update_page($_POST['page_id'], $posted["pageTitle"], $posted['pageContent'], $pageSlug, $posted["authorID"],($posted["templates"] == -1 ? '': $posted['templates']), 0, 0, 'page', '', 
								$posted["status"]);
				kv_direct(get_url("admin").'pages.php?edit_id='.$_POST['page_id'].'&status=updated');

			}else{
				$id = kv_insert_page( $posted["pageTitle"], $posted['pageContent'], $pageSlug, $posted["authorID"],($posted["templates"] == -1 ? '': $posted['templates']), 0, 0, 'page', '', 
								$posted["status"]);
				kv_direct(get_url("admin").'pages.php?edit_id='.$id.'&status=added');
			}
		}
	}
	?>
	<section id="top" class="one dark cover">
		<div class="container"><?php 
				if(!empty($errors)) {
						echo '<div class="error">';
						foreach ($kv_errors as $error) {
							echo '<p>'.$error.'</p>';
						}
						echo '</div>';
				} 
				if(isset($_GET['status'])){					
					if($_GET['status'] == 'added')
						echo '<div class="success"> Added Successfully <a target="_blank" href="'.get_url().$edit_arr['slug'].'"> View it</a>. </div>';
					if($_GET['status'] == 'updated')
						echo '<div class="success"> Updated Successfully <a target="_blank" href="'.get_url().$edit_arr['slug'].'"> View it</a>. </div>';
				}
				?>

			<form method="post" action="">
				<div class="row">
					<div class="12u 12u$(mobile)"><input type="text" name="pageTitle" placeholder="<?php echo _("Page Title"); ?>" value="<?php if($edit_arr['pageTitle'] != '') { echo $edit_arr['pageTitle']; } else if(isset($_POST['pageTitle'])) {  echo $_POST['pageTitle']; } ?>" /></div>
					
					</div>
					<div class="row">				
						<div class="9u 12u$(mobile)"><textarea id="editor" name="pageContent" placeholder="Content"><?php echo htmlspecialchars_decode($edit_arr['pageContent']); ?></textarea></div>
						<div class="3u 12u$(mobile)">

							<div> <label> <?php _("Status"); ?> </label>
								<select name="status">
									<option value="Published" <?php if($edit_arr['status'] == 'Published') echo "selected"; ?> > Published </option>
									<option value="Draft" <?php if($edit_arr['status'] == 'Draft') echo "selected"; ?>> Draft </option>
									<option value="Trashed" <?php if($edit_arr['status'] == 'Trashed') echo "selected"; ?>> Trashed </option>
								</select>
							</div>				

							<div><label> <?php echo _("Template"); ?>: </label>
								<?php echo get_theme_templates($edit_arr['template']); ?>
							</div>

							<div> 
								<label> <?php echo _("Author"); ?>: </label>
								<select name="authorID">
								<?php $users = get_all_users();
									$current_user = kv_get_current_user();
									foreach ($users as $user) { ?>								
									
									<option value="<?php echo $user['ID']; ?>" <?php if(($edit_arr['authorID'] != null && $edit_arr['authorID'] == $user['ID']) || $current_user['ID'] == $user['ID']) echo "selected"; ?> > <?php echo $user['full_name']; ?> </option>
									<?php } ?>
								</select>
							</div>

						</div>
					<div class="3u 12u$(mobile)"><input type="hidden" name="page_submit" value="yes">
						<?php if(isset($_GET['edit_id'])){ ?> 
						<input type="hidden" name="page_id" value="<?php echo $edit_arr['ID']; ?>">
						<?php } ?>
						<input type="submit" value="<?php echo $button_text; ?>" />
					</div>
				</div>
				</div>
					
			</form>
		</div>
	</section>
<?php 
} ?>
<style>
.page_header{
	display: none;
}
.mfp-iframe-holder{
	padding:0 !important;
}
.mce-edit-area { height: 50%; }
#editor_ifr { height:100% !important; }
</style>
<script src="<?php echo get_url("admin");?>assets/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
var filechooser_url = '<?php echo get_url('admin'); ?>filechooser.php';
site_url = '<?php echo get_url(); ?>';
	uploads_url = site_url+'<?php echo NEEM_UPLOADS; ?>';
tinymce.init({
              selector: "#editor",
              autosave_restore_when_empty: false,
              autosave_ask_before_unload:false, 
              theme: 'modern',
              plugins: [
              "advlist autolink autosave link lists charmap print  hr pagebreak spellchecker",
               "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
              "table contextmenu directionality emoticons textcolor paste textcolor colorpicker textpattern"
              ],

        toolbar1: " bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent blockquote | searchreplace print fullscreen ltr rtl spellchecker",
        toolbar2: "styleselect formatselect fontselect fontsizeselect | undo redo | link unlink kvimages code | insertdatetime | forecolor backcolor | table | hr removeformat | subscript superscript | charmap emoticons |  | visualchars visualblocks nonbreaking  pagebreak ",

        menubar: false,
        toolbar_items_size: 'small',
        content_style: ".mce-content-body {font-size:15px;font-family:Arial,sans-serif;zoom:1.2; }",
        style_formats: [
              {title: 'Bold text', inline: 'b'},
              {title: 'Red text', inline: 'span', styles: {color: '#ff0000'}},
              {title: 'Red header', block: 'h1', styles: {color: '#ff0000'}},
              {title: 'Example 1', inline: 'span', classes: 'example1'},
              {title: 'Example 2', inline: 'span', classes: 'example2'},
              {title: 'Table styles'},
              {title: 'Table row 1', selector: 'tr', classes: 'tablerow1'}
        ],

		file_browser_callback: function(field_name, url, type, win){
			win.document.getElementById(field_name).value = 'my browser value';
		}, 
		relative_urls : false,
		convert_urls : true,
		//document_base_url : uploads_url, 
		setup: function(editor) {
        editor.addButton('kvimages', {
            type: 'button',
            title: 'Insert image',
            icon: 'image',
            id: 'kvimages', 
			onclick : function() {
				 //var img = "<img src='http://archive.tinymce.com/images/logo.png?" + Date.now() + "'>";
				//tinymce.activeEditor.execCommand('mceInsertContent', false, img);
            	//editor.windowManager.alert('Hello world!! Selection: ' + editor.selection.getContent({format : 'text'}));
            	editor.focus();
            	$.magnificPopup.open({
					items: {              
						src: filechooser_url,          
						type: 'iframe'
					}
				});
         }
        });
		
		editor.on('init', function() {
        this.execCommand("fontName", false, "Verdana");
        this.execCommand("fontSize", false, "13pt");
    });
       
    }  

});
</script>