<?php 

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in

login_required(); ?><link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/font-awesome.min.css" />

<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/main.css" />

	<script src="<?php echo get_url("admin");?>assets/js/jquery.min.js"></script>

	<script src="<?php echo get_url("admin");?>assets/js/jquery.magnific-popup.min.js"></script>

	<script> site_url = '<?php echo get_url(); ?>'; </script>

	<div class="view_attachment" id="wrap">

	<div class="view_header" > <h3>  <span class="fa fa-clone"></span> Choose Media </h3>

		<span class="pull-right" >

		<ul>

		<li> <a href="#" id="view_popup_close"><span class="fa fa-close"></span></a> </li> 

		</ul> </span> <div style="clear:both" > </div></div>

	<div id="wrapper" > 
		<div class="filemanager">		

			<div class="search"><input type="search" placeholder="Find a file.." />	</div>

			<ul class="data"></ul>

			<div class="nothingfound">

				<div class="nofiles"></div>

				<span><?php echo _("No files here"); ?>.</span>

			</div>

		</div>
		</div>

		<div id="footer"> 
			<button class="button" id="cancel_media" >Cancel </button>
			<button class="button" id="insert_media" data-url="summa" >Select </button>	
		</div>

  	</div>

	</div> 

	<style>
	body { margin:0; }
	#wrap { position: relative; } 
	#wrapper {  padding-bottom: 70px; /*  margin-bottom: 70px !important;*/ }
	#footer {  width: 100%;   height: 70px; position: absolute; bottom: 0; left: 0;}
	a{ text-decoration: none; cursor: pointer;}
	.filemanager { overflow: auto;  padding-bottom: 0;  }
	.form_buttons{ float:right; width: 100%;  border: 1px solid #eee;  padding: 5px; bottom: 0; position: relative;
    margin-top: -50px; height: 50px; clear: both;}
	#insert_media, #cancel_media { float:right; margin-right: 8px;}
	.success { 	background-color: #BBF6E2;border: 1px solid #6ADE95;margin:20px auto; padding:10px;border-radius:5px;}
	.mfp-close { display: none; }
	a.button {  display: none; }
	.view_attachment{ max-width:100%; margin: 0 ;padding: 0; } 
	.view_attachment img { border:1px solid #c5c5c5; border-radius:4px; margin:2% auto; max-width: 80%;}
	.view_attachment img:hover { border:1px solid #e5e5e5; } 
	#view_popup_close, li a{ float:left; border: 1px solid #eee; box-shadow:0 1px 3px rgba(0, 0, 0, 0.05); background: #fcfcfc; -webkit-font-smoothing: subpixel-antialiased; }
	.view_header { -webkit-box-shadow: 0 5px 15px rgba(0,0,0,.7);  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.16); background: #fcfcfc; -webkit-font-smoothing: subpixel-antialiased; border: 1px solid #eee;}
	.view_header h3 { color: #353535; padding: 8px; float:left; width: 60%; margin: 0; text-align: left;}
	/*a#view_media{ border: 2px solid #eee; }*/
	.filemanager .data li a.selected_image, a#view_media:hover {  border: 2px solid #3498db; }
	.filemanager .search {	margin-top: 0 !important; }
	.filemanager .search input[type=search] { margin-left: -205px !important; }
	
	
	</style> 
	<script> 
	site_url = '<?php echo get_url(); ?>';
	uploads_url = site_url+'<?php echo NEEM_UPLOADS; ?>';
		$(document).ready(function () {

			$(".view_attachment").on('click', '#view_media', function(e){	
				e.preventDefault(); 
				var url_selected = $(this).attr('data_url');
				$("#insert_media").attr("data-url",url_selected);
				$(".view_attachment #view_media").removeClass('selected_image');
				$(this).addClass('selected_image');
			});

			$("#insert_media").on("click", function(){
				var insmedia = $(this).attr('data-url');				
				if (insmedia != "summa") {
					parent.tinymce.activeEditor.execCommand('mceInsertContent', false, '<img src="' + insmedia + '">'); 
					parent.$.magnificPopup.close();	
				}else{
					alert("No Media Selected. Please Select One");
				}
			});

			$(".view_attachment").on('dblclick', '#view_media', function(e) {
    			e.preventDefault(); 
				var insmedia = $(this).attr('data_url');
				if (insmedia != "summa") {
					parent.tinymce.activeEditor.execCommand('mceInsertContent', false, '<img src="' + insmedia + '">'); 
					parent.$.magnificPopup.close();	
				}else{
					alert("No Media Selected. Please Select One");
				}
			});

			$("#cancel_media, #view_popup_close").on("click", function(){	
				parent.$.magnificPopup.close();	
			});
		});

	</script>
	<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/tabbed.css" />
	<script src="<?php echo get_url("admin");?>assets/js/filemanager.js" > </script>	