<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/ 
require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
login_required();

get_admin_header('Users', 'user', 'users.php?add-new=yes', "no");

if(isset($_GET['add-new']) || isset($_GET['edit_id'])){
	require_once("add-edit-user.php");
}
elseif(isset($_GET['delete_id'])){
	$deleted = Delete("users",array('ID'=> $_GET['delete_id']));
	kv_direct(get_url("admin").'users.php?status=deleted');
} else {

	if(isset($_GET['status'])) {
		if($_GET['status'] == 'Added')
			echo '<div class="success"> '._("A New User Added Successfully"). '</div>'; 
		elseif($_GET['status'] == 'Updated') 
			echo '<div class="success"> '._("User Profile Updated Successfully").'</div>'; 
	}
?>
	<table id="neem_pagination_Table">
			<thead> 
			<tr>
				<th class="table-checkbox1" style="width:0%;"> <?php echo _("ID"); ?></th>
				<th ><strong><?php echo _("Username"); ?> </strong></th>
				<th ><strong><?php echo _("Email"); ?> </strong></th>	
				<th ><strong><?php echo _("Full Name"); ?> </strong></th>
				<th ><strong><?php echo _("Role"); ?> </strong></th>							
				<th><strong><?php echo _("Theme"); ?> </strong></th>							
				<th ><strong><?php echo _("Status"); ?> </strong></th>
			</tr>
		</thead><tbody>		</tbody>
	</table>
	</div>
</section>

<script>
<?php 
if(isset($_GET['role'])){
	echo "ajax_url = 'users=yes&role=".$_GET['role']."';";
} else
	echo "ajax_url = 'users=yes';"; ?>
 type='users';
</script>
<style> 
#Roles {  display: inline-block;  float: left;}
#Roles ul li {    display: inline;    padding-left: 10px;}
#Roles ul {	margin: 1em 0 ;}
#Roles a { font-size: 16px; }
</style>
<?php 
}
//get_main_body();
get_admin_footer();
?>