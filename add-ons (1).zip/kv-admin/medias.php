<?php 
/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/
require('admin-functions.php'); 

//make sure user is logged in, function will redirect use if not logged in
login_required();

if( isset($_GET['view_id'])){ // Viewing the media  
	require_once('view-media.php');
	exit;
}

get_admin_header('Medias', 'clone', '#add_new_media', "no", 'add_media'); ?>
		<div class="filemanager">		

			<div class="search">
				<input type="search" placeholder="Find a file.." />
			</div>

			<ul class="data"></ul>

			<div class="nothingfound">
				<div class="nofiles"></div>
				<span><?php echo _("No files here"); ?>.</span>
			</div>

		</div>

		<div id="add_new_media" class="mfp-hide">
			<?php require_once('add-media.php'); ?>
		</div>

	</div>
	</section>
	<script> site_url = '<?php echo get_url(); ?>'; </script>
	<link rel="stylesheet" href="<?php echo get_url("admin");?>assets/css/tabbed.css" />
	<script src="<?php echo get_url("admin");?>assets/js/filemanager.js" > </script>
	<script> 
	$(document).ready(function(){

		$(".filemanager").on('click', '#view_media', function(e){		
			e.preventDefault(); 
			$.magnificPopup.open({
				items: {              
					src: $(this).attr('href'),          
					type: 'iframe'
				}
			});
		});

		$('.add_media_item').magnificPopup({
			type: 'inline',
			midClick: true, 
			callbacks: {
				open: function() {
					$.magnificPopup.instance.close = function() {
						kv_filemanager();
						$.magnificPopup.proto.close.call(this);
					};
				}
			}						  
		});
	});
	</script>
	<?php 
get_admin_footer('add_media'); ?>