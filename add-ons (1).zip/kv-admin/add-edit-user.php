<?php 

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

//require('includes/functions.php');
require_once(FA_PATH.'config_db.php');
global $db_connections, $current_user, $use_dimension;

$use_dimension = get_company_details('use_dimension');
$edit_arr['ID'] = $edit_arr['full_name']= $edit_arr['email']=  $edit_arr['role']=  $edit_arr['status'] = ''; 
if(isset($_GET['add-new'])){
	$title = _("Add New User");
	$button_text = _("Add New User");
}elseif(isset($_GET['edit_id'])){ 
	$title = _("Edit User");

	$edit_arr = GetRow("users", array("ID" => $_GET['edit_id']));
	//print_r($edit_arr);
	$button_text = _("Update User");
}

$kv_errors= array();
if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['user_submit'])) {
	$fields = array('full_name', 'username', 'email', 'password', 'role', 'pos_id', 'status', 'language', 'provision', 'provision2', 'break_pt', 'salesman_phone', 'company_id', 'role_id', 'bank_accounts', 'cash_accounts', 'theme', 'strict_dimension', 'dimension2_id', 'dimension_id');

	foreach ($fields as $field) {
		if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
	}
	if ($posted['full_name'] == null)
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter the User Full Name.', 'neem'));
	if ($posted['email'] == null)
		array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the User Email.', 'neem'));
	if ($posted['password'] == null && !isset($_POST['user_id']))
		array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the User Password.', 'neem'));
	if ($posted['salesman_phone'] == null )
		array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the Salesman Phone number.', 'neem'));
	// if($posted['role'] != 'Administrator'){
	if($posted['role'] == 'Salesman'){
		if ($posted['provision'] == null )
			array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the Salesman provision.', 'neem'));
		if ($posted['provision2'] == null )
			array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the Salesman provision2 .', 'neem'));
		if ($posted['break_pt'] == null )
			array_push($kv_errors, sprintf('<strong>Notice</strong>: Please enter the Salesman Break even Point.', 'neem'));
	} else {
		$posted['provision'] =1000;
		$posted['provision2'] =1500;
		$posted['break_pt'] = 1.5;
	}

	if(isset($_POST['strict_dimension'])){
		if ($_POST['dimension_id'] == 0 )
			array_push($kv_errors, sprintf('<strong>Notice</strong>: Please select a Dimension.', 'neem'));
		if ($_POST['dimension2_id'] == 0 )
			array_push($kv_errors, sprintf('<strong>Notice</strong>: Please select a Dimension2.', 'neem'));
	}
	
	if(!isset($_POST['user_id']) && email_exist('users', $posted['email'])){
		array_push($kv_errors, sprintf('<strong>Notice</strong>: Email Already Exists,Try something else.', 'neem'));
	}
	if(strlen($posted['username']) <4)
		array_push($kv_errors, sprintf('<strong>Notice</strong>: Username must more than 3 Characters long.'));
	$errors = array_filter($kv_errors);
	$edit_arr = $posted;
			//var_dump($edit_arr);
	if (empty($errors)) { 
		$users_Arr = array(
							"full_name" => $posted["full_name"],
							"email" => $posted["email"],							
							"role" => $posted['role'],
							"username" => $posted['username'],
							"theme" => $posted['theme'],
							"language" => $posted['language'],
							"status" => $posted["status"],
							"provision2" => $posted["provision2"],
							"provision" => $posted["provision"],
							"break_pt" => $posted["break_pt"],
							"sales_pos_id" => $posted["pos_id"],
							"strict_dimension" => (isset($_POST["strict_dimension"]) ? 1 : 0 ),
							"dimension2_id" => $posted["dimension2_id"],
							"dimension_id" => $posted["dimension_id"],
							"bank_accounts" => $posted["bank_accounts"],
							"cash_accounts" => $posted["cash_accounts"],
							"name" => $db_connections[$posted['company_id']]['name'],
							"host" => $db_connections[$posted['company_id']]['host'],
							"dbname" => $db_connections[$posted['company_id']]['dbname'],
							"dbuser" => $db_connections[$posted['company_id']]['dbuser'],
							"dbpassword" => $db_connections[$posted['company_id']]['dbpassword'],
							"tbpref" => $db_connections[$posted['company_id']]['tbpref'],
							"selected_id" => $posted['company_id'],
							);
		if($posted['role'] == 'Salesman') {			
			$salesmandb = mysqli_connect($db_connections[$posted['company_id']]['host'], $db_connections[$posted['company_id']]['dbuser'], $db_connections[$posted['company_id']]['dbpassword'], $db_connections[$posted['company_id']]['dbname']);
			if (mysqli_connect_errno()) {
				return mysqli_connect_error();
			}
			$result = mysqli_query($salesmandb, "SET sql_mode=''");
						
			if(!$result && $err_msg != null ){       
				return $err_msg;
			}	
			$inactive = ((isset($posted["status"]) && $posted["status"] == 1) ? 1 : 0);
			
			if(isset($_POST['salesman_code']) && $_POST['salesman_code'] > 0 ) {
				if($_POST['salesman_code'] != $_POST['s_id']) {
					$users_Arr['s_id'] = $_POST['s_id'];
				} else {
					$sql_update = "UPDATE ".$db_connections[$posted['company_id']]['tbpref']."salesman SET salesman_name = '" . mysqli_real_escape_string($salesmandb, $posted["full_name"]) . "',	salesman_email = '" . mysqli_real_escape_string($salesmandb, $posted["email"]) . "',
											provision2 = " . mysqli_real_escape_string($salesmandb, $posted["provision2"]) . ",
											provision = " . mysqli_real_escape_string($salesmandb, $posted["provision"]) . ",
											salesman_phone = " . mysqli_real_escape_string($salesmandb, $posted["salesman_phone"]) . ",
											break_pt = " . mysqli_real_escape_string($salesmandb, $posted["break_pt"]) . ",
											inactive = " . $inactive . " WHERE salesman_code = " . mysqli_real_escape_string($salesmandb, $_POST["salesman_code"]);											
					$result = mysqli_query($salesmandb, $sql_update);
				}
				$sql2 = "UPDATE ".$db_connections[$posted['company_id']]['tbpref']."users SET role_id='" . mysqli_real_escape_string($salesmandb, $posted["role_id"]) . "' WHERE id = " . mysqli_real_escape_string($salesmandb, $_POST["fa_user_id"]);
				$result = mysqli_query($salesmandb, $sql2);
			} else {
				if($_POST['s_id'] > 0 ){
					$salesman_code = $_POST['s_id'];
				} else {
					$sql_insert = "INSERT INTO ".$db_connections[$posted['company_id']]['tbpref']."salesman (salesman_name, salesman_email, provision2, provision, salesman_phone, break_pt, inactive)
									VALUES ('" . mysqli_real_escape_string($salesmandb, $posted["full_name"]) . "',
												 '" . mysqli_real_escape_string($salesmandb, $posted["email"]) . "',
												 " . mysqli_real_escape_string($salesmandb, $posted["provision2"]) . ",
												 " . mysqli_real_escape_string($salesmandb, $posted["provision"]) . ",
												 " . mysqli_real_escape_string($salesmandb, $posted["salesman_phone"]) . ",
												 " . mysqli_real_escape_string($salesmandb, $posted["break_pt"]) . ",
												 " . $inactive.")";											
					$result = mysqli_query($salesmandb, $sql_insert);	
					$salesman_code = mysqli_insert_id($salesmandb);
				}
				$sql2 = "INSERT INTO ".$db_connections[$posted['company_id']]['tbpref']."users (user_id,  password, real_name, role_id, phone, email, language) values (
						'" . mysqli_real_escape_string($salesmandb, $posted["username"]) . "',  
						'" . md5(mysqli_real_escape_string($salesmandb, $posted["password"])) . "',  
						'" . mysqli_real_escape_string($salesmandb, $posted["full_name"]) . "',  
						'" . mysqli_real_escape_string($salesmandb, $posted["role_id"]) . "',  
						'" . mysqli_real_escape_string($salesmandb, $posted["salesman_phone"]) . "',  
						'" . mysqli_real_escape_string($salesmandb, $posted["email"]) . "',  'C' ) "; 					
					
				$result = mysqli_query($salesmandb, $sql2);	
				$fa_user_id = mysqli_insert_id($salesmandb);
				$users_Arr['s_id'] = (isset($salesman_code) ? $salesman_code : 0 );
				$users_Arr['fa_user_id'] = (isset($fa_user_id) ? $fa_user_id : 0 );
			}
			mysqli_close($salesmandb);
		}else {
			$users_Arr['s_id'] = 1;
			$users_Arr['fa_user_id'] = 1;

		}

		if($posted['password'] != null){
			$wp_hasher = new PasswordHash(16, true);
			$pass = $wp_hasher->HashPassword( trim( $posted['password'] ) );
			$users_Arr['password'] = $pass;
		}

		/*if(isset($_POST['space'])){
			$users_Arr['space'] = stripslashes(trim($_POST['space'])). ' GB';
			if(stripslashes(trim($_POST['space'])). ' GB' != $edit_arr['space']){
				kv_mail($posted["email"], 'Your Upload Space Updated - '.stripslashes(trim($_POST['space'])). ' GB', 'Hello '.$posted['full_name'].', '.PHP_EOL.' Your Upload Space has been updated. Now onwards you can upload files upto '.stripslashes(trim($_POST['space'])). ' GB and still you need more you can contact us to get more or if you have not get updated space. Email us to check your service again.');
			}
		}*/

		$users_Arr['permissions'] = serialize($_POST['permissions']);
		if(isset($_POST['user_id'])){
			
			Update('users', array("ID" => $_POST["user_id"]), $users_Arr  );
			kv_direct('users.php?status=Updated');
		}else{			
			$userId = Insert('users', $users_Arr );
			if($userId){
				kv_mail($posted["email"], 'New user Registered', 'There will be new user access created with your email address and the details will be added soon.');
				kv_direct('users.php?status=Added');
			}			
		}
	}
}?>
<section id="top" class="one dark cover">
	<div class="container">
		<header><h3 class="alt"><span class="icon fa-user-plus"> </span> <?php echo $title; ?> </h3></header>
		<?php if(!empty($errors)) {
				echo '<div class="error">';
				foreach ($kv_errors as $error) {
					echo '<p>'.$error.'</p>';
				}
				echo '</div>';
			} ?>

		<form method="post" action="">
		<?php if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0 ) {
				echo '<input type="hidden" name="salesman_code" value="'.$edit_arr['s_id'].'" > ';
				echo '<input type="hidden" name="fa_user_id" value="'.$edit_arr['fa_user_id'].'" > ';
		} ?>
		<div class="row">
		<div class="7u 12u$(mobile)" >
			<header><h3 class="alt"><span class="icon fa-vcard-o"> </span> <?php echo 'Information'; ?> </h3></header>
			<div class="row">				
				<div class="4u 12u$(mobile)" > <?php echo _("Full Name"); ?>  </div>
				<div class="8u 12u$(mobile)" > <input type="text" name="full_name" placeholder="<?php echo _("Full Name"); ?>" value="<?php echo $edit_arr['full_name']; ?>" /></div>
				
				<?php if(isset($_GET['edit_id']) || isset($posted['username'])){ ?>
					<div class="4u 12u$(mobile)" > <?php echo _("Username"); ?>  </div>
					<div class="8u 12u$(mobile)"> <input type="text" name="usernameold" placeholder="<?php echo _("Username"); ?>" value="<?php echo $edit_arr['username']; ?>" disabled />
					<input type="hidden" name="username" value="<?php echo $edit_arr['username']; ?>" ></div>
				<?php }else {?>
					<div class="4u 12u$(mobile)" > <?php echo _("Username"); ?>  </div>
					<div class="8u 12u$(mobile)"> <input type="text" name="username" placeholder="<?php echo _("Username"); ?>"  > </div>
					<?php } ?>
					<div class="4u 12u$(mobile)" > <?php echo _("e-Mail"); ?> </div>
				<div class="8u 12u$(mobile)"><input type="text" name="email" placeholder="<?php echo _("E-mail"); ?>" value="<?php echo $edit_arr['email']; ?>" /></div>
				<div class="4u 12u$(mobile)" > <?php echo _("Password"); ?>  </div>
				<div class="8u 12u$(mobile)"><input type="text" name="password" placeholder="<?php echo _("Password"); ?>" /></div>

				<div class="4u 12u$(mobile)"><label> <?php echo _("Role"); ?> </label></div>
				<div class="8u 12u$(mobile)" >
					<select name="role" id="UserRole">
						<?php $userRoles = get_user_roles(); 
							foreach($userRoles as $role){ 
								echo '<option value="'.$role.'" '.($edit_arr['role'] == $role ? "selected" : '').' > '.$role.' </option>'; 										
							} ?>
					</select>
				</div>

				<div class="4u 12u$(mobile)"><label> <?php echo _("Theme"); ?> </label></div>
				<div class="8u 12u$(mobile)" >
					<select name="theme" id="theme">
						<?php $templates = available_themes_list(); 
							foreach($templates as $folder => $theme){ 
								echo '<option value="'.$folder.'" '.($edit_arr['theme'] == $folder ? "selected" : (get_active_theme() == $folder ? 'selected' : '')).' > '.$theme.' </option>'; 										
							} ?>
					</select>
				</div>				
			
				<div class="4u 12u$(mobile)"><label> <?php echo _("Company"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php 
					$companies = array();
					foreach($db_connections as $id => $single){
						$companies[$id] = $single['name'];
					}					
					$company_id = null; 
					if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0 ) { 
						// echo '<label> '.$db_connections[$edit_arr['selected_id']]['name'].'</label>';
						$company_id = $edit_arr['selected_id'];
						// echo '<input type="hidden" name="company_id" value="'.$edit_arr['selected_id'].'">';
					} elseif(isset($_POST['company_id'])) { 
						$company_id = $_POST['company_id'];
					}
					echo select_options_list('company_id', $companies, $company_id, 'no', null, null, 'CompanyPOS');  
					// }
					?>
				</div> 		
			
				<div class="4u 12u$(mobile)"><label> <?php echo _("Sales POS"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php 
					 
					if(isset($edit_arr['sales_pos_id']) && $edit_arr['sales_pos_id'] > 0 ) { 
						$sales_pos = FAGetAll('sales_pos', array('id' => $edit_arr['sales_pos_id'] ));
						$pos_id = $edit_arr['sales_pos_id'];
						//var_dump($sales_pos);
					} else 
						$pos_id = null;
					
						$pos = [];
						$sales_pos = FAGetAll('sales_pos', array('inactive' => 0 ));
						//var_dump($sales_pos);
						foreach($sales_pos as $single){
							$pos[$single['id']] = $single['pos_name'];
						}					
						// $pos_id = null;
						echo select_options_list('pos_id', $pos, $pos_id, 'no', null, null, 'POSList');  
					// }
					?>
				</div> 	
				
				<div class="4u 12u$(mobile)"><label> <?php echo _("Cash in Drawer"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php 
					$cash_accs = [];
					$cash_accounts = FAGetAll('bank_accounts', array('account_type' => '3'));
				
					foreach($cash_accounts as $single){
						$cash_accs[$single['id']] = $single['bank_account_name'];
					}					
					$pos_id = null; 
					if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0 ) { 
						echo '<label> '.FAGetSingleValue('bank_accounts', 'bank_account_name', array('id' => $edit_arr['cash_accounts'])).'</label>';
						echo '<input type="hidden" name="cash_accounts" value="'.$edit_arr['cash_accounts'].'">';
					} else { 
						echo select_options_list('cash_accounts', $cash_accs, null, 'no', null, null, 'cash_accounts');  
					}?>
				</div>
				
				<div class="4u 12u$(mobile)"><label> <?php echo _("Bank Account"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php 
					$bank_accs = [];
					$bank_accounts = FAGetAll('bank_accounts', array('account_type' => array('3', '<>' )));
					//var_dump($sales_pos);
					foreach($bank_accounts as $single){
						$bank_accs[$single['id']] = $single['bank_account_name'];
					}					
					$pos_id = null; 
					if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0 ) { 
						echo '<label> '.FAGetSingleValue('bank_accounts', 'bank_account_name', array('id' => $edit_arr['bank_accounts'])).'</label>';
						echo '<input type="hidden" name="bank_accounts" value="'.$edit_arr['bank_accounts'].'">';
					} else { 
						echo select_options_list('bank_accounts', $bank_accs, null, 'no', null, null, 'bank_accounts');  
					}?>
				</div> 	
					
				<div class="4u 12u$(mobile)"><label> Is </label></div>
				<div class="8u 12u$(mobile)" > <label> 
					<input type="checkbox" name="strict_dimension" value="yes" <?php echo (isset($edit_arr['strict_dimension']) && $edit_arr['strict_dimension'] == 1 ? 'checked' : '' ); ?> >  <?php echo _("Dimension  mandatory"); ?> </label>
				</div>

				 <?php  if ($use_dimension > 0){ 
                      echo '<div class="4u 12u$(mobile)"><label>'. _("Dimension").' </label></div>
				<div class="8u 12u$(mobile)">  ';
                      Dimensions_dropdown('dimension_id', 1, false, (isset($edit_arr['dimension_id']) ? $edit_arr['dimension_id'] : 0 ));
                      echo '</div></div>';
                 } else 
                 	echo '<hidden type="hidden" name="dimension_id" value="'.(isset($edit_arr['dimension_id']) ? $edit_arr['dimension_id'] : 0 ).'" >';

                 if ($use_dimension > 1){ 
                      echo '<div class="4u 12u$(mobile)"><label>'. _("Dimension 2").' </label></div>
				<div class="8u 12u$(mobile)">  ';
                      Dimensions_dropdown('dimension2_id', 2, false, (isset($edit_arr['dimension2_id']) ? $edit_arr['dimension2_id'] : 0 ));
                      echo '</div> 	';
                 } else 
                 	echo '<hidden type="hidden" name="dimension2_id" value="'.(isset($edit_arr['dimension2_id']) ? $edit_arr['dimension2_id'] : 0 ).'" >';?>
				
                 </div>
				<div class="SalesmanDetails row"> 
					<div class="12u 12u$(mobile)"><hr></div>
					<div class="4u 12u$(mobile)"><label> <?php echo _("Salesman"); ?> </label></div>
					<div class="8u 12u$(mobile)">  
					<?php 
						$posroles= array( 0 => 'New Salesman');
						$roles = FAGetAll('salesman', array('inactive' => 0 ));
						foreach($roles as $single){
							$posroles[$single['salesman_code']] = $single['salesman_name'];
						}		
						
						// if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0 ) { 
						// 	$pos_id = FAGetSingleValue('users', 'role_id', array('id' => $edit_arr['fa_user_id']));
						// } else 
						// 	$pos_id = 0;$none=null, $style=null, $class=null, $id=null
						echo select_options_list('s_id', $posroles, (isset($edit_arr['s_id']) ? $edit_arr['s_id'] : 0 ), 'no', null, null, 's_id');  
						?>
					</div> 


					<div class="4u 12u$(mobile)" > <?php echo _("Provision "); ?>  </div>
					<div class="8u 12u$(mobile)" > <input type="text" name="provision" placeholder="<?php echo _("Ex : 10000"); ?>" value="<?php echo $edit_arr['provision']; ?>" />
					</div>
					
					<div class="4u 12u$(mobile)" > <?php echo _("Provision 2"); ?>  </div>
					<div class="8u 12u$(mobile)" > <input type="text" name="provision2" placeholder="<?php echo _("Ex: 1500"); ?>" value="<?php echo $edit_arr['provision2']; ?>" />
					</div>
					
					<div class="4u 12u$(mobile)" > <?php echo _("Turnover Break Pt Level"); ?>  </div>
					<div class="8u 12u$(mobile)" > <input type="text" name="break_pt" placeholder="<?php echo _("Ex : 1.5"); ?>" value="<?php echo $edit_arr['break_pt']; ?>" />
					</div>	
					
					<div class="4u 12u$(mobile)" > <?php echo _("Salesman Phone"); ?>  </div>
					<div class="8u 12u$(mobile)" > <input type="text" name="salesman_phone" placeholder="<?php echo _("Phone No"); ?>" value="0" />
					</div>	
				<div class="4u 12u$(mobile)"><label> <?php echo _("FA Role"); ?> </label></div>
				<div class="8u 12u$(mobile)">  
				<?php 
					$posroles= array();
					$roles = FAGetAll('security_roles', array('inactive' => 0 ));
					foreach($roles as $single){
						$posroles[$single['id']] = $single['role'];
					}		
					
					if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0 ) { 
						$pos_id = FAGetSingleValue('users', 'role_id', array('id' => $edit_arr['fa_user_id']));
					} else 
						$pos_id = 0;
					echo select_options_list('role_id', $posroles, $pos_id, 'no');  
					?>
				</div> 	
				<div class="12u 12u$(mobile)"><hr></div>
			</div>
			
				<div class="4u 12u$(mobile)"><label> <?php echo _("Language"); ?> </label></div>
				<div class="8u 12u$(mobile)" >
					<?php $language_ar = GetLanguagesList();
					 echo select_options_list('language', $language_ar, $edit_arr['language'], 'no');  ?>
				</div>			

				<div class="4u 12u$(mobile)"><label> <?php echo _("Status"); ?> </label></div>
				<div class="8u 12u$(mobile)" > 
					<select name="status">
						<option value="Active" <?php if($edit_arr['status'] == 'Active') echo "selected"; ?> > Active </option>
						<option value="Inactive" <?php if($edit_arr['status'] == 'Inactive') echo "selected"; ?>> Inactive </option>
					</select>
				</div>
				<div class="4u 12u$(mobile)"><label>  </label></div>
				<div class="8u 12u$(mobile)" > <label> 
					<input type="checkbox" name="send_email" value="yes" >  <?php echo _("Send Password through mail"); ?> </label>
				</div>
				<div class="12u$">
					<input type="hidden" name="user_submit" value="yes">
					<?php if(isset($_GET['edit_id'])){ ?> 
						<input type="hidden" name="user_id" value="<?php echo $edit_arr['ID']; ?>" >
					<?php } ?>
					<input type="submit" name="submit" value="<?php echo $button_text; ?>" />
				</div>
			</div>
			</div>
			

			<div class="5u 12u$(mobile)" >
				<header><h3 class="alt"><span class="icon fa-ban"> </span> <?php echo 'Permissions'; ?> </h3></header>
				<?php if(isset($edit_arr['permissions'])){ 
					$permissions = unserialize($edit_arr['permissions']);					
				} else 
					$permissions = []; 
					$sql = "SELECT * FROM `".TB_PREF."modulepage` as mp  inner join `".TB_PREF."permission` as m on mp.id = m.module_no Group by mp.id";
					$array_list = db_query($sql, "can't get results");
					while ($permit = db_fetch($array_list)) {						
					// foreach ($array_list as $permit) {
						?>
						<div class="12u 12u$(mobile)"><label> <?php echo $permit['pageName']; ?> </label></div>
						<?php
						$query = GetDataFilter('permission', array('ID,page_permit'), array('module_no' => $permit['id']));
						
						foreach ($query as $page_content) { ?>
							<div class="2u 12u$(mobile)"><label> </label></div>
							<div class="8u 12u$(mobile)" > 
								<label><input type="checkbox" name="permissions[]" value="<?php echo $page_content['ID'] ?>" <?php if(!empty($permissions) && in_array($page_content['ID'], $permissions)) { echo 'checked'; } ?> >  <?php echo $page_content['page_permit']; ?> </label>
							</div>
						<?php }
						
					}?>
			</div>
			</div>
		</form>
	</div>
</section>
</div>
<style>
.page_header { display: none; }

</style>

<script>
$(function() {
	<?php if(isset($edit_arr['s_id']) && $edit_arr['s_id'] > 0  && $edit_arr['role'] == 'Salesman') { ?>	
		$(".SalesmanDetails").show();
	<?php } else { ?>
		$(".SalesmanDetails").hide();
	<?php } ?>
	$("#UserRole").on("change", function() {
		var role = $(this).val();
		if(role == 'Salesman'){
			$(".SalesmanDetails").show();
		} else
			$(".SalesmanDetails").hide();
	});

	$("#CompanyPOS").on("change", function(){
		var company_id = $(this).val();
		$.ajax({
             url: '<?php echo get_url(); ?>includes/kv-ajax.php?CompanyPOS='+company_id,
             type: 'post',
             dataType: 'json',
             success:function(response){
                 console.log(response);
                if(response != 'false'){
                	$('#POSList').find('option').remove().end();
                	$.each(response, function (key, val) {                		
                		$('#POSList').append('<option value="'+val.id+'">'+val.pos_name+'</option>');
                	});
                	$('#POSList').trigger('change');
                }
             }
		});
		$.ajax({
             url: '<?php echo get_url(); ?>includes/kv-ajax.php?CompanyBankAcc='+company_id,
             type: 'post',
             dataType: 'json',
             success:function(response){
                 console.log(response);
                if(response != 'false'){
                	$('#bank_accounts').find('option').remove().end();
                	$.each(response, function (key, val) {                		
                		$('#bank_accounts').append('<option value="'+val.id+'">'+val.bank_account_name+'</option>');
                	});
                }
             }
		});


		//Get Sales mans list
		$.ajax({
             url: '<?php echo get_url(); ?>includes/kv-ajax.php?getCompanySalesMansList='+company_id,
             type: 'post',
             dataType: 'json',
             success:function(response){
                 console.log(response);
                if(response != 'false'){
                	$('#s_id').find('option').remove().end();
                	$("#s_id").append('<option value="0"> New Salesman</option>');
                	$.each(response, function (key, val) {                		
                		$('#s_id').append('<option value="'+val.salesman_code+'">'+val.salesman_name+'</option>');
                	});
                }
             }
		});

		if($("#dimension_id").length){
			$.ajax({
	             url: '<?php echo get_url(); ?>includes/kv-ajax.php?getCompanydimensionList='+company_id+'&type=1',
	             type: 'post',
	             dataType: 'json',
	             success:function(response){
	                 console.log(response);
	                if(response != 'false'){
	                	$('#dimension_id').find('option').remove().end();
	                	$("#dimension_id").append('<option value="0"> Select a dimension</option>');
	                	$.each(response, function (key, val) {                		
	                		$('#dimension_id').append('<option value="'+val.salesman_code+'">'+val.salesman_name+'</option>');
	                	});
	                }
	             }
			});
		}
		if($("#dimension2_id").length){
			$.ajax({
	             url: '<?php echo get_url(); ?>includes/kv-ajax.php?getCompanydimensionList='+company_id+'&type=2',
	             type: 'post',
	             dataType: 'json',
	             success:function(response){
	                 console.log(response);
	                if(response != 'false'){
	                	$('#dimension2_id').find('option').remove().end();
	                	$("#dimension2_id").append('<option value="0"> Select a dimension</option>');
	                	$.each(response, function (key, val) {                		
	                		$('#dimension2_id').append('<option value="'+val.salesman_code+'">'+val.salesman_name+'</option>');
	                	});
	                }
	             }
			});
		}
	});
	$("#POSList").on("change", function(){
		var pos_id = $("#CompanyPOS").val();
		$.ajax({
             url: '<?php echo get_url(); ?>includes/kv-ajax.php?CompanyCashAcc='+pos_id,
             type: 'post',
             dataType: 'json',
             success:function(response){
                 console.log(response);
                if(response != 'false'){
                	$('#cash_accounts').find('option').remove().end();
                	$.each(response, function (key, val) {                		
                		$('#cash_accounts').append('<option value="'+val.id+'">'+val.bank_account_name+'</option>');
                	});
                }
             }
		});
	});
});
</script>