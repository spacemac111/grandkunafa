<?php 

define("CALL_CENTER_DB", 'grandkun_kvcodes_kot.0_');

function GetContactLocation($loc_id) {

	$sql = "SELECT * FROM ".CALL_CENTER_DB."contacts_kot_location WHERE id =".fadb_escape($loc_id);
	$res = fadb_query($sql, "Can't get location details");
	if(fadb_num_rows($res)){
		return fadb_fetch_assoc($res);
	} 
	return false;
}
if(!function_exists('TAGetSingleValue')) {
	function TAGetSingleValue($tablename, $column_single, $conditions=null, $order_by = null, $sql=false){
		$sql0 = "SELECT ".$column_single." FROM ".CALL_CENTER_DB.$tablename." WHERE 1=1";
		if($conditions){
			foreach($conditions as $key=>$value){
				$sql0 .= " AND {$key} = '${value}'";
			}
		}		
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		//if($sql)
		//	return $sql0;
		$result = fadb_query($sql0, "could not get sales type", $sql);
		$row = fadb_fetch_row($result);
		return $row[0];
	}
}

if(!function_exists('TAGetAll')) {
	function TAGetAll($table_name, $conditions = null, $order_by = null, $limit=0, $page = 0){
		$sql0 = "SELECT * FROM ".CALL_CENTER_DB.$table_name." WHERE 1=1";
		if($conditions != null) {
			foreach($conditions as $key=>$value){
				if(is_array($value)) { 
	                $sql0 .= " AND ".$key." ".$value[1]." ". fadb_escape($value[0]);
	            } else
	                $sql0 .= " AND {$key} =".fadb_escape($value);
				}
		}
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		if($limit>0){
			if($page > 0 ){
				$offset = ($page - 1)*$limit;				
				$sql0 .=" LIMIT ".$offset.", ".$limit;
			} else 
				$sql0 .=" LIMIT ".$limit;
		}
		$result = fadb_query($sql0, "Could not get data from {$table_name}");
		$data = array();
		while($row = fadb_fetch_assoc($result)) {
			$data[] = $row;
		}
		return $data;
	}
}


if(!function_exists('TAGetRow')) {
	function TAGetRow($table_name, $conditions = null, $order_by = null, $show_sql=false){
		$sql0 = "SELECT * FROM ".CALL_CENTER_DB.$table_name." WHERE 1=1";
		if($conditions != null) {
			foreach($conditions as $key=>$value){
				$sql0 .= " AND {$key} = '${value}'";
			}
		}
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		$sql0 .= ' LIMIT 1'; 
		$result = fadb_query($sql0, "Could not get data from {$table_name}", $show_sql);
		$data = fadb_fetch($result);
		
		return $data;
	}
}

if(!function_exists('TAGetDataJoin')) {
	function TAGetDataJoin($main_table, $joins, $columns=array(), $conditions=null, $order_by = null, $single=false, $sql=false, $limit = 0, $page=0){
		$sql0 = "SELECT ";
		if(count($columns)>0){
			foreach ($columns as $value) {
				$sql0 .= $value.",";
			}
			$sql0 = substr($sql0, 0, -1);
		}else{
			$sql0 .= " *";
		}
		$sql0 .= " FROM ".CALL_CENTER_DB."{$main_table} ";
		foreach ($joins as $value) {
			if(isset($value['join'])){
				$sql0 .= " {$value['join']} JOIN ".CALL_CENTER_DB.$value['table_name'].' ON '.$value['conditions'];
			}else{
				$sql0 .= " INNER JOIN ".CALL_CENTER_DB.$value['table_name'].' ON '.$value['conditions'];
			}
		}
		$sql0 .= " WHERE 1=1 ";
		if($conditions != null) {
			foreach($conditions as $key=>$value){
				if(is_array($value)){
					if($value[0] == 'OR')
						$sql0 .= " AND ({$key} = ".fadb_escape($value[1])." OR {$key} = ".fadb_escape($value[2])." )";
					else
						$sql0 .= " AND {$key} {$value[0]} ".fadb_escape($value[1]);
				} else 
					$sql0 .= " AND {$key} = ".fadb_escape($value);
			}
		}
		//echo $sql0;
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		if($single)
			$sql0 .= ' LIMIT 1'; 
		elseif($limit>0){
			if($page > 0 ){
				$offset = ($page - 1)*$limit;				
				$sql0 .=" LIMIT ".$offset.", ".$limit;
			} else 
				$sql0 .=" LIMIT ".$limit;
		}
		
		$result = fadb_query($sql0, "Could not get data!", $sql);
		if($single){
			$data = fadb_fetch($result);
		} else { 
			$data = array();
			while($row = fadb_fetch($result)) {
				$data[] = $row;
			}
		}
		
		return $data;
	}
}

function TAInsert($table_name, $data, $show_sql=false){
    $sql0 = "INSERT INTO ".TB_PREF.$table_name."(";
    $sql1 = " VALUES (";
    foreach($data as $key=>$value){
        $sql0 .= $key.",";
		if(is_array($value)) { 
			if($value[1] == 'date')				
				$sql1 .=  fadb_escape(date2sql($value[0])).",";
			if($value[1] == 'float')
				$sql1 .= $value.",";
            if($value[1] == 'noesc')
                $sql1 .= "'".$value[0]."',";
		}else 
			$sql1 .= fadb_escape($value).",";
    }
    $sql0 = substr($sql0, 0, -1).")";
    $sql1 = substr($sql1, 0, -1).")";
	fadb_query("SET CHARACTER SET utf8", "");
	fadb_query($sql0.$sql1, "Could not insert data to table {$table_name}", $show_sql);
	return  fadb_insert_id();
}

if(!function_exists('TADelete')) {
	function TADelete($table_name, $conditions){
		$sql0 = "DELETE FROM ".TB_PREF.$table_name." WHERE 1=1";
		foreach ($conditions as $key=>$value) {
			$sql0 .= " AND ".$key."=".$value;
		}
		$result = fadb_query($sql0, "Could not delete data from {$table_name}");
		return $result;
	}
}
if(!function_exists('TAUpdate')) {
	function TAUpdate($table_name, $primary_key, $data , $show_sql=false){

		if(kvcodesTAdb_Has_Data_on_Table($table_name, $primary_key)){
			$sql0 = "UPDATE ".TB_PREF.$table_name." SET ";
			foreach($data as $key=>$value){
				if(is_array($value)) { 
					if($value[1] == 'date')             
						$sql0 .= "`".$key."` = ". fadb_escape(date2sql($value[0])).",";
					if($value[1] == 'float')
						$sql0 .= "`".$key."` = ". $value.",";
					if($value[1] == 'noesc')
						$sql0 .= "`".$key."` = '". $value[0]."',";
				}else {
					$sql0 .= "`".$key."` = ".fadb_escape($value).",";
				}
			}
			$sql0 = substr($sql0, 0, -1);
			$sql0 .= " where 1=1";
			foreach($primary_key as $key=>$value){
				if(is_array($value)) { 
					if(isset($value[2]))
						$operator = $value[2];
					else
						$operator = '=';

					if($value[1] == 'date')             
						$sql0 .= " AND ".$key." ".$operator." ". fadb_escape(date2sql($value[0]));
					elseif($value[1] == 'float')
						$sql0 .= " AND ".$key." ".$operator." ". $value;
					else
						$sql0 .= " AND ".$key." ".$operator." ". fadb_escape($value[0]);
				}else{
					if(is_numeric($value)){
						$sql0 .=" AND ". $key." = ".$value;
					}else
					   $sql0 .= " AND ".$key." = ".fadb_escape($value);
				}
			}
		   return  fadb_query($sql0, "Could not update data on table {$table_name}", $show_sql);
		}else{
			foreach($primary_key as $key => $value){
				if($key != 'id')
					$data[$key] = $value;
			}
			return TAInsert($table_name, $data);
		}     
	}
}

if(!function_exists('kvcodesTAdb_Has_Data_on_Table')) {
	function kvcodesTAdb_Has_Data_on_Table($table_name, $primary_key =false){

		$sql = "SELECT COUNT(*) FROM ".TB_PREF.$table_name." WHERE 1=1";
		if($primary_key){
			foreach($primary_key as $key=>$value){
				if(is_array($value)) { 
					if($value[1] == 'date')             
						$sql .= " AND ".$key." = ". fadb_escape(date2sql($value[0])).",";
					if($value[1] == 'float')
						$sql .= " AND ".$key." = ". $value.",";
				}else{
					if(is_numeric($value)){
						$sql .=" AND ". $key." = ".$value;
					}else
					   $sql .= " AND ".$key." = ".fadb_escape($value);
				}
			}
		}
		return  kvcodes_check_empty_result($sql);
	}
}