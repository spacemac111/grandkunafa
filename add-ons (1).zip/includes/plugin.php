<?php
/**
 * The plugin API is located in this file, which allows for creating actions
 * and filters and hooking functions, and methods. The functions or methods will
 * then be run when the action or filter is called.
 *
 * The API callback examples reference functions, but can be methods of classes.
 * To hook methods, you'll need to pass an array one of two ways.
 *
 * Any of the syntaxes explained in the PHP documentation for the
 * {@link http://us2.php.net/manual/en/language.pseudo-types.php#language.types.callback 'callback'}
 * type are valid.
 */

// Initialize the filter globals.
global $kv_filter, $kv_actions, $merged_filters, $kv_current_filter;

if ( ! isset( $kv_filter ) )
	$kv_filter = array();

if ( ! isset( $kv_actions ) )
	$kv_actions = array();

if ( ! isset( $merged_filters ) )
	$merged_filters = array();

if ( ! isset( $kv_current_filter ) )
	$kv_current_filter = array();

function add_filter( $tag, $function_to_add, $priority = 10, $accepted_args = 1 ) {
	global $kv_filter, $merged_filters;

	$idx = _wp_filter_build_unique_id($tag, $function_to_add, $priority);
	$kv_filter[$tag][$priority][$idx] = array('function' => $function_to_add, 'accepted_args' => $accepted_args);
	unset( $merged_filters[ $tag ] );
	return true;
}


function has_filter($tag, $function_to_check = false) {
	// Don't reset the internal array pointer
	$kv_filter = $GLOBALS['wp_filter'];

	$has = ! empty( $kv_filter[ $tag ] );

	// Make sure at least one priority has a filter callback
	if ( $has ) {
		$exists = false;
		foreach ( $kv_filter[ $tag ] as $callbacks ) {
			if ( ! empty( $callbacks ) ) {
				$exists = true;
				break;
			}
		}

		if ( ! $exists ) {
			$has = false;
		}
	}

	if ( false === $function_to_check || false === $has )
		return $has;

	if ( !$idx = _wp_filter_build_unique_id($tag, $function_to_check, false) )
		return false;

	foreach ( (array) array_keys($kv_filter[$tag]) as $priority ) {
		if ( isset($kv_filter[$tag][$priority][$idx]) )
			return $priority;
	}

	return false;
}

function apply_filters( $tag, $value ) {
	global $kv_filter, $merged_filters, $kv_current_filter;

	$args = array();

	// Do 'all' actions first.
	if ( isset($kv_filter['all']) ) {
		$kv_current_filter[] = $tag;
		$args = func_get_args();
		_wp_call_all_hook($args);
	}

	if ( !isset($kv_filter[$tag]) ) {
		if ( isset($kv_filter['all']) )
			array_pop($kv_current_filter);
		return $value;
	}

	if ( !isset($kv_filter['all']) )
		$kv_current_filter[] = $tag;

	// Sort.
	if ( !isset( $merged_filters[ $tag ] ) ) {
		ksort($kv_filter[$tag]);
		$merged_filters[ $tag ] = true;
	}

	reset( $kv_filter[ $tag ] );

	if ( empty($args) )
		$args = func_get_args();

	do {
		foreach ( (array) current($kv_filter[$tag]) as $the_ )
			if ( !is_null($the_['function']) ){
				$args[1] = $value;
				$value = call_user_func_array($the_['function'], array_slice($args, 1, (int) $the_['accepted_args']));
			}

	} while ( next($kv_filter[$tag]) !== false );

	array_pop( $kv_current_filter );

	return $value;
}

function apply_filters_ref_array($tag, $args) {
	global $kv_filter, $merged_filters, $kv_current_filter;

	// Do 'all' actions first
	if ( isset($kv_filter['all']) ) {
		$kv_current_filter[] = $tag;
		$all_args = func_get_args();
		_wp_call_all_hook($all_args);
	}

	if ( !isset($kv_filter[$tag]) ) {
		if ( isset($kv_filter['all']) )
			array_pop($kv_current_filter);
		return $args[0];
	}

	if ( !isset($kv_filter['all']) )
		$kv_current_filter[] = $tag;

	// Sort
	if ( !isset( $merged_filters[ $tag ] ) ) {
		ksort($kv_filter[$tag]);
		$merged_filters[ $tag ] = true;
	}

	reset( $kv_filter[ $tag ] );

	do {
		foreach ( (array) current($kv_filter[$tag]) as $the_ )
			if ( !is_null($the_['function']) )
				$args[0] = call_user_func_array($the_['function'], array_slice($args, 0, (int) $the_['accepted_args']));

	} while ( next($kv_filter[$tag]) !== false );

	array_pop( $kv_current_filter );

	return $args[0];
}

function remove_filter( $tag, $function_to_remove, $priority = 10 ) {
	$function_to_remove = _wp_filter_build_unique_id( $tag, $function_to_remove, $priority );

	$r = isset( $GLOBALS['wp_filter'][ $tag ][ $priority ][ $function_to_remove ] );

	if ( true === $r ) {
		unset( $GLOBALS['wp_filter'][ $tag ][ $priority ][ $function_to_remove ] );
		if ( empty( $GLOBALS['wp_filter'][ $tag ][ $priority ] ) ) {
			unset( $GLOBALS['wp_filter'][ $tag ][ $priority ] );
		}
		if ( empty( $GLOBALS['wp_filter'][ $tag ] ) ) {
			$GLOBALS['wp_filter'][ $tag ] = array();
		}
		unset( $GLOBALS['merged_filters'][ $tag ] );
	}

	return $r;
}

function remove_all_filters( $tag, $priority = false ) {
	global $kv_filter, $merged_filters;

	if ( isset( $kv_filter[ $tag ]) ) {
		if ( false === $priority ) {
			$kv_filter[ $tag ] = array();
		} elseif ( isset( $kv_filter[ $tag ][ $priority ] ) ) {
			$kv_filter[ $tag ][ $priority ] = array();
		}
	}

	unset( $merged_filters[ $tag ] );

	return true;
}

function current_filter() {
	global $kv_current_filter;
	return end( $kv_current_filter );
}

function current_action() {
	return current_filter();
}

function doing_filter( $filter = null ) {
	global $kv_current_filter;

	if ( null === $filter ) {
		return ! empty( $kv_current_filter );
	}

	return in_array( $filter, $kv_current_filter );
}

function doing_action( $action = null ) {
	return doing_filter( $action );
}

function add_action($tag, $function_to_add, $priority = 10, $accepted_args = 1) {
	return add_filter($tag, $function_to_add, $priority, $accepted_args);
}

function do_action($tag, $arg = '') {
	global $kv_filter, $kv_actions, $merged_filters, $kv_current_filter;

	if ( ! isset($kv_actions[$tag]) )
		$kv_actions[$tag] = 1;
	else
		++$kv_actions[$tag];

	// Do 'all' actions first
	if ( isset($kv_filter['all']) ) {
		$kv_current_filter[] = $tag;
		$all_args = func_get_args();
		_wp_call_all_hook($all_args);
	}

	if ( !isset($kv_filter[$tag]) ) {
		if ( isset($kv_filter['all']) )
			array_pop($kv_current_filter);
		return;
	}

	if ( !isset($kv_filter['all']) )
		$kv_current_filter[] = $tag;

	$args = array();
	if ( is_array($arg) && 1 == count($arg) && isset($arg[0]) && is_object($arg[0]) ) // array(&$this)
		$args[] =& $arg[0];
	else
		$args[] = $arg;
	for ( $a = 2, $num = func_num_args(); $a < $num; $a++ )
		$args[] = func_get_arg($a);

	// Sort
	if ( !isset( $merged_filters[ $tag ] ) ) {
		ksort($kv_filter[$tag]);
		$merged_filters[ $tag ] = true;
	}

	reset( $kv_filter[ $tag ] );

	do {
		foreach ( (array) current($kv_filter[$tag]) as $the_ )
			if ( !is_null($the_['function']) )
				call_user_func_array($the_['function'], array_slice($args, 0, (int) $the_['accepted_args']));

	} while ( next($kv_filter[$tag]) !== false );

	array_pop($kv_current_filter);
}

function did_action($tag) {
	global $kv_actions;

	if ( ! isset( $kv_actions[ $tag ] ) )
		return 0;

	return $kv_actions[$tag];
}

function has_action($tag, $function_to_check = false) {
	return has_filter($tag, $function_to_check);
}

function remove_action( $tag, $function_to_remove, $priority = 10 ) {
	return remove_filter( $tag, $function_to_remove, $priority );
}


function remove_all_actions($tag, $priority = false) {
	return remove_all_filters($tag, $priority);
}


function plugin_basename( $file ) {
	global $kv_plugin_paths;

	foreach ( $kv_plugin_paths as $dir => $realdir ) {
		if ( strpos( $file, $realdir ) === 0 ) {
			$file = $dir . substr( $file, strlen( $realdir ) );
		}
	}

	$file = wp_normalize_path( $file );
	$plugin_dir = wp_normalize_path( WP_PLUGIN_DIR );
	$mu_plugin_dir = wp_normalize_path( WPMU_PLUGIN_DIR );

	$file = preg_replace('#^' . preg_quote($plugin_dir, '#') . '/|^' . preg_quote($mu_plugin_dir, '#') . '/#','',$file); // get relative path from plugins dir
	$file = trim($file, '/');
	return $file;
}

function wp_register_plugin_realpath( $file ) {
	global $kv_plugin_paths;

	// Normalize, but store as static to avoid recalculation of a constant value
	static $kv_plugin_path = null, $kvmu_plugin_path = null;
	if ( ! isset( $kv_plugin_path ) ) {
		$kv_plugin_path   = wp_normalize_path( WP_PLUGIN_DIR   );
		$kvmu_plugin_path = wp_normalize_path( WPMU_PLUGIN_DIR );
	}

	$plugin_path = wp_normalize_path( dirname( $file ) );
	$plugin_realpath = wp_normalize_path( dirname( realpath( $file ) ) );

	if ( $plugin_path === $kv_plugin_path || $plugin_path === $kvmu_plugin_path ) {
		return false;
	}

	if ( $plugin_path !== $plugin_realpath ) {
		$kv_plugin_paths[ $plugin_path ] = $plugin_realpath;
	}

	return true;
}

function plugin_dir_path( $file ) {
	return trailingslashit( dirname( $file ) );
}


function plugin_dir_url( $file ) {
	return trailingslashit( plugins_url( '', $file ) );
}

function register_activation_hook($file, $function) {
	$file = plugin_basename($file);
	add_action('activate_' . $file, $function);
}

function register_deactivation_hook($file, $function) {
	$file = plugin_basename($file);
	add_action('deactivate_' . $file, $function);
}
function register_uninstall_hook( $file, $callback ) {
	if ( is_array( $callback ) && is_object( $callback[0] ) ) {
		_doing_it_wrong( __FUNCTION__, __( 'Only a static class method or function can be used in an uninstall hook.' ), '3.1' );
		return;
	}

	$uninstallable_plugins = (array) get_option('uninstall_plugins');
	$uninstallable_plugins[plugin_basename($file)] = $callback;

	update_option('uninstall_plugins', $uninstallable_plugins);
}
?>