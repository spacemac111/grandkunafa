<?php 

require_once('../config.php' );
require('functions.php');

if(isset($_GET['export'])){
	$myFile = 'Ex'.get_site_title()."-".time().".xml";
	$mask = ABSPATH.NEEM_UPLOADS.'/'.'Ex*.*';
	array_map('unlink', glob($mask));

	$fh = fopen(ABSPATH.NEEM_UPLOADS.'/'.$myFile, 'w') or kv_die("can't open file");

	$rss_txt .= '<?xml version="1.0" encoding="utf-8"?>';
	$rss_txt .= "<rss version='2.0'>".PHP_EOL;

	$userquery = db_query("SELECT * FROM ".TB_PREF."users", "Can't run Export");

	if($userquery){
	    $rss_txt .= '<users>'.PHP_EOL;	    	
	    while($values_query = db_fetch_assoc($userquery))  {
		    $rss_txt .= '<user>';
		    $rss_txt .= '<ID>' .$values_query['ID']. '</ID>';
		    $rss_txt .= '<username>' .$values_query['username']. '</username>';
		    $rss_txt .= '<password>' .$values_query['password']. '</password>';
		    $rss_txt .= '<full_name>' .$values_query['full_name']. '</full_name>';
		    $rss_txt .= '<activation>' .$values_query['activation']. '</activation>';
		    $rss_txt .= '<email>' .$values_query['email']. '</email>';
		    $rss_txt .= '<role>' .$values_query['role']. '</role>';
		    $rss_txt .= '<status>' .$values_query['status']. '</status>';
		    $rss_txt .= '</user>'.PHP_EOL;
		}
		$rss_txt .= '</users>'.PHP_EOL;
	}
	$usrmetaquery = db_query("SELECT * FROM ".TB_PREF."usermeta", "Can't run Export");    
	
	if($usrmetaquery)  {
		$rss_txt .= '<usermeta>'.PHP_EOL;
		while($values_query = db_fetch_assoc($usrmetaquery))  {
	        $rss_txt .= '<user>';
	        $rss_txt .= '<ID>' .$values_query['ID']. '</ID>';
	        $rss_txt .= '<userID>' .$values_query['userID']. '</userID>';
	        $rss_txt .= '<meta_key>' .$values_query['meta_key']. '</meta_key>';
	        $rss_txt .= '<meta_value>' .$values_query['meta_value']. '</meta_value>';
	        $rss_txt .= '</user>'.PHP_EOL;
	    }
		$rss_txt .= '</usermeta>'.PHP_EOL;
	}
	
	$pagesquery = db_query("SELECT * FROM ".TB_PREF."pages", "Can't run Export");   
	if($pagesquery)  {
		$rss_txt .= '<pages>'.PHP_EOL;	    
	    while($values_query = db_fetch_assoc($pagesquery))  {
	        $rss_txt .= '<page>';
	        $rss_txt .= '<ID>' .$values_query['ID']. '</ID>';
	        $rss_txt .= '<authorID>' .$values_query['authorID']. '</authorID>';
	        $rss_txt .= '<pageTitle>' .$values_query['pageTitle']. '</pageTitle>';
	        $rss_txt .= '<isRoot>' .$values_query['isRoot']. '</isRoot>';
	        $rss_txt .= '<pageContent>' .$values_query['pageContent']. '</pageContent>';
	        $rss_txt .= '<slug>' .$values_query['slug']. '</slug>';
	        $rss_txt .= '<page_type>' .$values_query['page_type']. '</page_type>';
	        $rss_txt .= '<template>' .$values_query['template']. '</template>';
	        $rss_txt .= '<parentID>' .$values_query['parentID']. '</parentID>';
	        $rss_txt .= '<pDate>' .$values_query['parentID']. '</pDate>';
	        $rss_txt .= '<status>' .$values_query['parentID']. '</status>';
	        $rss_txt .= '</page>'.PHP_EOL;
	    }
		$rss_txt .= '</pages>'.PHP_EOL;
	}
	$pagemtaquery = db_query("SELECT * FROM ".TB_PREF."pagemeta", "Can't run Export");
	if($pagemtaquery)  {
		$rss_txt .= '<pagemeta>'.PHP_EOL;
	    
	    while($values_query = db_fetch_assoc($pagemtaquery))  {
	        $rss_txt .= '<page>';
	        $rss_txt .= '<ID>' .$values_query['ID']. '</ID>';
	        $rss_txt .= '<postID>' .$values_query['postID']. '</postID>';
	        $rss_txt .= '<meta_key>' .$values_query['meta_key']. '</meta_key>';
	        $rss_txt .= '<meta_value>' .$values_query['meta_value']. '</meta_value>';
	        $rss_txt .= '</page>'.PHP_EOL;
	    }
		$rss_txt .= '</pagemeta>'.PHP_EOL;
	}
	
	$query = db_query("SELECT * FROM ".TB_PREF."settings", "Can't run Export");
	if($query)  {
		$rss_txt .= '<settings>'.PHP_EOL;
	    while($values_query = db_fetch_assoc($query))  {
	        $rss_txt .= '<setting>';
	        $rss_txt .= '<ID>' .$values_query['ID']. '</ID>';
	        $rss_txt .= '<option_name>' .$values_query['option_name']. '</option_name>';
	        $rss_txt .= '<option_value>' .$values_query['option_value']. '</option_value>';
	        $rss_txt .= '</setting>'.PHP_EOL;
	    }
		$rss_txt .= '</settings>'.PHP_EOL;
	}
	$rss_txt .= '</rss>';
	fwrite($fh, $rss_txt);
	fclose($fh);
	echo get_url().NEEM_UPLOADS.'/'.$myFile;
}

if(isset($_GET['import'])){
	
}

