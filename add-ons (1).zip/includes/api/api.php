<?php    
	
	require_once("Rest.inc.php");
	include("../../config.php");
	require_once("../class-phpass.php");

	class API extends REST {
	
		public $data = "";
		
		private $db = NULL;
	
		public function __construct(){
			parent::__construct();				// Init parent contructor
			$this->dbConnect();					// Initiate Database connection
		}
		
		/*
		 *  Database connection 
		 */
		private function dbConnect(){			
			$this->db = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);			
		}
		
		/*
		 * Public method for access api.
		 * This method dynmically call the method based on the query string
		 */
		public function processApi(){
			$func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));
			if((int)method_exists($this,$func) > 0)
				$this->$func();
			else
				$this->response('',404);	// If the method not exist with in this class, response would be "Page not found".
		}
		
		/* 
		 *	Simple login API
		 *  Login must be POST method
		 *  email : <USER EMAIL>
		 *  pwd : <USER PASSWORD>
		 */
		public function login(){ // Cross validation if the request method is POST else it will return "Not Acceptable" status
			if($this->get_request_method() != "POST"){
				$this->response('',406);
			}
			
			$email = $this->_request['email'];		
			$password = $this->_request['pwd'];
			$return  = null;
			if(!empty($email) and !empty($password)){
				if(filter_var($email, FILTER_VALIDATE_EMAIL)){
					$query = "SELECT ID, password FROM `".TB_PREF."users` WHERE email = '".$email."' AND status = 'Active' LIMIT 1";
					$sql = mysqli_query($this->db, $query);
					if(mysqli_num_rows($sql) > 0){
						$result = mysqli_fetch_array($sql,MYSQLI_NUM);
						$wp_hasher = new PasswordHash(16, true);
						if($wp_hasher->CheckPassword($password, $result[1])) 
							$return  = $result[0];
					}					
				}
			}			
			return $return;
		}

		/*
		 *	Inserting...
		 */
		function InsertLogin(){
			if($this->login() > 0){
				$table_name = $this->_request['table'];	
				$email = $this->_request['email'];		
				$password = $this->_request['pwd'];
				$data = $this->_request['data'];

			    $sql0 = "INSERT INTO ".TB_PREF.$table_name." (";
			    $sql1 = " VALUES (";
			    foreach($data as $key=>$value){
			        $sql0 .= $key.",";
					if(is_array($value)) { 
						if($value[1] == 'date')				
							$sql1 .=  $this->db_escape($value[0]).",";
						if($value[1] == 'float')
							$sql1 .= $value.",";
					}else {
						if($key == 'password'){
							$wp_hasher = new PasswordHash(16, true);
                     		$value = $wp_hasher->HashPassword( trim( $value ) );
						}						
						$sql1 .= $this->db_escape($value).",";
					}
			    }
			    $sql0 = substr($sql0, 0, -1).")";
			    $sql1 = substr($sql1, 0, -1).")";
			    //$string =  str_replace('\"', '',$sql0.$sql1);
			    $string = stripslashes($sql0.$sql1);
			   // $this->response($string, 400);
				$sql = mysqli_query($this->db, $sql0.$sql1);
				if(mysqli_insert_id($this->db) > 0){				
					$this->response($this->json(array( 'inserted_id' => mysqli_insert_id($this->db))), 200);
				}
				//$this->response('', 204);
				$error = array('status' => "Failed", "msg" => "Failed To Insert ".$string);
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}

		function GetAllCompanyFiles(){
			$login =$this->login();
			if( $login > 0){	//$this->response($this->json(array("id" => $this->login() )), 400);
				$table_name = $this->_request['table'];	
				$company_name = $this->_request['company'];	
				//print_r($this->_request);
				$sql = "SELECT * FROM `".TB_PREF."users` WHERE name='".$company_name."' LIMIT 1";
				$sql_res = mysqli_query($this->db, $sql);  
			    if(mysqli_num_rows($sql_res) > 0){
					if($row =  mysqli_fetch_array($sql_res, MYSQLI_ASSOC)){
						//$this->response($this->json(array($row['ID'] => $row['name'])), 200);
						$sql0 = "SELECT id, userid, date_time, attach_id, status, Doc_type FROM `".TB_PREF.$table_name."` WHERE userid=".$row["ID"]." ORDER BY id DESC";   //  echo $sql0;
					    $result = array();
					    //$this->response($this->json(array($sql0)), 200);
					    $sql = mysqli_query($this->db, $sql0);  
					    if(mysqli_num_rows($sql) > 0){
							while($row =  mysqli_fetch_array($sql, MYSQLI_ASSOC)){
								$result[] = $row;
							}	        				
							$this->response($this->json($result), 200);
						}else{
							$error=array('status' => "Failed", "msg" => "Sorry No data found.");
							$this->response($this->json($error), 400);		
						}
					}
				}else{
					$error=array('status' => "Failed", "msg" => "Sorry Company data's not found.");
					$this->response($this->json($error), 400);		
				}

			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.".$login);
				$this->response($this->json($error), 400);
			}
			
			$this->response('', 204);	// If no records "No Content" status
			$error = array('status' => "Failed", "msg" => "Sorry It's Not Working");
			$this->response($this->json($error), 400);
		}

		function GetAll(){
			$login =$this->login();
			if( $login > 0){	//$this->response($this->json(array("id" => $this->login() )), 400);
				$table_name = $this->_request['table'];	
				if(isset($this->_request['conditions']))
					$conditions = $this->_request['conditions'];	
				else 
					$conditions = null;

				if(isset($this->_request['order_by']))
					$order_by = $this->_request['order_by'];	
				else 
					$order_by = null;	

			    $sql0 = "SELECT * FROM ".TB_PREF.$table_name." WHERE 1=1";
			    if($conditions != null) {
					foreach($conditions as $key=>$value){
						$sql0 .= " AND {$key} = '${value}'";
					}
			    }
			    if($order_by != null) {
			        $sql0 .=" ORDER BY ";
			        foreach($order_by as $key=>$value){
			            $sql0 .= " {$key} ${value}";
			        }
			    }  //  echo $sql0;
			    $sql = mysqli_query($this->db, $sql0);  
			    if(mysqli_num_rows($sql) > 0){
					while($row =  mysqli_fetch_array($sql, MYSQLI_ASSOC)){
						$result[] = $row;
					}	        				
					$this->response($this->json($result), 200);
				}
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.".$login);
				$this->response($this->json($error), 400);
			}
			
			$this->response('', 204);	// If no records "No Content" status
			$error = array('status' => "Failed", "msg" => "Sorry It's Not Working");
			$this->response($this->json($error), 400);
		}

		function GetRow(){
			if($this->login() > 0){
				$table_name = $this->_request['table'];	
				$conditions = $this->_request['conditions'];
				if(isset($this->_request['order_by']))
					$order_by = $this->_request['order_by'];	
				else 
					$order_by = null;	   
			    $sql0 = "SELECT * FROM ".$table_name." WHERE 1=1";
			    if($conditions != null) {
					foreach($conditions as $key=>$value){
						$sql0 .= " AND {$key} = '${value}'";
					}
			    }
			    if($order_by != null) {
			        $sql0 .=" ORDER BY ";
			        foreach($order_by as $key=>$value){
			            $sql0 .= " {$key} ${value}";
			        }
			    }  //  echo $sql0;
			    $sql0 .= " LIMIT 1"; 
			    $sql = mysqli_query($this->db, $sql0);  
			    if(mysqli_num_rows($sql) > 0){
					if($row =  mysqli_fetch_array($sql, MYSQLI_ASSOC))        				
						$this->response($this->json($row), 200);
					else
						$this->response(array('status' => "Failed", "msg" => "Sorry It's Not Working"), 400);
				}
				$this->response('', 204);	// If no records "No Content" status
				$error = array('status' => "Failed", "msg" => "Sorry It's Not Working");
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}

		/*
		 *	Update with multiple primary keys...
		 */
		function Update( ){
			if($this->login() > 0){
				$table_name = $this->_request['table'];
				$primary_key = $this->_request['conditions'];
				$data  = $this->_request['data'];
			    $sql0 = "UPDATE ".TB_PREF.$table_name." SET ";
			    foreach($data as $key=>$value){
			        if(is_array($value)) { 
			            if($value[1] == 'date')             
			                $sql0 .= $key." = ". $this->db_escape($value[0]).",";
			            if($value[1] == 'float')
			                $sql0 .= $key." = ". $value.",";
			        }else 
			            $sql0 .= $key." = ".$this->db_escape($value).",";
			    }
			    $sql0 = substr($sql0, 0, -1);
			    $sql0 .= " where ";

			     foreach($primary_key as $key=>$value){
			        if(is_array($value)) { 
			            if($value[1] == 'date')             
			                $sql0 .= $key." = ". $this->db_escape($value[0]).",";
			            if($value[1] == 'float')
			                $sql0 .= $key." = ". $value.",";
			        }else 
			            $sql0 .= $key." = ".$this->db_escape($value).",";
			    }
			    $sql0 = substr($sql0, 0, -1);

			    $sql_result = mysqli_query($this->db, $sql0);   
			    $report = array('status' => "Update", "msg" => $sql_result);
				$this->response($this->json($report), 200);   
		    }else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}		

		function GetSingleValue(){
			if($this->login() > 0){
				$tablename = $this->_request['table'];	
				$column_single = $this->_request['column_single'];	
				if(isset($this->_request['conditions']))
					$conditions = $this->_request['conditions'];
				else
					$conditions = null; 

				$sql0 = "SELECT ".$column_single." FROM ".TB_PREF.$tablename." WHERE 1=1";
			    if($conditions != null) {
			        foreach($conditions as $key=>$value){
			            if(is_numeric($value))
			                $sql0 .= " AND {$key} = ${value}";
			            else
			                $sql0 .= " AND {$key} = '${value}'";
			        }
			    }  
			    $sql = mysqli_query($this->db, $sql0);  
			    if(mysqli_num_rows($sql) > 0){
					if($row =  mysqli_fetch_array($sql, MYSQLI_ASSOC))        				
						$this->response($this->json($row), 200);
					else
						$this->response(array('status' => "Failed", "msg" => "Sorry It's Not Working"), 400);
				}
				$this->response('', 204);	// If no records "No Content" status
				$error = array('status' => "Failed", "msg" => "Sorry It's Not Working");
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}
		function Delete(){
			if($this->login() > 0){
				$table_name = $this->_request['table'];	
				$conditions = $this->_request['conditions'];

			    $sql0 = "DELETE FROM ".TB_PREF.$table_name." WHERE 1=1";
			    foreach ($conditions as $key=>$value) {
			        if(is_numeric($value))
			            $sql0 .= " AND ".$key."=".$value;
			        else
			            $sql0 .= " AND ".$key."='".$value."'";
			    }
			    $sql = mysqli_query($this->db, $sql0);
				if(mysqli_affected_rows($this->db) > 0){				
					$this->response($this->json(array( 'Delete Count' => mysqli_affected_rows($this->db), 'msg' => true)), 200);
				}
				$this->response('', 204);
				$error = array('status' => "Failed", "msg" => "Failed To Delete");
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}

		function GetDataJoin(){
			if($this->login() > 0){	
				$main_table = $this->_request['table'];	
				$joins = $this->_request['joins'];
				if($this->_request['columns'])
					$columns = $this->_request['columns'];
				else
					$columns = array();
				if(isset($this->_request['conditions']))
					$conditions = $this->_request['conditions'];
				else
					$conditions = null; 

			    $sql0 = "SELECT ";
			    if(count($columns)>0){
			        foreach ($columns as $value) {
			            $sql0 .= $value.",";
			        }
			        $sql0 = substr($sql0, 0, -1);
			    }else{
			        $sql0 .= " *";
			    }
			    $sql0 .= " FROM "."{$main_table} ";
			    foreach ($joins as $value) {
			        if(isset($value['join'])){
			            $sql0 .= " {$value['join']} JOIN ".$value['table_name'].' ON '.$value['conditions'];
			        }else{
			            $sql0 .= " INNER JOIN ".$value['table_name'].' ON '.$value['conditions'];
			        }
			    }
			    $sql0 .= " WHERE 1=1 ";
			    foreach($conditions as $key=>$value){
			        $sql0 .= " AND {$key} = ${value}";
			    }
			    $sql = mysqli_query($this->db, $sql0);  
			    if(mysqli_num_rows($sql) > 0){
					while($row =  mysqli_fetch_array($sql, MYSQLI_ASSOC))
	        				$result[] = $row;
					$this->response($this->json($result), 200);
				}
				$this->response('', 204);	// If no records "No Content" status
				$error = array('status' => "Failed", "msg" => "Sorry It's Not Working");
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}

		function GetDataFilter(){
			if($this->login() > 0){
			    $table_name = $this->_request['table'];	
				$email = $this->_request['email'];		
				$password = $this->_request['pwd'];
				$joins = $this->_request['joins'];	
				$columns = $this->_request['columns'];
				
				if(isset($this->_request['conditions']))
					$conditions = $this->_request['conditions'];
				else
					$conditions = null; 

				if(isset($this->_request['order_by']))
					$order_by = $this->_request['order_by'];
				else
					$order_by = null; 

			     $sql0 = "SELECT ";
			   
			    if(count($columns)>0){
			        foreach ($columns as $value) {
			            $sql0 .= $value.",";
			        }
			    }else{
			        $sql0 .= " * ";
			    }
			    // remove the last character ','
			    $sql0 = substr($sql0, 0, -1);
			    $sql0 .= " FROM ".$table_name." WHERE 1=1 ";
			    if($conditions){
			        foreach($conditions as $key=>$value){
			            if(is_numeric($value))
			                $sql0 .= " AND {$key} = ${value}";
			            else
			                $sql0 .= " AND {$key} = '${value}'";
			        }
			    }  

			    if($order_by != null) {
			        $sql0 .=" ORDER BY ";
			        foreach($order_by as $key=>$value){
			            $sql0 .= " {$key} ${value}";
			        }
			    }
			   // echo $sql0;
			    $sql0 .= " LIMIT 1"; 
			    $sql = mysqli_query($this->db, $sql0);  
			    if(mysqli_num_rows($sql) > 0){
					if($row =  mysqli_fetch_array($sql, MYSQLI_ASSOC))        				
						$this->response($this->json($row), 200);
					else
						$this->response(array('status' => "Failed", "msg" => "Sorry It's Not Working"), 400);
				}
				$this->response('', 204);	// If no records "No Content" status
				$error = array('status' => "Failed", "msg" => "Sorry It's Not Working");
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}
		
		/*
		 *	Inserting...
		 */
		function Insert(){
			if($this->login() > 0){
				$table_name = $this->_request['table'];	
				$email = $this->_request['email'];		
				$password = $this->_request['pwd'];
				$data = $this->_request['data'];

			    $sql0 = "INSERT INTO ".TB_PREF.$table_name." (";
			    $sql1 = " VALUES (";
			    foreach($data as $key=>$value){
			        $sql0 .= $key.",";
					if(is_array($value)) { 
						if($value[1] == 'date')				
							$sql1 .=  $this->db_escape($value[0]).",";
						if($value[1] == 'float')
							$sql1 .= $value.",";
					}else 
						$sql1 .= $this->db_escape($value).",";
			    }
			    $sql0 = substr($sql0, 0, -1).")";
			    $sql1 = substr($sql1, 0, -1).")";
			    //$string =  str_replace('\"', '',$sql0.$sql1);
			    $string = stripslashes($sql0.$sql1);
			   // $this->response($string, 400);
				$sql = mysqli_query($this->db, $sql0.$sql1);
				if(mysqli_insert_id($this->db) > 0){				
					$this->response($this->json(array( 'inserted_id' => mysqli_insert_id($this->db))), 200);
				}
				//$this->response('', 204);
				$error = array('status' => "Failed", "msg" => "Failed To Insert ".$string);
				$this->response($this->json($error), 400);
			}else{
				$error = array('status' => "Failed", "msg" => "Sorry You are not authenticated.");
				$this->response($this->json($error), 400);
			}
		}

		public	function db_escape($value = "", $nullify = false){			
			$value = @html_entity_decode($value);
			$value = @htmlspecialchars($value);

		  	//reset default if second parameter is skipped
			$nullify = ($nullify === null) ? (false) : ($nullify);

		  	//check for null/unset/empty strings
			if ((!isset($value)) || (is_null($value)) || ($value === "")) {
				$value = ($nullify) ? ("NULL") : ("''");
			} else {
				if (is_string($value)) {
		      		//value is a string and should be quoted; determine best method based on available extensions
					if (function_exists('mysqli_real_escape_string')) {
				  		$value = "'" . mysqli_real_escape_string($this->db, $value) . "'";
					} else {
					  $value = "'" . mysqli_escape_string($this->db, $value) . "'";
					}
				} else if (!is_numeric($value)) {
					//value is not a string nor numeric
					display_error("ERROR: incorrect data type send to sql query");
					echo '<br><br>';
					exit();
				}
			}
			return $value;
		}


		/*
		 *	Encode array into JSON
		 */
		private function json($data){
			if(is_array($data)){
				return json_encode($data);
			}
		}
	}
	
	// Initiiate Library
	
	$api = new API;
	$api->processApi();
?>