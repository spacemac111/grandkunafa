<?php

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/
global $language_codes, $installed_languages, $thoseps, $decseps; 
if (defined('DEBUGGING') && DEBUGGING > 0)
	error_reporting(-1);
else
	error_reporting( E_CORE_ERROR | E_CORE_WARNING | E_COMPILE_ERROR | E_ERROR | E_WARNING | E_PARSE | E_USER_ERROR | E_USER_WARNING | E_RECOVERABLE_ERROR );

ini_set("log_errors", 1);
ini_set("error_log", "neem_errors.log");

if(!defined('ABSPATH')){
	define( 'ABSPATH', dirname(dirname(__FILE__)). "/" );
}

$thoseps 		= array(",", ".", " ");
$decseps 		= array(".", ",");


if ( file_exists( ABSPATH . 'config.php') ) { /** The config file resides in ABSPATH */
	require_once( ABSPATH . 'config.php' );
	ini_set('display_errors', DEBUGGING);
	$db = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);
	if(!$db){
		kv_die( "Sorry! There seems to be a problem connecting to our database.");
	}else{
		require_once(ABSPATH."includes/db-functions.php");
		$schecking = check_empty_result(); 

		if(is_bool($schecking) && $schecking == true){}else{
			kv_die($schecking);
		}
	}	
	
} else{
	$final_url = str_replace( '\\', '/', get_neem_root_base());
	//$last_string_url = substr($final_url, -1);
	//echo $last_string_url.'----';
	//if($last_string_url == '/')
	//	$final_url = substr($final_url, 0, -1); 
	$url = "document.location.origin+'/".$final_url."install.php'";
	$url = str_replace( '//', '/', $url);
	
	echo "\n<script type=\"text/javascript\">\n"
		. "<!--\n"
		. " window.location={$url};\n"
		. "-->\n"
		. "</script>\n"; 
	echo $url ;
	echo '<center><h1> Error Connecting Database!. Config.php is missing</h1></center>';
	exit(0);
}
require_once(ABSPATH.'includes/lang/gettext.inc');
 get_text_init();

	 global $GetText, $current_user;
	 $current_user = kv_get_current_user();
	if($current_user['language'])
		$dflt_lang = $current_user['language'];
	else
		$dflt_lang = get_default_language();	
	//$lang = array_search_value($dflt_lang, $installed_languages,  'code');
	//echo $dflt_lang;
	$GetText->set_language($dflt_lang, strtoupper('utf-8'));
	if($dflt_lang != 'en_US'){		
		if (file_exists(dirname(dirname(__FILE__)).'/lang/'.$dflt_lang.'/LC_MESSAGES/'.$dflt_lang.'.po'))
			$GetText->add_domain($dflt_lang, dirname(dirname(__FILE__)) . "/lang");		
	}


function GetPageSlug($url_string){
	$url_string = strtolower($url_string);
	$site_url = get_site_option('site_url');
	if(strpos($site_url, 'https://') !== false){
		$url_string = 'https://'.$url_string;
	}elseif(strpos($site_url, 'http://') !== false){
		$url_string = 'http://'.$url_string;
	}
	$len = strlen($site_url);

	$url_string = substr($url_string, $len); 
	$pos_end = stripos($url_string, '?');
	
	if($pos_end){		
		$ret = substr($url_string, 0, $pos_end);
		return $ret;
	}else
		return $url_string;
}
function get_encoding(){
	return (defined('ENCODING') ? ENCODING : 'UTF-8' );
}

function get_default_language(){
	$selected_language = get_site_option('Default_Language'); 
	return ($selected_language ? $selected_language : 'en_US' );
}

function GetLanguagesList($selected=null){
	global $language_codes, $installed_languages; 
	$path = dirname(dirname(__FILE__)).'/lang';
	$FilesAndFolders = array_diff(scandir($path), array('.', '..'));
	$languages = ['C' => 'English'];
	$installed_languages = [['code' => 'C', 'encoding' => 'utf-8']];
	foreach ($FilesAndFolders as $single) {	
		$lang = $path .'/'. $single;
		$po = $lang.'/LC_MESSAGES/'.$single.'.po';
		$mo = $lang.'/LC_MESSAGES/'.$single.'.mo';
        if (is_dir($lang) && file_exists($po) && file_exists($mo)) {
        	$languages[$single] = $language_codes[substr($single, 0, 2)];
        	$installed_languages[] = ['code' => $single, 'encoding' => 'utf-8'];
        }
    }
   
	return $languages; 
}

if (!function_exists("_")) {
	function _($text) {
		global $GetText;
		if (!isset($GetText)) // Don't allow using gettext if not is net.
			return $text;

		$retVal = $GetText->gettext($text);
		if ($retVal == "")
			return $text;
		return $retVal;
	}
}
function GetTablelist($cid){
	global $db_connections;
	$sql = "SELECT value FROM ".$db_connections[$cid]['dbname'].'.'.$db_connections[$cid]['tbpref']."sys_prefs WHERE name ='table_no';";
	$res = db_query($sql, "");

	if(db_num_rows($res)> 0){
		$selected_tabl = db_fetch($res);
		$selected_table = $selected_tabl['value'];
	}else
		$selected_table = get_site_option('table_no');
	$tbl_select = '';
	$tbl_select .= '<select name ="table_no_'.$cid.'" id="table_no"><option value="-1" > None </option>';

	foreach (range(1, 85) as $number) {
    	$tbl_select .='<option value= "'.$number.'" '.($selected_table == $number ? 'selected' : '' ).'>'.$number.'</option>';
	}
	$tbl_select .="</select>";
	return $tbl_select;
}

//require_once(ABSPATH."includes/email.class.php");
require_once(ABSPATH."includes/class-phpass.php");
require_once(ABSPATH."includes/shortcuts.php");
require_once(ABSPATH."includes/PHPMailer/PHPMailerAutoload.php");
require_once(ABSPATH."includes/callcenter.php");

global $default_menu_items, $actions_array;

	$default_menu_items = array(
			0 => array(
				get_url("admin"),//url parameter
				'th-large', // Icon
				'Dashboard', // Name
				'dashboard_fn', // function name	
				array('Auditor', 'Administrator')  // Author Roles
			 ), 

			5 => array(
				get_url("admin")."pages.php",//url parameter
				'clone', // Icon
				'Pages', // Name
				'dashboard_fn', // function name
				array('Author', 'Administrator')  // Author Roles
			 ),

			6 => array(
				get_url("admin")."medias.php",//url parameter
				'paperclip', // Icon
				'Medias', // Name
				'dashboard_fn', // function name
				array('Author', 'Administrator')  // Author Roles
			 ),
			
			
			10 => array(
				get_url("admin")."themes.php",//url parameter
				'tv', // Icon
				'Appearance', // Name
				'theme_function', // function name	
				array('Author', 'Administrator')  // Author Roles
			 ),

			11 => array(
				get_url("admin")."plugins.php",//url parameter
				'plug', // Icon
				'Plugins', // Name
				'theme_function', // function name	
				array('Author', 'Administrator')  // Author Roles
			 ),

			15 => array(
				get_url("admin")."users.php",//url parameter
				'users', // Icon
				'Users', // Name
				'logout_fn', // function name	
				array('Author', 'Administrator')  // Author Roles
			 ),
			20=> array(
				get_url("admin")."permissions.php",//url parameter
				'ban', // Icon
				'Permissions', // Name
				'logout_fn', // function name	
				array('Author', 'Administrator')  // Author Roles
			 ),

			25 => array(
				get_url("admin")."options.php",//url parameter
				'gear', // Icon
				'Settings', // Name
				'logout_fn', // function name	
				array('Author', 'Administrator')  // Author Roles
			 ),

			35 => array(
				get_url("admin")."version.php",//url parameter
				'refresh', // Icon
				'Version', // Name
				'logout_fn', // function name	
				array('Author', 'Administrator')  // Author Roles
			 ),

			100 => array(
				get_url("admin")."?logout",//url parameter
				'power-off', // Icon
				'Logout', // Name
				'logout_fn', // function name	
				array('Author', 'Administrator')  // Author Roles
			 )			
	);	
if($current_user['username'] != 'kvcodes') {	
	unset($default_menu_items[5]);
	unset($default_menu_items[6]);
	unset($default_menu_items[10]);
	unset($default_menu_items[11]);
}

require_once(ABSPATH.'/includes/erp/fadb.php');
require_once(ABSPATH.'/includes/erp/erp_functions.php');

if(file_exists('callcenter.php')){
	include_once('callcenter.php');
}
if(file_exists(get_current_theme_abs_path().'functions.php')){
	include_once(get_current_theme_abs_path().'functions.php');
}

function add_action($array_to_add, $action_name){
	global $actions_array; 
	$actions_array[$array_to_add] = $action_name; 
}

function do_action($action_load){
	global $actions_array; 
	if(function_exists($actions_array[$action_load]))
		$actions_array[$action_load]();
}
function get_neem_root_base(){
	
	$doc_root = str_replace( '/', '\\', $_SERVER["DOCUMENT_ROOT"] )."\\";
	$doc_path = str_replace( '/', '\\', dirname(dirname(__FILE__))) . "\\";

	$first_pos = strlen($_SERVER["DOCUMENT_ROOT"]);
	$base_path = substr($doc_path, $first_pos);
	//echo $first_pos .'---'. $doc_root.'--'.$doc_path .'--'.$base_path; 
	return $base_path;
}

function get_menus_dropdown(){
	$menus_list = '';
	$menus = GetDataFilter('pages', array('DISTINCT template'), array('status' => 'Published', 'page_type' => 'neem_menu'));
	$menus_list .= '<select name="neem_menus" id="neem_menus" > <option value="-1" > None </option>';
	if(!empty($menus)){		
		foreach($menus as $menu){
			$menus_list .='<option value="'.$menu['template'].'" > '.$menu['template'].'</option>';
		}		
	}
	$menus_list .= '</select>'; 
	return $menus_list;
}
function add_menu_item($Title, $slug, $fn_name,  $roles_ar, $position=null, $Icon='gear'){
	global $default_menu_items;
	//print_r($default_menu_items);

	$keys = array_key_exists($position, $default_menu_items);
	
	$default_menu_items[$position] = array(
				$slug, //url parameter
				$Icon, // Icon
				$Title, // Name
				$fn_name, // function name
				$roles_ar  // Author Roles
	);
	//print_r($default_menu_items);
}

function is_ssl() {
	if ( isset($_SERVER['HTTPS']) ) {
		if ( 'on' == strtolower($_SERVER['HTTPS']) )
			return true;
		if ( '1' == $_SERVER['HTTPS'] )
			return true;
	} elseif ( isset($_SERVER['SERVER_PORT']) && ( '443' == $_SERVER['SERVER_PORT'] ) ) {
		return true;
	}
	return false;
}


function kv_die($msg){
	die('<div style=" margin: 0 auto; margin-top: 10%; padding: 2%; line-height: 24px; font-size: 18px;  width: 280; border: 1px solid #9E9E9E; background: #e4e4e4; ">'.$msg.'</div>');
}

if (!defined('included')){
	kv_die('You cannot access this file directly!');
}

$time_out = get_site_option('login_timeout');

if($time_out >0 ) {
	if (isset($_SESSION['CREATED']) && time() - $_SESSION['CREATED'] > $time_out) {		
		unset($_SESSION['CREATED']);     
		// unset $_SESSION variable for the run-time 
		//session_destroy();   // destroy session data in storage
	}
}

if(isset($_SESSION['failed_retry']) && $_SESSION['failed_retry'] == 3){
	$time_failed_out = 86400;
} elseif(isset($_SESSION['failed_retry']) && $_SESSION['failed_retry'] == 2){
	$time_failed_out = 3600;
}else 
	$time_failed_out = 300;

if (isset($_SESSION['Failed_login']) && time() - $_SESSION['Failed_login'] > $time_failed_out) {		
	unset($_SESSION['Failed_login']);  
	unset($_SESSION['retries']);  
	if(isset($_SESSION['failed_retry']))
		$_SESSION['failed_retry']++; 
	else
		$_SESSION['failed_retry']= 0; 
}

//log user in ---------------------------------------------------
function login($user, $pass, $rememberme, $redirect_to){
	global $db, $db_connections, $def_coy; 
	if(defined('FA_PATH'))
		include_once(FA_PATH.'/config_db.php');
   	//strip all tags from variable   
   	$user = login_db_escape($user);
  	$pass = login_db_escape($pass);
  	$access="false";
  	$response=$_POST["g-recaptcha-response"];
  	if(isset($response)) {
  		$secret_key = get_site_option('google_secret_key'); 	
		$verify=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secret_key}&response={$response}");
		$captcha_success=json_decode($verify);
		if($captcha_success->success == true)
			$access = "true" ; 
		else
			$access = "false";
  	}else{
  		$access = "true";
  	}
  	
  	if($access == "true"){
  		$redirect_url  = strip_tags(mysqli_real_escape_string($db, $redirect_to));
	
		if ((strpos($redirect_url, 'login') !== false) || $redirect_url == null ) {
			$redirect_url = get_url(); 
		}
		$user_id = 0; 
	   	// check if the user id and password combination exist in database
	   	//unset($_SESSION['retries']);
	   	if(filter_var($user, FILTER_VALIDATE_EMAIL))
	   		$user = GetRow('users', array('email' => $user)); //, 'status' => 'Active'));
	   	else
	   		$user = GetRow('users', array('username' => $user)); //, 'status' => 'Active'));

	   	if($user['status'] == 'Inactive')
	   		$_SESSION['error'] = 'Sorry, You are Deactivated, Contact Site Administrator';	 

	   	else {
	   		
	   		$password_hashed = $user['password'];
			$wp_hasher = new PasswordHash(16, true);
			if($wp_hasher->CheckPassword($pass, $password_hashed)) {
				$_SESSION['user_id'] = $user['ID'];
				$_SESSION['fa_user_id'] = $user['fa_user_id'];
				$_SESSION['role'] = $user['role'];
				$_SESSION['dimension2_id'] = $user['dimension2_id'];
				$_SESSION['dimension_id'] = $user['dimension_id'];
				$_SESSION['permissions'] = unserialize($user['permissions']);
				$_SESSION['allPermissions'] = GetAll('permission');

				if(is_array($db_connections)){
					$tbpref = $db_connections[$def_coy]['tbpref'];
					$result = db_query("SELECT * FROM ".$tbpref."sales_pos WHERE id =".$user['sales_pos_id']." LIMIT 1", "can't get results");
					$_SESSION['pos_details'] =  fadb_fetch($result);
				}
				
				if($rememberme == null)
					$_SESSION['CREATED'] = time();	// echo $redirect_url; 
				unset($_SESSION['retries']);
				unset($_SESSION['Failed_login']);
				if($user['role'] == 'Administrator' || $user['role'] == 'Auditor')
					kv_direct($redirect_url);// direct to admin	
				else {
					kv_direct(get_url());// direct to front end	
				}	
						
				
			} else {			
				if(isset($_SESSION['retries'] )){
					$_SESSION['retries']++;
					
					$login_retries_allowed = get_site_option('login_retries_allowed');
					if($_SESSION['retries'] > $login_retries_allowed){				
						$_SESSION['Failed_login'] = time();	
						unset($_SESSION['retries']);			
					}
				}else
					$_SESSION['retries']= 1;

				if(isset($_SESSION['Failed_login'])){
					$time_v = time()- $_SESSION['Failed_login'] ;
					$res_time = $time_failed_out - $time_v;
					$res_time_val = gmdate('H:i:s', $res_time);
					$_SESSION['error'] = ' Sorry, You are Reached your Maximum Retires. Wait for '.$res_time_val.' to get Access again'. $_SESSION['failed_retry'] ;
				}else
					$_SESSION['error'] = 'Sorry, wrong username or password'.$_SESSION['retries'];
			}
		}
  	}	
}

function has_user_permission($permission, $module){
	if(isset($_SESSION['role']) && $_SESSION['role'] == 'Administrator'){
		return true;
	} elseif(isset($_SESSION['user_id'])){
		$allPermissions = $_SESSION['allPermissions'];
		//var_dump($_SESSION['allPermissions']);
		
		foreach($allPermissions as $single){

			//if($_SESSION['user_id'] == 34 && $single['page_permit'] == trim($permission) && $single['module'] == trim($module)) 
			//	echo json_encode($allPermissions);
			if($single['page_permit'] == trim($permission) && strcmp($single['module'],$module) == 0){				
				$permissin = $single['ID'];				
				break;
			}
			else
				$permissin = 0;
		}
		//echo $permissin;
		if(is_array($_SESSION['permissions']) && in_array($permissin, $_SESSION['permissions']))
			return true;
		else
			return false;
	} else 
		return false;
}
function user_permission(){
	$current_user = kv_get_current_user();
	if($current_user['role'] == 'Author' || $current_user['role'] == 'Administrator'){ 
	} else
		kv_die("<div class='error' style='text-align: center;' >Sorry!, You can't access these page</div>");
}

//forget password------------------------------------------------
function forgot_password($username_or_email, $front='no'){
	$unique_key = uniqid(12);
	if($front == 'no')
		$url = get_url('admin');
	else
		$url = get_url('flogin');
	if(filter_var($username_or_email, FILTER_VALIDATE_EMAIL)){
		$field = 'email';
	}else
		$field = 'username';
	$user_details = GetRow('users', array($field => $username_or_email));
	if($user_details['ID'] != null){
		Update('users', array('ID' => $user_details['ID']), array('activation' => $unique_key) );
		$subject ="New Password Request from ".get_site_option();
		$message = " Hello, <br>Someone requested resetting Your Password with our system. If its you please follow the below link to create new password for you to login with our system. <br><a href='".$url."?reset_password=".$unique_key."' style='font-size: 24px;'> Rest Password </a>";
		$message .="<br> 
			Thank you,<br>".get_site_option();
		//$attachment = array( 'summa.png' => ABSPATH.'/files/58b5a51e865e9.png');
		kv_mail($user_details['email'], $subject, $message, "html"); //, $attachment);
	}
}

//kv email function---------------------------------------
function kv_mail($to, $subject, $message, $type="plain", $attachments=array(), $reply_to=null){

		$mail = new PHPMailer; 

		if(get_site_option('smtp_host') != null && get_site_option('smtp_port_no') != null && get_site_option('smtp_login_email') != null && get_site_option('smtp_password') != null ){

			$mail->isSMTP();	//Enable SMTP debugging	// 0 = off (for production use)	// 1 = client messages		// 2 = client and server messages
			$mail->SMTPDebug = 0;
			//Ask for HTML-friendly debug output
			$mail->Debugoutput = 'html';
			//Set the hostname of the mail server
			$mail->Host = get_site_option('smtp_host');
			//Set the SMTP port number - likely to be 25, 465 or 587
			$mail->Port = get_site_option('smtp_port_no');
			//Whether to use SMTP authentication
			$mail->SMTPAuth = true;
			//Username to use for SMTP authentication
			$mail->Username = get_site_option('smtp_login_email');
			//Password to use for SMTP authentication
			$mail->Password = get_site_option('smtp_password');
		}
		if(get_site_option('from_email')){
			$mail->setFrom(get_site_option('from_email'), get_site_option('site_title'));
		}else
			$mail->setFrom('neem@'.$_SERVER['SERVER_NAME'], get_site_option('site_title'));
		
		if($reply_to != null)
			$mail->addReplyTo($reply_to['email'], $reply_to['name']);		

		$mail->addAddress($to);
		//Set the subject line
		$mail->Subject = $subject;

		if($type != 'plain'){			
			$mail->isHTML(true);
			$mail->msgHTML = $message;
		}
		$mail->Body = $message;
		
		//Attach an image file
		if(!empty($attachments)){
			foreach ($attachments as $key => $value) {
				$mail->addAttachment($value, $key);
			}			
		}

		//send the message, check for errors
		if ($mail->send()) {
		    return  "<div class='success'> "._("Email sent"). "</div>"; 
		} else { 
		    return  "<div class='error'>Failed to send email: " . $mail->ErrorInfo."</div>"; 
		}		    
}

// Authentication
function logged_in() {
	if(isset($_SESSION['user_id'])){
		return true;		
	}else
		return false;
}

// Is Administrator Logged In
function is_admin() {
	if(isset($_SESSION['user_id']) && $_SESSION['role'] == 'Administrator') {
		return true;		
	} else
		return false;
}

// Is Administrator Logged In
function is_auditor() {
	if(isset($_SESSION['user_id']) && $_SESSION['role'] == 'Auditor') {
		return true;		
	} else
		return false;
}

function kv_get_current_user(){
	if(logged_in()){
		return get_user_details($_SESSION['user_id']);
	}else
		return false;
}

function login_required() {
	if(logged_in())	
		return true;
	else 
		kv_direct(get_url("admin").'?action=login');		
}

function logout(){
	unset($_SESSION['user_id']);
	session_destroy();
	kv_direct(get_url());
}

function neem_has_username($username){
	$userID = GetSingleValue('users', 'ID', array('username' => $username));
	if($userID>0)
		return true;
	else
		return false;
}

function kv_direct($url){
	header('Location: '.$url);
	exit();
}
// Render error messages
function messages() {
    $message = '';

	if(isset($_SESSION['success']) && $_SESSION['success'] != '') {
	        $message = '<div class="msg-ok">'.$_SESSION['success'].'</div>';
	        $_SESSION['success'] = '';
	}
	if(isset($_SESSION['error']) && $_SESSION['error'] != '') {
	        $message = '<div class="msg-error">'.$_SESSION['error'].'</div>';
	        $_SESSION['error'] = '';
	}
	
    echo "$message";
}

function errors($error){
	if (!empty($error)){
		$i = 0;
		while ($i < count($error)){
			$showError.= "<div class=\"msg-error\">".$error[$i]."</div>";
			$i ++;
		}
		echo $showError;
	}// close if empty errors
} // close function
function kot_ajax_url(){
	return get_url('ajax-kot-new');
}
function ajax_url(){
	return get_url('ajax');
}

function get_url($site_url='site'){
	$site_url_fl = GetSingleValue('settings', 'option_value', array('option_name' => 'site_url'));
	if($site_url == 'site')
		return $site_url_fl;
	elseif($site_url == 'admin')
		return $site_url_fl.'kv-admin/';
	elseif($site_url == 'logout')
		return $site_url_fl.'kv-admin/?logout';
	elseif($site_url == 'login')
		return $site_url_fl.'kv-admin/?action=login';
	elseif($site_url == 'flogin')
		return $site_url_fl.'login';
	elseif ($site_url== 'ajax') {
		return $site_url_fl.'includes/kv-ajax.php';
	}elseif($site_url== 'compact')
		return $site_url_fl.'includes/compact';
	elseif($site_url== 'includes')
		return $site_url_fl.'includes/';
		
	return $site_url_fl.$site_url;		
}

function get_site_title(){
	return GetSingleValue('settings', 'option_value', array('option_name' => 'site_title'));
}

function get_user_roles(){
	return get_site_option('System_Roles');
}

function get_site_option($option='site_title'){
	$return = GetSingleValue('settings', 'option_value', array('option_name' => $option));

	$data = @unserialize($return);
	if ($data !== false) {
	    return unserialize($return);
	} else {
	    return $return; 
	}
}
function get_site_admin_email(){
	return GetSingleValue('settings', 'option_value', array('option_name' => 'admin_email'));
}
function get_site_option_id($option='site_title'){
	return GetSingleValue('settings', 'id', array('option_name' => $option));
}
function get_all_pages($status= null, $order_by=null){
	if($status != null)
		return GetAll('pages', array('status' => $status, 'page_type' => 'page'), $order_by);
	else
		return GetAll("pages",  array('status' => 'Published', 'page_type' => 'page'), $order_by);
}

function get_a_page($id, $order_by=null){

	if(is_numeric($id))
		return GetRow('pages', array('ID' => $id), $order_by);
	else
		return GetRow('pages', array('slug' => $id), $order_by);
}

function get_home_page(){
	$id = get_site_option('isRoot');
	return GetRow('pages', array('ID' => $id), null);
}

function get_all_users($status="Active", $role=null){
	if($role == null)
		return GetAll('users', array('status' => $status));
	else
		return GetAll('users', array('status' => $status, 'role' => $role));
}

function get_user_details($id){
	return GetRow('users', array('ID' => $id));
}

function get_user_detail($id, $field){
	return GetSingleValue('users', $field, array('ID' => $id));
}
function get_user_meta($user_id, $meta_key){
	$return = GetSingleValue('usermeta', 'meta_value', array('userID' => $user_id, 'meta_key' => $meta_key));

	$data = @unserialize($return);
	if ($data !== false) {
	    return unserialize($return);
	} else {
	    return $return; 
	}		
}

function add_user_meta($user_id, $meta_key, $meta_value){	
	if(is_array($meta_value)){
		$meta_value = serialize($meta_value);
	}
	$usermeta = get_user_meta($user_id, $meta_key);
	if(!empty($usermeta))
		return Update('usermeta', array('userID' => $user_id, 'meta_key' => $meta_key), array( 'meta_value' => $meta_value) );
	else
		return Insert('usermeta', array('userID' => $user_id, 'meta_key' => $meta_key, 'meta_value' => $meta_value));
}

function delete_user_meta($user_id, $meta_key){
	return  Delete("usermeta",array('userID' => $user_id, 'meta_key' => $meta_key));
}
function get_author_name($id){
	return GetSingleValue('users', 'full_name', array('ID' => $id));
}

function seoUrl($string, $pageID=null) {
	$string = trim($string, ' ');
    //Lower case everything
    $string = strtolower($string);
    //Make alphanumeric (removes all other characters)
    $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    //Clean up multiple dashes or whitespaces
    $string = preg_replace("/[\s-]+/", " ", $string);
    //Convert whitespaces and underscore to dash
    $string = preg_replace("/[\s_]/", "-", $string);

	$page_exist = GetSingleValue('pages', 'ID', array('slug' => $string)); 
	if($page_exist > 0 && $pageID != null && $page_exist != $pageID)   
		$string = $string.'-2';
	
    return $string;
}

function neem_count($table, $type=null){
	if($type ==null)
		return GetSingleValue($table, 'COUNT(*)');
	else{
		$final_array = array($type[0] => $type[1]);
		if(isset($type[3]))
			$final_array[$type[2]]= $type[3];
		return GetSingleValue($table, 'COUNT(*)', $final_array);
	}
}
function get_active_theme(){
	global $current_user;
	 $current_user = kv_get_current_user();
	if(isset($current_user['theme']) && $current_user['theme'] != ''){
		if(file_exists(ABSPATH.'/themes/'.$current_user['theme'].'/index.php') && file_exists(ABSPATH.'/themes/'.$current_user['theme'].'/functions.php') && file_exists(ABSPATH.'/themes/'.$current_user['theme'].'/style.css'))
			$theme = $current_user['theme'];
		else
			$theme = get_site_option('template');
	} else
		$theme = get_site_option('template');

	return $theme;
}

function available_themes_list() {
	$themes_list = [];
	foreach(glob(ABSPATH.'/themes/*', GLOB_ONLYDIR) as $dir) {
		//$dirname = basename($dir);
		//foreach(glob(ABSPATH.'/themes/'.$dirname, GLOB_ONLYDIR) as $single) {
			$theme_folder = basename($dir);
				    	//echo ABSPATH.'/themes/'.$theme_folder.'/index.php'; 
			if(file_exists(ABSPATH.'/themes/'.$theme_folder.'/index.php') && file_exists(ABSPATH.'/themes/'.$theme_folder.'/functions.php') && file_exists(ABSPATH.'/themes/'.$theme_folder.'/style.css')){
				$myFile = ABSPATH.'/themes/'.$theme_folder.'/style.css';
				$lines = file($myFile);//file in to an array

				$theme_name = 'Theme Name';
				$theme_n = array_filter($lines, function($var) use ($theme_name){ return preg_match("/\b$theme_name\b/i", $var); });

				$theme_nam=  implode('', $theme_n);
				$positio = strpos($theme_nam, ':');
				$theme_fullname =trim(substr($theme_nam, $positio+1)); 
				if(!in_array($theme_folder, $themes_list))
					$themes_list[$theme_folder] = $theme_fullname;
			}
		//}
	}
	return $themes_list;
}
function get_plugin_uri(){
	return get_url()."add-ons/";
}

function get_plugin_abs_path(){
	return ABSPATH."add-ons/";
}

function get_current_theme_uri(){
	return get_url()."themes/".get_active_theme()."/";
}
function get_current_theme_abs_path(){
	return ABSPATH."themes/".get_active_theme()."/";
}

function get_header(){
	if(file_exists(get_current_theme_abs_path()."/header.php"))
		require_once(get_current_theme_abs_path()."/header.php");
	else
		require_once("compact/header.php");
}
function get_footer(){
	if(file_exists(get_current_theme_abs_path()."/footer.php"))
		require_once(get_current_theme_abs_path()."/footer.php");
	else
		require_once("compact/footer.php");
}
function get_kotheader(){
	if(file_exists(get_current_theme_abs_path()."/kot_header.php"))
		require_once(get_current_theme_abs_path()."/kot_header.php");
	else
		require_once("compact/header.php");
}
function get_kotfooter(){
	if(file_exists(get_current_theme_abs_path()."/kot_footer.php"))
		require_once(get_current_theme_abs_path()."/kot_footer.php");
	else
		require_once("compact/footer.php");
}


function get_All_attachments($id = null){
	if($id != null)
		return GetAll('pages', array('ID' => $id, 'page_type' => 'media'));
	else
		return GetAll('pages', array('page_type' => 'media'));
}

function get_attachment_name($id){
	return GetSingleValue('pages', 'pageTitle', array('ID' => $id));
}

function get_attachment_string($id){
	return GetSingleValue('pages', 'slug', array('ID' => $id));
}

function get_attachment_date($id){
	return GetSingleValue('pages', 'pDate', array('ID' => $id));
}
function get_attachment_url($id){
	$url =  GetSingleValue('pages', 'slug', array('ID' => $id));
	return get_url(NEEM_UPLOADS."/".$url);
}

function delete_attachment($attach_id){
	$name = get_attachment_string($attach_id);
	if ($attach_id && file_exists(ABSPATH.NEEM_UPLOADS."/".$name)){		
		unlink(ABSPATH.NEEM_UPLOADS."/".$name);
		$deleted = Delete("pages",array('ID'=> $attach_id));
		return true;
	}else{
		return false;
	}
	
}
// get Current Theme Templates List ---------------------------
function get_theme_templates($selected_template_name){
	$files = scandir(ABSPATH."themes/".get_active_theme());
	$drop_down = '<select name="templates" ><option value="-1" > None </option>';
	foreach($files as $single_file){
		$ext = pathinfo($single_file, PATHINFO_EXTENSION);
		if($ext == 'php'){
			$myFile = get_current_theme_abs_path().$single_file;
			$lines = file($myFile);//file in to an array

			$theme_name = 'Template Name';
			$theme_n = array_filter($lines, function($var) use ($theme_name) { return preg_match("/\b$theme_name\b/i", $var); });
			
			$theme_nam=  implode('', $theme_n);
			$positio = strpos($theme_nam, ':');
			$template_name= trim(substr($theme_nam, $positio+1));
			if($template_name != null)
			$drop_down .= '<option value="'.$single_file.'" '.($single_file == $selected_template_name ? "selected" : " " ).' > '.$template_name.'</option>';
		}
	}
	$drop_down .= '</select>';
	return $drop_down ;
}

function select_options_list($name, $array_list, $selected=null, $none=null, $style=null, $class=null, $id=null){
	$fl_ary = array();
	$drop_down = "<select name='".$name."'";
	if($id != null)
		$drop_down .= " id='". $id."'";
	if($class != null)
		$drop_down .= " class='". $class."'";
	if($style != null)
		$drop_down .= " style='". $style."'";

	$drop_down .=  " >";
	if(!is_array($array_list)){
		if($array_list == 'users'){
			$array_list = GetDataFilter('users', array('ID', 'full_name'));
			foreach ($array_list as $value) {				
				$fl_ary[$value['ID']] = $value['full_name'];
			}
		}
		
		if($array_list == 'pages'){
			$array_list = GetDataFilter('pages', array('ID', 'pageTitle'), array('page_type' => 'page'));
			foreach ($array_list as $value) {				
				$fl_ary[$value['ID']] = $value['pageTitle'];
			}
			//$drop_down .= '<option value="0"> Other </option>' ;
		}
	}else{
		$fl_ary = $array_list;
	}
	//print_r($array_list);
	if($none != null && $none != "no")
		$drop_down .= "<option value='-1'> ".$none ." </option>";
	elseif($none== "no")
		$drop_down .="";
	else
		$drop_down .= "<option value='-1' ".($selected == null ? 'selected' : '')."> None </option>";
	foreach ($fl_ary as $key => $value) {
		$drop_down .= "<option value='".$key."' ".($selected == $key ? 'selected' : '' )." > ".$value." </option>";
	}
	$drop_down .= "</select>";

	return $drop_down;
}

function get_frontpage(){
	$single_val = GetSingleValue('pages', 'ID', array('isRoot' => 1));
	if($single_val > 0)
		return $single_val;
	else
		return false;
}

function email_exist($table, $email){
	$e_Count = GetSingleValue($table, 'COUNT(*)', array('email' => $email));
	if($e_Count > 0)
		return true;
	else
		return false;
}

function get_permalink($id_or_slug){
	$option = get_site_option('permalink');
	if($option == 'slug'){
		return get_url().GetSingleValue('pages', 'slug', array('slug' => $id_or_slug)).'/';
	}elseif($option == 'id'){
		return get_url().'?p='.GetSingleValue('pages', 'ID', array('ID' => $id_or_slug));
	}
}

function GetRootPage(){
	return GetSingleValue('pages', 'ID', array('isRoot' => 1));
}
function UpdateRoot($page_id){
	$existing_root = GetRootPage(); 
	if( $existing_root != $page_id){		
		Update('pages',  array('ID' => $existing_root), array('isRoot' =>0 ));
		Update('pages',  array('ID' => $page_id), array('isRoot' =>1));
	}else{
		Update('pages',  array('ID' => $page_id), array('isRoot' =>1));
		//Insert('settings', array('option_name'=> 'isRoot', 'option_value' => $page_id));
	}
	
}

function get_page_title($id =null, $site_url=false){
	if(isset($_GET['p'])){
		$q = get_a_page($_GET['p']);
	} else { 					
		$q =get_home_page();
		$site_url=false; 
	}
	$title = $q['pageTitle'];
	if($site_url == true && $title != null)	
		return _($title).' - '. get_site_title();	
	elseif($site_url == true && $title == null)
		return '404 Page Not Found - '.get_site_title();
	elseif($site_url == false && $title != '')
		return _($title);
}

function Current_page_slug(){
	if(isset($_GET['p'])){
		$q = get_a_page($_GET['p']);
	} else { 					
		$q =get_home_page();
	}
	return $q['slug'];
}
function get_page_content($p=null){
	if($p){
		$q = get_a_page($p);
		if($q  != false || $q !=  ''){ 			
			echo html_entity_decode(nl2br($q['pageContent']));		
		}
	} else {
		if(isset($_GET['p'])){
			$q = get_a_page($_GET['p']);
		} else { 					
			$q = get_home_page();
			$home_page ='yes';
		} 
		if($q  != false || $q !=  ''){ 			
			echo html_entity_decode(nl2br($q['pageContent']));		
		}else{
			include("compact/404.php");
		}	
	}	
}



function KvGetMenu($type){

	$all_menus = GetDataFilter('pages', array('ID','pageTitle','pageContent','parentID', 'slug'), array('page_type' => 'neem_menu', 'template' => $type), array('ID' => 'ASC'));
	
	$formattedArray = [];
    $subItems = [];

    foreach ($all_menus as $item) {
        $pid = $item['parentID'];

        if ($pid != 0) {
            if (isset($subItems[$pid]))
                $subItems[$pid][] = $item;
            else
                $subItems[$pid] = [$item];
        } else
            $formattedArray[] = $item;
    }

    foreach ($formattedArray as $key => $parent) {
        resolveChild($formattedArray[$key], $subItems);
    }

    return $formattedArray;
}

function resolveChild(&$parent, &$subItems) {
    //return if no child
    if (!isset($subItems[$parent['ID']]))
        return $parent;

    foreach ($subItems[$parent['ID']] as $key => $child) {
        if (isset($parent['sub_items']))
            $parent['sub_items'][] = resolveChild($subItems[$parent['ID']][$key], $subItems);
        else
            $parent['sub_items'] = [resolveChild($subItems[$parent['ID']][$key], $subItems)];
     }

    return $parent;
}

function kv_nav_menu($location = null, $options_arr){
	/*$options_arr =  array(					
					'nav'			=> false, 	// outer nav (true/false)
					'out_nav_id'=> '',			// Outer nav id for styling
					'out_nav_class' => '',		// out class nav
					'menu_class'	=> array('first_menu', 'second_menu', 'third_menu'), 		// menu class
					'menu_id'		=> array('first_menu', 'second_menu', 'third_menu'), 		// menu id
					'first_sub_id'		=> '', 		// first Sub menu id
					'first_sub_class'		=> '', 		// First Sub menu Class
	);*/ 
	if(isset($options_arr['active_class'])){ }else{
		$options_arr['active_class'] = 'active'; 
	}

	if($location == null)
		$pages = get_all_pages();
	else
		$pages = KvGetMenu($location);	
	$pages_list = '';
	if($options_arr['nav']){
		$pages_list .='<nav ';
		if($options_arr['out_nav_id'] != '')
			$pages_list .= 'id="'.$options_arr['out_nav_id'].'" ';
		if($options_arr['out_nav_class'] != '')
			$pages_list .= 'class="'.$options_arr['out_nav_class'].'" ';
		$pages_list .= '>';
	}
 	
 	$pages_list .= GenerateChildMenus($pages, $options_arr);

	if($options_arr['nav']){
		$pages_list .='</nav>';
	}
	echo $pages_list;
}


function GenerateChildMenus($pages, $options_arr, $depth=0){
	
	$pages_list .='<ul ';
	if($options_arr['menu_class'][$depth] != '')
		$pages_list .= 'class="'.$options_arr['menu_class'][$depth].'" ';
	if($options_arr['menu_id'][$depth] != '')
		$pages_list .= 'id="'.$options_arr['menu_id'][$depth].'" ';
	$pages_list .= '>';

	foreach($pages as $page){ 
		//if(has_user_permission('View '.$page['pageTitle'], $page['pageTitle'])) {
			if ($page['pageContent'] == get_url().Current_page_slug()) {
				$pages_list .= '<li class="'.$options_arr['active_class'].'" > <a href="'.$page['pageContent'].'" '.($page['slug'] != '' ? 'target="_blank"' : '' ).'> '._($page['pageTitle']).' </a>';
			}else
				$pages_list .= '<li  data-summa="'.get_url().Current_page_slug().'"> <a href="'.$page['pageContent'].'" '.($page['slug'] != '' ? 'target="_blank"' : '' ).'> '._($page['pageTitle']).' </a>';
			if(!empty($page['sub_items'])){
				$pages_list .= GenerateChildMenus($page['sub_items'], $options_arr, ++$depth);	
			}
			$pages_list .= '</li>'; 	//var_dump($page);
		//}
	}
	$pages_list .='</ul>';

	return $pages_list;
}
 function formatSizeUnits($bytes)  {
    if ($bytes >= 1073741824)  {
        $bytes = number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576)  {
        $bytes = number_format($bytes / 1048576, 2) . ' MB';
    }elseif ($bytes >= 1024) {
        $bytes = number_format($bytes / 1024, 2) . ' kB';
   	} elseif ($bytes > 1)  {
        $bytes = $bytes . ' bytes';
    } elseif ($bytes == 1) {
        $bytes = $bytes . ' byte';
    } else {
        $bytes = '0 bytes';
    }
    return $bytes;
}

$activedPlugins = get_site_option('active_plugins');
if($activedPlugins){
	foreach ($activedPlugins as $plgsingle) {
		if(file_exists(get_plugin_abs_path().$plgsingle))
			include_once(get_plugin_abs_path().$plgsingle);
		else{
			if (($key = array_search($plgsingle, $activedPlugins)) !== false) {
			    unset($activedPlugins[$key]);
			    $activatedPlgns = serialize($activedPlugins);
				$current_option_id = get_site_option_id('active_plugins');
				Update('settings', array( "ID" => $current_option_id), array( "option_value" => array($activatedPlgns, 'noesc') ));	
			}
		}
	}
}

$language_codes = [
    'ab' => 'Abkhazian',
    'aa' => 'Afar',
    'af' => 'Afrikaans',
    'ak' => 'Akan',
    'sq' => 'Albanian',
    'am' => 'Amharic',
    'ar' => 'Arabic',
    'an' => 'Aragonese',
    'hy' => 'Armenian',
    'as' => 'Assamese',
    'av' => 'Avaric',
    'ae' => 'Avestan',
    'ay' => 'Aymara',
    'az' => 'Azerbaijani',
    'bm' => 'Bambara',
    'ba' => 'Bashkir',
    'eu' => 'Basque',
    'be' => 'Belarusian',
    'bn' => 'Bengali',
    'bh' => 'Bihari languages',
    'bi' => 'Bislama',
    'bs' => 'Bosnian',
    'br' => 'Breton',
    'bg' => 'Bulgarian',
    'my' => 'Burmese',
    'ca' => 'Catalan, Valencian',
    'km' => 'Central Khmer',
    'ch' => 'Chamorro',
    'ce' => 'Chechen',
    'ny' => 'Chichewa, Chewa, Nyanja',
    'zh' => 'Chinese',
    'cu' => 'Church Slavonic, Old Bulgarian, Old Church Slavonic',
    'cv' => 'Chuvash',
    'kw' => 'Cornish',
    'co' => 'Corsican',
    'cr' => 'Cree',
    'hr' => 'Croatian',
    'cs' => 'Czech',
    'da' => 'Danish',
    'dv' => 'Divehi, Dhivehi, Maldivian',
    'nl' => 'Dutch, Flemish',
    'dz' => 'Dzongkha',
    'en' => 'English',
    'eo' => 'Esperanto',
    'et' => 'Estonian',
    'ee' => 'Ewe',
    'fo' => 'Faroese',
    'fj' => 'Fijian',
    'fi' => 'Finnish',
    'fr' => 'French',
    'ff' => 'Fulah',
    'gd' => 'Gaelic, Scottish Gaelic',
    'gl' => 'Galician',
    'lg' => 'Ganda',
    'ka' => 'Georgian',
    'de' => 'German',
    'ki' => 'Gikuyu, Kikuyu',
    'el' => 'Greek (Modern)',
    'kl' => 'Greenlandic, Kalaallisut',
    'gn' => 'Guarani',
    'gu' => 'Gujarati',
    'ht' => 'Haitian, Haitian Creole',
    'ha' => 'Hausa',
    'he' => 'Hebrew',
    'hz' => 'Herero',
    'hi' => 'Hindi',
    'ho' => 'Hiri Motu',
    'hu' => 'Hungarian',
    'is' => 'Icelandic',
    'io' => 'Ido',
    'ig' => 'Igbo',
    'id' => 'Indonesian',
    'ia' => 'Interlingua (International Auxiliary Language Association)',
    'ie' => 'Interlingue',
    'iu' => 'Inuktitut',
    'ik' => 'Inupiaq',
    'ga' => 'Irish',
    'it' => 'Italian',
    'ja' => 'Japanese',
    'jv' => 'Javanese',
    'kn' => 'Kannada',
    'kr' => 'Kanuri',
    'ks' => 'Kashmiri',
    'kk' => 'Kazakh',
    'rw' => 'Kinyarwanda',
    'kv' => 'Komi',
    'kg' => 'Kongo',
    'ko' => 'Korean',
    'kj' => 'Kwanyama, Kuanyama',
    'ku' => 'Kurdish',
    'ky' => 'Kyrgyz',
    'lo' => 'Lao',
    'la' => 'Latin',
    'lv' => 'Latvian',
    'lb' => 'Letzeburgesch, Luxembourgish',
    'li' => 'Limburgish, Limburgan, Limburger',
    'ln' => 'Lingala',
    'lt' => 'Lithuanian',
    'lu' => 'Luba-Katanga',
    'mk' => 'Macedonian',
    'mg' => 'Malagasy',
    'ms' => 'Malay',
    'ml' => 'Malayalam',
    'mt' => 'Maltese',
    'gv' => 'Manx',
    'mi' => 'Maori',
    'mr' => 'Marathi',
    'mh' => 'Marshallese',
    'ro' => 'Moldovan, Moldavian, Romanian',
    'mn' => 'Mongolian',
    'na' => 'Nauru',
    'nv' => 'Navajo, Navaho',
    'nd' => 'Northern Ndebele',
    'ng' => 'Ndonga',
    'ne' => 'Nepali',
    'se' => 'Northern Sami',
    'no' => 'Norwegian',
    'nb' => 'Norwegian Bokmål',
    'nn' => 'Norwegian Nynorsk',
    'ii' => 'Nuosu, Sichuan Yi',
    'oc' => 'Occitan (post 1500)',
    'oj' => 'Ojibwa',
    'or' => 'Oriya',
    'om' => 'Oromo',
    'os' => 'Ossetian, Ossetic',
    'pi' => 'Pali',
    'pa' => 'Panjabi, Punjabi',
    'ps' => 'Pashto, Pushto',
    'fa' => 'Persian',
    'pl' => 'Polish',
    'pt' => 'Portuguese',
    'qu' => 'Quechua',
    'rm' => 'Romansh',
    'rn' => 'Rundi',
    'ru' => 'Russian',
    'sm' => 'Samoan',
    'sg' => 'Sango',
    'sa' => 'Sanskrit',
    'sc' => 'Sardinian',
    'sr' => 'Serbian',
    'sn' => 'Shona',
    'sd' => 'Sindhi',
    'si' => 'Sinhala, Sinhalese',
    'sk' => 'Slovak',
    'sl' => 'Slovenian',
    'so' => 'Somali',
    'st' => 'Sotho, Southern',
    'nr' => 'South Ndebele',
    'es' => 'Spanish, Castilian',
    'su' => 'Sundanese',
    'sw' => 'Swahili',
    'ss' => 'Swati',
    'sv' => 'Swedish',
    'tl' => 'Tagalog',
    'ty' => 'Tahitian',
    'tg' => 'Tajik',
    'ta' => 'Tamil',
    'tt' => 'Tatar',
    'te' => 'Telugu',
    'th' => 'Thai',
    'bo' => 'Tibetan',
    'ti' => 'Tigrinya',
    'to' => 'Tonga (Tonga Islands)',
    'ts' => 'Tsonga',
    'tn' => 'Tswana',
    'tr' => 'Turkish',
    'tk' => 'Turkmen',
    'tw' => 'Twi',
    'ug' => 'Uighur, Uyghur',
    'uk' => 'Ukrainian',
    'ur' => 'Urdu',
    'uz' => 'Uzbek',
    've' => 'Venda',
    'vi' => 'Vietnamese',
    'vo' => 'Volap_k',
    'wa' => 'Walloon',
    'cy' => 'Welsh',
    'fy' => 'Western Frisian',
    'wo' => 'Wolof',
    'xh' => 'Xhosa',
    'yi' => 'Yiddish',
    'yo' => 'Yoruba',
    'za' => 'Zhuang, Chuang',
    'zu' => 'Zulu'
];
?>