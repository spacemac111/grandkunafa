<?php 

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

require_once('../config.php' );
require_once('functions.php' );
require_once('db-functions.php' );
require_once(FA_PATH.'config_db.php');
global $db_connections, $db;
if(isset($_GET['action']) && $_GET['action'] == 'media_add'){
	$added_id =  array();
	if('POST' == $_SERVER['REQUEST_METHOD'] ) {
		$uploads_folder = ABSPATH.NEEM_UPLOADS; 

		foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
				$file_name = $_FILES['files']['name'][$key];
				$file_size =$_FILES['files']['size'][$key];
				$file_tmp =$_FILES['files']['tmp_name'][$key];
				$file_type=$_FILES['files']['type'][$key];	
				$ext=pathinfo($file_name,PATHINFO_EXTENSION);
				if(in_array($ext, array('jpg', 'jpeg', 'png', 'bmp', 'txt', 'zip', 'docx','doc','pdf','rtf','gif', 'tiff'))){
					if(is_dir($uploads_folder)==false){
			                mkdir($uploads_folder, 0700); //Create directory if it doesn't exist
			            }
			            $temp = explode(".", $_FILES["files"]["name"][$key]);
						$newfilename = uniqid() . '.' . $ext;
			            if(is_dir($uploads_folder ."/".$newfilename)==false){
			                move_uploaded_file($file_tmp,$uploads_folder."/".$newfilename);
			            }else{	// rename the file if another one exist
			                move_uploaded_file($file_tmp,$uploads_folder."/".$newfilename.time());		
			            }
			       		$current_user = kv_get_current_user();
						$inserted_id = Insert('pages', array(
										"pageTitle" => $file_name,
										"authorID" => $current_user["ID"],
										"template" => '',
										"pageContent" => '',
										"page_type" => 'media',
										"slug" => $newfilename,
										"pDate" => date('Y-m-d'),
										"status" => 'Published'));
					$added_id[] = array('success' => true, 'id' => $inserted_id) ;
				}
				
		}
		//kv_direct(get_url("admin").'medias.php?status=added');
	}
	//echo json_encode($added_id);
	echo json_encode(array(
	"success" => true,
	"error" => "Failed to Upload",	
	"items" => $added_id
));
	exit;
}

if(isset($_GET['action']) && $_GET['action'] == 'next_media'){
	if(isset($_POST['media_id'])){

		$sql0 = "SELECT ID FROM ".TB_PREF."pages WHERE page_type ='media' AND ID < ".trim($_POST['media_id'])." ORDER BY ID DESC LIMIT 1";
    	$nxt_media_id = db_get_single_value($sql0, "Could not get next Media");
    	if($nxt_media_id>0)
    		echo get_url("admin")."medias.php?view_id=".$nxt_media_id;
    	else
    		echo 'failure';
	}else
		echo 'failure';
	exit; 
} 

if(isset($_GET['action']) && $_GET['action'] == 'prev_media'){
	if(isset($_POST['media_id'])){

		$sql0 = "SELECT ID FROM ".TB_PREF."pages WHERE page_type ='media' AND ID > ".trim($_POST['media_id'])." ORDER BY ID ASC LIMIT 1";
    	$nxt_media_id = db_get_single_value($sql0, "Could not get next Media");
    	if($nxt_media_id>0)
    		echo get_url("admin")."medias.php?view_id=".$nxt_media_id;
    	else
    		echo 'failure';
	}else
		echo 'failure';
	exit; 
} 

if(isset($_GET['action']) && $_GET['action'] == 'delete_page'){
	if(delete_attachment($_POST['media_id']))
		echo "success"; 
	else
		echo 'failure';
	exit; 
} 

if(isset($_GET['action']) && $_GET['action'] == 'menu_change'){
	$formattedArray = KvGetMenu($_GET['menu_name']);
	echo json_encode($formattedArray);
	exit;
}

if(isset($_GET['action']) && $_GET['action'] == 'menu_save'){
	/*[[{"data_id":1,"menu":"Top Meen","db_id":"1","data_url":"http://localhost/cms/","data_text":"Home","parent_id":0}], ]  */
	$current_user = kv_get_current_user();
	$menus = json_decode($_GET['menuss']);
	$current_menu_name = $_GET['menu_nam'];
	$insertedID = $last_parentID = 0;
	$parent_id_ar = array();
	Delete('pages', array('page_type' => 'neem_menu', 'template' => $current_menu_name ));
	foreach ($menus as $key => $value) {
		$val = $value[0];
		if($val->db_id > 0 && db_has_pageID($val->db_id)){   // Menu already exist. So let's Update it
			Update('pages', array('ID' => $val->db_id), array('pageTitle' => $val->data_text, 'pageContent'  => $val->data_url, 'template' => $val->menu, 'pDate' => date('Y-m-d'), 'authorID' => $current_user['ID'], 'parentID' =>  $val->parent_id) );
			$parent_id_ar[$val->data_id] = $val->db_id;
		}else{  // Menu does not exist. so let's create it.
			if($val->parent_id > 0){
				$parID = $parent_id_ar[$val->parent_id]; 
			}else
				$parID = 0;
			$insertedID = Insert('pages', array('pageTitle' => $val->data_text, 'page_type'  => 'neem_menu','pageContent'  => $val->data_url, 'template' => $val->menu, 'parentID' =>  $parID , 'authorID' => $current_user['ID'], 'pDate' => date('Y-m-d'), 'status' => 'Published') );
			$parent_id_ar[$val->data_id] = $insertedID;
		}
		
	}
	exit;
}
if (isset($_GET['moduleNO'])) {
	$mid  = $_GET['moduleNO'];

	$data = GetRow("modulepage", array("id" => $mid));
	echo json_encode(array('name'=> $data['pageName']));
}
if(isset($_GET['CompanyPOS'])){
	$company_id = $_GET['CompanyPOS'];
	global $db_connections;
	//var_dump($db_connections[$company_id]);
	$salesmandb = mysqli_connect($db_connections[$company_id]['host'], $db_connections[$company_id]['dbuser'], $db_connections[$company_id]['dbpassword'], $db_connections[$company_id]['dbname']);
	if (mysqli_connect_errno()) {
		echo mysqli_connect_error();
	}
	$result = mysqli_query($salesmandb, "SET sql_mode=''");
	
	if(!$result && $err_msg != null ){       
		echo $err_msg;
	}	
	$sql ="SELECT * FROM ".$db_connections[$company_id]['tbpref']."sales_pos WHERE inactive = 0 ";
	$result = mysqli_query($salesmandb, $sql);
	$final = [];
	if(mysqli_num_rows($result)>0){
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			$final[] = $row;
		}
	}
	if(!empty($final))
		echo json_encode($final);
	else
		echo 'false';
}

if(isset($_GET['CompanyBankAcc'])){
	$company_id = $_GET['CompanyBankAcc'];
	global $db_connections;
	//var_dump($db_connections[$company_id]);
	$salesmandb = mysqli_connect($db_connections[$company_id]['host'], $db_connections[$company_id]['dbuser'], $db_connections[$company_id]['dbpassword'], $db_connections[$company_id]['dbname']);
	if (mysqli_connect_errno()) {
		echo mysqli_connect_error();
	}
	$result = mysqli_query($salesmandb, "SET sql_mode=''");
	
	if(!$result && $err_msg != null ){       
		echo $err_msg;
	}	
	$sql ="SELECT * FROM ".$db_connections[$company_id]['tbpref']."bank_accounts WHERE account_type <> 3 ";
	$result = mysqli_query($salesmandb, $sql);
	$final = [];
	if(mysqli_num_rows($result)>0){
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			$final[] = $row;
		}
	}
	if(!empty($final))
		echo json_encode($final);
	else
		echo 'false';
}
if(isset($_GET['CompanyCashAcc'])){
	$company_id = $_GET['CompanyCashAcc'];
	global $db_connections;
	//var_dump($db_connections[$company_id]);
	$salesmandb = mysqli_connect($db_connections[$company_id]['host'], $db_connections[$company_id]['dbuser'], $db_connections[$company_id]['dbpassword'], $db_connections[$company_id]['dbname']);
	if (mysqli_connect_errno()) {
		echo mysqli_connect_error();
	}
	$result = mysqli_query($salesmandb, "SET sql_mode=''");
	
	if(!$result && $err_msg != null ){       
		echo $err_msg;
	}	
	$sql ="SELECT * FROM ".$db_connections[$company_id]['tbpref']."bank_accounts WHERE account_type = 3 ";
	$result = mysqli_query($salesmandb, $sql);
	$final = [];
	if(mysqli_num_rows($result)>0){
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			$final[] = $row;
		}
	}
	if(!empty($final))
		echo json_encode($final);
	else
		echo 'false';
}

if(isset($_GET['getCompanydimensionList'])) {
	$company_id = $_GET['getCompanydimensionList'];
	$type = isset($_GET['type']) ? $_GET['type'] : 2 ;
	global $db_connections;
	//var_dump($db_connections[$company_id]);
	$salesmandb = mysqli_connect($db_connections[$company_id]['host'], $db_connections[$company_id]['dbuser'], $db_connections[$company_id]['dbpassword'], $db_connections[$company_id]['dbname']);
	if (mysqli_connect_errno()) {
		echo mysqli_connect_error();
	}
	$result = mysqli_query($salesmandb, "SET sql_mode=''");
	
	if(!$result && $err_msg != null ){       
		echo $err_msg;
	}	
	$sql ="SELECT * FROM ".$db_connections[$company_id]['tbpref']."dimensions WHERE closed = 0 AND type=".$type;
	$result = mysqli_query($salesmandb, $sql);
	$final = [];
	if(mysqli_num_rows($result)>0){
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			$final[] = $row;
		}
	}
	if(!empty($final))
		echo json_encode($final);
	else
		echo 'false';
	exit;
} 
if(isset($_GET['getCompanySalesMansList'])) {
	$company_id = $_GET['getCompanySalesMansList'];
	global $db_connections;
	//var_dump($db_connections[$company_id]);
	$salesmandb = mysqli_connect($db_connections[$company_id]['host'], $db_connections[$company_id]['dbuser'], $db_connections[$company_id]['dbpassword'], $db_connections[$company_id]['dbname']);
	if (mysqli_connect_errno()) {
		echo mysqli_connect_error();
	}
	$result = mysqli_query($salesmandb, "SET sql_mode=''");
	
	if(!$result && $err_msg != null ){       
		echo $err_msg;
	}	
	$sql ="SELECT * FROM ".$db_connections[$company_id]['tbpref']."salesman WHERE inactive = 0 ";
	$result = mysqli_query($salesmandb, $sql);
	$final = [];
	if(mysqli_num_rows($result)>0){
		while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
			$final[] = $row;
		}
	}
	if(!empty($final))
		echo json_encode($final);
	else
		echo 'false';
	exit;
}

$sql_details = array( 
 'user' => DBUSER,
 'pass' => DBPASS,
 'db'   => DBNAME,
 'host' => DBHOST
); 



//$current_user = kv_get_current_user(); 

if(isset($_GET['pages'])){	
	$main_table =	TB_PREF. 'pages';
	$users =	TB_PREF. 'users';
	$primaryKey = 'ID';
	$page_type = $_GET['pages'];
	if($page_type == 'slider'){
		$columns = array(
			array( 'db' => '`pg`.`ID`',	'dt' => 0,'field' => 'ID'),
			array( 'db' => 'pageTitle',  'dt' => 1,'field' => 'pageTitle', 'formatter' => function ($d, $row){ //$page= get_a_page($row[0]);				

					return '<img src="'.get_attachment_url($row[0]).'" style="width:90%;"  id="view_media_img" > <br><a class="table_actions" id="view_media" href="'.get_url('admin').'medias.php?view_id='.$row[0].'" >View</a>  <span class="table_actions" > | </span><a class="table_actions" href="'.get_url('admin').'medias.php?delete_id='.$row[0].'" >Delete</a> ' ;

			}),

			array( 'db' => '`pg`.`pageTitle`', 	'dt' => 2,'field' => 'pageTitle'),
			array( 'db' => 'pDate',   			'dt' => 3,'field' => 'pDate'),
			array( 'db' => '`pg`.`status`',   	'dt' => 4,'field' => 'status')	
		);
	}else{
		$columns = array(
			array( 'db' => '`pg`.`ID`',	'dt' => 0,'field' => 'ID'),
			array( 'db' => 'pageTitle',  'dt' => 1,'field' => 'pageTitle', 'formatter' => function ($d, $row){
					$page= get_a_page($row[0]);
					if($page['isRoot'] == 1){
						$added_action = '<span style="font-weight: 500;" >'.$row[1].'</span>-<span style="font-size:13px;font-style:bold" >Front Page</span><br><a class="table_actions blue"  href="'.get_url('admin').'pages.php?edit_id='.$page['ID'].'"  >Edit</a>  <span class="table_actions" > | </span><a class="table_actions green" href="'.get_url().$page['slug'].'" >View</a> </td>';
					}else{
						$added_action =  '<span style="font-weight: 500;" >'.$row[1].'</span><br><a class="table_actions blue"  href="'.get_url('admin').'pages.php?edit_id='.$page['ID'].'"  >Edit</a> <span class="table_actions" > | </span><a class="table_actions green" id="view_media" href="'.get_url().$page['slug'].'" >View</a>  <span class="table_actions" > | </span><a class="table_actions red" href="'.get_url('admin').'pages.php?delete_id='.$page['ID'].'" >Delete</a> ';
					}
					return $added_action;
			}),

			array( 'db' => '`usr`.`full_name`', 'dt' => 2,'field' => 'full_name'),
			array( 'db' => 'pDate',   			'dt' => 3,'field' => 'pDate'),
			array( 'db' => '`pg`.`status`',   	'dt' => 4,'field' => 'status')	
		); 
	}

	//$joinQuery = "FROM `{$pages}` AS `so`  LEFT JOIN {$main_table} AS cstatus ON so.authorID = cstatus.ID";

	$joinQuery = "FROM ".$main_table." AS `pg`  LEFT JOIN ".$users."  AS `usr` ON `pg`.`authorID` = `usr`.`ID`";
	$extra_Where = " `pg`.`page_type`='{$page_type}'" ; //1=1 ORDER BY '; 
	$group_by = "";

}


if(isset($_GET['users'])){
	$main_table =	TB_PREF. 'users';
	$primaryKey = 'ID';

	$columns = array(
		array( 'db' => 'ID',	'dt' => 0,'field' => 'ID'),
		array( 'db' => 'username',  'dt' => 1,'field' => 'username', 'formatter' => function ($d, $row){			

				return '<span style="font-weight: 600;" >'.$row[1].'</span><br><a class="table_actions green"  href="'.get_url('admin').'users.php?edit_id='.$row[0].'"  >Edit</a> <span class="table_actions" > | </span><a class="table_actions red" href="'.get_url('admin').'users.php?delete_id='.$row[0].'" >Delete</a> ';}),
		array( 'db' => 'email',   	'dt' => 2,'field' => 'email'),
		array( 'db' => 'full_name', 'dt' => 3,'field' => 'full_name'),
		array( 'db' => 'role', 		'dt' => 4,'field' => 'role'),
		array( 'db' => 'theme', 	'dt' => 5,'field' => 'theme'),
		array( 'db' => 'status',   	'dt' => 6,'field' => 'status')	

	); 
	$joinQuery = 'FROM '.$main_table.' AS `pg`';
	if(isset($_GET['role'])){
		$extra_Where = "role='".$_GET['role']."'";
	} else
		$extra_Where ='';
	$group_by = "";
}

if(isset($_GET['permissions'])){
	$main_table = TB_PREF. 'permission';
	$primaryKey = 'id';	
	$columns = array(array( 'db' => 'ID',	'dt' => 0,'field' => 'ID'),
		array( 'db' => 'page_permit',	'dt' => 1,'field' => 'page_permit', 'formatter' => function ($d, $row){	

				return '<span style="font-weight: 600;" >'.$row[1].'</span><br><a class="table_actions green"  href="'.get_url('admin').'permissions.php?edit_id='.$row[0].'"  >Edit</a> <span class="table_actions" >';}),
		array( 'db' => 'module',	'dt' => 2,'field' => 'module'),
		array('db' => 'description', 'dt' => 3, 'field' => 'description')); 
	$joinQuery = $extra_Where = $group_by = "";
}

//do_action('Neem-ajax');

$Ajax_Result =Master_Table::simple( $_GET, $sql_details, $main_table, $primaryKey, $columns, $joinQuery , $extra_Where , $group_by, false) ; 

echo json_encode( $Ajax_Result ); 


function db_has_pageID($id){
	return GetRow('page', ['ID' => $id]); 

	global $db;
	$settings_sql  = "SELECT * FROM ".TB_PREF."page WHERE ID='".$id."'";
	$table_data_exist = mysqli_query($db, $settings_sql);
	$tbl_data_ext = mysqli_fetch_row($table_data_exist);
	if($tbl_data_ext[0] > 0){
	  	return true;
	}else
	   	return false; 
} 
?>