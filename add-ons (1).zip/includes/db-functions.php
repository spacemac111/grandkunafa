<?php

/*-------------------------------------------------------+
| Neem CMS
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+
| Add, Edit, Delete, Get And Get Join 
|--------------------------------------------------------+*/

global $db;

$db = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);
if(!$db){
    die( "Sorry! There seems to be a problem connecting to our database.");
}

if (strncmp(mysqli_get_server_info($db), "5.6", 3) >= 0) 
    db_query("SET sql_mode = ''");
   
    mysqli_query($db, "SET NAMES 'utf8';");
     mysqli_query($db,"SET CHARACTER SET utf8");

//DB wrapper functions to change only once for whole application
function db_query($sql, $err_msg=null, $testing=false){
    global $db;
    $result = mysqli_query($db, $sql);
    if($testing)
        echo $sql;

    if(!$result && $err_msg != null ){  
        return $err_msg;
    }    
    return $result;
}


function check_empty_result(){
    global $db;
    $tables =  array('pages', 'users', 'settings');
    foreach( $tables as $tablename){
        $table_exist = mysqli_query($db, "SHOW TABLES LIKE '".TB_PREF.$tablename."'");
        $tbl_ext = mysqli_num_rows($table_exist) > 0;
        if(!$tbl_ext)
            return $tablename .' is missing in your Database'; 
    }
    $tbls =  array('pages', 'users');
    foreach ($tbls as  $value) {
        $sql =  "SELECT COUNT(*) FROM ".TB_PREF.$value;
        $table_data_exist = mysqli_query($db, $sql);
        $tbl_data_ext = mysqli_fetch_row($table_data_exist);
        if($tbl_data_ext[0] > 0){
            //return true;
        }
        else
            return $value .' does not have valid informations in it' ;
    } 

    $settings_params = array ('site_url', 'admin_email', 'site_title', 'allow_user_registration', 'upload_path', 'login_timeout', 'captcha_login', 'login_retries_allowed', 'isRoot' ) ;
     foreach ($settings_params as  $value) {
        $settings_sql  = "SELECT * FROM ".TB_PREF."settings WHERE option_name='".$value."' LIMIT 1";
        $table_data_exist = mysqli_query($db, $settings_sql);
        $tbl_data_ext = mysqli_fetch_row($table_data_exist);
        if($tbl_data_ext[0] > 0){
            //$return = true;
        }        else
            return 'Your Settings has some missing arguments. Please correct it' ;
    }
    return true;
}


function db_get_single_value($sql, $err_msg =null) {
    global $db;
    
    $result = mysqli_query($db, $sql);
    if(!$result && $err_msg != null ){      
        return $err_msg;
    }
    $row = db_fetch_row($result);   
    return $row[0];
}


function db_fetch_row ($result){    return mysqli_fetch_row($result);   }

function db_fetch_assoc ($result){  return mysqli_fetch_assoc($result); }

function db_fetch ($result){    return mysqli_fetch_array($result, MYSQLI_ASSOC);   }

function db_seek (&$result,$record){    return mysqli_data_seek($result, $record);  }
function db_free_result ($result){
    if ($result)
        mysqli_free_result($result);
}

function db_num_rows ($result){ echo is_string($result) ? $result : '' ; 
    return mysqli_num_rows($result);}

function db_num_fields ($result){   return mysqli_num_fields($result);}

function db_escape($value = "", $nullify = false){
    global $db;  
    $value = @html_entity_decode($value);
    $value = @htmlspecialchars($value);
    //reset default if second parameter is skipped
    $nullify = ($nullify === null) ? (false) : ($nullify);
    //check for null/unset/empty strings
    if ((!isset($value)) || (is_null($value)) || ($value === "")) {
        $value = ($nullify) ? ("NULL") : ("''");
    } else {
        if (is_string($value)) {
            //value is a string and should be quoted; determine best method based on available extensions
            if (function_exists('mysqli_real_escape_string')) {
                $value = "'". mysqli_real_escape_string($db, $value)."'";
            } else {
              $value =  "'".mysqli_escape_string($db, $value) ."'" ;
            }
        } else if (!is_numeric($value)) {
            //value is not a string nor numeric
            display_error("ERROR: incorrect data type send to sql query");
            echo '<br><br>';
            exit();
        }
    }
     if(strpos($value, '&quot;')){
       $value =str_replace("&quot;", '"', $value);
    }
    return $value;
}



function login_db_escape($value = "", $nullify = false){
    global $db;
    $value = @html_entity_decode($value);
    $value = @htmlspecialchars($value);
    //reset default if second parameter is skipped
    $nullify = ($nullify === null) ? (false) : ($nullify);
    //check for null/unset/empty strings
    if ((!isset($value)) || (is_null($value)) || ($value === "")) {
        $value = ($nullify) ? ("NULL") : ("''");
    } else {
        if (is_string($value)) {
            //value is a string and should be quoted; determine best method based on available extensions
            if (function_exists('mysqli_real_escape_string')) {
                $value = mysqli_real_escape_string($db, $value);
            } else {
              $value =  mysqli_escape_string($db, $value) ;
            }
        } else if (!is_numeric($value)) {
            //value is not a string nor numeric
            display_error("ERROR: incorrect data type send to sql query");
            echo '<br><br>';
            exit();
        }
    }
    return $value;
}

function db_error_no (){
    global $db;
    return mysqli_errno($db);
}

function db_error_msg($conn){   return mysqli_error($conn);}

function db_insert_id(){
    global $db;
    return mysqli_insert_id($db);
}

function db_num_affected_rows(){
    global $db;
    return mysqli_affected_rows($db);
}

function db_field_name($result, $n){    return mysqli_fetch_field($result); }
function db_close($dbase = null){
    global $db;
    if (!$dbase)
        $dbase = $db;
    return mysqli_close($dbase);
}

function Insert($table_name, $data, $show_query=false){

    $sql0 = "INSERT INTO ".TB_PREF.$table_name."(";

    $sql1 = " VALUES (";

    foreach($data as $key=>$value){

        $sql0 .= $key.",";

        if(is_array($value)) { 

            if($value[1] == 'date')             

                $sql1 .=  db_escape(date2sql($value[0])).",";

            if($value[1] == 'float')

                $sql1 .= $value.",";

            if($value[1] == 'noesc')

                $sql1 .= "'".$value[0]."',";

        }else 

            $sql1 .= db_escape($value).",";

    }

    $sql0 = substr($sql0, 0, -1).")";

    $sql1 = substr($sql1, 0, -1).")";

    if($show_query)
	echo $sql0.$sql1;

    db_query($sql0.$sql1, "Could not insert data to table {$table_name}");

    return  db_insert_id();

}

function kvInsert($table_name, $data){

    $sql0 = "INSERT INTO ".TB_PREF.$table_name."(";

    $sql1 = " VALUES (";

    foreach($data as $key=>$value){

        $sql0 .= $key.",";

        if(is_array($value)) { 

            if($value[1] == 'date')             

                $sql1 .=  db_escape(date2sql($value[0])).",";

            if($value[1] == 'float')

                $sql1 .= $value.",";

            if($value[1] == 'noesc')

                $sql1 .= "'". $value[0]."',";

        }else 

            $sql1 .= db_escape($value).",";

    }

    $sql0 = substr($sql0, 0, -1).")";

    $sql1 = substr($sql1, 0, -1).")";

    //display_notification($sql0.$sql1);

    echo $sql0.$sql1;

    db_query($sql0.$sql1, "Could not insert data to table {$table_name}");

    return  db_insert_id();

}

function Update($table_name, $primary_key ,$data ){

     $sql0 = "UPDATE ".TB_PREF.$table_name." SET ";

    foreach($data as $key=>$value){

        if(is_array($value)) { 

            if($value[1] == 'date')             

                $sql0 .= $key." = ". db_escape(date2sql($value[0])).",";

            if($value[1] == 'float')

                $sql0 .= $key." = ". $value.",";

            if($value[1] == 'noesc')

                $sql0 .= $key." = '". $value[0]."',";

        }else {

            $sql0 .= $key." = ".db_escape($value).",";

        }
    }
    $sql0 = substr($sql0, 0, -1);
    $sql0 .= " where 1=1";
    foreach($primary_key as $key=>$value){
        if(is_array($value)) { 
            if($value[1] == 'date')             
                $sql0 .= " AND ".$key." = ". db_escape(date2sql($value[0])).",";
            if($value[1] == 'float')
                $sql0 .= " AND ".$key." = ". $value.",";
        }else{
            if(is_numeric($value)){
                $sql0 .=" AND ". $key." = ".$value;
            }else
               $sql0 .= " AND ".$key." = ".db_escape($value);
        }

    }

   // $sql0 = substr($sql0, 0, -1);

    return  db_query($sql0, "Could not update data on table {$table_name}");

}



function kvUpdate($table_name, $primary_key ,$data ){

     $sql0 = "UPDATE ".TB_PREF.$table_name." SET ";

    foreach($data as $key=>$value){
        if(is_array($value)) { 
            if($value[1] == 'date')             
                $sql0 .= $key." = ". db_escape(date2sql($value[0])).",";
            if($value[1] == 'float')
                $sql0 .= $key." = ". $value.",";
            if($value[1] == 'noesc')
                $sql0 .= $key." = '". $value[0]."',";
        }else {
            $sql0 .= $key." = ".db_escape($value).",";
        }
    }

    $sql0 = substr($sql0, 0, -1);
    $sql0 .= " where 1=1";
    foreach($primary_key as $key=>$value){
        if(is_array($value)) { 
            if($value[1] == 'date')             
                $sql0 .= " AND ".$key." = ". db_escape(date2sql($value[0])).",";
            if($value[1] == 'float')
                $sql0 .= " AND ".$key." = ". $value.",";
        }else {
            if(is_numeric($value)){
                $sql0 .= " AND ".$key." = ".$value;
            }else
               $sql0 .= " AND ".$key." = ".db_escape($value);
        }
    }
   // $sql0 = substr($sql0, 0, -1);
    echo $sql0;
    return  db_query($sql0, "Could not update data on table {$table_name}");         

}

function Delete($table_name, $conditions){
    $sql0 = "DELETE FROM ".TB_PREF.$table_name." WHERE 1=1";
    foreach ($conditions as $key=>$value) {
        if(is_numeric($value))
            $sql0 .= " AND ".$key."=".$value;
        else
            $sql0 .= " AND ".$key."='".$value."'";
    }
    $result = db_query($sql0, "Could not delete data from {$table_name}");
    return $result;
}

function GetDataJoin($main_table, $joins, $columns=array(), $conditions=null){
     $result_final= array();
    $sql0 = "SELECT ";
    if(count($columns)>0){
        foreach ($columns as $value) {
            $sql0 .= $value.",";
        }

        $sql0 = substr($sql0, 0, -1);
    }else{
        $sql0 .= " *";
    }
    $sql0 .= " FROM ".TB_PREF."{$main_table} ";    foreach ($joins as $value) {
        if(isset($value['join'])){
            $sql0 .= " {$value['join']} JOIN ".TB_PREF.$value['table_name'].' ON '.$value['conditions'];
        }else{
            $sql0 .= " INNER JOIN ".TB_PREF.$value['table_name'].' ON '.$value['conditions'];
        }
    }

    $sql0 .= " WHERE 1=1 ";
    foreach($conditions as $key=>$value){
        $sql0 .= " AND {$key} = ${value}";
    }

    //echo $sql0;
    $result = db_query($sql0, "Could not get data!");   
     while($row = db_fetch($result))
        $result_final[] = $row;
    return $result_final;
}

function GetAll($table_name, $conditions = null, $order_by=null){

    $result_final= array();
    $sql0 = "SELECT * FROM ".TB_PREF.$table_name." WHERE 1=1";
    if($conditions != null) {
        foreach($conditions as $key=>$value){
            $sql0 .= " AND {$key} = '${value}'";
        }
    }

    if($order_by != null) {
        $sql0 .=" ORDER BY ";
        foreach($order_by as $key=>$value){
            $sql0 .= " {$key} ${value}";
        }
    }

  //  echo $sql0;
    $result = db_query($sql0, "Could not get data from {$table_name}");  
     while($row = db_fetch($result))
        $result_final[] = $row;
    return $result_final;
}

function GetRow($table_name, $conditions = null, $order_by=null){
    $sql0 = "SELECT * FROM ".TB_PREF.$table_name." WHERE 1=1";
    if($conditions != null) {
        foreach($conditions as $key=>$value){
            $sql0 .= " AND {$key} = '${value}'";
        }    }

    if($order_by != null) {
        $sql0 .=" ORDER BY ";
        foreach($order_by as $key=>$value){
            $sql0 .= " {$key} ${value}";
        }
    }
    $sql0 .= " LIMIT 1";     
    $result = db_query($sql0, "Could not get data from {$table_name}");
    $data = db_fetch($result);  
    return $data;
}


function GetDataFilter($table_name, $columns, $conditions=null, $order_by=null, $group_by=null){

     $result_final= array();
     $sql0 = "SELECT ";
       if(count($columns)>0){
        foreach ($columns as $value) {
            $sql0 .= $value.",";
        }
    }else{
        $sql0 .= " * ";
    }
    // remove the last character ','

    $sql0 = substr($sql0, 0, -1);
    $sql0 .= " FROM ".TB_PREF.$table_name." WHERE 1=1 ";
    if($conditions){
        foreach($conditions as $key=>$value){
            if(is_numeric($value))
                $sql0 .= " AND {$key} = ${value}";
            else
                $sql0 .= " AND {$key} = '${value}'";
        }

    }  

    if($group_by != null) {
        $sql0 .=" GROUP BY";
        foreach($group_by as $value){
            $sql0 .= " ${value}";        }
    }
    if($order_by != null) {
        $sql0 .=" ORDER BY";
        foreach($order_by as $key=>$value){
            $sql0 .= " {$key} ${value}";
        }
    }

   // echo $sql0;

    $result = db_query($sql0, "Could not get data from {$table_name}");  
    while($row = db_fetch($result))
        $result_final[] = $row;
    return $result_final;
}



function GetSingleValue($tablename, $column_single, $conditions=null){
    $sql0 = "SELECT ".$column_single." FROM ".TB_PREF.$tablename." WHERE 1=1";
    if($conditions != null) {
        foreach($conditions as $key=>$value){
            if(is_numeric($value))
                $sql0 .= " AND {$key} = ${value}";
            else
                $sql0 .= " AND {$key} = '${value}'";
        }
    }    

    //if($tablename == 'users')

    //return db_get_single_value($sql0, "Could not get data from {$tablename}");

    //else
    return db_get_single_value($sql0, "Could not get data from {$tablename}");

}


// For testing purpose

function kvGetSingleValue($tablename, $column_single, $conditions=null){

   $sql0 = "SELECT ".$column_single." FROM ".TB_PREF.$tablename." WHERE 1=1";

    if($conditions != null) {
        foreach($conditions as $key=>$value){
            if(is_numeric($value))
                $sql0 .= " AND {$key} = ${value}";
            else
                $sql0 .= " AND {$key} = '${value}'";
        }
    }   
    echo $sql0;
    exit;
    return db_get_single_value($sql0, "Could not get data from {$tablename}");
}

function deslash($content) {
    /*
     * Replace one or more backslashes followed by a single quote with
     * a single quote.
     */
    $content = preg_replace("/\\\+'/", "'", $content);
    /*
     * Replace one or more backslashes followed by a double quote with
     * a double quote.
     */
    $content = preg_replace('/\\\+"/', '"', $content);
    // Replace one or more backslashes with one backslash.
    $content = preg_replace("/\\\+/", "\\", $content);
    return $content;
}


function kv_insert_page($Title, $Content, $slug, $aID=1, $template='', $root=0, $pID=0, $type='page', $pDate='', $status='Published'){

    $final_string = addslashes(deslash($Content));
    if($pDate == '')
        $pDate = date('Y-m-d');   
    db_query("INSERT INTO ".TB_PREF."pages (pageTitle,pageContent, slug, page_type, authorID, isRoot, template, parentID, pDate, status) VALUES(
            '{$Title}', '{$final_string}', '{$slug}', '{$type}', '{$aID}', '{$root}', '{$template}', '{$pID}', '{$pDate}', '{$status}')");
    return  db_insert_id();

}



function kv_update_page($ID, $Title, $Content, $slug, $aID=1, $template='', $root=0, $pID=0, $type='page', $pDate='', $status='Published'){  

    $final_string = addslashes(deslash($Content));
    if($pDate == '')
        $pDate = date('Y-m-d');
    $sql_value = "UPDATE ".TB_PREF."pages SET 
            pageTitle='{$Title}',
            pageContent = '{$final_string}', 
            slug = '{$slug}', 
            page_type = '{$type}', 
            authorID = '{$aID}', 
            isRoot ='{$root}', 
            template = '{$template}', 
            parentID = '{$pID}', 
            pDate = '{$pDate}', 
            status = '{$status}'  WHERE ID={$ID}" ;
    return db_query($sql_value,"Can't insert into pages");
}


function db_import($filename, $connection, $force=true, $init=true, $protect=false, $return_errors=false){

    global $db; //, $SysPrefs;
   // $trail = $SysPrefs->sql_trail;

    //$SysPrefs->sql_trail = false;

    $allowed_commands = array(
        "create"  => 'table_queries', 
        "delimiter" => 'table_queries',
        "alter table" => 'table_queries', 
        "insert" => 'data_queries', 
        "update" => 'data_queries', 
        "set names" => 'set_names',
        "drop table if exists" => 'drop_queries',
        "drop function if exists" => 'drop_queries',
        "drop trigger if exists" => 'drop_queries',
        "select" => 'data_queries', 
        "delete" => 'data_queries', 
        );



    $protected = array(
        'security_roles',
        'users'
    );



    $ignored_mysql_errors = array( //errors ignored in normal (non forced) mode
        '1022', // duplicate key
        '1050', // Table %s already exists
        '1060', // duplicate column name
        '1061', // duplicate key name
        '1062', // duplicate key entry
        '1091'  // can't drop key/column check if exists
    );



    $set_names =   $data_queries =  $drop_queries =  $table_queries = $sql_errors = array();

    $old_encoding = db_get_charset($db);
    ini_set("max_execution_time", max("180", ini_get("max_execution_time")));
    db_query("SET foreign_key_checks=0");
    db_set_collation($db, 'utf8');

    $check_line_len = false;
    // uncompress gziped backup files

    if (strpos($filename, ".gz") || strpos($filename, ".GZ")) {   
        $lines = db_ungzip("lines", $filename);
        $check_line_len = true;
    } elseif (strpos($filename, ".zip") || strpos($filename, ".ZIP"))
        $lines = db_unzip("lines", $filename);
    else
        $lines = file("". $filename);
    // parse input file

    $query_table = '';
    $delimiter = ';';

    foreach($lines as $line_no => $line)  {

        $gzfile_bug = $check_line_len && (strlen($line) == 8190); // there is a bug in php (at least 4.1.1-5.5.9) gzfile which limits line length to 8190 bytes!
        $line = trim($line);
        if ($init)
            $line = str_replace("kv_", $connection["tbpref"], $line);
        if ($query_table == '')    {   // check if line begins with one of allowed queries

            foreach($allowed_commands as $cmd => $table)       {
                if (strtolower(substr($line, 0, strlen($cmd))) == $cmd)      {
                    if ($cmd == 'delimiter') {
                        $delimiter = trim(substr($line, 10));
                        continue 2;
                    }
                    $query_table = $table;
                    $skip = false;
                    if ($protect)          {
                        foreach($protected as $protbl){
                            if (strpos($line, $connection["tbpref"].$protbl) !== false)
                            {
                                $skip = true; break;
                            }
                        }
                    }
                    if (!$skip)
                        ${$query_table}[] = array('', $line_no+1);
                    break;
                }
            }
         }

         if($query_table != '')  {// inside allowed query        

            $table = $query_table;
            if (!$gzfile_bug && substr($line, -strlen($delimiter)) == $delimiter)  {         
                $line = substr($line, 0, strlen($line) - strlen($delimiter)); // strip delimiter
                $query_table = '';        
            }

            if (!$skip)
                ${$table}[count(${$table}) - 1][0] .= $line . "\n";
        }
    }

    //
    // 'set names' or equivalents should be used only on post 2.3 FA versions
    // otherwise text encoding can be broken during import
    //
    $encoding = null; // UI encoding for default site language is the default

    $new_db = $init || db_fixed();
    $new_file = count($set_names);
    if ($new_db)  {
        if ($new_file) {
            if (count($set_names)) {// standard db restore            
                if (preg_match('/set\s*names\s*[\']?(\w*)[\']?/i', $set_names[0][0], $match))
                    $encoding = $match[1];
            }
            // otherwise use default site ui encoding
        }
    }
    else   {
        if ($new_file)     { // import on old db is forbidden: this would destroy db content unless latin1 was used before in UI
        
            $msg = _("This is new format backup file which cannot be restored on database not migrated to utf8.");
            if ($return_errors)
                return $msg;
            else
                display_error($msg);
            return false;
        }
         else   // backup restore during upgrade failure
            $encoding = 'latin1'; // standard encoding on mysql client
    }
   db_set_charset($db, $encoding);

    /*/ {   // for debugging purposes
    global $path_to_root;
    $f = fopen($path_to_root.'/tmp/dbimport.txt', 'w+');
    fwrite($f, print_r($set_names,true) ."\n");
    fwrite($f, print_r($drop_queries,true) ."\n");
    fwrite($f, print_r($table_queries,true) ."\n");
    fwrite($f, print_r($data_queries,true));
    fclose($f);
    }

    /*/

    if ($return_errors)   {   // prevent errors display
        $save_debug = $SysPrefs->go_debug;
        $SysPrefs->go_debug = 0;
    }

    // execute drop tables if exists queries

    if (is_array($drop_queries))   {
        foreach($drop_queries as $drop_query)    {
            if (!db_query($drop_query[0]))       {
                if (!in_array(db_error_no(), $ignored_mysql_errors) || !$force)
                    $sql_errors[] = array(db_error_msg($db), $drop_query[1]);

            }
        }
    }



    // execute create tables queries

    if (is_array($table_queries)) {
        foreach($table_queries as $table_query)     {
            if (!db_query($table_query[0])) {   
                if (!in_array(db_error_no(), $ignored_mysql_errors) || !$force) {
                    $sql_errors[] = array(db_error_msg($db), $table_query[1]);
                }
            }
        }
   }
    // execute insert data queries
    if (is_array($data_queries))   {
        foreach($data_queries as $data_query)     {
            if (!db_query($data_query[0]))   {
                if (!in_array(db_error_no(),$ignored_mysql_errors) || !$force)
                    $sql_errors[] = array(db_error_msg($db), $data_query[1]);
            }
        }
    }

    if ($return_errors)
        $SysPrefs->go_debug = $save_debug;

    //$SysPrefs->sql_trail = $trail;

    db_query("SET foreign_key_checks=1");
    if ($delimiter != ';') db_query("delimiter ;"); // just for any case
    db_set_charset($db, $old_encoding); // restore connection encoding

    if (count($sql_errors)) {
        if ($return_errors)
            return $sql_errors;
        // display first failure message; the rest are probably derivative 

        $err = $sql_errors[0];
        display_error(sprintf(_("SQL script execution failed in line %d: %s"),
            $err[1], $err[0]));
        return false;
    } else
        return true;
}



function db_set_charset($db, $charset){
    global $db;
    return mysqli_set_charset($db, $charset);
}

function db_set_collation($db, $collation){
    return mysqli_query($db, "ALTER DATABASE COLLATE ".get_mysql_collation($collation));
}
?>
