<?php 
/* 
Template Name : Sales Transactions
*/
global $current_user;
if(has_user_permission('View Overall', 'Sales') || has_user_permission('View Own', 'Sales')) {
// if($current_user['role'] != 'Administrator') 
	
  $use_dimension = get_company_details('use_dimension');
  $kv_batch = get_company_details('kv_batch');
  $kv_exp_date = get_company_details('kv_exp_date');

get_header(); ?>

<div class="container dashboard" id="bodySection">
	<div class="row" >	

    <h3 class="NewCustomerInvoice" style="max-width: 300px;" > <span> <?php echo _("Sales Invoices"); ?> </span> <a  class="btn-floating btn-large primary-color" href="<?php echo get_url('pos'); ?>" > <i class="material-icons">insert_drive_file</i></a></h3>

    <label style="padding-left: 5%;margin-top: 20px;margin-bottom: -40px;line-height: 50px;"> <?php echo _("Filter Status"); ?> : <select name="FilterCustomerInvoice"  id="FilterCustomerInvoice"> 
        <option value="-1" > <?php echo _("All"); ?> </option>
        <option value="Overdue" > <?php echo _("Overdue"); ?> </option>
        <option value="Yet To Receive" > <?php echo _("Yet To Receive"); ?> </option> 
        <option value="Received" > <?php echo _("Received"); ?> </option>
      </select></label>   

    <label style="padding-left: 5%;margin-top: 20px;margin-bottom: -40px;line-height: 50px;"> <?php echo _("Date"); ?> : <select name="FilterDate"  id="FilterDate"> 
        <option value="-1" > <?php echo _("All"); ?> </option>
        <option value="ThisMonth" > <?php echo _("This Month"); ?> </option>
        <option value="LastMonth" > <?php echo _("Last Month"); ?> </option>  
        <option value="LastWeek" > <?php echo _("Last Week"); ?> </option>
        <option value="ThisWeek" > <?php echo _("This Week"); ?> </option>
        <option value="Yesterday" > <?php echo _("Yesterday"); ?> </option>
        <option value="Today" selected> <?php echo _("Today"); ?> </option></select></label>
        <?php if($current_user['role'] == 'Administrator' || has_user_permission('View Overall', 'Sales')){?>
           <label style="padding-left: 5%;margin-top: 20px;margin-bottom: -40px;line-height: 50px;"> <?php echo _("Salesman"); ?> : <select name="Salesman"  id="Salesman"> 
        <option value="-1" > <?php echo _("All"); ?> </option>
        <?php $salesmans = FAGetAll('salesman');
            foreach($salesmans as $single) {
          echo '<option value="'.$single['salesman_code'].'" > '.$single['salesman_name'].'</option>';
        } ?></select></label>
        <?php } ?>
         </div>
         <div class="row"> 
        <?php  if ($use_dimension > 0){
                      echo '<div class="col-md-2 col-sm-6"><label>'._("Dimension").'</label></div><div class="col-md-3  col-sm-6">';
                      Dimensions_dropdown('dimension_id', 1, false);
                      echo '</div></div>';
                }
                if ($use_dimension > 1){
                      echo '<div class="col-md-2">'._("Dimension 2").'</div><div class="col-md-3">';
                      Dimensions_dropdown('dimension2_id', 2, false);
                      echo '</div></div>'; 
                }?>
  </div>
  <div class="row">
		<table class="list bordered highlight" id="CustomerInvoices">
				<thead><tr> <th> <?php echo _("Reference"); ?> </th> <th> <?php echo _("Customer Name"); ?> </th> <th> <?php echo _("Invoice Date"); ?></th> <th> <?php echo _("Due Date"); ?></th style="text-align: right"> <th> <?php echo _("Amount"); ?> </th> <th style="text-align: right"> <?php echo _("Yet To Receive"); ?></th><th> <?php echo _("Return"); ?> </th><th> <?php echo _("Status"); ?></th> </tr></thead>
			</table>
	</div>
</div>

<?php 
} else kv_direct(get_url('404')); ?>
<style>
#CustomerInvoices tr td:nth-child(5), #CustomerInvoices tr td:nth-child(6){ text-align: right; }

</style>
 <!-- New message Structure -->
<div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="PDFTitle" >
               <i class="material-icons"> receipt</i> <?php echo _("Receipt"); ?>
            </h4>
         </div>
         <div class="modal-body" style="min-height:500px;">
          <div style="min-height:500px;text-align: center;margin: 0 auto;vertical-align: middle;" id="PreLoaderImg">
        <img src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF" style="  padding-top: 25%;"> </div>
            <div class="iframe-container" style="min-height:500px;">  
               <iframe src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF">    </iframe>   
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"> <?php echo _("Close"); ?></button>
         </div>
      </div>
   </div>
</div>

 <!-- Payment Receive  -->
<div class="modal fade" id="PaymentModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="PDFTitle" >
               <i class="material-icons"> receipt</i> <?php echo _("Receive Payment"); ?>
            </h4>
         </div>
		  <form action="#" class="" id="CustomerPayment" enctype="multipart/form-data" method="post" accept-charset="utf-8">
         <div class="modal-body" style="min-height:350px;">
          <div class="row">
                  <div class="col-sm-12">
                     
					 <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Payment Reference"); ?></label>
                        <div class="col-md-7"><label id="ref"> <?php echo   $Refs->get_next(ST_CUSTPAYMENT); ?></label></div>
                     </div>
					  <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Payment Date"); ?></label>
                        <div class="col-md-7"><label id="ref"> <?php echo  date('d-m-Y'); ?></label></div>
                     </div>
					 <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Invoice No"); ?></label>
                        <div class="col-md-7"><label id="invNo"> <?php echo ''; ?></label></div>
                     </div>
                     <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Invoice Reference"); ?></label>
                        <div class="col-md-7"><label id="invRef"> <?php echo  ''; ?></label></div>
                     </div> 

                     <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Invoice Amount"); ?></label>
                        <div class="col-md-7"><label id="inv_amount"> <?php echo  ''; ?></label></div>
                     </div>

                     <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Yet to Collect"); ?></label>
                        <div class="col-md-7"><label id="yettocollect"> <?php echo  ''; ?></label>
                          <input type="hidden" name="yettocollect" class="yettocollect" value="0" ></div>
                     </div>
                     
                    <?php $bankList = FAGetAll('bank_accounts');

                    foreach($bankList as $bank) { ?>
                        <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo $bank['bank_account_name']; ?> <!--<span class="currency" ></span> --></label>
                        <div class="col-md-7"><input type="text" name="bank_<?php echo $bank['id']; ?>" class="form-control Amount user_paid"></div>
                     </div> 
                   <?php } ?>

					<!-- <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Payment Mtd"); ?></label>
                        <div class="col-md-7"> <div class="radio radio-primary"><label> <input type="radio" name="paymentOpt" class="form-control paymentOpt" value="0"> <span class="circle"></span><span class="check"></span><?php echo _("Cash Only"); ?> </label></div>
						 <div class="radio radio-primary"> <label> <input type="radio" name="paymentOpt" class="form-control paymentOpt" value="1"> <span class="circle"></span><span class="check"></span> <?php echo _("Credit/Debit Card"); ?> </label> </div>
						</div>
                     </div>
                     <div class="row form-group CardRef">
                        <label class="col-md-5 control-label"><?php echo _("Trans Reference"); ?></label>
                        <div class="col-md-7"><input type="text" name="trans_ref" id="trans_ref" class="form-control"></div>
                     </div>
                     <div class="row form-group">
                        <label class="col-md-5 control-label"><?php echo _("Amount to Receive"); ?> <span class="currency" ></span></label>
                        <div class="col-md-7"><input type="text" name="amount" id="user_paid" class="form-control"></div>
                     </div> -->
					</div>
				</div>
				<input type="hidden" name="invNo" value="0" class="invNo" > 
         </div>
         <div class="modal-footer">		  
            <button type="button" class="btn btn-default" data-dismiss="modal"> <?php echo _("Close"); ?></button>
			<?php if(has_user_permission('Collect Payment', 'sales')){ ?>
            <button type="submit" class="btn btn-primary" id="RecordPayment"><?php echo _("Submit"); ?></button>
            <?php } ?>
         </div>
		 </form>
      </div>
   </div>
</div>

 <!-- Return Modal Popup -->
<div class="modal fade" id="SalesReturn" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="PDFTitle" >
               <i class="material-icons"> rotate_90_degrees_ccw</i> <?php echo _("Sales Return Record"); ?>
            </h4>
         </div>
         <div class="modal-body" style="min-height:500px;">
            <div class="row">
                  <div class="col-sm-12">
                     
                    <div class="col-md-6 form-group">
                        <label class="col-md-6 control-label"><?php echo _("Credit Reference"); ?></label>
                        <div class="col-md-6"><label id="CreditRef"> <?php echo $Refs->get_next(ST_CUSTCREDIT); ?></label></div>
                    </div>

                     <div class="form-group col-md-6">
                        <label class="col-md-6 control-label"><?php echo _("Invoice Reference"); ?></label>
                        <div class="col-md-6"><label id="R_invRef"> <?php echo  ''; ?></label></div>
                     </div>

                    <div class="form-group col-md-6">
                        <label class="col-md-6 control-label"><?php echo _("Credit Date"); ?></label>
                        <div class="col-md-6"><label id="R_date"> <?php echo  date('d-m-Y'); ?></label></div>
                     </div>
                    <div class="form-group col-md-6">
                        <label class="col-md-6 control-label"><?php echo _("Invoice Date"); ?></label>
                        <div class="col-md-6"><label id="R_invDate"> <?php echo ''; ?></label></div>
                     </div>

                     <div class="form-group col-md-6">
                        <label class="col-md-6 control-label"><?php echo _("Invoice No"); ?></label>
                        <div class="col-md-6"><label id="R_invNo"> <?php echo ''; ?></label></div>
                     </div>    

                     <div class="form-group col-md-6">
                        <label class="col-md-6 control-label"><?php echo _("Invoice Amount"); ?></label>
                        <div class="col-md-6"><label id="R_amt"> <?php echo ''; ?></label></div>
                     </div>
                  <input type="hidden" name="InvNumber" id="InvNumber" value="">
                  <input type="hidden" name="TotalReturnAmt" id="TotalReturnAmt" value="">
              </div>
              <div class="col-md-12">
                <table id="SalesReturnCart">
                  <thead>
                    <tr> <th> <?php echo _("Item Name"); ?></th> <th> <?php echo _("Price"); ?> </th><th> <?php echo _("Qty"); ?></th> 

                      <?php if($kv_batch || $kv_exp_date){ ?>
                              <th> <?php echo _("Batch No"); ?></th> 
                              <?php if($kv_exp_date) {?>
                              <th> <?php echo _("Exp Date"); ?></th> 
                            <?php }
                         } ?> <th> <?php echo _("Return Qty"); ?></th> <th style="text-align: right;"> <?php echo _("Amount"); ?></th></tr>
                  </thead>
                  <tbody>

                  </tbody>
                </table>
              </div>
        </div>
            
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"> <?php echo _("Close"); ?></button>
            <?php if(has_user_permission('Refund', 'sales')){ ?>
            <button type="submit" class="btn btn-primary" id="ReceiveGoods"><?php echo _("Submit"); ?></button>
            <?php } ?>
         </div>
      </div>
   </div>
</div>
 <script>
 $(function(){
    var pric_Dec =  '<?php echo user_price_dec(); ?>'; 

  $("input[class*='Amount']").keydown(function (event) {
        if (event.shiftKey == true) {
            event.preventDefault();
        }
        if ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || event.keyCode == 46 || event.keyCode == 190 || event.keyCode == 188 || event.keyCode == 189 ) {
        } else {
            event.preventDefault();
        }            
        if($(this).val().indexOf(',') !== -1 && event.keyCode == 188)
            event.preventDefault(); 
    if($(this).val().indexOf('-') !== -1 && event.keyCode == 189)
            event.preventDefault();      
});

$(".Amount").on('change', function () {

  var amt = $(this).val();   
  var amount = formatMoney(amt);
  $(this).val(amount);
});

   FilterVal = $("#FilterCustomerInvoice").val();   
   FilterDate = $("#FilterDate").val(); 
   if($("#Salesman").length > 0 )  
    Salesman = $("#Salesman").val();   
  else
    Salesman = -1;
	 $(".CardRef").hide();
	ToReceiveTable = $("#CustomerInvoices").dataTable({
          "processing": true,
          "serverSide": true,
          "order": [[ 6, "desc" ]],
          "pageLength": 25,
		  "dom": '<"FilterCustomerInvoice">frtip',
          "ajax": "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterDate="+FilterDate
      });
		//$("div.FilterCustomerInvoice").html(' ');
		$("#FilterCustomerInvoice").on("change", function(){    
      FilterVal = $(this).val();    
      dimension_id = $("#dimension_id").val();
      dimension2_id = $("#dimension2_id").val();  
      Salesman = $("#Salesman").val();
      FilterDate = $("#FilterDate").val(); 
      var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate+"&Salesman="+Salesman+"&dim="+dimension_id+"&dim2="+dimension2_id;
      ToReceiveTable.api().ajax.url(newURL).load();
    });

    $("#FilterDate").on("change", function(){		
			FilterDate = $(this).val();		      
      dimension_id = $("#dimension_id").val();
      dimension2_id = $("#dimension2_id").val(); 
      Salesman = $("#Salesman").val();
       FilterVal = $("#FilterCustomerInvoice").val(); 
			var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate+"&Salesman="+Salesman+"&dim="+dimension_id+"&dim2="+dimension2_id;
			ToReceiveTable.api().ajax.url(newURL).load();
		}); 	

    $("#Salesman").on("change", function(){   
      Salesman = $(this).val();    
      dimension_id = $("#dimension_id").val();
      dimension2_id = $("#dimension2_id").val();   
      FilterDate = $("#FilterDate").val();  
      FilterVal = $("#FilterCustomerInvoice").val();   
      var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate+"&Salesman="+Salesman+"&dim="+dimension_id+"&dim2="+dimension2_id;
      ToReceiveTable.api().ajax.url(newURL).load();
    }); 

     <?php  if ($use_dimension > 0) { ?>
        $("#dimension_id").on("change", function(){   
          dimension_id = $(this).val();      
          dimension2_id = $("#dimension2_id").val(); 
          FilterDate = $("#FilterDate").val();  
          Salesman = $("#Salesman").val();
          FilterVal = $("#FilterCustomerInvoice").val();        
          var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate+"&Salesman="+Salesman+"&dim="+dimension_id;
          ToReceiveTable.api().ajax.url(newURL).load();
        }); 
        $("#dimension2_id").on("change", function(){   
          dimension_id = $("#dimension_id").val();         
          dimension2_id = $(this).val();   
          FilterDate = $("#FilterDate").val();  
          Salesman = $("#Salesman").val();
          FilterVal = $("#FilterCustomerInvoice").val();       
          var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate+"&Salesman="+Salesman+"&dim="+dimension_id+"&dim2="+dimension2_id;
          ToReceiveTable.api().ajax.url(newURL).load();
        }); 

     <?php } ?>

		$(".paymentOpt").on("change", function(){
			var radioVal = $("input:radio[name ='paymentOpt']:checked").val();			
			if(radioVal == 1){
				$(".CardRef").show();
				$(".CardRef").focus();
			} else {
				$(".CardRef").hide(); 
			}
		});
    $("body").on("keyup", ".ReturnQty", function(e){
      var max_qty = $(this).data('qty');
      var price = $(this).data('price');
      var stock_id = $(this).data('stock_id');
      var return_qty = $(this).val();
      var amt_td = $(this).parent().next();

      if(return_qty <= max_qty){
        amt_td.html(formatMoney(price*return_qty, parseInt(pric_Dec) ));        
      } else{
        alert('<?php echo _("You are inputting more than sold Quantity"); ?>');
        $(this).val('');
        amt_td.html(formatMoney(0, parseInt(pric_Dec) )); 
      }
      CalculateTotal();
    }); 

    function CalculateTotal(){
      var TotalReturnAmt = 0 ;
      $('.ReturnQty').each(function(i, obj) {
           var qty = $(this).val();           
          if(qty > 0 ){           
            var price = $(this).data('price');
            TotalReturnAmt +=price * qty;
          }
      });
        $(".TotalReturnAmt").html(formatMoney(TotalReturnAmt, parseInt(pric_Dec)));
        $("#TotalReturnAmt").val(TotalReturnAmt);
    }
    $("body").on("click", "#ReceiveGoods", function(e){
        var InvNumber = $("#InvNumber").val();
        var TotalReturnAmt = $("#TotalReturnAmt").val();
        var BankAccountsList = $("#BankAccountsList").val();
		    var ifrme_modal = $("#pdfModal");
        var final = [];
        $('.ReturnQty').each(function(i, obj) {
          var qty = $(this).val();
          if(qty > 0 ){
            var stock_id = $(this).data('stock_id');
            var price = $(this).data('price');
            var discount = $(this).data('discount');
            var batch_no = $(this).data('batch_no');
            var exp_date = $(this).data('exp_date');
            final.push([stock_id, qty, price, discount, batch_no, exp_date]);
          }
        });
        $.ajax({
             url: 'ajax?WriteReturn=1',
             type: 'post',
             data: {'details':final, 'trans_no': InvNumber, 'amt' : TotalReturnAmt, 'bank_id' : BankAccountsList},             
             success:function(response){
                var id = parseInt(response.trim());
                if(id > 0){
					         $('#SalesReturn').modal('hide'); 					
					         $.ajax({
        						  type: 'post',
        						  url: 'ajax?PrepareReport=yes&trans_no='+id+'&rep=113',           
        						  dataType: "json",
        						  success: function (data) {  
        							   ifrme_modal.find('iframe').attr('id','printf');
        							   var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();               
        							   ifrme_modal.find('iframe').attr('src',ifram_url);						       
        						      $('#pdfModal').modal('show');
        						      var title = ifrme_modal.contents().find("title").html();
        						      $("#PDFTitle").html(data.actual_name+' - View');
        						      $("#actual_name").val(data.actual_name);
        						      $("#PreLoaderImg").hide();
        						      $(".iframe-container").show();
        						  }
        					 });
					       $('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
				        }
             }
        });
        console.log(final);
    });
	
	 $('body').on('load', "#printf", function() {
		 var id = $(this).attr('src');
		 var tabId = id.substr(id.length - 3);  		
		 if(tabId == 'pdf')
			document.getElementById('printf').contentWindow.print();
	 });
	 
    $("body").on("click", ".SalesReturn", function(e){
      var trans_no = $(this).data('trans_no');
        $.ajax({
          url: 'ajax?GetInvoice=yes&trans_no='+trans_no+'&return=yes',
          type: 'POST',
          data : {'trans_no': trans_no },  
          dataType: 'JSON',   
          success: function(data) {       
            $("#CreditRef").html(); 
            $("#R_invRef").html(data.reference);
            $("#R_invDate").html(data.tran_date);
            $("#R_invNo").html(data.trans_no);            
            $("#R_amt").html(data.Total);  
            $("#InvNumber").val(data.trans_no);
            last_class = 'even';
            $('#SalesReturn').find('tbody').empty();
            var colspan=2;
            var line_item_exist = false;
            $.each(data.line_items, function (key, val) {
               if(last_class == 'odd')
                  class_name = 'even';
               else
                  class_name ='odd';
                var qty_bal = val.quantity-val.qty_done;
                //if(qty_bal <= 0 )
                 // continue;
                if(val.quantity != val.qty_done && val.quantity > 0 && qty_bal > 0 ){
                  var price = parseFloat(val.unit_price).toFixed(data.dec);				 
                  
                  var this_row = '<tr class="'+class_name+'" id="Cart_ID_'+val.id+'"><td>'+val.stock_id+' - '+val.description+'</td><td class="amount" >'+price+'</td><td>'+qty_bal+'</td>';

                  if(data.kv_batch || data.kv_exp_date){
                    this_row += '<td>'+val.batch_no+'</td>';
                    colspan= 3;
                    if(data.kv_exp_date){
                      this_row += '<td>'+val.exp_date+'</td>';
                      colspan = 4;
                    }
                  }
                  this_row += '<td class="form-group"><input type="text" class="form-control amount ReturnQty" data-stock_id="'+val.stock_id+'" data-qty="'+qty_bal+'" name="Cart_ID_'+val.id+'" data-price="'+price+'" data-batch_no="'+val.batch_no+'" data-exp_date="'+val.exp_date+'" data-discount="'+val.discount+'" value="" onkeypress="return IsNumeric(event);"> </td><td class="amt_'+val.id+' " style="text-align:right;"> 0.00</td></tr>';
                   $("#SalesReturnCart  > tbody:last-child").append(this_row);                
                  last_class = class_name;
                  line_item_exist = true;
              }
            }); 

            if(line_item_exist == true){
                var bank_acc_select = '';

                <?php if(count($bankList)) {
                    echo ' bank_acc_select += "<select id=\"BankAccountsList\" name=\"BankAccountsList\" class=\"form-control\">"; ';
                    foreach($bankList as $bank) {
                        echo ' bank_acc_select += "<option value=\"'.$bank['id'].'\" > '.$bank['bank_account_name'].'</option>";';
                    }  
                    echo ' bank_acc_select += "</select>" ;';
                  }?>
                  //var shipping_row =  ' <tr> <td></td><td></td><td colspan="'+colspan+'" class="amount"> <?php echo _("Delivery Cost"); ?></td> <</tr>';

                 // $("#SalesReturnCart  > tbody:last-child").append(shipping_row);

                var this_row = ' <tr> <td> <?php echo _("Paid Out"); ?> </td> <td> '+bank_acc_select+'</td> <td colspan="'+colspan+'" class="amount"> <?php echo _("Total"); ?></td> <td class="TotalReturnAmt amount">'+formatMoney(0, parseInt(pric_Dec) )+'</td></tr>';
                $("#ReceiveGoods").show();
            } else {
              var this_row = '<tr><td colspan="'+(colspan+3)+'" style="text-align: center; font-weight: bold; "> <?php echo _("No Items found to Return"); ?> </td></td>';
              $("#ReceiveGoods").hide();
            }
            $("#SalesReturnCart  > tbody:last-child").append(this_row);
            $('#SalesReturn').modal('show'); 
          } 
        });        
    });
		$("#RecordPayment").on("click", function(e){
			e.preventDefault();
			var trans_no = $(".invNo").val();
			var left_to_amount = $(".yettocollect").val();
			//var pmtd = $("input:radio[name ='paymentOpt']:checked").val();
			var trans_ref = $("#trans_ref").val();
      var this_alloc_amount = 0;
       $('.Amount').each(function() {
        this_alloc_amount += parseFloat($(this).val());

      });
       if(this_alloc_amount <= left_to_amount){
        $('.Amount').each(function() {
          var amount = parseFloat($(this).val());
          var bank_id = $(this).attr('name').substr(5);
          $.ajax({
            url: 'ajax?WritePayment=Yes',
            type: 'POST',
            data : {'trans_no': trans_no, 'amount' : amount ,  'trans_ref' : trans_ref, 'bank_id' : bank_id},  
            dataType: 'JSON',   
            success: function(data) { 
              var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes";
              ToReceiveTable.api().ajax.url(newURL).load();
              $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
              $('#PaymentModal').modal('hide'); 
            } 
          });
        });
      } else {
        alert("The entered amount is greater than invoice amount");
      }
      
		}); 
		
		$("body").on("click", ".PaymentModal", function(e) {
			$("#trans_ref").val('');
			$("input[name=paymentOpt][value=0]").prop('checked', true);
			$(".CardRef").hide();
			var trans_no = $(this).data('trans_no');
			$.ajax({
            type: 'post',
            url: 'ajax?GetInvoice=yes&trans_no='+trans_no,           
            dataType: "json",
            success: function (data) {  
              var inv_amount = eval(data.ov_gst) + eval(data.ov_amount);              
              var left_to = inv_amount - parseFloat(data.alloc);
      				$("#invRef").html(data.reference);
              $("#inv_amount").html(formatMoney(inv_amount));
      				$("#yettocollect").html(formatMoney(left_to));
              $(".yettocollect").val(left_to);
              $("#invNo").html(data.trans_no);
      				$(".invNo").val(data.trans_no);
      				$("#user_paid").val(data.balance);				
      				$(".currency").html(data.curr_symbol);   
              $(".Amount").val('');
              $('#PaymentModal').modal('show');            
            }
          });
		});
		// Print the last processed invoice from the sales man
	$("body").on("click", ".PrintReceipt", function(e){  //$('.PrintReceipt').on("click",function(e){    
		$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
		$('#PayComplete').modal('hide'); 
		$('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
		var trans_no = $(this).data('trans_no');
        var ifrme_modal = $("#pdfModal");
          $.ajax({
            type: 'post',
            url: 'ajax?Prepare<?php echo ($current_user['theme'] == 'kot' ? 'Pos' : ''); ?>Report=yes&trans_no='+trans_no,           
            dataType: "json",
            success: function (data) {            
              var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();               
              ifrme_modal.find('iframe').attr('src',ifram_url);     
               $('#pdfModal').modal('show');
               var title = ifrme_modal.contents().find("title").html();
               $("#PDFTitle").html(data.actual_name+' - View');
               $("#actual_name").val(data.actual_name);
               $("#PreLoaderImg").hide();
               $(".iframe-container").show();
            }
          });
          $('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
	});	
	setInputFilter(document.getElementById("user_paid"), function(value) {
  return /^-?\d*[.,]?\d*$/.test(value); });
 });
 
  function setInputFilter(textbox, inputFilter) {
  ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
     if(textbox.length){
        textbox.addEventListener(event, function() {
        if (inputFilter(this.value)) {
          this.oldValue = this.value;
          this.oldSelectionStart = this.selectionStart;
          this.oldSelectionEnd = this.selectionEnd;
        } else if (this.hasOwnProperty("oldValue")) {
          this.value = this.oldValue;
          this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
        }
      });
    }
  });
}

/*
  formate money into comma seperator 
*/
function formatMoney(amount, decimalCount = 2, decimal = ".", thousands = ",") {
  try {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
    const negativeSign = amount < 0 ? "-" : "";
    let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
    let j = (i.length > 3) ? i.length % 3 : 0;
    return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
  } catch (e) {
    console.log(e)
  }
}

var specialKeys = new Array();
specialKeys.push(8,46); //Backspace
function IsNumeric(e) {
    var keyCode = e.which ? e.which : e.keyCode;
    console.log( keyCode );
    var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
    return ret;
}
 </script>
 <style>
 #FilterCustomerInvoice, #FilterDate, #Salesman { border:0; padding: 7px; }
 .NewCustomerInvoice { float: left; } 
 html[dir="rtl"] .NewCustomerInvoice { float:right; padding-left: 50px; }
 #SalesReturn .modal-dialog { width: 700px; }
 #SalesReturn .form-group label.control-label { margin: 6px 0 0 0; }
 #SalesReturnCart tr th:first-child, #SalesReturnCart th td:first-child{ width:40%; }
 <?php if($kv_batch || $kv_exp_date) { ?>
    #SalesReturnCart tr th:nth-child(4){ width:15%; }
<?php if($kv_exp_date) { ?>
    #SalesReturnCart tr td:nth-child(5){ width:20%; }
<?php } }  ?>
 .Amount { text-align: right; }
 </style>
<?php get_footer(); ?>