<?php 
/*
Template Name: Report Preview
*/
//include(ABSPATH."/includes/reporting/pdf_report.inc");
//include("includes/gettext.inc");
//include("includes/sysnames.inc");

get_text_init();
//print_r($_POST);
if(isset($_GET['send_mail']) && $_GET['send_mail'] == 'yes'){
	$subject =$_POST['subject'];
	$email = $_POST['email'];
	$message = $_POST['message'];
	$attachment = array( $_POST['actual_name'] => $_POST['full_path']);
	echo kv_mail($email, $subject, $message, "html", $attachment);
	exit;
} else {
	if( isset($_POST['REP_ID'])) {
		 $rep_file = ABSPATH ."/includes/reporting/rep/rep".$_POST['REP_ID'].".php"; 
		if(file_exists($rep_file)){
			//echo $rep_file;
	  		require_once($rep_file);
		}
	}
	if(isset($_GET['trans_no']) && isset($_GET['type'])){
		if($_GET['type'] == 20){
			$rep_file = dirname(__FILE__) ."/reporting/rep207.php"; 
			if(file_exists($rep_file))
				require_once($rep_file);
		}elseif($_GET['type'] == 10){
			$rep_file = dirname(__FILE__) ."/reporting/rep107.php"; 
			if(file_exists($rep_file))
				require_once($rep_file);
		}elseif($_GET['type'] == 100){
			$rep_file = dirname(__FILE__) ."/reporting/rep1000.php"; 
			if(file_exists($rep_file))
				require_once($rep_file);
		}
			
	}
}

function user_langauge(){
	global $selected_user;
	if($selected_user['language'] == 'en_US')
		return 'C';
	else
		return 'nl_NL';	
}

//echo "sergsergse";
?>