<?php 
/*
* Template Name : 404
*/
get_header(); ?>

			Sorry!, The Page not Found.	

<?php get_footer(); ?>