<?php 
/* 
Template Name: Return
*/
global $current_user;
if(!has_user_permission('Refund', 'Sales')) 
	kv_direct(get_url('404'));
get_header(); ?>

<div class="container dashboard" id="bodySection">

	<div class="row">
		<table class="list bordered highlight" id="ReturnInvoices">
				<thead><tr> <th> <?php echo _("No"); ?> </th> <th> <?php echo _("Reference"); ?> </th> <th> <?php echo _("Customer Name"); ?> </th> <th> <?php echo _("Date"); ?></th> <th style="text-align: right;"> <?php echo _("Amount"); ?> </th> </tr></thead>
			</table>
	</div>
</div>
<style>
#ReturnInvoices tr td:nth-child(5){ text-align: right; }
</style>
 <!-- New message Structure -->
<div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header" >
            <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="PDFTitle" >
               <i class="material-icons"> receipt</i> <?php echo _("Receipt"); ?>
            </h4>
         </div>
         <div class="modal-body" style="min-height:500px;">
          <div style="min-height:500px;text-align: center;margin: 0 auto;vertical-align: middle;" id="PreLoaderImg">
        <img src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF" style="  padding-top: 25%;"> </div>
            <div class="iframe-container" style="min-height:500px;">  
               <iframe src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF">    </iframe>   
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"> <?php echo _("Close"); ?></button>
         </div>
      </div>
   </div>
</div>

<script>
 $(function(){
    var pric_Dec =  '<?php echo user_price_dec(); ?>';
    
	ToReceiveTable = $("#ReturnInvoices").dataTable({
          "processing": true,
          "serverSide": true,
          "order": [[ 0, "desc" ]],
          "pageLength": 25,
		  "ajax": "<?php  echo get_url(); ?>ajax?ReturnInvoices=yes"
      });
		//$("div.FilterCustomerInvoice").html(' ');
	$("body").on("click", ".PrintReceipt", function(e){  //$('.PrintReceipt').on("click",function(e){    
		$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
		$('#PayComplete').modal('hide'); 
		$('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
		var trans_no = $(this).data('trans_no');
        var ifrme_modal = $("#pdfModal");
          $.ajax({
            type: 'post',
            url: 'ajax?PrepareReport=yes&trans_no='+trans_no+'&rep=113',           
            dataType: "json",
            success: function (data) {            
              var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();               
              ifrme_modal.find('iframe').attr('src',ifram_url);     
               $('#pdfModal').modal('show');
               var title = ifrme_modal.contents().find("title").html();
               $("#PDFTitle").html(data.actual_name+' - View');
               $("#actual_name").val(data.actual_name);
               $("#PreLoaderImg").hide();
               $(".iframe-container").show();
            }
          });
          $('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
	});		
 });
 </script>
 
  <style>
 #FilterCustomerInvoice, #FilterDate, #Salesman { border:0; padding: 7px; }
 .amount { text-align: right; }
 </style>
<?php get_footer(); ?>