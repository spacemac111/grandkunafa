<meta http-equiv="refresh" content="1; URL=https://pos.grandkunafa.online/cash/New%20folder%20(2)/close_cash.php?operation=insert" />
