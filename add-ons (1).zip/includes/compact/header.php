<!DOCTYPE HTML>

<html>
	<head>
		<title><?php echo get_page_title(null, true);?></title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
 
 		<link rel="stylesheet" href="<?php echo get_url('compact'); ?>/style.css" />
         <style type="text/css">
           
         </style>  
	</head>
	<body>
		<div id="page-wrapper">			
			<div id="header"><!-- Header -->
                <div class="header-wrap"> 
                <div class="logo">
					 <a href="<?php echo get_url();?>"><?php echo get_site_title(); ?></a>
          		</div>
				 <!-- Nav -->
							<?php $options_arr =  array(					
					'nav'			=> true, 	
					'out_nav_id'	=> 'main-menu',			
					'out_nav_class' => 'main_nav',		
					'menu_class'	=> 'top_menu', 		
					'menu_id'		=> 'top_menu_id', 		
	);

	kv_nav_menu('top-menu', $options_arr); ?>	
								
				</div>

				</div> 