<?php 
/*
Template Name : Login Page
*/ 

if(logged_in()) {
  //if(is_admin())
    //header('Location: '.get_url("admin"));
 // else
	$selected_user = kv_get_current_user(); 
	
	if($selected_user['role'] == 'Staff' )
		header('Location: '.get_url('uploads'));
	else
		header('Location: '.get_url());
}

if( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['submit'])) {
    if(isset($_POST['login_form']) &&  $_POST['login_form'] == 'yes')
        login($_POST['username'], $_POST['password'], $_POST['rememberme'], $_POST['redirect_to']);
    if(isset($_POST['forget_password']) && $_POST['forget_password'] == 'yes'){
        forgot_password(stripslashes(trim($_POST['username'])), 'front');
    }
    if(isset($_POST['reset_password']) && $_POST['reset_password'] == 'yes'){
        $kv_errors= array();
        $fields = array( 'password',   'c_password', 'user_id'  );
        foreach ($fields as $field) {
            if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
        }
              
        if ($posted['password'] != $posted['c_password'] )
            array_push($kv_errors,  sprintf('<strong>Notice</strong>: Your Password Didnt match.', 'neem'));
        if ($posted['password'] ==null )
            array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Password.', 'neem'));
        if ($posted['c_password'] ==null )
            array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Confirm Password.', 'neem'));
            $rst_errors = array_filter($kv_errors);
        if (empty($rst_errors)) { 
              $wp_hasher = new PasswordHash(16, true);
              $pass = $wp_hasher->HashPassword( trim( $posted['password'] ) );
              Update("users", array('ID' => $posted['user_id']),array("password" => $pass));                    
              kv_direct(get_url("flogin")."?action=login&password_updated=yes");
        }
  }            
}
?>
<html class=""><head>

<head>
<title><?php echo get_page_title(null, true);?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
<link href="https://fonts.googleapis.com/css?family=Lato|Open+Sans|PT+Sans|Roboto|Roboto+Slab|Titillium+Web" rel="stylesheet">
<link href="<?php echo get_current_theme_uri(); ?>css/login.css" rel="stylesheet">

<style class="cp-pen-styles">
  * { box-sizing:border-box; }
</style>
<?php if(isset($_SESSION['retries'])){
    echo "<script src='https://www.google.com/recaptcha/api.js'></script>"; 
  } ?>
</head><body>
  <div class="background"></div>
  <div class="background2"></div>
   <div class="loginForm"> 
    <hgroup>
      <h1>  <?php 
				$logo = get_site_option('logo');
				if($logo && file_exists(ABSPATH."themes/pos/images/".$logo)) { ?>
					<img src="<?php echo get_current_theme_uri();?>images/<?php echo $logo; ?>" width="150">
				<?php } else { ?>
					<img src="<?php echo get_current_theme_uri();?>images/kvcodes.png" width="150">
				<?php } ?> </h1>
    </hgroup>

  <?php

        if(isset($_GET['action']) && $_GET['action'] =='forgot_password'){ ?>

         <div id="login">
            
            <form method="post" action="">
                <div class="group">
                  <?php echo messages();?>      
                </div>
                <div class="group">
                <input type="text" name="username"  <?php echo $disabled; ?> ><span class="highlight"></span><span class="bar"></span>
                <label><?php echo _('Enter Your Username or Email'); ?></label>
            </div>              
        <input type="hidden" name="forget_password" value="yes" >                 
            <input type="submit" class="buttonui  used" name="submit" value="<?php echo _("Get Password"); ?>">
            <p> <a style="text-align:right;text-decoration: none" href="<?php echo get_url('flogin'); ?>"> <?php echo _("Login Back"); ?> </a>   
          </p> 
         </form>       
        </div>           
        
        <?php } elseif(isset($_GET['reset_password'])) { ?>

    <div id="login">
           
        <form method="post" action="">
            <?php if(!empty($rst_errors)) {
                    echo '<div class="error">';
                    foreach ($rst_errors as $error) {
                        echo '<p>'.$error.'</p>';
                    }
                    echo '</div>';
                } ?>
            <div class="login-block">
                
               <?php $user_id= GetSingleValue('users', 'ID', array('activation'=>$_GET['reset_password']));
                if($user_id != null && $user_id > 0 ){  ?>
                <input type="password" value="" name="password"  placeholder="<?php echo _("Password"); ?>" id="password" />
                <input type="password" value="" name="c_password"  placeholder="<?php echo _("Confirm Password"); ?>" id="password" />              
                <input type="hidden" name="reset_password" value="yes" >
                <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" >
                <input type="submit" name="submit" class="button" value="<?php echo _("Change Password"); ?>"  />
                 <p style="text-align:right;"> <a href="<?php echo get_url('admin'); ?>?action=login"> <?php echo _("Login Back"); ?> >></a>   </p>
         <p style="text-align:left;"> <a href="<?php echo get_url(); ?>"> << <?php echo _("Back to Home Page"); ?> </a>   </p> 
                 <?php }else { 
                    echo '<div class="error"> Sorry!, The given Security String is invalid!.</div>';
                 } ?>
            </div>  
        </form>       
    </div>
        
    <?php

        } else { 
          $disabled = ''; 
  
          if(isset($_SESSION['Failed_login']) ){
              $disabled = 'disabled'; 
              UNSET($_POST);      
          } ?>

        <form method="post" action="">
         <div class="group">
        <?php echo messages(); 
          if(isset($_GET['password_updated']) && $_GET['password_updated'] == 'yes'){
                echo '<div class="success" > '._('Successfully Resetted Your Password login With New Password now').'!.</div>';
            }?>
            </div>
      <div class="group">
        <input type="text" class="used" name="username"  <?php echo $disabled; ?> ><span class="highlight"></span><span class="bar"></span>
        <label><?php echo _("Username/Email"); ?></label>
      </div>
      <div class="group">
        <input type="password" name="password" <?php echo $disabled; ?> ><span class="highlight"></span><span class="bar"></span>
        <label><?php echo _("Password"); ?></label>
      </div>
    
      <?php if(isset($_SESSION['retries'])){
                    $site_key = get_site_option('google_site_key');
                    echo '<div class="group" ><div class="g-recaptcha" data-sitekey="'.$site_key.'"></div></div>'; 
                  } ?>   
      <input type="hidden" name="login_form" value="yes" >
        <input type="hidden" name="redirect_to" value="<?php echo ((isset($_GET['first']) && $_GET['first'] == 'yes' ) ? get_url() : $_SERVER['HTTP_REFERER']); ?>" >
      <div class="group">
        <input type="hidden" class="rememberme" name="rememberme" value="1"> 
        <input  type="submit" class="buttonui " <?php echo $disabled; ?> name="submit" value="<?php echo _("Login"); ?>">
      </div>

        <!--  <a style="float: left; text-decoration: none;" href="<?php echo get_url('flogin'); ?>?action=forgot_password"> <?php echo _("Forget Password"); ?> </a> -->
    </form>    
    <?php } ?>    
 <div class="powered">
          <a href="<?php echo get_url(); ?>">  <?php echo _("Back to Home Page"); ?> </a>  
      </div>
  </div>
<script src="<?php echo get_current_theme_uri(); ?>js/jquery.min.js"></script>
<script>$(window, document, undefined).ready(function() {

  $('input').blur(function() {
    var $this = $(this);
    if ($this.val())
      $this.addClass('used');
    else
      $this.removeClass('used');
  });
  var $ripples = $('.ripples');
  $ripples.on('click.Ripples', function(e) {

    var $this = $(this);
    var $offset = $this.parent().offset();
    var $circle = $this.find('.ripplesCircle');
    var x = e.pageX - $offset.left;
    var y = e.pageY - $offset.top;

    $circle.css({
      top: y + 'px',
      left: x + 'px'
    });
    $this.addClass('is-active');
  });

  $ripples.on('animationend webkitAnimationEnd mozAnimationEnd oanimationend MSAnimationEnd', function(e) {
    $(this).removeClass('is-active');
  });
});
</script>
</body></html>