<?php 

require_once(dirname(dirname(__FILE__)).'/callcenter.php');
// Restaurant POS
if(isset($_GET['fetchCat'])){
	$sql = "SELECT c.description, c.category_id FROM ".TB_PREF."stock_category as c, ".TB_PREF."stock_master AS master WHERE c.parent_id = 0 AND c.category_id= master.category_id ";                    
    $sql.= ' GROUP BY c.category_id';
	fadb_query("SET NAMES UTF8", '');
	$sales_typ_res= fadb_query($sql, "can't get results");	
	$output = [];
	while($row = fadb_fetch_assoc($sales_typ_res)){	
		$sql2 = "SELECT count(i.id) as total, i.description as itemDescription FROM ".TB_PREF."stock_master s, ".TB_PREF."item_codes i LEFT JOIN ".TB_PREF."stock_category c ON c.category_id =i.category_id Where i.stock_id = s.stock_id ";
		$sql2 .= "AND i.category_id = ".fadb_escape($row['category_id'])." or c.parent_id= ".fadb_escape($row['category_id']);
		fadb_query("SET NAMES UTF8", '');
		$res= fadb_query($sql2, "can't get results");
		$dt = [];	
		while($row2 = fadb_fetch_assoc($res)){	
		echo '<pre>';			
			print_r($row2['itemDescription']);
			// $dt  = $row2['itemDescription'];
		}	   	
		if($dt > 1){
		// $output[] = ['name'=>$row['description'], 'count'=> $dt, 'category_id'=>$row['category_id']];
		}
	}
	// echo json_encode($output);
}
if(isset($_GET['fetchData'])){

	// $sql =" SELECT s.stock_id, s.description AS name, pr.price FROM ".TB_PREF."stock_master AS s LEFT JOIN ".TB_PREF."prices AS pr ON pr.stock_id=s.stock_id";				
	// $sql = "SELECT i.item_code, i.description, c.description, count(*)>1 as kit,
	// 		 i.inactive, 
	// 		FROM
	// 		0_stock_master s,
	// 		0_item_codes i
	// 		LEFT JOIN
	// 		0_stock_category c
	// 		ON i.category_id=c.category_id
	// 		WHERE i.stock_id=s.stock_id AND !i.is_foreign AND !i.inactive AND !s.inactive AND !s.no_sale Group BY i.item_code";
	// $sql = "SELECT i.item_code, i.description as itemDescription FROM ".TB_PREF."stock_master s,".TB_PREF."item_codes i WHERE i.stock_id = s.stock_id ";
	$sql = "SELECT i.item_code, i.description as itemDescription, sum(round(m.qty, 2)) as qty, s.units, i.stock_id FROM ".TB_PREF."stock_master s 
				LEFT JOIN ".TB_PREF."stock_moves AS m ON s.stock_id = m.stock_id , ".TB_PREF."item_codes i 
				LEFT JOIN ".TB_PREF."stock_category c ON c.category_id =i.category_id AND !c.inactive AND !c.dflt_no_sale 
				Where i.stock_id = s.stock_id ";
	
	// if(isset($_SESSION['sales_type_id'])){
	// 	$sql .= " AND pr.sales_type_id= ".fadb_escape($_SESSION['sales_type_id']);
	// }

	if(isset( $_SESSION['pos_details']['pos_location']))
		$sql .=" AND m.loc_code=".fadb_escape($_SESSION['pos_details']['pos_location'])." ";


	if (isset($_GET['cat_id']) && $_GET['q'] == '' && $_GET['cat_id'] != ''){
		// $sql .= " AND i.category_id = ".fadb_escape($_GET['cat_id']);
		$sql .= "AND i.category_id = ".fadb_escape($_GET['cat_id'])." or c.parent_id= ".fadb_escape($_GET['cat_id']);

	}
	elseif(isset($_GET['q']) && $_GET['q'] != '' && $_GET['cat_id'] != ''){
		// $sql .= " AND i.category_id = ".fadb_escape($_GET['cat_id']);
		$sql .= "AND i.category_id = ".fadb_escape($_GET['cat_id'])." or c.parent_id= ".fadb_escape($_GET['cat_id']);
		$sql .= " AND (i.stock_id LIKE '%".$_GET['q']."%' OR i.description LIKE '%".$_GET['q']."%' )";
	}
	elseif(isset($_GET['q']) && $_GET['q'] != '' && $_GET['cat_id'] == ''){
		$sql .= " AND i.stock_id LIKE '%".$_GET['q']."%' OR i.description LIKE '%".$_GET['q']."%' ";
	}
	else{
		$sql .= '';
	}
	$sql .= " AND !i.is_foreign AND !i.inactive AND !s.inactive AND !s.no_sale Group BY i.item_code";	

	$negative_Stock = FAGetSingleValue('sys_prefs', 'value', ['name' => 'allow_negative_stock']);
	// stock_master, price, item_code
	$sql.= ' Limit 100';
	$sales_typ_res= fadb_query($sql, "can't get results");	
	$output = [];
	if(fadb_num_rows($sales_typ_res) > 0){
		while($row = fadb_fetch_assoc($sales_typ_res)){				
			$string = $row['itemDescription'];
			//echo $string.'<br>';
			if(!$negative_Stock && $row['qty'] <= 0 )
				continue;
			if($current_user['language'] =='C' || $current_user['language'] == ''){
				if (strlen($string) > 18) {
					$trimstring = substr($string, 0, 18). '...';
				} else {
					$trimstring = $string;
				}
			} else 
				$trimstring = $string;
			$price = get_kit_price($row['item_code'], $_SESSION['curr_code'],$_SESSION['sales_type_id']);
			$this_Array  = ['name'=>$trimstring, 'price'=> ($price == null ? 0 : $price),'stock_id'=>$row['item_code'], 'curr' => $_SESSION['currency'], 'qty' => $row['qty'], 'unit' => $row['units']];
			if($row['stock_id'] != $row['item_code'])
				$this_Array['color'] = 'bg_blue';
			else
				$this_Array['color'] = 'bg_blue_dark3';
			$output[] = $this_Array;
		}	
	}	
	echo json_encode($output);
	exit;
}
if(isset($_GET['fetchCategory'])){
	$sql = "SELECT c.description, c.category_id FROM ".TB_PREF."stock_category as c, ".TB_PREF."stock_master AS master WHERE c.parent_id = 0 AND c.category_id= master.category_id ";
	if(isset($_GET['q']) && $_GET['q'] != ''){
		$sql .= " AND c.description  LIKE '%".$_GET['q']."%'";
	}
	$sql.= ' AND !c.inactive AND !c.dflt_no_sale GROUP BY c.category_id Limit 10';
	fadb_query("SET NAMES UTF8", '');
	$sales_typ_res= fadb_query($sql, "can't get results");	
	$output = [];
	while($row = fadb_fetch_assoc($sales_typ_res)){				   	
		$output[] = ['name'=>$row['description'], 'category_id'=>$row['category_id']];
	}
	echo json_encode($output);
}
if(isset($_GET['fetchSubCategory'])){
    $sql = "SELECT c.description, c.category_id from ".TB_PREF."stock_category as c  where c.inactive = 0 AND c.parent_id != 0";
	if(isset($_GET['q']) && $_GET['q'] != ''){
		$sql .= " AND c.parent_id =".$_GET['q'];
	}
	fadb_query("SET NAMES UTF8", '');
	$sales_typ_res= fadb_query($sql, "can't get results");	
	$output = [];
	while($row = fadb_fetch_assoc($sales_typ_res)){				   	
		$output[] = ['name'=>$row['description'], 'category_id'=>$row['category_id']];
	}
	echo json_encode($output);	
}
if(isset($_GET['numofDelivery'])){
	$date = date('Y-m-d');
	$userid = $_POST['id'];
	$sql = "SELECT count(*) FROM ".TB_PREF."sales_orders as so WHERE so.trans_type = 30 AND so.version = 0 AND so.delivery_no > 0 and so.ord_date =".fadb_escape($date)." and so.deliveryman='".$userid."' ORDER BY so.order_no DESC";
 fadb_query("SET NAMES UTF8", '');
    $result= fadb_query($sql, "can't get results");
    if(fadb_num_rows($result) >0){
       $del_count = fadb_fetch_row($result);
    }else{
    	$del_count = 0;
    }
    echo json_encode(array('count' => $del_count));
}
if(isset($_GET['get_numofDelivery'])){
	$date = date('Y-m-d');
	$id = $_POST['id'];
	$sql = "SELECT * FROM ".TB_PREF."sales_orders as so WHERE so.trans_type =30 AND (so.version = 0 OR so.version = 1) AND so.delivery_no > 0 and so.ord_date ='".$date."' and so.deliveryman='".$id."' ORDER BY so.order_no DESC";
	fadb_query("SET NAMES UTF8", '');
    $result= fadb_query($sql, "can't get results");
    $output = [];
    if(fadb_num_rows($result) >0){
    	while($row = fadb_fetch($result)){
        if($row['version'] == 1){
          $selected = 'delivered';
        }else{
          $selected = 'ordered';
        }
        $output[] = ['order_no' => $row['order_no'],'delivery_no' => $row['delivery_no'], 'selected' => $selected];
      }  
    }
    echo json_encode($output);
}

if(isset($_GET['load_takeaway_item'])){
	$date = date('Y-m-d');
	$sql = "SELECT * FROM ".TB_PREF."sales_orders WHERE trans_type =30 AND (version = 0 OR version = 1) AND token_no > 0 and ord_date = '".$date."' GROUP BY token_no  ORDER BY order_no DESC";
    fadb_query("SET NAMES UTF8", '');
    $result= fadb_query($sql, "can't get results");
    $output = [];
    if(fadb_num_rows($result) >0 ){
      while($row = fadb_fetch($result)){
        if($row['version'] == 1){
          $selected = 'delivered';
        }else{
          $selected = 'ordered';
        }
        $output[] = ['token_no' => $row['token_no'], 'selected' => $selected];
      }                    
    }
    echo json_encode($output);     
}

if(isset($_GET['load_cart_data']) && $_GET['load_cart_data'] == 'Yes'){

	if((isset($_POST['tablenum']) && $_POST['tablenum'] > 0) || (isset($_POST['token_no']) && $_POST['token_no'] > 0) || (isset($_POST['del_no']) && $_POST['del_no'] > 0)) {
		$price_dec = user_price_dec();
		$date = date('Y-m-d');
		$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
		$order_details = FAGetDataJoin('sales_orders AS so', array( array('join' => 'LEFT', 'table_name' => 'debtors_master AS info', 'conditions' => '`info`.`debtor_no` = `so`.`debtor_no`'), array('join' => 'LEFT', 'table_name' => 'cust_branch AS br', 'conditions' => '`br`.`branch_code` = `so`.`branch_code`'),
					array('join' => 'LEFT', 'table_name' => 'currencies AS cr', 'conditions' => '`cr`.`curr_abrev` = `info`.`curr_code`')), 
					array('so.*, info.*, br.*, cr.curr_symbol'), 
					array('`so`.`trans_type`' => 30, '`so`.`version`' => array('OR', 0, 1), '`so`.`table_no`' => $_POST['tablenum'], '`so`.`token_no`' => $_POST['token_no'],'`so`.`delivery_no`' => $_POST['del_no'],'`so`.`ord_date`' => $date), null,true, false);		
		
		if(is_array($order_details)){		
			$total_amt = number_format(floatval($order_details['total']),$price_dec, '.', '');			
			$order_items = FAGetAll('sales_order_details', array('order_no' => $order_details['order_no'], 'trans_type' => $order_details['trans_type']));
			$data =[];
			foreach($order_items as $key => $row){

				if($non_detailed_sales_kit && $row['kit'] != ''){
				//echo "TesT";
					if($order_items[$key+1]['kit'] == $row['kit'])
						continue;
					$item_detail = FAGetRow('item_codes', ['item_code' => $row['kit'], 'stock_id' => $row['stk_code']]);
					$row['description'] = $item_detail['description'];
					//echo $row['quantity'].'_'.$item_detail['quantity'];
					$row['unit_price'] = get_kit_price($row['kit'], $order_details['curr_code'], $order_details['sales_type'], null, null, false);
					//$row['stk_code'] = $row['kit'];
					$row['quantity'] = round($row['quantity']/$item_detail['quantity'], get_qty_dec($row['kit']));
				}

				$data[] = ['last_id' => $key, 'id' => $row['id'], 'name'=>$row['description'], 'stock_id' => $row['stk_code'],'kit' => ($row['kit'] != '' ? 'yes' : ''), 'qty' => $row['quantity'], 'price' => number_format(floatval($row['unit_price']), $price_dec, '.', ''),'line_total' => number_format(floatval($row['quantity'] * $row['unit_price']), $price_dec, '.', '')];
			}	
			
			 $output = array(
					   'cart_count'  => count($order_items),
					   'grand_total'  => $total_amt,
					   'cart_data'   => $data,
					   'CustomerId' => $order_details['debtor_no'],
					   'order_id' => $order_details['order_no'],
					   'del_no' => $order_details['delivery_no'],
					   'del_num' => $order_details['deliveryman']
			);
			$delivery_no = FAGetSingleValue('debtor_trans', 'trans_no', array('version' => 0, 'type' => 13, 'order_' => $order_details['order_no']));
			if($order_details['version'] == 1) {
				
				if($delivery_no)
					$output['delivery_no'] = $_SESSION['delivery_no'] = $delivery_no;
				else
					$output['delivery_no'] = $_SESSION['delivery_no'] = 0;				
			} else
					$output['delivery_no'] = $_SESSION['delivery_no'] = ( $delivery_no > 0 ?  $delivery_no : 0);
				
			$order_details['tax_included'] = FAGetSingleValue('sales_types', 'tax_included', ['id' => $order_details['sales_type']]);
			//var_dump($order_details);
			$output['tax_included'] 		= $order_details['tax_included'];
			$_SESSION["CustomerName"] 		= $order_details['name'];
			$_SESSION["currency"] 			= $order_details['curr_symbol'];
			$_SESSION["sales_type_id"] 		= $order_details['sales_type'];
			$_SESSION["tax_included"] 		= $order_details['tax_included'];
			$_SESSION["old_curr_code"] 		= $order_details['curr_code'];
			$_SESSION["curr_code"] 			= $order_details['curr_code'];
			
			$_SESSION["TableNo"] 			= $order_details['table_no'];
			$_SESSION["token_no"]			= $order_details['token_no'];
			$_SESSION['del_no'] 			= $order_details['delivery_no'];

			$output['freight_cost'] 		= $_SESSION['freight_cost'] 		= ($order_details['delivery_no'] > 0 ? $order_details['freight_cost'] : 0 );
			$output['customer_ref'] 		= $_SESSION['customer_ref'] 		= $order_details['customer_ref'];
			$output['contact_phone'] 		= $_SESSION['contact_phone'] 		= $order_details['contact_phone'];
			$output['delivery_address'] 	= $_SESSION['delivery_address'] 	= $order_details['delivery_address'];
			$output['deliver_to'] 			= $_SESSION['deliver_to'] 			= $order_details['deliver_to'];
			$output['client_id'] 			= $_SESSION['client_id']  			= $order_details['client_id'];

			$_SESSION["tax_group_id"] 		= $order_details['tax_group_id'];
			$_SESSION["date"] 				= $order_details['ord_date'];
			$_SESSION["order_id"] 			= $order_details['order_no']; //needed
			$_SESSION["trans_type"] 		= 30;			
			$_SESSION["cart_item"] 			= $data;
			$_SESSION['cart_count'] 		= count($order_items);
			$_SESSION['items_count'] 		= count($order_items);
			$_SESSION['grand_total'] 		= $total_amt;
			$_SESSION['CustomerId'] 		= $order_details['debtor_no'];
			$tax_val 						= fa_get_taxes($_SESSION);
			$_SESSION["subtotal_price"] 	= $order_details['total']-$tax_val;
			//$output['grand_total'] += ($order_details['tax_included'] == 1 ? 0 : $tax_val);

			$_SESSION['tax_val'] 			= $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');
			echo json_encode($output);
		}
		else{
			$data = UnsetCart();
			 $output = array(
					   'cart_count'  => 0,
					   'grand_total'  => number_format2(0, $price_dec),
					   'cart_data'   => $data,
					   'CustomerId' => 1,
					   'order_id' => 0,
					   'deliverID' =>0
				);
			echo json_encode($output);
		}
	}     
}
if(isset($_GET['fetchDelivaryDara']) && $_GET["fetchDelivaryDara"] == "Yes"){
	$trans_no = $_POST['trans_no'];
	$sql = "SELECT so.table_no FROM ".TB_PREF."debtor_trans as dt inner join ".TB_PREF."sales_orders as so where so.order_no = dt.order_ AND dt.trans_no = ".$trans_no." AND dt.version = 0 and so.version = 1";
	$debtor_row =  fadb_query($sql, "Can't get any data");
	$data = array();
	if($row = fadb_fetch_row($debtor_row)){
		$data['tablenum'] = $row[0];
	}	
	echo json_encode($data);
}
if(isset($_GET['get_tableplan']) && $_GET['get_tableplan'] == "Yes"){
	$c_id = $_POST['c_id'];
	$users_arr = array();
	$sql = "SELECT id, table_count FROM ".TB_PREF."table_plan where company_id = ".$c_id;
	$result = db_query($sql, "can't get any data");
	$data = array();
	if($row=db_fetch_row($result)){
		$data['id'] = $row[0];
		$data['table_count'] = $row[1];
	}else{
		$data['id'] = 0;
		$data['table_count'] = -1;
	}
	echo json_encode($data);
}
if(isset($_GET['get_pageContent']) && $_GET['get_pageContent'] == "Yes"){
	$c_id = $_POST['c_id'];
	$users_arr = array();
	$sql = "SELECT page_id, page_permit FROM ".TB_PREF."permission where page_id = ".$c_id;
	$result = db_query($sql, "can't get any data");
	$data = array();
	while($row = db_fetch($result)){
		$data[] = ['page_id'=>$row['page_id'], 'page_permit'=> $row["page_permit"]];
	}
	echo json_encode($data);  
}
if(isset($_GET['load_token_no']) && $_GET['load_token_no'] == 'Yes'){
	$date = date('Y-m-d');
	$get_token = FAGetSingleValue('sales_orders', 'MAX(`token_no`)', array('trans_type' => ST_SALESORDER, 'ord_date' => $date));
	if($get_token == null){
		$get_token = 1;
	}
	echo json_encode($get_token);
}
if(isset($_GET['load_door_item'])){
	$date = date('Y-m-d');
	$sql = "SELECT deb.debtor_no,deb.name,deb.address,so.delivery_no,so.version, so.deliveryman FROM ".TB_PREF."debtors_master as deb, ".TB_PREF."sales_orders as so WHERE so.trans_type =30 AND (so.version = 0 OR so.version = 1) AND so.delivery_no > 0 and so.ord_date ='".$date."' and  so.debtor_no=deb.debtor_no GROUP BY so.delivery_no  ORDER BY so.order_no DESC";

    fadb_query("SET NAMES UTF8", '');
    $result= fadb_query($sql, "can't get results");
    $output = [];
    if(fadb_num_rows($result) >0 ){
      while($row = fadb_fetch($result)){
        if($row['version'] == 1){
          $selected = 'delivered';
        }else{
          $selected = 'ordered';
        }
        $output[] = ['delivery_no' => $row['delivery_no'], 'selected' => $selected, 'name' => $row['name'], 'address' => $row['address'], 'del_man' => $row['deliveryman']];
      }                    
    }
    echo json_encode($output);     
}
if(isset($_GET['loadData'])){
	$keyword = strval($_POST['query']);
	$search_param = "{$keyword}%";
	$sql ="SELECT * FROM ".TB_PREF."stock_master WHERE `description` LIKE '%".$search_param."%' " ;	
	$res = fadb_query($sql, "can't get results");
	$output =[];		
	while($row = fadb_fetch_assoc($res)){		
		$string = $row['description'];
		if (strlen($string) > 18) {
			$trimstring = substr($string, 0, 18). '...';
		} else {
			$trimstring = $string;
		}
		$price = get_price ($row['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id']);		
		$output[] = ['name'=>$trimstring, 'price'=> $price,'stock_id'=>$row['stock_id']];
	}
	echo json_encode($output);
}
if(isset($_GET['getSearch'])){
	$keyword = strval($_POST['query']);
	$search_param = "{$keyword}%";
	$sql ="SELECT * FROM ".TB_PREF."stock_master WHERE `description` LIKE '%".$search_param."%' " ;	
		$res = fadb_query($sql, "can't get results");
		$data =[];		
		while($row = fadb_fetch_assoc($res)){		
			$data[] = ['name'=>$row['description']];
		}		
	echo json_encode($data);
}

if(isset($_GET['AddPOSItemToCart']) && $_GET['AddPOSItemToCart'] == 'Yes') {
	echo AddPOSItemToCart($_POST['TableNo'],$_POST['token_no'],$_POST['del_no'],$_POST['status'], $_POST['CustomerId'], $_POST['deliverID'], $_POST['currency'], $_POST['tax_group_id'], $_POST['stock_id'], $_POST['price'], $_POST['qty'], $_POST['total_q'], $_POST['total_am'], $_POST['step'], $_POST['discount'], $_POST['date'] );
}

if(isset($_GET['RemovePOSItemFromCart']) && $_GET['RemovePOSItemFromCart'] == 'Yes') {
	$price_dec = user_price_dec();
	$cart_id = intval( $_POST['cart_id'] );
	$total_amt=0;

	$total_amt=0;
	if(!empty($_SESSION["cart_item"][$cart_id])) {
		unset($_SESSION["cart_item"][$cart_id]);		
		foreach($_SESSION["cart_item"] as $k => $v) {
			$total_amt += $v['line_total'];
		}
	}
	$_SESSION['subtotal_price'] = $total_amt;
	$tax_val = fa_get_taxes($_SESSION);
	$_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.','');
	 if($_SESSION['tax_included'] == 1)
    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
	$_SESSION['grand_total'] = number_format(floatval($total_amt),$price_dec, '.','');
	echo json_encode(array('currency' => $_SESSION['currency'], 'cart_count' => count($_SESSION['cart_item']), 'last_id' => $cart_id, 'name' => $name, 'subtotal_price' => $_SESSION['subtotal_price'], 'tax_val' => $_SESSION['tax_val'], 'grand_total' => $_SESSION['grand_total']));	

}
if(isset($_GET['saveposorder']) && $_GET['saveposorder'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){
		$id = save_sales_order();
		echo json_encode($id);	
	}
}

if(isset($_GET['saveorder']) && $_GET['saveorder'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){
		$_SESSION['deliverID'] = $_POST['deliverID'];
		$data = array();
		$data['message'] = 'New Delivery Added';
		/*if(!isset($_SESSION['client_id']) && !isset($_SESSION['contact_phone'])){
		 	$_SESSION['client_id'] = $_POST['client_id'];
		 	$_SESSION['contact_phone'] = $_POST['contact_phone'];
		 	$_SESSION['delivery_address'] = $_POST['delivery_address'];
		 	$_SESSION['default_location'] = $_POST['default_location'];
		 	$_SESSION['delivery_cost'] = $_POST['delivery_cost'];
		}*/
		$id = save_sales_order();	
		if($pusher_keys['allow_pusher'] == 1){
			$data['pusher'] = 1;
			$batch = array();
			$batch[] = array('channel' => 'channel-1', 'name' => 'my-event', 'data' => $id);
			$batch[] = array('channel' => 'channel-2', 'name' => 'my-event-'.$_SESSION['deliverID'], 'data' => array('message' => 'You have new Delivery', 'id' => $_SESSION['deliverID']));
			$pusher->triggerBatch($batch);
		}else{
			$id['pusher'] = 0 ;
			echo json_encode($id); //array('id' => $id, 'pusher' => 0));	
		}
		// echo json_encode(array('id' => $id, 'msg'=> 'Payment Completed Successfully'));
		// echo json_encode($id);
		// $batch = array();
		// $batch[] = array('channel' => 'channel-1', 'name' => 'my-event', 'data' => $id);
		// $batch[] = array('channel' => 'channel-2', 'name' => 'my-event-'.$_SESSION['deliverID'], 'data' => array('message' => 'You have new Delivery', 'id' => $_SESSION['deliverID']));
		// $pusher->triggerBatch($batch);
	}	
}
if(isset($_GET['send_data_msg']) && $_GET['send_data_msg'] == 'Yes'){
	$data = array();
	$data['message'] = "Admin Send you a message";
	$pusher->trigger('my-channel', 'payment_complete', $data);
}
if(isset($_GET['fetch_trans_no']) && $_GET['fetch_trans_no'] == 'Yes'){
	$t_no = FAGetSingleValue('debtor_trans', 'trans_no', array('version' => 0, 'type' => 13, 'order_' => $_POST['order_id']));
	$data = array();
	if($t_no > 0){
	  $data['id'] = $t_no;
	}else{
	  $data['id'] = 0;
	}
	echo json_encode($data);
}
if(isset($_GET['delivaryorder']) && $_GET['delivaryorder'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){
		$id = deliver_orders();
		// UnsetCart();		
		echo json_encode($id);
	}	
}

if(isset($_GET['load_delcart_data']) && $_GET['load_delcart_data'] == 'Yes'){
		$price_dec = user_price_dec();
		$date = date('Y-m-d');
		$order_details = FAGetDataJoin('sales_orders AS so', array( array('join' => 'LEFT', 'table_name' => 'debtors_master AS info', 'conditions' => '`info`.`debtor_no` = `so`.`debtor_no`'),
					array('join' => 'LEFT', 'table_name' => 'cust_branch AS br', 'conditions' => '`br`.`branch_code` = `so`.`branch_code`'),
					array('join' => 'LEFT', 'table_name' => 'crm_persons as pr', 'conditions' => '`pr`.`ref` = `info`.`debtor_ref`' ),
					array('join' => 'LEFT', 'table_name' => 'currencies AS cr', 'conditions' => '`cr`.`curr_abrev` = `info`.`curr_code`')), 
					array('so.*, info.*, br.*, cr.curr_symbol, pr.phone, pr.email'), array('`so`.`trans_type`' => 30, '`so`.`version`' => array('OR', 0, 1),'`so`.`delivery_no`' => $_POST['del_no'],'`so`.`ord_date`' => $date), null,true, false);
		
		if(is_array($order_details)){		
			$total_amt = number_format(floatval($order_details['total']),$price_dec, '.', '');			
			$order_items = FAGetAll('sales_order_details', array('order_no' => $order_details['order_no'], 'trans_type' => $order_details['trans_type']));
			$data =[];
			foreach($order_items as $key => $row){
				$data[] = ['last_id' => $key, 'id' => $row['id'], 'name'=>$row['description'], 'stock_id' => $row['stk_code'], 'qty' => $row['quantity'], 'price' => number_format(floatval($row['unit_price']), $price_dec, '.', ''),'line_total' => number_format(floatval($row['quantity'] * $row['unit_price']), $price_dec, '.', '')];
			}	
			 $output = array(
					   'cart_count'  => count($order_items),
					   'grand_total'  => $total_amt,
					   'cart_data'   => $data,
					   'CustomerId' => $order_details['debtor_no'],
					   'order_id' => $order_details['order_no'],
					   'CustomerPhone' => $order_details['phone'],
					   'CustomerEmail' => $order_details['email'],
					   'CustomerAddress' => $order_details['address']
			);
			$delivery_no = FAGetSingleValue('debtor_trans', 'trans_no', array('version' => 0, 'type' => 13, 'order_' => $order_details['order_no']));
			if($order_details['version'] == 1) {
				
				if($delivery_no)
					$output['delivery_no'] = $_SESSION['delivery_no'] = $delivery_no;
				else
					$output['delivery_no'] = $_SESSION['delivery_no'] = 0;				
			} else
					$output['delivery_no'] = $_SESSION['delivery_no'] = ($delivery_no > 0  ? $delivery_no : 0);
				
			$_SESSION["CustomerName"] = $order_details['name'];
			$_SESSION["currency"] = $order_details['curr_symbol'];
			$_SESSION["sales_type_id"] = $order_details['sales_type'];;
			$_SESSION["tax_included"] = $order_details['tax_included'];;
			$_SESSION["old_curr_code"] = $order_details['curr_code'];
			$_SESSION["curr_code"] = $order_details['curr_code'];
			$_SESSION['del_no'] = $order_details['delivery_no'];
			$_SESSION["tax_group_id"] = $order_details['tax_group_id'];;
			$_SESSION["date"] = $order_details['ord_date'];;
			$_SESSION["order_id"] = $order_details['order_no']; //needed
			$_SESSION["trans_type"] = 30;			
			$_SESSION["cart_item"] = $data;
			$_SESSION['cart_count'] = count($order_items);
			$_SESSION['items_count'] = count($order_items);
			$_SESSION['grand_total'] = $total_amt;
			$_SESSION['CustomerId'] = $order_details['debtor_no'];			
			$tax_val = fa_get_taxes($_SESSION);
			$_SESSION["subtotal_price"] = $order_details['total']-$tax_val;
			$_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');
			echo json_encode($output);
		}
}

//-----------------------------------------------------------------------------------------------------
// Clients Programs 
//-----------------------------------------------------------------------------------------------------

if(isset($_GET['clients']) && $_GET['clients'] == 'yes'){
	//$sql = "SELECT c.description, c.category_id FROM ".TB_PREF."stock_category as c, ".TB_PREF."stock_master AS master WHERE c.category_id=master.category_id ";

	$table = CALL_CENTER_DB. 'contacts_kot';
	$primaryKey = 'id';
	$columns = array(
		//array('db' => 'c.id', 				'dt' =>0, 	'field' => 'id'),
		array('db' => 'c.client_name', 		'dt' =>0, 	'field' => 'client_name'),
		array('db' => 'c.phone', 			'dt' =>1, 	'field' => 'phone'),
		array('db' => 'c.address',			'dt' =>2,	'field' => 'address'),
		array('db' => 'l.location_name', 	'dt' =>3, 	'field' => 'location_name'),
		array('db' => 'c.inactive', 		'dt' =>4, 	'field' => 'c.inactive',  	'formatter' => function( $d, $row) { return ($row['inactive'] == 1) ? 'Inactive': 'Active' ; }));

	$columns[]= array( 'db' => 'c.id',  	'dt' => 5,	'field' => 'c.id', 'formatter' => function( $d, $row ) { return '<i data-target="#ClientAddNew" class="material-icons EditClient" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-clientid="'.$row['id'].'" > create </i>'.'<i class="material-icons DeleteClient" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-clientid="'.$row['id'].'" > delete_forever </i>' ; });

	$joinQuery = "FROM {$table} AS `c` LEFT JOIN ".CALL_CENTER_DB."contacts_kot_location AS l ON `c`.`location` = `l`.`id` ";  
	$extraWhere = ''; 	
	$wigepa_sources =Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '', false ) ;
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}

if(isset($_GET['Edit_Client']) && $_GET['Edit_Client'] > 0){
	$clientinfo = TAGetRow('contacts_kot', ['id' => $_GET['Edit_Client']]);
	echo json_encode($clientinfo);
}

if(isset($_GET['delete_Client']) && $_GET['delete_Client'] > 0){
	echo TADelete('contacts_kot', ['id' => $_GET['delete_Client']]);	
}

if(isset($_GET['submit_client']) && $_GET['submit_client'] == 'yes'){

	if(isset($_POST['clientid']) && $_POST['clientid'] == 0 ){
		$id = TAInsert('contacts_kot', ['client_name' => $_POST['client_name_1'], 'phone' => $_POST['phone_1'], 'address' => $_POST['address'],'location' =>$_POST['location']]);
		if($id > 0)
			echo json_encode(['type' => 'success' , 'msg' => _("New Client Added Successfully"), 'client_id' => $id, 'customer_ref' => $_POST['client_name']]);
	}
	else{
		$res =TAUpdate('contacts_kot', ['id' => $_POST['clientid']], ['client_name' => $_POST['client_name_1'], 'phone' => $_POST['phone_1'], 'address' => $_POST['address'], 'location' => $_POST['location']]);
		if($res){
			$loc_rate = TAGetRow('contacts_kot_location', ['id' => $_POST['location']]);
			$_SESSION['delivery_cost'] = $loc_rate['rate'];
			echo json_encode(['type' => 'success' , 'msg' =>_("Selected Client Updated Successfully"), 'client_name' => $_POST['client_name_1'], 'phone' => $_POST['phone_1'], 'address' => $_POST['address'], 'location' => $_POST['location'], 'location_name' => $loc_rate['location_name'], 'delivery_cost' => $loc_rate['rate']]);
		}
	}
}

if(isset($_GET['get_customers_client'])){
	
	$sql ="SELECT id, client_name FROM ".CALL_CENTER_DB."contacts_kot WHERE 1 ";	   
	if(isset($_GET['q']) && $_GET['q'] != '')
		$sql .= " AND (phone LIKE '%".$_GET['q']."%' OR address LIKE '%".$_GET['q']."%' OR client_name LIKE '%".$_GET['q']."%') ";
	$sql .=" ORDER BY id DESC Limit 20";				
		$sales_typ_res= fadb_query($sql, "can't get results");
	$json = [];
	while($row = fadb_fetch($sales_typ_res)){
		// $json[] = ['id'=>$row['debtor_no'], 'text'=> _($row["debtor_ref"])]; // text mayb running problem
		$json[] = ['id'=>$row['id'], 'text'=> $row["client_name"]];
	}
	echo json_encode($json);     
}

if(isset($_GET['GetclientDetails']) && ( $_GET['GetclientDetails'] >= 1 || $_GET['GetclientDetails'] == 'phone')) {
	if($_GET['GetclientDetails'] >= 1)
		$res = TAGetRow('contacts_kot', ['id' => $_GET['GetclientDetails']]);
	else
		$res = TAGetRow('contacts_kot', ['phone' => $_POST['phone']]);
	
	if(!empty($res)){
		$_SESSION['customer_ref'] 		= $res['client_name'];
		$_SESSION['contact_phone'] 		= $res['phone'];
		$_SESSION['delivery_address'] 	= $res['address'];
		$_SESSION['deliver_to'] 		= $res['location'];
		$_SESSION['client_id'] 			= $res['id'];

		$loc_rate = TAGetRow('contacts_kot_location', ['id' => $res['location']]);
		$_SESSION['delivery_cost'] = $res['delivery_cost'] = $loc_rate['rate'];
		$res['location_name'] = $loc_rate['location_name'];
		if(isset($_SESSION['grand_total']))
			$res['grand_total'] = $_SESSION['grand_total'];
		echo json_encode($res);
	} else
		echo 1;
}

if(isset($_GET['GetclientDetailsRate']) && $_GET['GetclientDetailsRate'] >= 1) {
	$res = [];
	if((isset($_SESSION['del_no']) && $_SESSION['del_no'] > 0 ) || $_GET['type'] == 'doordelivary' ){
		$res['delivery_cost'] = TAGetSingleValue('contacts_kot_location', 'rate', ['id' => $_GET['GetclientDetailsRate']]);
		$_SESSION['freight_cost'] = $res['delivery_cost'];
		$res['grand_total'] = $_SESSION['grand_total'];
	} else 
		$res['freight_cost'] = 0;
	echo json_encode($res);
}

//-----------------------------------------------------------------------------------------------------
// Locations Programs 
//-----------------------------------------------------------------------------------------------------

if(isset($_GET['clients_location']) && $_GET['clients_location'] == 'yes'){
	//$sql = "SELECT c.description, c.category_id FROM ".TB_PREF."stock_category as c, ".TB_PREF."stock_master AS master WHERE c.category_id=master.category_id ";
	global $price_dec;
	$price_dec = user_price_dec();
	$table = CALL_CENTER_DB. 'contacts_kot_location';
	$primaryKey = 'id';
	$columns = array(
		//array('db' => 'c.id', 				'dt' =>0, 	'field' => 'id'),
		array('db' => 'location_name', 	'dt' => 0, 	'field' => 'location_name'),
		array('db' => 'rate', 			'dt' => 1, 	'field' => 'rate', 'formatter' => function( $d, $row) { global $price_dec; return number_format($row['rate'], $price_dec) ; }),
		array('db' => 'inactive', 		'dt' => 2, 	'field' => 'inactive', 'formatter' => function( $d, $row) { return ($row['inactive'] == 1) ? 'Inactive': 'Active' ; }));

	$columns[]= array( 'db' => 'id',  	'dt' => 3,	'field' => 'id', 'formatter' => function( $d, $row ) { return '<i data-target="#LocationAddNew" class="material-icons EditLocation" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-locationid="'.$row['id'].'" > create </i>'.'<i class="material-icons DeleteLocation" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-locationid="'.$row['id'].'" > delete_forever </i>' ; });

	$joinQuery = "FROM {$table} AS `c` ";  
	$extraWhere = ''; 	
	$wigepa_sources = Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '', false ) ;
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}

if(isset($_GET['Edit_Location']) && $_GET['Edit_Location'] > 0){
	$clientinfo = TAGetRow('contacts_kot_location', ['id' => $_GET['Edit_Location']]);
	echo json_encode($clientinfo);
}

if(isset($_GET['delete_Location']) && $_GET['delete_Location'] > 0){
	echo TADelete('contacts_kot_location', ['id' => $_GET['delete_Location']]);	
}

if(isset($_GET['submit_Location']) && $_GET['submit_Location'] == 'yes'){

	if(isset($_POST['locationid']) && $_POST['locationid'] == 0 ){
		$id = TAInsert('contacts_kot_location', ['location_name' => $_POST['location_name'], 'rate' => $_POST['rate']]);
		if($id > 0 )
			echo json_encode(['type' => 'success' , 'msg' => _("Rate Added Successfully")]); 
	}
	else{
		$res = TAUpdate('contacts_kot_location', ['id' => $_POST['locationid']], ['location_name' => $_POST['location_name'], 'rate' => $_POST['rate']]);
		if($res)
			echo json_encode(['type' => 'success' , 'msg' => _("Rate Update Successfully")]); 
	}
}