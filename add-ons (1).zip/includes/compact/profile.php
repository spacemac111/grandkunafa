<?php 
/*
Template Name: Profile
*/ 
global $current_user;
$current_user = kv_get_current_user(); 

if($current_user['role'] == 'Administrator' ){
  $customer_vat_mandatory = get_company_details('customer_vat_mandatory');
  $customer_email_unique = get_company_details('customer_email_unique');
  $customer_email_mandatory = get_company_details('customer_email_mandatory');
  $allow_negative_stock_pos = get_company_details('allow_negative_stock_pos');
  $use_dimension = get_company_details('use_dimension');
  $show_customer_on_pdf = get_company_details('show_customer_on_pdf');
  $show_customer_address_on_pdf = get_company_details('show_customer_address_on_pdf');
  $non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
}

if( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['submit'])) {

}
get_header(); ?>

 <!--   ###########  Body Section ##############  -->  
 <div class="container" id="bodySection" >

  <div class="col-md-12">
    <div class="panel ">
      <div class="panel-heading padrl20" data-background-color="purple">
        <h4 class="title txtColor"><?php echo _("Profile"); ?></h4>
      </div>
      <div class="panel-body padrl20">
        <form action="" method="post">
          <div class="row">
            <div class="col-md-5"><?php $company_name = get_company_details(); ?>
              <div class="form-group label-floating <?php  if(trim($company_name) == ''){ echo 'is-empty'; } ?>">
                <label class="control-label"><?php echo _("Company"); ?></label>
                <input type="text" class="form-control"  value="<?php echo $company_name; ?>" >
                <span class="material-input"></span>
              </div>
            </div>
            <div class="col-md-3"><?php $phone = get_company_details('phone'); ?>
              <div class="form-group label-floating <?php  if(trim($phone) == ''){ echo 'is-empty'; } ?>">
              <label class="control-label"><?php echo _("Phone"); ?></label>
              <input type="text" class="form-control" value="<?php echo $phone; ?>">
              <span class="material-input"></span>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group label-floating <?php if(trim($current_user['email']) == ''){ echo 'is-empty'; } ?>">
              <label class="control-label"><?php echo _("Email address"); ?></label><input type="email" class="form-control" value="<?php echo $current_user['email']; ?>" ><span class="material-input"></span></div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group label-floating <?php if(trim($current_user['full_name']) == ''){ echo 'is-empty'; } ?>"><label class="control-label"><?php echo _("Full Name"); ?></label>
              <input type="text" class="form-control" value="<?php  echo $current_user['full_name']; ?>">
              <span class="material-input"></span></div>
            </div>
            <div class="col-md-6"><?php $gst = get_company_details('gst_no'); ?>
              <div class="form-group label-floating  <?php if(trim($gst) == ''){ echo 'is-empty'; } ?>">
                <label class="control-label"><?php echo _("GST"); ?></label>
                <input type="text" class="form-control" value="<?php  echo $gst; ?>">
                <span class="material-input"></span></div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <?php $address = get_company_details('postal_address'); ?>
              <div class="form-group label-floating <?php if(trim($address) == ''){ echo 'is-empty'; } ?>">
              <label class="control-label"><?php echo _("Address"); ?></label>
              <input type="text" class="form-control" value="<?php  echo $address; ?>">
              <span class="material-input"></span></div>
            </div>
          </div>
         <!-- <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label class="txtColor"><?php echo _("About Me"); ?></label>
                <div class="form-group label-floating is-empty">
                <label class="control-label"> <?php echo _("Just Describe about your Company in few lines. Which is won't be used somewhere except here"); ?>.</label>
                <textarea class="form-control" rows="5"></textarea>
                <span class="material-input"></span></div>
              </div>
            </div>
          </div> -->
          <?php if($current_user['role'] == 'Administrator' ){ ?>
          <div class="row">
            <div class="col-md-12"> <h3> <?php echo _("Company Setup"); ?> </h3> </div>
            <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="customer_vat_mandatory" value="1" <?php echo ($customer_vat_mandatory ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> <?php echo _("Customer VAT/GST mandatory and unique"); ?></label>
                </div>
            </div>

            <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="allow_negative_stock_pos" value="1" <?php echo ($allow_negative_stock_pos ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> <?php echo _("Proceed with Negative Inventory"); ?></label>
                </div>
            </div>


            <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="customer_email_mandatory" value="1" <?php echo ($customer_email_mandatory ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> <?php echo _("Customer Email Mandatory"); ?></label>
                </div>
            </div>

            <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="customer_email_unique" value="1" <?php echo ($customer_email_unique ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> <?php echo _("Email Unique"); ?></label>
                </div>
            </div>

          </div>
          <div class="row">
            <div class="col-md-3">
              <label class="control-label col-md-4"><?php echo _("Use dimension"); ?></label> <div class="col-md-8">
               <?php $dimension = [0 => 0, 1 => 1, 2 => 2]; echo select_options_list('use_dimension', $dimension, $use_dimension, 'no', null, 'form-control Change_Value', 'use_dimension');  ?>
             </div>
            </div>


            <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="show_customer_on_pdf" value="1" <?php echo ($show_customer_on_pdf ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> Show Customer name in PDF (A6, A7, A8)</label>
                </div>
            </div> 
            <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="show_customer_address_on_pdf" value="1" <?php echo ($show_customer_address_on_pdf ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> Show Customer Detail in PDF (A6, A7, A8)</label>
                </div>
            </div>  <div class="col-md-3">
                <div class="checkbox">
                  <label><input class="Change_Value" type="checkbox" name="non_detailed_sales_kit" value="1" <?php echo ($non_detailed_sales_kit ? 'checked=""' : ''); ?> ><span class="checkbox-decorator"><span class="check"></span><div class="ripple-container"></div></span> No Detailed Sales Kit</label>
                </div>
            </div> 
          </div>
          <!-- <input type="submit" name="submit" class="btn btn-primary pull-right buttonui" value="<?php //echo _("Update Profile"); ?>" >  -->
        <div class="clearfix"></div>
      <?php } ?>
        <div class="row">
          <div class="col-md-12">
              <div class="panel-heading padrl20" data-background-color="purple">
                <h4 class="title txtColor"><?php echo _("Appearance"); ?></h4>
              </div>
          </div>
        </div>
        <div class="row"> 
        <div class="col-md-12"> 
         <label class="control-label"><?php echo _("Color Scheme"); ?></label> </div>
         <?php $ColorScheme = get_user_meta($current_user['ID'], 'ColorScheme'); ?>
         <div class="col-md-3"> 
                  <div class="radio radio-warning">
                    <label><input type="radio" name="ColorScheme" class="ColorScheme" value="kvcodes" <?php if($ColorScheme =='kvcodes' || $ColorScheme == false) { echo 'checked=""'; } ?>><span class="circle"></span><span class="check"></span>
                      <?php echo _("Default"); ?> </label>
                  </div>
            </div>
        

           <div class="col-md-2">
              <div class="radio radio-info">
                    <label><input type="radio" name="ColorScheme" class="ColorScheme" value="blue" <?php if($ColorScheme =='blue' ) { echo 'checked=""'; } ?>><span class="circle"></span><span class="check"></span>
                      <?php echo _("Blue"); ?> </label>
                  </div>
                </div>
              <div class="col-md-2" > 
                <div class="radio radio-primary">
                    <label ><input type="radio" name="ColorScheme" class="ColorScheme" value="green" <?php if($ColorScheme =='green' ) { echo 'checked=""'; } ?>><span class="circle"></span><span class="check"></span>
                      <?php echo _("Green"); ?> </label>
                  </div>
                </div>
				<div class="col-md-2" > 
                <div class="radio radio-primary">
                    <label ><input type="radio" name="ColorScheme" class="ColorScheme" value="pink" <?php if($ColorScheme =='pink' ) { echo 'checked=""'; } ?>><span class="circle"></span><span class="check"></span>
                      <?php echo _("Pink"); ?> </label>
                  </div>
                </div>
				<div class="col-md-2" > 
                <div class="radio radio-primary">
                    <label ><input type="radio" name="ColorScheme" class="ColorScheme" value="orange" <?php if($ColorScheme =='orange' ) { echo 'checked=""'; } ?>><span class="circle"></span><span class="check"></span>
                      <?php echo _("Orange"); ?> </label>
                  </div>
                </div>
             </div>  

			<div class="row">
          <div class="col-md-12">
              <div class="panel-heading padrl20" data-background-color="purple">
                <h4 class="title txtColor"><?php echo _("Language & PDF Templates"); ?></h4>
              </div>
          </div>
        </div>
		 <div class="row"> 
        <div class="col-md-6" ><div class="col-md-6"> 
         <label class="control-label"><?php echo _("Choose Your Language"); ?></label> </div>
        
         <div class="col-md-6"> 
                  <?php $language_ar = GetLanguagesList(); echo select_options_list('language', $language_ar, $current_user['language'], 'no', null, 'form-control', 'UserLang');  ?>
            </div>
          </div>
          <div class="col-md-6" > 
            <div class="col-md-6"><label class="control-label"><?php echo _("PDF Size"); ?></label></div>
            <div class="col-md-6"><?php $list = get_pdf_templates_list();
            //var_dump($list); 
            echo select_options_list('pdf_template', $list, $current_user['pdf_template'], 'no', null, 'form-control', 'PDF_Template');  ?></div>
          </div>
		</div>
      </form>      
    </div>
  </div>
</div>
<script> 
$(document).ready(function(){
 /* $(".ColorScheme").on("click", function(){
     $("#ColorScheme").trigger("change");
  }); */
  $(".Change_Value").on("change", function(){
      if($(this).attr('type') == 'checkbox')
        var option_value = ($(this).is(':checked') ? 1 : 0 );
      else 
        var option_value = $(this).val();
     var option_name = $(this).attr('name');
     $.ajax({
            type: "POST",
            url: "ajax?change_sys_prefs=yes",
            data: { name : option_name, value : option_value },
            success: function(data){              
              if(data >= 1 || data >0){
                alert('<?php echo _("Your change updated"); ?>');
                location.reload();
              }
            }
          });
  });
  $(".ColorScheme").on("change", function(){
    var ColorScheme = $(this).val(); 
     //alert(ColorScheme);
     $.ajax({
            type: "POST",
            url: "ajax?ChangeColorScheme="+ColorScheme,
            data: 0,
            success: function(data){              
              if(data == 1 || data >0){
                alert('<?php echo _("Your Color Scheme changed!"); ?>.');
                location.reload();
              }
            }
          });
  });
  
  $("#UserLang").on("change", function(){
    var UserLang = $(this).val(); 
     //alert(ColorScheme);
     $.ajax({
            type: "POST",
            url: "ajax?ChangeUserLang="+UserLang,
            data: 0,
            success: function(data){              
              if(data == 1 || data >0){
                alert('<?php echo _("Your Language changed!"); ?>.');
                location.reload();
              }
            }
     });
  });

  $("#PDF_Template").on("change", function(){
    var pdf_size = $(this).val(); 
     //alert(ColorScheme);
     $.ajax({
            type: "POST",
            url: "ajax?ChangePDFSize="+pdf_size,
            data: 0,
            success: function(data){              
              if(data == 1 || data >0){
                alert('<?php echo _("Your PDF Size changed!"); ?>.');
                //location.reload();
              }
            }
     });
  });
});
</script>
<?php get_footer(); ?>