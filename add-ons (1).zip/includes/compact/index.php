<?php 
  

get_header();

echo '
<div class="content" > '; 
get_page_content();

echo '</div>';
get_footer();
?> 