<?php
/* 
Template Name: Return
*/
global $current_user;
if($current_user['role'] != 'Administrator') 
	kv_direct(get_url('404'));
get_header();
?>

<div class="container dashboard" id="bodySection">

    <div class="row">
        <iframe src="<?php echo GetSingleValue('settings', 'option_value', array('option_name' => 'site_url'))?>/vm/purchasing/po_entry_items.php?NewOrder=Yes" width="100%" height=600/>
    </div>
    
</div>

<?php get_footer(); ?>