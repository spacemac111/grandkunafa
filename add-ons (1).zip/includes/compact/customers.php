<?php 
/*
Template Name: Customer
*/ 
global $current_user, $selected_user;
get_header(); 
if(has_user_permission('View Customers', 'Customers')) {
	$customer_email_unique = get_company_details('customer_email_unique');
  	$customer_email_mandatory = get_company_details('customer_email_mandatory');
	$customer_vat_mandatory = get_company_details('customer_vat_mandatory');
?>
<style type="text/css">
#bodySection { position:relative; }
.EditName { opacity: 0; }
.rewiteFilename { display: none; }
.AssignTransaction{ cursor: pointer; }
table.dataTable tbody td:nth-child(2):hover i {  opacity: 1; }
table.dataTable tbody td { line-height: 45px; padding: 3px 10px; }
.success { color:#39c558 }
.processed { color:#00b4ff  }
.pending { color:#ffbe41}
.rejected { color:#ff3e43 }
i.material-icons.SubmitNameChange, i.material-icons.RevertNameBack, i.material-icons.EditName{ padding:0 ; }
.modal-content .modal-footer {    border-top: none;    padding: 7px;    border-top: 1px solid #eee;}
.modal-content .modal-footer button {  margin-top:5px; }
.fixed-action-btn {    position:relative;    padding-top: 15px;    margin-bottom: 0;    z-index: 1001;}

/* responsive iFrame style */
.iframe-container {  position: relative;  height: 0;  overflow: hidden;}
 
/* 16x9 Aspect Ratio */
.iframe-container {  padding-bottom: 100%;}
 
/* 4x3 Aspect Ratio */
.iframe-container-4x3 {  padding-bottom: 75%;} 
.iframe-container iframe {  position: absolute;  top:0;  left: 0;  width: 100%;  height: 100%;}

/*  ###  Modal PDF style ####  */
.warning { background : #fdd396 !important; } 
.warning:hover { background : #f7b95e !important; } 
@media (max-width: 767px) {
  .iframe-container {  height: 100%;}
}

.gray, .gray:hover { color: #9E9E9E; }
.Processing {  color: #9C27B0;}
.Processed {  color: #03a9f4;}
.New {  color: #4CAF50;}
.Hold {  color: #FF9800;}
.Duplicate {color:#FF5722 }
.checkbox .checkbox-material .check, label.checkbox-inline .checkbox-material .check{  border-radius: 0px; }
.icon_round{  line-height: 1;    width: 43px;    padding: 6px;    padding-top: 10px;    border-radius: 50%;    background: hsla(291, 84%, 55%, 0.58);}
.FilterUploads{   float: left;   text-align: left; }
.FilterUploads select{ padding: 7px;    border-color: #dddddd; }
</style>

 <!--   ###########  Body Section ##############  -->    
 <div class="container" id="bodySection" >
   <div class="row"> 
      <div class="col-md-12">
          <h3> <?php echo _("Customers"); ?> &nbsp;&nbsp;&nbsp; <?php /*if(($actual_data < $total_space && $selected_user['ID'] == $current_user['ID'])  || ($current_user['role'] == 'Administrator' || $current_user['role'] == 'Auditor')) { */?><span style="display:inline-block"> <?php echo _("Add New Customer"); ?> </span>        
      		<?php if(has_user_permission('Add/Edit Customer', 'Customers')){ ?>
      		<button class="btn-floating btn-large primary-color " data-target="#CustomerAddNew" id="AddNewCustomerBtn" > <i class="material-icons">group_add</i></button> <?php /*}  */ ?> 
          	<?php } ?>
          </h3>          
      </div>
   </div>
   <?php if($actual_data > ($total_space-20)) { 
          echo '<div class="container" > <div class="warning col-sm-10" style="padding:8px; margin:15px;"> <span style="float:left;padding: 0 6px;width: 35px;border-radius: 30px;/* line-height: 2; */background: #fed;"> <i class="material-icons red" style=" line-height: 1.5;""> announcement </i> </span> <span style=" line-height: 2.5;  padding-left: 8px;  color: #E91E63;""> '._("You are nearing to your File Uploading Limit, Please contact Administrator to get more space").'</span> </div></div>';
    } ?>
          <table class="list bordered highlight" id="CustomersDatatable">
              <thead> <tr> <th> <?php echo _("ID"); ?> </th> <th> <?php echo _("Short Name"); ?> </th> <th> <?php echo _("Full Name"); ?></th> <th> <?php echo _("Sales Type"); ?> </th> <?php if($customer_vat_mandatory) { echo '<th>'._("VAT/GST").'</th>'; } ?> <th> <?php echo _("Address"); ?></th> <th> </th> <th> </th></tr> </thead> 
          </table>                
    
</div> <!-- /container -->
<?php } ?>
<!-- New message Modal Trigger -->
   
    <!-- New message Structure -->
    <div class="modal fade" id="CustomerAddNew" tabindex="-1" role="dialog" aria-labelledby="UploadTitle">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="UploadTitle"> <!--<i class="material-icons"> folder_open</i> --> <?php echo _("New Customer"); ?></h4>
          </div>
		  <form action="<?php echo get_url('customers'); ?>" class="" id="NewCustomerAdd" enctype="multipart/form-data" method="post" accept-charset="utf-8">
          <div class="modal-body" style="min-height:200px;">
            <div id="UploadStatus"> </div> 
            <div class="row">            
              <div class="col-sm-12"> 
			 
                  <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Full Name"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="client_name" class="form-control"></div></div>
                  
                  <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Short Name"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="cust_ref" class="form-control"></div></div>
					<div class="form-group"><label class="col-md-4 control-label"><?php echo _("Phone"); ?></label><div class="col-md-8"><input type="text" name="phone" class="form-control"></div></div>
					<div class="form-group"><label class="col-md-4 control-label"><?php echo _("Email Address"); ?></label><div class="col-md-8"><input type="text" name="client_email" class="form-control"></div></div>
                  
                  <div class="form-group" ><label for="textArea" class="col-md-4 control-label"><?php echo _("Address"); ?></label>

                <div class="col-md-8"><textarea class="form-control" rows="3" id="CustomerAddress" name="address"></textarea>
                  
                </div>
				</div>
				<div class="form-group"><label class="col-md-4 control-label"><?php echo _("VAT/BTW no"); ?><?php if($customer_vat_mandatory) { echo '<span style="color:#fb2e18;" > * </span>'; }?></label><div class="col-md-8"><input type="text" name="tax_id" class="form-control" required></div></div>
				<div class="form-group"><label class="col-md-4 control-label"><?php echo _("Bank Acc"); ?></label><div class="col-md-8"><input type="text" name="bank_account" class="form-control"></div></div>
				
				<div class="form-group"><label class="col-md-4 control-label"><?php echo _("Sales Type"); ?></label>
					<div class="col-md-8"><select autocomplete="off" name="sales_type" class="form-control">
					<?php  $sql ="SELECT id, sales_type, inactive FROM ".TB_PREF."sales_types ORDER BY sales_type";
						$sales_typ_res= fadb_query($sql, "can't get results");
						while($row = fadb_fetch($sales_typ_res)){
							// echo '<option value="'.$row['id'].'" > '. _($row['sales_type']).' </option>';
							echo '<option value="'.$row['id'].'" > '. $row['sales_type'].' </option>';
						}
						?>
					</select></div></div>
				
				<div class="form-group"><label class="col-md-4 control-label"><?php echo _("Payment Terms"); ?></label>
					<div class="col-md-8"><select autocomplete="off" name="payment_terms" class="form-control">
					<?php $sql ="SELECT terms_indicator, terms, inactive FROM ".TB_PREF."payment_terms ORDER BY terms";
						$pmt_tm= fadb_query($sql, "can't get results");
						while($row = fadb_fetch($pmt_tm)){
							if($row['inactive'] == 0)
							// echo '<option value="'.$row['terms_indicator'].'" > '. _($row['terms']).' </option>';
							echo '<option value="'.$row['terms_indicator'].'" > '. $row['terms'].' </option>';

						}
						?>
					</select></div></div>
					
					<div class="form-group"><label class="col-md-4 control-label"><?php echo _("Tax Group"); ?></label>
					<div class="col-md-8"><select autocomplete="off" name="tax_group_id" class="form-control">
					<?php  $sql ="SELECT id, name FROM ".TB_PREF."tax_groups ORDER BY id";
						$tax_gp= fadb_query($sql, "can't get results");
						while($row = fadb_fetch($tax_gp)){
							if($row['inactive'] == 0)
							// echo '<option value="'.$row['id'].'" > '. _($row['name']).' </option>';
								echo '<option value="'.$row['id'].'" > '. $row['name'].' </option>';
						}
						?>
					</select></div></div>
				<input type="hidden" name="customer_id" value="0" > 
				<?php $curr_default = get_company_details('curr_default'); ?>
				<input type="hidden" name="curr_code" value="<?php echo $curr_default; ?>" > 
				
              </div>
             
              <div class="col-md-12 form-group" id="errorWarning" style="display: none;background: #ffc0bb; border: 1px solid #F44336; border-radius: 2px; color: #f44336;" > 
              <label style="color: rgb(243, 32, 17); font-weight: 300;  padding-top: 10px;" > </label>
              </div> 
            </div>            
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
			<input type="hidden" name="submit_customer" value="yes" > 
            <button type="submit" class="btn btn-primary" id="Submitbtn"><?php echo _("Submit"); ?></button>
          </div>
		  </form>
        </div>
      </div>
    </div>

    <!-- Datatable Js --> 
<script src="<?php echo get_current_theme_uri(); ?>js/datatables.min.js"></script>
<script type="text/javascript">
 //  datatable filter redraw plugin
 $(function(){
$.fn.dataTableExt.oApi.fnStandingRedraw = function(oSettings) {

    if(oSettings.oFeatures.bServerSide === false){
        var before = oSettings._iDisplayStart;
        oSettings.oApi._fnReDraw(oSettings);       
        oSettings._iDisplayStart = before;
        oSettings.oApi._fnCalculateEnd(oSettings);
    } 
    oSettings.oApi._fnDraw(oSettings);
};

<?php 
  if($current_user['role'] == 'Administrator' || $current_user['role'] == 'Auditor'){
    echo 'var customerid= "&customerId='.$selected_user['ID'].'";';
    echo 'var customer_id= "&customerID='.$selected_user['ID'].'";';
  } else {
    echo 'var customerid="";' ;
    echo 'var customer_id="";' ;
  }
  ?>
  UploadsTable = $("#CustomersDatatable").dataTable({
          "processing": true,
          "serverSide": true,
          "order": [[ 0, "desc" ]],
          "pageLength": 25,
		 // "dom": '<"FilterUploads">frtip',
          "ajax": "<?php  echo get_url(); ?>ajax?customers=yes"+customerid
      });

	$('#CustomersDatatable').on('show.bs.modal', function (e) {
      $('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
  })
  $('#CustomersDatatable').on('hide.bs.modal', function (e) {
    $("#CustomersDatatable").dataTable().fnStandingRedraw();
    
   // $("#uploaderDiv").hide();
    $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
  });
	$(document).bind('keydown', 'shift+n', function(e){  //New Customer
	   $('#CustomerAddNew').modal('show');  
	  // $('.client_name').focus();
	  });
  $('iframe').load(function() {
    $(this).contents().find('img').css({'max-width': '100%', 'padding' : '5%'});
  });  
  
	// Add Newcustomer Popup submit
	$('form#CustomerAddNew').on('submit', function (e) {
		alert("ghfgf");
		e.preventDefault();		  
		$.ajax({
            type: 'post',
            url: 'ajax?submit_customer=yes',
            data: $(this).serialize(),
            success: function (result) {
				alert(result);
				$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
				$('#CustomerAddNew').modal('hide');
				$("#CustomersDatatable").dataTable().fnStandingRedraw();			  
            }
		});
    });
	$("body").on("click", "#Submitbtn", function(e){ 
		e.preventDefault();
		var emailaddress = $('input[name="client_email"]').val();
		if($('input[name="client_name"]').val()==''){
			$('input[name="client_name"]').focus();			
			$("#errorWarning label").html('<?php echo _("You have to input client full name"); ?>');
			$("#errorWarning").show();
		}
		<?php if($customer_email_mandatory) {?>  
		else if( !isEmail(emailaddress) && emailaddress.length>0) { 
			$('input[name="client_email"]').focus();
			$("#errorWarning label").html('<?php echo _("You have to input valid client email"); ?>');
			$("#errorWarning").show();
		}
	<?php } ?>
		else if($('input[name="cust_ref"]').val() == ''){
			$('input[name="cust_ref"]').focus();
			$("#errorWarning label").html('<?php echo _("You have to input client Short name"); ?>');
			$("#errorWarning").show();
		}
		<?php if($customer_vat_mandatory) { ?>
		else if($('input[name="tax_id"]').val().trim() == ''){
			$('input[name="tax_id"]').focus();
			$("#errorWarning label").html('<?php echo _("You have to input Customer VAT/GST"); ?>');
			$("#errorWarning").show();
		}else if($('input[name="tax_id"]').val().trim() != '' && $('input[name="customer_id"]').val() == '0' ) {

			var tax_id = $('input[name="tax_id"]').val();
			
			$.ajax({
				type 		: 'post',
				url 	: 'ajax?validate_gst=yes',
				data 		: { 'tax_id' : tax_id },
				success: function (result) {
					if(result == 1){
						$('input[name="tax_id"]').focus();
						$("#errorWarning label").html('<?php echo _("You have entered Duplicate VAT/GST No"); ?>');
						$("#errorWarning").show();			
					}  else {
						$("#errorWarning").hide();
						$.ajax({
							type: 'post',
							url: 'ajax?submit_customer=yes',
							data: $('#NewCustomerAdd').serialize(),
							success: function (result) {
								alert(result);
								$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
								$('#CustomerAddNew').modal('hide');
								$("#CustomersDatatable").dataTable().fnStandingRedraw();			  
							}
						});
					}
				}
			});
		}
	<?php } ?>
		
		else if($('input[name="customer_id"]').val() == '0') {
			<?php if($customer_email_unique) {?> 
			$.ajax({
				type: "POST",
				url: "ajax?Email_validate="+emailaddress,
				data: 0,
				success: function(data){ 					
					if(data >= 1){
						$('input[name="client_email"]').focus();
						$("#errorWarning label").html('<?php echo _("Client email already exist, Please try some other email"); ?>');
						$("#errorWarning").show();
					}else {
						$("#errorWarning").hide();
						$.ajax({
							type: 'post',
							url: 'ajax?submit_customer=yes',
							data: $('#NewCustomerAdd').serialize(),
							success: function (result) {
								alert(result);
								$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
								$('#CustomerAddNew').modal('hide');
								$("#CustomersDatatable").dataTable().fnStandingRedraw();			  
							}
						});
					}
				}, error:function(data){
					
				}
			});
		<?php } else { ?>
			$("#errorWarning").hide();
					$.ajax({
						type: 'post',
						url: 'ajax?submit_customer=yes',
						data: $('#NewCustomerAdd').serialize(),
						success: function (result) {
							alert(result);
							$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
							$('#CustomerAddNew').modal('hide');
							$("#CustomersDatatable").dataTable().fnStandingRedraw();			  
						}
					});
		<?php } ?>
		}else {
			$("#errorWarning").hide();
			$.ajax({
				type: 'post',
				url: 'ajax?submit_customer=yes',
				data: $('#NewCustomerAdd').serialize(),
				success: function (result) {
					alert(result);
					$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
					$('#CustomerAddNew').modal('hide');
					$("#CustomersDatatable").dataTable().fnStandingRedraw();			  
				}
			});
		} 		
	});
	$("body").on("click", "#AddNewCustomerBtn", function(e){ 
		$("#UploadTitle").html('<?php echo _("Add New Customer"); ?>');
		$('input[name="client_name"]').val('');
		$('input[name="cust_ref"]').val('');
		$('input[name="tax_id"]').val('');
		$('input[name="customer_id"]').val(0);
		$('#CustomerAddress').val('');
		$('input[name="phone"]').val('');
		$('input[name="client_email"]').val('');
		$('input[name="bank_account"]').val('');				
		$('input[name="sales_type"]').prop("selectedIndex", 1);
		$('input[name="payment_terms"]').prop("selectedIndex", 1);
		$('input[name="tax_group_id"]').prop("selectedIndex", 1);
		$('input[name="curr_code"]').val('<?php echo $curr_default; ?>');
		$("#errorWarning").hide();
		$("#CustomerAddNew").modal('show');
	});
	$("body").on("click", ".EditCustomer", function(e){ 	
		//e.preventDefault();
		var edit_customer_id = $(this).data('customerid'); 
		EdiCustomer(edit_customer_id); 
   });
	$("body").on("click", ".DeleteCustomer", function(e){ 
		var delete_customer_id = $(this).data('customerid'); 
		DeleteCustomer(delete_customer_id); 
   }); 
});

function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}

function EdiCustomer(Customerid){  	
	$.ajax({
		type: "POST",
		dataType: "json",
		url: "ajax?Edit_Customer="+Customerid,
		data: 0,
		success: function(data){    
			console.log(data);						
          if(data != 1){
				$("#UploadTitle").html('<?php echo _("Edit Customer"); ?>');
				$('input[name="client_name"]').val(data.name);
				$('input[name="cust_ref"]').val(data.debtor_ref);
				$('input[name="tax_id"]').val(data.tax_id);
				$('input[name="customer_id"]').val(data.debtor_no);
				$('#CustomerAddress').val(data.address);
				$('input[name="phone"]').val(data.phone);
				$('input[name="client_email"]').val(data.email);
				$('input[name="bank_account"]').val(data.bank_account);
				
				$('input[name="sales_type"]').prop("selectedIndex", data.sales_type);
				$('input[name="payment_terms"]').prop("selectedIndex", data.payment_terms);
				$('input[name="tax_group_id"]').prop("selectedIndex", data.tax_group_id);
				$('input[name="curr_code"]').val(data.curr_code);
				$("#errorWarning").hide();
			//alert(data.name);
			$("#CustomerAddNew").modal('show');
          }else{
            alert("Failed to Edit : "+data);
          }               
        }
	});   
}

function DeleteCustomer(Customerid){
  var r = confirm('<?php echo _("Are you sure to delete this Customer?"); ?>');
  if (r == false) {
    return false;
  } else {	 
    $.ajax({
        type: "POST",
        url: "ajax?delete_Customer="+Customerid,
        data: 0,
        success: function(data){        
          if(data == 1){
            alert('<?php echo _("The customer was deleted successfully."); ?>');
            $("#CustomersDatatable").dataTable().fnStandingRedraw();
          }else{
            alert("Failed to Delete : "+data);
          }               
        }
    });
  }
}
</script>
<?php get_footer(); ?>