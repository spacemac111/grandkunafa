<?php 
/*
Template Name: Ajax
*/ 
require_once(FA_PATH.'config_db.php');
require_once(ABSPATH.'pusher/vendor/autoload.php');
global $current_user, $selected_user, $Refs, $price_dec, $db_connections; 
$price_dec = user_price_dec();
$pusher_keys = get_site_option('pusher');
$options = array(
'cluster' => $pusher_keys['app_cluster'],
'encrypted' => $pusher_keys['allow_pusher']
);
$pusher = new Pusher\Pusher($pusher_keys['app_id'],
    $pusher_keys['app_key'],
    $pusher_keys['app_secret_id'],
    $options
);
if(isset($_GET['pusher_auth'])){

	if ( logged_in() ){
	  $current_user = kv_get_current_user();

	  $presence_data = array('name' => $current_user['full_name']);
	  echo $pusher->presence_auth($_POST['channel_name'], $_POST['socket_id'], $current_user['ID'], $presence_data);
	}else{
	  header('', true, 404);
	  echo( "Forbidden" );
	}
}

if(isset($currrent_user['fa_user_id'])){
	$price_dec = FAGetSingleValue('users', 'prices_dec', array('id' => $current_user['fa_user_id']));
}
if(isset($_GET['Selected_User'])){
	$selected_user = (int)($_GET['Selected_User']);
	echo $_SESSION['Selected_User'] = $selected_user;
}

$sql_details = array( 'user' => $selected_user['dbuser'], 'pass' => $selected_user['dbpassword'], 'db'   => $selected_user['dbname'], 'host' => $selected_user['host']  ); 
define('FA_PREF', $selected_user['tbpref']);


function getExtension($str){
    $i = explode('.', $str);
    return strtolower(end($i));
}

if(isset($_GET['Get_AttachID_From_trans_no']) && $_GET['Get_AttachID_From_trans_no'] > 0){
	//echo $_GET['Get_AttachID_From_trans_no'];
	echo Get_AttachID_From_trans_no($_GET['Get_AttachID_From_trans_no']);
}

if(isset($_GET['CustomerInvoices']) && $_GET['CustomerInvoices'] == 'yes'){	
	//$customerInvoices = CustomerTable();
	global $price_dec, $sql_details;
	//$pric_dec = user_price_dec();
	//var_dump($sql_details);
	$table = FA_PREF. 'debtor_trans';
	$table2= FA_PREF. 'debtors_master';
	$primaryKey = 'debtor_no';
	
	$columns = array(
		//array( 'db' => '`so`.`trans_no`', 	'dt' => 0,	'field' => 'trans_no'	),
		array( 'db' => '`so`.`reference`',  'dt' => 0,	'field' => 'reference', 'formatter' => function( $d, $row ) 	{ return '<a href="#" class="pdfModal PrintReceipt" data-trans_no="'.$row[7].'" data-type="10" data-target="#pdfModal" data-toggle="modal" style="font-weight: 600;text-decoration:none;" > '.$d.' </a>'; } ),
		array( 'db' => '`debtor`.`name`',  	'dt' => 1,	'field' => 'name'),
		array( 'db' => '`so`.`tran_date`',	'dt' => 2,	'field' => 'tran_date','formatter' => function( $d, $row ) 	{ return date( 'jS M y', strtotime($d)); } ),
		array( 'db' => '`so`.`due_date`',   'dt' => 3,	'field' => 'due_date', 'formatter' => function( $d, $row ) 	{ return date( 'jS M y', strtotime($d)); } ),
		array( 'db' => '`so`.`ov_amount`',  'dt' => 4,	'field' => 'ov_amount','formatter' => function( $d, $row )	{global $price_dec; return round(get_total_Amount($row[7]), $price_dec);} ),
		array( 'db' => '`so`.`alloc`',  	'dt' => 5,	'field' => 'alloc','formatter' => function( $d, $row )	{global $price_dec;  $alloc =  round((get_total_Amount($row[7])-$d ), $price_dec);
				return ($alloc > 0 ? '<a href="#" class="PaymentModal" data-trans_no="'.$row[7].'" data-target="#PaymentModal"  style="font-weight: 600;text-decoration:none;" > '.$alloc.' </a>' : 0 );} ),
		array( 'db' => '`so`.`trans_no`',   'dt' => 6,	'field' => 'trans_no','formatter' => function( $d, $row )	{ global $price_dec; 

		if(has_user_permission('Refund', 'Sales')){ 

		 $alloc =  round((get_total_Amount($row[7])-$row[5] ), $price_dec);  return ($alloc == 0 ? '<a href="#" class="SalesReturn" data-trans_no="'.$row[7].'" data-type="10"  style="font-weight: 600;text-decoration:none;" > <i class="material-icons"> rotate_90_degrees_ccw</i> </a>' : '' );  
		}
		} 	),
		array( 'db' => '`so`.`trans_no`',   'dt' => 7,	'field' => 'trans_no','formatter' => function( $d, $row )	{ return get_invoice_status(10,$d);} 	)
	);

	$joinQuery = "FROM `{$table}` AS `so` LEFT JOIN {$table2} AS debtor ON so.debtor_no = debtor.debtor_no";  
	$extraWhere = ' `so`.`type` = 10 '; //AND `so`.`debtor_no` ='.$debtor_no; 
	if($current_user['role'] == 'Salesman')
		$extraWhere .= ' AND `so`.`salesman` ='.$current_user['s_id'];
	if(isset($_GET['FilterStatus'])){
		if($_GET['FilterStatus'] == 'Received'){
			$extraWhere .= " AND ROUND((so.ov_amount + so.ov_gst + so.ov_freight + so.ov_freight_tax + so.ov_discount), 2) = ROUND(so.alloc, 2) ";
		}elseif($_GET['FilterStatus'] == 'Overdue'){
			$extraWhere .=" AND CURDATE() > so.due_date AND ROUND((so.ov_amount + so.ov_gst + so.ov_freight + so.ov_freight_tax + so.ov_discount), 2) <> ROUND(so.alloc, 2)";
		}elseif($_GET['FilterStatus'] == 'Yet To Receive' ){
			$extraWhere .=" AND ROUND((so.ov_amount + so.ov_gst + so.ov_freight + so.ov_freight_tax + so.ov_discount), 2) <> ROUND(so.alloc, 2)";
		}
	}

	if(isset($_GET['FilterDate'])){
		if($_GET['FilterDate'] == 'Today'){
			$extraWhere .= " AND so.tran_date = '".date('Y-m-d')."'";
		}elseif($_GET['FilterDate'] == 'Yesterday'){
			$extraWhere .= " AND so.tran_date = '".date('Y-m-d',strtotime("-1 days"))."'";
		}elseif($_GET['FilterDate'] != -1) {
			if($_GET['FilterDate'] == 'LastMonth'){
		        $today1 = date('Y-m-d', strtotime('last day of previous month'));
		        $begin1 = date('Y-m-d', strtotime('first day of previous month'));
		    }elseif($_GET['FilterDate'] == 'ThisMonth'){
		        $begin1 = date("Y-m-d", strtotime("first day of this month"));
		        $today1 = date("Y-m-d", strtotime("last day of this month"));
		    }elseif($_GET['FilterDate'] =='LastWeek'){
		        $begin1 = date("Y-m-d", strtotime("last week monday"));
		        $today1 = date("Y-m-d", strtotime("last week sunday"));
		    } elseif($_GET['FilterDate'] =='ThisWeek'){
		        $begin1 = date("Y-m-d", strtotime("this week monday"));
		        $today1 = date("Y-m-d", strtotime("this week sunday"));
		    }
		    $extraWhere .= " AND so.tran_date >= '".$begin1."' AND so.tran_date <= '".$today1."'";
		}
	}
	// if(has_user_permission('View Own', 'Sales') && (isset($_SESSION['role']) && $_SESSION['role'] != 'Administrator')){
	// 	$_GET['Salesman'] = $_SESSION['s_id'];
	// }
	if(isset($_GET['Salesman']) && $_GET['Salesman'] > 0 ){
		$extraWhere .=" AND so.salesman = ".$_GET['Salesman']." ";
	}

	if(isset($_GET['dim']) && $_GET['dim'] > 0 ){
		$extraWhere .=" AND so.dimension_id = ".$_GET['dim']." ";
	}
	if(isset($_GET['dim2']) && $_GET['dim2'] > 0 ){
		$extraWhere .=" AND so.dimension2_id = ".$_GET['dim2']." ";
	}

	$customerInvoices = Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '', false );
	echo json_encode($customerInvoices);
}


if(isset($_GET['ReturnInvoices']) && $_GET['ReturnInvoices'] == 'yes'){	
	global $price_dec;
	//$pric_dec = user_price_dec();
	$table = FA_PREF. 'debtor_trans';
	$table2= FA_PREF. 'debtors_master';
	$primaryKey = 'debtor_no';
	
	$columns = array(
		//array( 'db' => '`so`.`trans_no`', 	'dt' => 0,	'field' => 'trans_no'	),
		array( 'db' => '`so`.`trans_no`',   'dt' => 0,	'field' => 'trans_no'),
		array( 'db' => '`so`.`reference`',  'dt' => 1,	'field' => 'reference', 'formatter' => function( $d, $row ) 	{ return '<a href="#" class="pdfModal PrintReceipt" data-trans_no="'.$row[0].'" data-type="11" data-target="#pdfModal" data-toggle="modal" style="font-weight: 600;text-decoration:none;" > '.$d.' </a>'; } ),
		array( 'db' => '`debtor`.`name`',  	'dt' => 2,	'field' => 'name'),
		array( 'db' => '`so`.`tran_date`',	'dt' => 3,	'field' => 'tran_date','formatter' => function( $d, $row ) 	{ return date( 'jS M y', strtotime($d)); } ),
		array( 'db' => '`so`.`ov_amount`',  'dt' => 4,	'field' => 'ov_amount','formatter' => function( $d, $row )	{global $price_dec; return number_format(get_total_Amount($row[0], 11), $price_dec);} )
		
	);

	$joinQuery = "FROM `{$table}` AS `so` LEFT JOIN {$table2} AS debtor ON so.debtor_no = debtor.debtor_no";  
	$extraWhere = ' `so`.`type` = 11 '; //AND `so`.`debtor_no` ='.$debtor_no; 

	if($current_user['role'] == 'Salesman')
		$extraWhere .= ' AND `so`.`salesman` ='.$current_user['s_id'];
	$wigepa_sources = Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '' );
	echo json_encode($wigepa_sources);
}
//-----------------------------------------------------------------------------------------------------
// Customers Programs 
//-----------------------------------------------------------------------------------------------------
if(isset($_GET['customers']) && $_GET['customers'] == 'yes'){	
	
	$table= FA_PREF. 'debtors_master';
	$primaryKey = 'debtor_no';
	$loc = (isset($_SESSION['pos_details']['pos_location'])? $_SESSION['pos_details']['pos_location'] : 'DEF');

	$columns = array(
		//array( 'db' => '`so`.`trans_no`', 	'dt' => 0,	'field' => 'trans_no'	),
		array( 'db' => 'deb.debtor_no',  	'dt' => 0,	'field' => 'debtor_no'),		
		array( 'db' => 'debtor_ref', 		'dt' => 1,	'field' => 'debtor_ref'),
		array( 'db' => 'name',				'dt' => 2,	'field' => 'name' ),
		array( 'db' => 'sales_type',		'dt' => 3,	'field' => 'sales_type', 'formatter' => function( $d, $row ) { return GetSalesTypeName($d); }),

	);

$customer_vat_mandatory = get_company_details('customer_vat_mandatory');

	if($customer_vat_mandatory){
		$columns[]= array( 'db' => 'tax_id',				'dt' => 4,	'field' => 'tax_id' );
		$columns[]= array( 'db' => 'address',  			'dt' => 5,	'field' => 'address');
		$columns[]= array( 'db' => 'deb.debtor_no',  	'dt' => 6,	'field' => 'debtor_no', 'formatter' => function( $d, $row ) { return '<i data-target="#CustomerAddNew" class="material-icons EditCustomer" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-customerid="'.$d.'" > create </i>' ; });
		$columns[]= array( 'db' => 'deb.debtor_no',  	'dt' => 7,	'field' => 'debtor_no', 'formatter' => function( $d, $row ) { return '<i class="material-icons DeleteCustomer" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-customerid="'.$d.'" > delete_forever </i>' ; });
	} else {
		$columns[]= array( 'db' => 'address',  			'dt' => 4,	'field' => 'address');
		$columns[]= array( 'db' => 'deb.debtor_no',  	'dt' => 5,	'field' => 'debtor_no', 'formatter' => function( $d, $row ) { return '<i data-target="#CustomerAddNew" class="material-icons EditCustomer" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-customerid="'.$d.'" > create </i>' ; });
		$columns[]= array( 'db' => 'deb.debtor_no',  	'dt' => 6,	'field' => 'debtor_no', 'formatter' => function( $d, $row ) { return '<i class="material-icons DeleteCustomer" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-customerid="'.$d.'" > delete_forever </i>' ; });
	}

	$joinQuery = "FROM `{$table}` AS `deb` LEFT JOIN ".FA_PREF."cust_branch AS br ON `deb`.`debtor_no` = `br`.`debtor_no` ";  
	
	$extraWhere = " br.default_location = ".fadb_escape($loc)."  "; 	
	$wigepa_sources = Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '') ;
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}

//-----------------------------------------------------------------------------------------------------
// Category Programs 
//-----------------------------------------------------------------------------------------------------

if(isset($_GET['categorytbl']) && $_GET['categorytbl'] == 'yes'){
	//$sql = "SELECT c.description, c.category_id FROM ".TB_PREF."stock_category as c, ".TB_PREF."stock_master AS master WHERE c.category_id=master.category_id ";

	$table = FA_PREF. 'stock_category';
	$primaryKey = 'category_id';
	$columns = array(
		array('db' => 'c.category_id', 	'dt' =>0, 	'field' => 'category_id'),
		array('db' => 'c.description', 	'dt' =>1, 	'field' => 'description'),
		array('db' => 'p.description AS p_desc', 	'dt' =>2, 	'field' => 'p_desc'),
		array('db' => 'c.dflt_mb_flag',	'dt' =>3,	'field' => 'dflt_mb_flag', 'formatter' => function( $d, $row ) { return $type = ($row['dflt_mb_flag'] == 'D') ? 'Service' : (($row['dflt_mb_flag'] == 'B') ? 'Purchased' : 'Manufactured'); }),
		array('db' => 'c.dflt_units', 	'dt' =>4, 	'field' => 'dflt_units'),
		array('db' => 'c.dflt_tax_type', 	'dt' =>5, 	'field' => 'dflt_tax_type', 'formatter' => function( $d, $row) { return $tax = ($row['dflt_tax_type'] == 1) ? 'Regular': '' ; }),
		array('db' => 'c.category_id',  	'dt' =>6,	'field' => 'category_id', 'formatter' => function( $d, $row ) { if(has_user_permission('Edit Inventory', 'Inventory')){ return '<i data-target="#CategoryAddNew" class="material-icons EditCategory" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-edid="'.$d.'" > create </i>' ; } else { return ''; } }),
		array('db' => 'c.category_id',  	'dt' =>7,	'field' => 'category_id', 'formatter' => function( $d, $row ) { if(has_user_permission('Delete Inventory', 'Inventory')){ return '<i class="material-icons DeleteCategory" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-inid="'.$d.'" > delete_forever </i>' ; } else { return ''; } })
	);
	$joinQuery = "FROM `{$table}` AS `c` LEFT JOIN ".FA_PREF."stock_category AS p ON `c`.`parent_id` = `p`.`category_id` ";  
	$extraWhere = ''; 	
	$wigepa_sources =Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '', false ) ;
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}

//-----------------------------------------------------------------------------------------------------
// Inventory Programs 
//-----------------------------------------------------------------------------------------------------
if(isset($_GET['inventory']) && $_GET['inventory'] == 'yes'){	
	
	$table= FA_PREF. 'stock_master';
	$primaryKey = 'stock_id';
	
	$columns = array(
		//array( 'db' => '`so`.`trans_no`', 	'dt' => 0,	'field' => 'trans_no'	),
		array( 'db' => '`so`.`stock_id`',  		'dt' => 0,	'field' => 'stock_id'),		
		array( 'db' => '`so`.`description`', 	'dt' => 1,	'field' => 'description','formatter' => function( $d, $row ) { return $row[1]; }),
		array( 'db' => '`so`.`wip_account`',	'dt' => 2,	'field' => 'name', 	'formatter' => function ($d, $row) { return ($row['mb_flag'] != 'D' ? qoh_on_hand($row['stock_id']) : '' ); }),
		array( 'db' => '`so`.`mb_flag`',		'dt' => 3,	'field' => 'mb_flag', 'formatter' => function( $d, $row ) { return ($row['mb_flag'] == 'D' ? 'Service' : 'Item'); }),
		array( 'db' => '`so`.`units`',  		'dt' => 4,	'field' => 'units'),
		array( 'db' => '`cat`.`description`',  			'dt' => 5,	'field' => 'description' /*'formatter' => function( $d, $row ) { return json_encode($row); }*/ ),
		array( 'db' => '`tax`.`name`',  			'dt' => 6,	'field' => 'name'),
		array( 'db' => '`so`.`stock_id`',  			'dt' => 7,	'field' => 'stock_id', 'formatter' => function( $d, $row ) { if(has_user_permission('Edit Inventory', 'Inventory')){ return '<i data-target="#InventoryAddNew" class="material-icons EditInventory" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-inid="'.$row['stock_id'].'" > create </i>' ; } else { return ''; } }),
		array( 'db' => '`so`.`stock_id`',  			'dt' => 8,	'field' => 'stock_id', 'formatter' => function( $d, $row ) { if(has_user_permission('Delete Inventory', 'Inventory')){ return '<i class="material-icons DeleteInventory" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-inid="'.$d.'" > delete_forever </i>' ; } else { return ''; } }),
	);

	$joinQuery = "FROM `{$table}` AS `so` LEFT JOIN ".FA_PREF."item_tax_types AS tax ON so.tax_type_id = tax.id LEFT JOIN ".FA_PREF."stock_category AS cat ON cat.category_id = so.category_id";  
	$extraWhere = ''; 	
	$wigepa_sources =Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '', false ) ;
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}

if(isset($_GET['saleskittable']) && $_GET['saleskittable'] == 'yes'){
	// SELECT i.item_code, i.description, c.description, count(*)>1 as kit,
	// 		 i.inactive, if(count(*)>1, '0', s.editable) as editable
	// 		FROM 0_stock_master s, 0_item_codes i LEFT JOIN
	// 		0_stock_category c
	// 		ON i.category_id=c.category_id
	// 		WHERE i.stock_id=s.stock_id
	// 	AND !i.is_foreign AND i.item_code!=i.stock_id
	// AND !i.inactive AND !s.inactive AND !s.no_sale
	// GROUP BY i.item_code;

	$table = FA_PREF. 'stock_master';
	$primaryKey = 'stock_id';
	$columns = array(
		array('db' => '`io`.`id`', 	'dt' =>0, 	'field' => 'id'),
		array( 'db' => '`io`.`description`', 	'dt' => 1,	'field' => 'description','formatter' => function( $d, $row ) { return $row[1]; }),
		array('db' => '`io`.`item_code`',	'dt' =>2,	'field' => 'item_code'),
		array( 'db' => '`cat`.`description`',  			'dt' => 3,	'field' => 'description' /*'formatter' => function( $d, $row ) { return json_encode($row); }*/ ),
		array('db' => '`io`.`item_code`',  	'dt' =>4,	'field' => 'item_code', 'formatter' => function( $d, $row ) { if(has_user_permission('Edit Inventory', 'Inventory')){ return '<i data-target="#ViewkitInfo" class="material-icons ViewSaleskit" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-edid="'.$d.'" > pageview </i>' ; } else { return ''; } }),
		array('db' => '`io`.`id`',  	'dt' =>5,	'field' => 'id', 'formatter' => function( $d, $row ) { if(has_user_permission('Edit Inventory', 'Inventory')){ return '<i data-target="#SaleskitEdit" class="material-icons EditSaleskit" style="cursor: pointer; font-weight: 600;text-decoration:none;" data-edid="'.$d.'" > create </i>' ; } else { return ''; } }),
		array('db' => '`io`.`id`',  	'dt' =>6,	'field' => 'id', 'formatter' => function( $d, $row ) { if(has_user_permission('Delete Inventory', 'Inventory')){ return '<i class="material-icons DeleteSaleskit" style="cursor: pointer; font-weight: 600;text-decoration:none;"  data-inid="'.$d.'" > delete_forever </i>' ; } else { return ''; } })
	);
	$joinQuery = "FROM `{$table}` AS `s`, ".FA_PREF."item_codes AS `io` LEFT JOIN  ".FA_PREF."stock_category cat ON io.category_id=cat.category_id";  
	$extraWhere = ' `io`.`stock_id` = `s`.`stock_id` '; //AND `so`.`debtor_no` ='.$debtor_no; 
	$extraWhere .= ' AND !io.is_foreign AND io.item_code!=io.stock_id ';
	$extraWhere .= ' AND !io.inactive AND !s.inactive AND !s.no_sale ';

	$groupBy = ' GROUP BY io.item_code';
	
	$wigepa_sources =Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, $groupBy, false ) ;
	 
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}

function qoh_on_hand($stock_id){
	$quantity = fadb_query("SELECT SUM(qty)  AS Quantity	FROM ".FA_PREF."stock_moves st
   		LEFT JOIN ".FA_PREF."voided v ON st.type=v.type AND st.trans_no=v.id        WHERE ISNULL(v.id)
          AND stock_id=".fadb_escape($stock_id)." AND tran_date <= '".date('Y-m-d')."'");

	if(fadb_num_rows($quantity) > 0 ){
		if($row = fadb_fetch($quantity))
			return $row['Quantity'];
		else
			return 0;
	} else
		return 0;
}


if(isset($_GET['table_plan']) && $_GET['table_plan'] == 'yes'){
	$table = TB_PREF. 'table_plan';
	$primaryKey = 'id';
	$columns = array(
		array('db' =>'company_id', 'dt' => 0, 'field' => 'company_id', 'formatter' => function( $d, $row ) {global  $db_connections; return $db_connections[$row[0]]['name']; }),
		array('db' => 'table_count', 'dt' => 1, 'field' => 'table_count'),
		array( 'db' => 'id',  	'dt' => 2,	'field' => 'id', 'formatter' => function( $d, $row ) { return '<a class="table_actions green"  href="'.get_url('admin').'admin.php?page=table_plan&edit_id='.$row[2].'"  >Edit</a>' ; }),
		array( 'db' => 'id',  	'dt' => 3,	'field' => 'id', 'formatter' => function( $d, $row ) { return '<a class="table_actions red" href="'.get_url('admin').'admin.php?page=table_plan&delete_id='.$row[3].'" >Delete</a>' ; })

		);
		$joinQuery = "" ;//FROM `{$table}` AS `so` ";  
		$extraWhere = ''; 	
		$wigepa_sources =Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '' ) ;
		//$lead_data = $wigepa_sources['data'];
		echo json_encode($wigepa_sources);
}
if(isset($_GET['table_permission']) && $_GET['table_permission'] == 'yes'){
	$table = TB_PREF. 'permission';
	$primaryKey = 'id';

	$columns = array(
		array( 'db' => 'page_id',	'dt' => 0,	'field' => 'page_id', 'formatter' => function( $d, $row ) { return getPageTitle($d); }),
		array('db' => 'page_permit', 'dt' => 1, 'field' => 'page_permit')
		);
	$joinQuery = "" ;//FROM `{$table}` AS `so` ";  
	$extraWhere = ''; 
	$wigepa_sources =Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '' ) ;
	//$lead_data = $wigepa_sources['data'];
	echo json_encode($wigepa_sources);
}
if(isset($_GET['Email_validate'])){
	$sql ="SELECT id FROM ".TB_PREF."crm_persons WHERE email='".$_GET['Email_validate']."' LIMIT 1";
	$debtor_row =  fadb_query($sql, "Can't get email validations");
	if($row = fadb_fetch_row($debtor_row)){
		echo $row[0];
	} else
		echo false;	
}

if(isset($_GET['WritePayment'])){
	echo WritePayment($_POST['trans_no'], $_POST['amount'], $_POST['trans_ref'], $_POST['bank_id']);
}
// SAles kit Program 
//
if(isset($_GET['get_itemredy'])){
	$category = FaGetAll('stock_category', array('inactive' => 0 ));
    $old_emplacement = '';
    $results = array();
	$i = -1;	
	foreach ($category as $array_campaign) {
	    $i++;
	    $results[$i]['id'] = $array_campaign['category_id'];
	    $results[$i]['text'] = $array_campaign['description'];
	    $c = 0;

    	$sql = "SELECT i.item_code as itemCode, i.description as itemDescription, count(*)>1 as kit FROM ".TB_PREF."stock_master s,".TB_PREF."item_codes i LEFT JOIN ".TB_PREF."stock_category c ON i.category_id=c.category_id WHERE i.stock_id=s.stock_id AND c.category_id = ".$array_campaign['category_id']." AND !i.is_foreign AND !i.inactive AND !s.inactive AND !s.no_sale Group BY i.item_code";
		$result = fadb_query($sql, "Cannot Returns data");
		while($row = fadb_fetch_assoc($result)){		
	
	    	$results[$i]['children'][$c]['id'] = $row['itemCode'];
	   	 	$results[$i]['children'][$c]['text'] = $row['itemDescription'];
	    	$c++;
		}

	}

	$results['pagination']["more"] = true;
	echo json_encode($results);
}
if(isset($_GET['get_items'])){
	// $sql = "SELECT stock_id, s.description AS name   FROM ".TB_PREF."stock_master s ";	
	 $sql = "SELECT i.item_code, i.description FROM ".TB_PREF."stock_master s,".TB_PREF."item_codes i WHERE i.stock_id = s.stock_id ";
   
	if(isset($_GET['q']) && $_GET['q'] != '')
		$sql .= " AND i.description LIKE '%".$_GET['q']."%' OR i.stock_id LIKE '%".$_GET['q']."%' ";
	
	$sql .= " AND !i.is_foreign AND !i.inactive AND !s.inactive AND !s.no_sale Group BY i.item_code";
	$sql .=" Limit 10";
	fadb_query("SET NAMES UTF8", '');
	$sales_typ_res= fadb_query($sql, "can't get results");
	$json = [];
	while($row = fadb_fetch($sales_typ_res)){
		// $json[] = ['id'=>$row['stock_id'], 'text'=> _($row["name"])];
		$json[] = ['id'=>$row['item_code'], 'text'=> htmlspecialchars_decode($row["description"])];

	}
	echo json_encode($json);     
}

if(isset($_GET['get_items_only'])){
	$sql ="SELECT stock_id, s.description AS name   FROM ".TB_PREF."stock_master s WHERE s.mb_flag <> 'D' ";	   
	if(isset($_GET['q']) && $_GET['q'] != '')
		$sql .= " AND s.description LIKE '%".$_GET['q']."%' OR stock_id LIKE '%".$_GET['q']."%' ";
	$sql .=" Limit 10";
	fadb_query("SET NAMES UTF8", '');
	$sales_typ_res= fadb_query($sql, "can't get results");
	$json = [];
	while($row = fadb_fetch($sales_typ_res)){
		// $json[] = ['id'=>$row['stock_id'], 'text'=> _($row["name"])]; // _( mus be error)
		$json[] = ['id'=>$row['stock_id'], 'text'=> htmlspecialchars_decode($row["name"])]; // _( mus be error)
			
	}
	echo json_encode($json);     
}

if(isset($_GET['get_customers'])){
	$loc = (isset($_SESSION['pos_details']['pos_location'])? $_SESSION['pos_details']['pos_location'] : 'DEF');
	$sql ="SELECT deb.debtor_no, deb.debtor_ref FROM ".TB_PREF."crm_persons p,".TB_PREF."crm_categories t, ".TB_PREF."crm_contacts r, ".TB_PREF."debtors_master AS deb LEFT JOIN ".TB_PREF."cust_branch AS br ON `deb`.`debtor_no` = `br`.`debtor_no` WHERE br.default_location = ".fadb_escape($loc)." AND r.type=t.type AND r.action=t.action AND r.person_id=p.id AND t.type='customer' AND r.entity_id=deb.debtor_no ";	   
	if(isset($_GET['q']) && $_GET['q'] != '')
		$sql .= " AND (p.phone LIKE '%".$_GET['q']."%' OR p.email LIKE '%".$_GET['q']."%' OR deb.debtor_no LIKE '%".$_GET['q']."%' OR deb.debtor_ref LIKE '%".$_GET['q']."%' OR deb.name LIKE '%".$_GET['q']."%' ) ";
	$sql .=" ORDER BY deb.debtor_no Limit 10";				
		$sales_typ_res= fadb_query($sql, "can't get results");
	$json = [];
	while($row = fadb_fetch($sales_typ_res)){
		// $json[] = ['id'=>$row['debtor_no'], 'text'=> _($row["debtor_ref"])]; // text mayb running problem
		$json[] = ['id'=>$row['debtor_no'], 'text'=> $row["debtor_ref"]];
	}
	echo json_encode($json);     
}

if(isset($_GET["get_customer_details"])){
	$cid = $_POST['cid'];
	$_SESSION['CustomerId']	= $_POST['cid'];
	$sql ="SELECT deb.debtor_no,deb.name,deb.address, debtor_ref, deb.sales_type, deb.payment_terms, stype.tax_included, curr_code, cur.curr_symbol, br.tax_group_id FROM ".TB_PREF."debtors_master as deb, ".TB_PREF."cust_branch as br,  ".TB_PREF."currencies as cur, ".TB_PREF."sales_types as stype WHERE  br.debtor_no=deb.debtor_no AND deb.curr_code = cur.curr_abrev AND stype.id = deb.sales_type AND deb.debtor_no = ".fadb_escape($cid)." ORDER BY debtor_no";
    $sales_typ_res= fadb_query($sql, "can't get results");   	
	// $final = ['details' => []];
	$final = array();
	if($row = fadb_fetch($sales_typ_res)){
		
		$final = array('curr_code' => $row['curr_code'], 'currency' => $row['curr_symbol'], 'sales_type_id' => $row['sales_type'], 'tax_included' => $row['tax_included'], 'id' => $row['debtor_no'], 'payment_terms' => $row['payment_terms'], 'name' => $row['name'], 'address' => $row['address'], 'tax_group_id' => $row['tax_group_id']);
		$_SESSION['currency'] = $row['curr_symbol']; 
		$_SESSION['sales_type_id'] =$row['sales_type']; 
		$_SESSION['tax_included'] =$row['tax_included']; 	
		$_SESSION['payment_terms'] = $row['payment_terms'];	
		if($_SESSION['curr_code'] != $row['curr_code']){
			$_SESSION['old_curr_code']=$row['curr_code']; 
			$final['old_curr_code'] = $row['curr_code'];
		} else
			$row['old_curr_code'] = '';		
		$_SESSION['curr_code'] = $row['curr_code'];
		$_SESSION['CustomerName'] = $row['debtor_ref'];
		$sql2 = "SELECT email, phone FROM ".TB_PREF."crm_persons AS person, ".TB_PREF."crm_contacts AS contact WHERE contact.entity_id=".$row['debtor_no']." AND contact.type='customer' AND contact.person_id=person.id";
		$debtor_row2 =  fadb_query($sql2, "Can't get debtors list");
		if($row2 =  fadb_fetch_assoc($debtor_row2)){
			$final['email'] = $row2['email'];
			$final['phone'] = $row2['phone'];
		}	
		$final['total_amount'] = get_customer_total_amount($row['debtor_no']);
		$final['last_bill']	= get_customer_last_bill($row['debtor_no']);
		$final['favorite_item'] = get_customer_favorite_item($row['debtor_no']);		

	}
	echo json_encode($final);
	
}

if(isset($_GET['GetCustomer'])){
	$cid = $_POST['cid'];
	$_SESSION['CustomerId'] = $_POST['cid'];
	$sql ="SELECT deb.debtor_no,deb.name,deb.address, debtor_ref, deb.sales_type, deb.payment_terms, stype.tax_included, curr_code, cur.curr_symbol, br.tax_group_id FROM ".TB_PREF."debtors_master as deb, ".TB_PREF."cust_branch as br,  ".TB_PREF."currencies as cur, ".TB_PREF."sales_types as stype WHERE  br.debtor_no=deb.debtor_no AND deb.curr_code = cur.curr_abrev AND stype.id = deb.sales_type AND deb.debtor_no = ".fadb_escape($cid)." ORDER BY debtor_no";
    $sales_typ_res= fadb_query($sql, "can't get results");   	
	$final = array();
	if($row = fadb_fetch($sales_typ_res)){
		$final = array('curr_code' => $row['curr_code'], 'currency' => $row['curr_symbol'], 'sales_type_id' => $row['sales_type'], 'tax_included' => $row['tax_included'], 'id' => $row['debtor_no'], 'payment_terms' => $row['payment_terms'], 'name' => $row['name'], 'address' => $row['address'], 'tax_group_id' => $row['tax_group_id']);
		$_SESSION['currency'] = $row['curr_symbol']; 
		$_SESSION['sales_type_id'] =$row['sales_type']; 
		$_SESSION['tax_included'] =$row['tax_included']; 	
		$_SESSION['payment_terms'] = $row['payment_terms'];	
		if($_SESSION['curr_code'] != $row['curr_code']){
			$_SESSION['old_curr_code']=$row['curr_code']; 
			$final['old_curr_code'] = $row['curr_code'];
		} else
			$row['old_curr_code'] = '';		
		$_SESSION['curr_code'] = $row['curr_code'];
		$_SESSION['CustomerName'] = $row['debtor_ref'];
	}
	echo json_encode($final);
}
if(isset($_GET['AddItemToCart']) && $_GET['AddItemToCart'] == 'Yes') {
	echo AddItemToCart($_POST['CustomerId'], $_POST['currency'], $_POST['tax_group_id'], $_POST['stock_id'], $_POST['price'], $_POST['qty'], $_POST['line_amount'], $_POST['total_q'], $_POST['total_am'], $_POST['step'], $_POST['discount'], $_POST['date'], (isset($_POST['batch_no']) ? $_POST['batch_no'] : ''), (isset($_POST['exp_date']) ? $_POST['exp_date'] : '0000-00-00') );
}

if(isset($_GET['AddInventoryToCart']) && $_GET['AddInventoryToCart'] == 'yes'){
	echo AddInventoryToCart( $_POST['stock_id'], $_POST['price'], $_POST['qty'], $_POST['line_amount'],$_POST['name'] );
}

if(isset($_GET['Get_Item_From_ItemCode']) && $_GET['Get_Item_From_ItemCode'] == 'yes'){
	$sql = FAGetRow('stock_master', array('stock_id' =>$_POST['item_id']));	
	echo  json_encode($sql);
}

if(isset($_GET['submit_sales_kit']) && $_GET['submit_sales_kit'] == 'yes'){
	$kit_code = $_POST['kit_code'];
	if($_POST['kit_code']){
		$result =  check_item_in_kit($kit_code);
		$total_row = fadb_num_rows($result);
		if($total_row > 0){
			echo json_encode(array('msg' => 'Item Already Exits', 'data' => 0));
		}else{
			echo add_item_code($_POST['kit_code'], $_POST['component_sel'], $_POST['kit_description'], $_POST['kit_category_id'], $_POST['qty'], $foreign=0);
			}
	}
}

if(isset($_GET['get_items_from_ItemCode']) && $_GET['get_items_from_ItemCode'] == 'yes'){
	$sql = FAGetRow('item_codes', array('item_code' => $_POST['item_code']));
	echo json_encode($sql);
}

if(isset($_GET['NewAdjustment']) && $_GET['NewAdjustment'] == 'yes'){
	unset($_SESSION['Inv_cart_item']);
	echo 1;
}

if(isset($_GET['RemoveInvFromCart']) && $_GET['RemoveInvFromCart'] >= 0 ){
	
	$price_dec = user_price_dec();
	//var_dump($_SESSION['Inv_cart_item']);
	if (is_array($_SESSION['Inv_cart_item'])) {		
		$cart_item = $_SESSION['Inv_cart_item'];	
		$session = $_GET['RemoveInvFromCart'];	
		if(isset($cart_item[$session])){			
			unset($cart_item[$session]);	
			$tl_price = 0;       
			foreach ($cart_item as $k => $value) {       
			   $tl_price += $value["line_total"];       
			}    
			
			$grand_total  = number_format(floatval($tl_price), $price_dec, '.', '');
			$_SESSION['Inv_cart_item'] = $cart_item;
			echo json_encode(array('last_id' => $session, 'grand_total' => $grand_total ));
		}
	}		
}
function EditInventoryToCart( $session, $price, $qty, $line_amount,$description, $tbpref =null ) {
	
	$price_dec = user_price_dec();
	$line_total = number_format(floatval($line_amount), $price_dec,'.', '');
	$total_am = number_format(floatval($price*$qty), $price_dec, '.', '');
	
	if (isset($_SESSION['Inv_cart_item'])) {
		$found=true;
		$cart_item = $_SESSION['Inv_cart_item'];		
		if(isset($cart_item[$session])){
			$cart_item[$session]['name'] = $description;
			$cart_item[$session]['qty'] = $qty;
			$cart_item[$session]['price'] = $price;
			$cart_item[$session]['line_total'] =  $qty *$price;						
			$_SESSION['Inv_cart_item'] = $cart_item;
			
			$tl_price = 0;       
			foreach ($cart_item as $k => $value) {       
			   $tl_price += $value["line_total"];       
			}   			
			$grand_total  = number_format(floatval($tl_price), $price_dec, '.', '');			
			return json_encode(array( 'stock_id' => $cart_item[$session]['stock_id'], 'cart_count' => count($cart_item), 'name' => $description, 'price' => number_format($price, $price_dec), 'qty' => $cart_item[$session]['qty'], 'unit' => $cart_item[$session]['unit'], 'line_total' => $cart_item[$session]['line_total'], 'last_id' => $session, 'exist' => 'yes', 'grand_total' => $grand_total ));
		}
	}		
}

function check_item_in_kit($kit_code){
	$sql="SELECT DISTINCT kit.*, item.units, comp.description as comp_name 
		FROM "
		.TB_PREF."item_codes kit,"
		.TB_PREF."item_codes comp
		LEFT JOIN "
		.TB_PREF."stock_master item
		ON 
			item.stock_id=comp.item_code
		WHERE
			kit.stock_id=comp.item_code
			AND kit.item_code=".fadb_escape($kit_code);

	$result = fadb_query($sql,"item kit could not be retrieved");

	return $result;
}


function AddInventoryToCart( $stock_id, $price, $qty,  $line_total, $desc=''){
	
	$price_dec = user_price_dec();
	fadb_query("SET NAMES UTF8", 'Cant execute');
	//echo number_format($price, $price_dec).'-'.$price_dec.'--'.$price;
	//$sql = "SELECT * FROM ".TB_PREF."stock_master WHERE stock_id = ".fadb_escape($stock_id);
	$stock_details = FAGetRow('stock_master', array('stock_id' => $stock_id));
	
	$line_total = number_format(floatval($line_total), $price_dec,'.', '');
	$total_am = number_format(floatval($price*$qty), $price_dec, '.', '');
	if($desc== '')
		$desc= $stock_details['description'];
	$itemArray = array(
		'stock_id' => $stock_id,
		'name' => $desc, 
		'qty' => $qty, 
		'unit' => $stock_details['units'],
		'price' => $price, 
		'standard_cost' => $stock_details['material_cost'], 				
		'line_total' => $line_total 
	);
	$exist = 'no';
	if (isset($_SESSION['Inv_cart_item'])) {
		$found=true;
		$cart_item = $_SESSION['Inv_cart_item'];
		foreach($cart_item as $keys => $values){
			if($cart_item[$keys]['stock_id'] == $stock_id)  {
			  //return json_encode(array('exist' => 'yes'));

				$cart_item[$keys]['qty'] = $cart_item[$keys]['qty'] + $qty;
			    $cart_item[$keys]['amount'] = $cart_item[$keys]['qty'] *($price);
			     	     
			    $cart_item[$keys]['line_total'] = $cart_item[$keys]['amount'];
			    $final_qty = $cart_item[$keys]['qty'];
			    $final_amount = number_format(floatval($cart_item[$keys]['amount']), $price_dec, '.', '');
			    $final_line_total = number_format(floatval($cart_item[$keys]['line_total']), $price_dec, '.', ''); 
			    $found = false;
				$exist = 'yes';
				$last_id = $keys;
		    }
		}
		if($found) {	    
	    $cart_item[] = $itemArray;
	    $final_qty = $qty;
		$final_amount = number_format(floatval($total_am), $price_dec, '.', '');
		$final_line_total = number_format(floatval($line_total), $price_dec, '.', '');
	   }
	} else {
		$cart_item[] = $itemArray;
		$final_qty = $qty;
		$final_amount = number_format(floatval($total_am), $price_dec, '.', '');		
		$final_line_total = number_format(floatval($line_total), $price_dec, '.', '');;
	}
	$_SESSION['Inv_cart_item'] = $cart_item;
	end($cart_item);
    if($exist == 'no')
	    $last_id=key($cart_item);
	
	$tl_price = 0;       
    foreach ($cart_item as $k => $value) {       
       $tl_price += $value["line_total"];       
    }       
    $grand_total  = number_format(floatval($tl_price), $price_dec, '.', '');
    $final_echo = array( 'stock_id' => $stock_id, 'cart_count' => count($cart_item), 'name' => $desc,  'price' => number_format($price, $price_dec), 'qty' => $final_qty, 'unit' => $stock_details['units'], 'line_total' => $final_line_total, 'last_id' => $last_id, 'grand_total' => $grand_total);
    if($exist == 'yes')
    	$final_echo['exist'] = 'yes';
	return json_encode($final_echo);
}

if(isset($_GET['SubmitInvAdjustment']) && $_GET['SubmitInvAdjustment'] == 'yes') {
	echo json_encode(WriteInvAdjustment());
}

function WriteInvAdjustment(){
	global $Refs;
	
	$items = $_SESSION['Inv_cart_item'];
	$fiscal_year_id = get_company_details('f_year');
	$fa_user_id = $current_user['fa_user_id'];
	begin_transaction();	
	$adj_id = get_next_trans_no(ST_INVADJUST);
	$credit_ref = $Refs->get_next(ST_INVADJUST);
	$date  = date('Y-m-d', strtotime($_POST['date']));
	foreach($items as $line) {	
		$stk_row = FAGetRow('stock_master', array('stock_id' => $line['stock_id']));
		
		if ($stk_row['mb_flag'] == 'D')  {
			return false;
		}
		
		//update_average_material_cost(null, $line['stock_id'], $standard_cost, $quantity, $date_, false, $stk_row, $tbpref);
		
		if ($stk_row['mb_flag'] == 'F') {
			$sql = "UPDATE ".TB_PREF."stock_master SET inactive=1	WHERE stock_id=".fadb_escape($line['stock_id']);
			fadb_query($sql); //,"The inactive flag for the fixed asset could not be updated");
		}
		
		FAInsert('stock_moves', array('trans_no' => $adj_id, 'type' => ST_INVADJUST, 'stock_id' => $line['stock_id'], 'loc_code' => $_POST['loc_code'], 'tran_date' => $date, 'price' => $line['price'], 'reference' => $credit_ref, 'qty' => $line['qty'], 'standard_cost' => $line['price']));
				
		$inv_value = $line['price'] * $line['qty'];
		$adj_value = $line['price'] * -($line['qty']);

		if ($stk_row['mb_flag'] == 'F') {	// get the initial value of the fixed assset.
			//$row = get_fixed_asset_move($line['stock_id'], ST_SUPPRECEIVE);
			//$inv_value = $row['price'] * $line['qty'];
			//$adj_value = (-($row['price']) + $line['price']) * $line['qty'];
		}
		
		if ($line['price'] > 0 || $stk_row['mb_flag'] == 'F' ){
			add_gl_trans_std_cost(ST_INVADJUST, $adj_id, $date,$stk_row['adjustment_account'], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stk_row['dimension_id']), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stk_row['dimension2_id']), $_POST['comments'], $adj_value, null, null, '' );
			
			add_gl_trans_std_cost(ST_INVADJUST, $adj_id, $date, $stk_row['inventory_account'], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stk_row['dimension_id']), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stk_row['dimension2_id']), $_POST['comments'], $inv_value, null, null, '' );
		}
	
		if ($stk_row['mb_flag'] == 'F') {// Additional gl entry for fixed asset.
			//$grn_act = get_company_details('default_loss_on_asset_disposal_act', $tbpref);
			//add_gl_trans_std_cost(ST_INVADJUST, $adj_id, $date_, $grn_act, 0, 0, $memo_, ($line['price'] * -($line['qty'])));
		}
	}	
	FAInsert('refs', array('id' => $adj_id, 'type' => ST_INVADJUST, 'reference' => $credit_ref));
	if(trim($_POST['comments']) != '' )
		FAInsert('comments', array('type' => ST_INVADJUST, 'id' => $adj_id, 'memo_' => $_POST['comments'], 'date_' => $date));
	FAInsert('audit_trail', array('type' => ST_INVADJUST, 'trans_no' => $adj_id, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date, 'gl_seq' => 0 ));
	
	commit_transaction();
	unset($_SESSION['Inv_cart_item']);
	if($adj_id > 0 )
		return array('id' => $adj_id, 'ref' => $credit_ref);
	else {
		
		return false;
	}
}

// Recalculate Tax and item prices based on the new customer
if(isset($_GET['RecaculateTaxandPrices'])) {

	if(is_array($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){
		foreach($_SESSION['cart_item'] as $keys => $item ) {
			$price = get_price ($item['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id']);
			if($price > 0 ){
				$_SESSION["cart_item"][$keys]['amount'] = $_SESSION["cart_item"][$keys]['qty'] *( $price);
				$_SESSION["cart_item"][$keys]['price'] = $price;
				 if($discount > 0 )
					 $_SESSION["cart_item"][$keys]['discount'] = $discount;		     
			     $_SESSION["cart_item"][$keys]['line_total'] = $_SESSION["cart_item"][$keys]['amount']-($_SESSION["cart_item"][$keys]['amount']* $_SESSION["cart_item"][$keys]['discount']);
			}
			
		}

		$_SESSION['subtotal_price'] = 0;       
	    foreach ($_SESSION['cart_item'] as $k => $value) {       
	       $_SESSION['subtotal_price'] += $value["line_total"];       
	    }    
	    $tax_val = fa_get_taxes($_SESSION);
	    $_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');   
	 //    if($_SESSION['tax_included'] == 1) {		
	 //    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
		// 	$f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
		// 	$tl_price = $_SESSION['subtotal_price'] + $_SESSION['tax_val'];
		// } else {
		// 	$tl_price = $f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
		// }
	    if($_SESSION['tax_included'] == 1)
	    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
	    $f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
	    $tl_price = $_SESSION['subtotal_price'] + $_SESSION['tax_val'];
	    $_SESSION['grand_total']  = number_format(floatval($tl_price), $price_dec, '.', '');
	    $_SESSION['subtotal_price'] = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');

	    $cart_items = [];
	    foreach($_SESSION['cart_item'] as $key => $single){
	    	$single['price'] = number_format(floatval($single['price']), $price_dec, '.', '');
	    	$single['amount'] = number_format(floatval($single['amount']), $price_dec, '.', '');
	    	$single['discount'] = number_format(floatval($single['discount']), $price_dec, '.', '');
	    	$single['line_total'] = number_format(floatval($single['line_total']), $price_dec, '.', '');
	    	$single['last_id'] = $key;
	    	
	    	$cart_items[$key] = $single;
	    }
	    echo json_encode(['details' => $cart_items, 'grand_total' => number_format(floatval($_SESSION['grand_total']), $price_dec, '.', ''), 'subtotal_price' => number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', ''), 'tax_val' => number_format(floatval($_SESSION['tax_val']), $price_dec, '.', ''),'cart_count' => (is_array($_SESSION['cart_item']) ? count($_SESSION['cart_item']) : 0 )]);
	} else 
		echo false;
}

function Get_stock_quantity($stock_id){
		$sql = "SELECT sum(round(s.qty, 2)) as qty FROM ".TB_PREF."stock_master as m LEFT JOIN ".TB_PREF."stock_moves as s ON m.stock_id = s.stock_id where m.stock_id = ".fadb_escape($stock_id);
	$price_typ_res= fadb_query($sql, "can't get results");
	//if($price_typ_res)
	if(fadb_num_rows($price_typ_res) > 0 ){
		$res = fadb_fetch($price_typ_res);
		//var_dump($res);
		return $res['qty'];
	}
	else
		return 0;
	
}
if(isset($_GET['barcode_item'])){
	$stock_id = $_GET['barcode_item'];
	$data = check_item_in_kit($stock_id);
	if(fadb_num_rows($data)){
		$price = get_kit_price($stock_id, $_POST['currency_code'],$_POST['sales_type_id']);
		echo AddItemToCart($_POST['CustomerId'], $_POST['currency'], $_POST['tax_group_id'], $stock_id, $price, 1, $price, 0, $price, 1, 0, $_POST['date'] );
	}else{
		echo json_encode(array('msg' => 'No data'));
	}
}
function AddItemToCart($CustomerId, $currency, $tax_group_id, $stock_id, $price, $qty,  $line_total, $total_q, $total_am, $step = 0, $discount= 0, $date=null, $batch_no='', $exp_date='0000-00-00'){
	$price_dec = user_price_dec();
	if($date == null)
		$date = date('Y-m-d');
	fadb_query("SET NAMES UTF8", '');
	//$stock_details = FAGetRow('stock_master', array('stock_id' => $stock_id));
	$final_result = ['details' => []];

	$kit = get_item_kit($stock_id);
	//echo fadb_num_rows($kit);
	if(fadb_num_rows($kit) > 1)
		$price_vary = true;
	else
		$price_vary = false;

	while($stock_details = fadb_fetch($kit)) {
		//echo $stock_details['stock_id'].'-'.$stock_id;

		if($step == 1){
			$discount = round(($discount / 100), $price_dec);
		}else{
			$discount = round($discount, $price_dec);
		}	
		$line_total = number_format(floatval($line_total), $price_dec,'.', '');
		//$total_am = number_format(floatval($total_am), $price_dec, '.', '');
		$_SESSION['CustomerId'] = $CustomerId;
		$_SESSION['currency'] = $currency;
		if(!isset($_SESSION['currency']) || $_SESSION['CustomerId'] != $CustomerId ){
			$currency_code = FAGetSingleValue('debtors_master','curr_code', array('debtor_no'=>$CustomerId));
			$_SESSION['currency'] = FAGetSingleValue('currencies','curr_symbol', array('curr_abrev'=> $currency_code));
		}
		$_SESSION['tax_group_id'] = $tax_group_id;
		$_SESSION['date'] = $date;
		//	$_SESSION['tax_included'] = null;
		//echo (is_numeric((float)$total_q) ? $total_q : Get_stock_quantity($stock_details['stock_id']));
		$price_calculated = ($price_vary == true ? get_price($stock_details['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id']) : $price); 
		
		
		$itemArray = array(
			'stock_id' => $stock_details['stock_id'],
			'name' => $stock_details['comp_name'], 
			'stock_quantity' => (is_numeric((float)$total_q) && $total_q != 0  ? $total_q : Get_stock_quantity($stock_details['stock_id'])),
			'qty' => $qty*$stock_details['quantity'], 
			'price' => $price_calculated, 
			'standard_cost' => $stock_details['material_cost'], 
			'amount' => ($qty*$stock_details['quantity'])*$price_calculated, 
			'discount' => $discount,
			'batch_no' => $batch_no,
			'exp_date' => $exp_date,
			'line_total' => ($qty*$stock_details['quantity'])*$price_calculated 
		);
		$exist = 'no';
		if(isset($_SESSION["cart_item"])){
			$found=true;
			foreach($_SESSION["cart_item"] as $keys => $values){
				if($_SESSION["cart_item"][$keys]['stock_id'] == $stock_details['stock_id'] && ($batch_no == '' || $_SESSION["cart_item"][$keys]['batch_no'] == $batch_no)){		     
			     $_SESSION["cart_item"][$keys]['qty'] = $_SESSION["cart_item"][$keys]['qty'] + $qty*$stock_details['quantity'];
			     $_SESSION["cart_item"][$keys]['amount'] = $_SESSION["cart_item"][$keys]['qty'] *( $_SESSION["cart_item"][$keys]['price']);
			     if($discount > 0 )
					 $_SESSION["cart_item"][$keys]['discount'] = $discount;		     
			     $_SESSION["cart_item"][$keys]['line_total'] = $_SESSION["cart_item"][$keys]['amount'] -($_SESSION["cart_item"][$keys]['amount']* $_SESSION["cart_item"][$keys]['discount']);
			    // $final_qty = $_SESSION["cart_item"][$keys]['qty'];
			     $final_amount = number_format(floatval($_SESSION["cart_item"][$keys]['amount']), $price_dec, '.', '');
			     $final_discount = number_format(floatval($_SESSION["cart_item"][$keys]['discount']), $price_dec, '.', '');
			     $final_line_total = number_format(floatval($_SESSION["cart_item"][$keys]['line_total']), $price_dec, '.', ''); 
			     $found = false;
			     if($batch_no != ''){
			     	if($_SESSION["cart_item"][$keys]['batch_no'] == $batch_no){
			     		$stock_details['exist'] = $exist = 'yes';
			     	}
			     } else 
				 	$stock_details['exist'] = $exist = 'yes';
				 $stock_details['key'] = $last_id = $keys;
				 // echo $_SESSION["cart_item"][$keys]['batch_no'].'__'.$batch_no;
				 // var_dump($itemArray);
			    }
			}
			if($found) {	    
			    $_SESSION["cart_item"][] = $itemArray;
			   // $final_qty = $qty;
				$final_amount = number_format(floatval($total_am), $price_dec, '.', '');
				$final_discount = $discount;
				$final_line_total = number_format(floatval($line_total), $price_dec, '.', '');
			}
		} else {
				$_SESSION["cart_item"][] = $itemArray;
				//$final_qty = $qty;
				$final_amount = number_format(floatval($total_am), $price_dec, '.', '');
				$final_discount = $discount;
				$final_line_total = number_format(floatval($line_total), $price_dec, '.', '');;
			}

		$_SESSION['trans_no'] =  0;
		$_SESSION['trans_type'] =  ST_SALESINVOICE;
		end($_SESSION["cart_item"]);
	    if($exist == 'no')
		    $stock_details['key'] = $last_id=key($_SESSION["cart_item"]);
		$_SESSION['subtotal_price'] = 0;       
	    foreach ($_SESSION['cart_item'] as $k => $value) {       
	       $_SESSION['subtotal_price'] += $value["line_total"];       
	    }   
    
	    $tax_val = fa_get_taxes($_SESSION);
	    $_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');   
	    if($_SESSION['tax_included'] == 1)
	    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
	    $f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
	    $tl_price = $f_subtotal_price + $_SESSION['tax_val'];
	    $_SESSION['grand_total']  = number_format(floatval($tl_price), $price_dec, '.', '');
	    $_SESSION['subtotal_price'] = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
	    $final_cart = array('stock_id' => $stock_details['stock_id'], 'name' => $stock_details['comp_name'], 'price' => number_format2($itemArray['price'], $price_dec), 'stock_quantity' => $itemArray['stock_quantity'], 'qty' => $_SESSION['cart_item'][$stock_details['key']]['qty'], 'amount' => number_format2($_SESSION['cart_item'][$stock_details['key']]['amount'], $price_dec), 'discount' => $final_discount*100, 'line_total' => number_format2($_SESSION['cart_item'][$stock_details['key']]['line_total'], $price_dec), 'last_id' => $stock_details['key'], 'exist' => $stock_details['exist']); 
	    if($exp_date != '0000-00-00')
	    	$final_cart['exp_date'] = $_SESSION['cart_item'][$stock_details['key']]['exp_date']; 
	    else
	    	$final_cart['exp_date'] = '';
	    if($batch_no != ''){
			$final_cart['batch_no'] = $_SESSION['cart_item'][$stock_details['key']]['batch_no'];
	    } else 
	    	$final_cart['batch_no'] = '';

		$final_result['details'][] = $final_cart;
	}
	$final_result['subtotal_price'] = $f_subtotal_price;
	$final_result['tax_val'] = $tax_val; 
	$final_result['grand_total'] = $_SESSION['grand_total'];
	$final_result['currency'] = trim($_SESSION['currency']);
	$final_result['cart_count'] = count($_SESSION['cart_item']);
	return json_encode($final_result);
}

if(isset($_GET['UpdateCartQuantity'])){	
	$price_dec = user_price_dec();
	$keys = $_POST['cart_id'];
	$qty = $_POST['qty'];
	if(isset($_SESSION["cart_item"])){			
		if($_SESSION["cart_item"][$keys])  {		     
		     $_SESSION["cart_item"][$keys]['qty'] = $qty;
		     $_SESSION["cart_item"][$keys]['amount'] = $_SESSION["cart_item"][$keys]['qty'] *( $_SESSION["cart_item"][$keys]['price']);
		     if($discount > 0 )
				 $_SESSION["cart_item"][$keys]['discount'] = $discount;		     
		     $_SESSION["cart_item"][$keys]['line_total'] = $_SESSION["cart_item"][$keys]['amount'] -($_SESSION["cart_item"][$keys]['amount']* $_SESSION["cart_item"][$keys]['discount']);
		     $final_qty = $_SESSION["cart_item"][$keys]['qty'];
		     $final_amount = number_format(floatval($_SESSION["cart_item"][$keys]['amount']), $price_dec, '.', '');
		     $final_discount = number_format(floatval($_SESSION["cart_item"][$keys]['discount']), $price_dec, '.', '');
		     $final_line_total = number_format(floatval($_SESSION["cart_item"][$keys]['line_total']), $price_dec, '.', ''); 
		     $last_id = $keys;
		     $_SESSION['subtotal_price'] = 0;       
		    foreach ($_SESSION['cart_item'] as $k => $value) {       
		       $_SESSION['subtotal_price'] += $value["line_total"];       
		    }    
		    $tax_val = fa_get_taxes($_SESSION);
		    $_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');   
		    if($_SESSION['tax_included'] == 1)
		    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
		    $f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
		    $tl_price = $f_subtotal_price + $_SESSION['tax_val'];
		    $_SESSION['grand_total']  = number_format(floatval($tl_price), $price_dec, '.', '');
		    $_SESSION['subtotal_price'] = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
			$cart_count = count($_SESSION['cart_item']);
			echo json_encode(array('qty' => $final_qty, 'amount' => $final_amount, 'discount' => $final_discount*100, 'line_total' => $final_line_total, 'last_id' => $last_id, 'exist' => 'yes','subtotal_price' => $f_subtotal_price, 'tax_val' => $tax_val, 'grand_total' => $_SESSION['grand_total'], 'currency' => trim($_SESSION['currency']), 'cart_count' => $cart_count));
		}	
	}
}
if(isset($_GET['paynow']) && $_GET['paynow'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0 ){
		// $_SESSION['payment_terms'] = $_POST['payment_terms'];
		$_SESSION['pmt_type'] = $_POST['pmt_type'];
		$_SESSION['trans_ref'] = $_POST['trans_ref'];
		if(isset($_SESSION['order_id']) > 0)
		{
			$_SESSION['grand_total'] = $_POST['user_paid'];
		}
		$id = write();
		UnsetCart();
		$next_ref = $Refs->get_next(ST_SALESINVOICE);	
		if($pusher_keys['allow_pusher'] == 1){
			$pusher->trigger('billing-channel', 'billing_payment', array('msg' => 'Payment Complete', 'id' => $id, 'newRef' => $next_ref));
		}else{
			echo json_encode(array('id' => $id, 'newRef' => $next_ref, 'msg'=> 'Payment Complete'));
		}
	}
}

//settlebill_now
if(isset($_GET['settlebill_now']) && $_GET['settlebill_now'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0 ){
		$_SESSION['payment_terms'] = $_POST['payment_terms'];
		$_SESSION['trans_ref'] = $_POST['trans_ref'];
		if($_POST['user_paid'] == $_SESSION['grand_total']){
			$_SESSION['pmt_type'] = 'cash';
		}else if($_POST['card_paid'] == $_SESSION['grand_total']){
			$_SESSION['pmt_type'] = 'card';
		}
		if($_POST['status'] == 'multiple'){
			$_SESSION['pmt_type'] = 'multiple';
		}

		$id = write();
		UnsetCart();

		echo json_encode(array('id' => $id, 'msg' => 'Payment completed'));
		
	}
}
if(isset($_GET['addBankamount']) && $_GET['addBankamount'] == 'Yes'){
	$itemArray = array('bank_id' => $_POST['bank_id'], 'trans_ref' => $_POST['trans_ref'], 'cashpaid' => $_POST['cashpaid']);
	$_SESSION["bankpay"][] = $itemArray;
	echo json_encode('added');
}
if(isset($_GET['paymentnow']) && $_GET['paymentnow'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){
		// $_SESSION['payment_terms'] = $_POST['payment_terms'];
		$_SESSION['pmt_type'] = $_POST['pmt_type'];
		$_SESSION['trans_ref'] = $_POST['trans_ref'];
		$id = save_invoice_from_delivery();
		UnsetCart();
		echo json_encode(array('id' => $id, 'msg'=> 'Payment Completed Successfully'));
	}
}
if(isset($_GET['delivarypayment']) && $_GET['delivarypayment'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){
		$_SESSION['payment_terms'] = $_POST['payment_terms'];
		$_SESSION['pmt_type'] = $_POST['pmt_type'];
		$_SESSION['trans_ref'] = $_POST['trans_ref'];
		$_SESSION['deliveryman'] = $_POST['userid']; 
		$id = save_invoice_from_deliveryman();
		UnsetCart();
		$batch = array();
		$batch[] = array('channel' => 'channel-3', 'name' => 'payment_done', 'data' => array( 'msg' => 'Payment done with following information: Delivery man '.$id['deliveryman'].' Payment Type: '.$id['payment_type'].' .Total amount'.$id['amount']));
		$batch[] = array('channel' => 'channel-4', 'name' => 'event-'.$_SESSION['deliveryman'], 'data' => array('message' => 'Delivery Completed', 'id' => $_SESSION['deliveryman']));
		$pusher->triggerBatch($batch);
		
	}
}


if(isset($_GET['WriteReturn']) && $_GET['WriteReturn'] == 1){
	echo Kvcodes_Add_Sales_Return($_POST['trans_no'], $_POST['amt'], $_POST['details']);
}

if(isset($_GET['GetInvoice']) && $_GET['GetInvoice'] == 'yes'){
	$price_dec = user_price_dec();
	$invdetails = Kvcodes_get_customer_trans($_GET['trans_no'], 10);
	$invdetails['balance'] = round(($invdetails['Total']-$invdetails['alloc']), $price_dec);
	$invdetails['curr_symbol'] = FAGetSingleValue('currencies','curr_symbol', array('curr_abrev'=> $invdetails['curr_code']));
	if(isset($_GET['return'])){
		$invdetails['tran_date'] = date('d-m-Y', strtotime($invdetails['tran_date']));
		$line_items = Kvcodes_get_customer_trans_details(10, $_GET['trans_no']);
		$trans_details = [];
		
		while ($myrow_=fadb_fetch($line_items)){ 
			$trans_details[] = $myrow_;
		}
		
		$Kit_Net = 0;
		$current_kit = '';
		$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
		foreach($trans_details as $key => $myrow2) {
			if($non_detailed_sales_kit && $myrow2['kit'] != ''){
				if($current_kit == '')
	    			$current_kit = $myrow2['kit'];
	    		$sign = 1;		
				if($current_kit == $myrow2['kit']){

					$Kit_Net += round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),   user_price_dec());
					if($myrow2['kit'] == $trans_details[$key+1]['kit'])
						continue;
				} else
					$current_kit = '';
					
				$myrow2['unit_price'] = $Kit_Net; 
				$Kit_Net = 0;
				$item_detail = FAGetRow('item_codes', ['item_code' => $myrow2['kit'], 'stock_id' => $myrow2['stock_id']]);
				$myrow2['description'] = $item_detail['description'];
					//echo $myrow2['quantity'].'_'.$item_detail['quantity'];
				$myrow2['stock_id'] = $myrow2['kit'];

				$myrow2['quantity'] = number_format2($myrow2['quantity']/$item_detail['quantity'], get_qty_dec($myrow2['kit']));
				$myrow2['unit_price'] = round2($myrow2['unit_price']/$myrow2['quantity'],   user_price_dec());
			}	

			$invdetails['line_items'][]= $myrow2;	
		}

		$invdetails['kv_batch'] = get_company_details('kv_batch');
		$invdetails['kv_exp_date'] = get_company_details('kv_exp_date');
		$invdetails['dec'] = $price_dec;
	}
	echo json_encode($invdetails);
}

if(isset($_GET['PrepareReport']) && $_GET['PrepareReport'] == 'yes'){
//	include(ABSPATH."/includes/reporting/pdf_report.inc");

	get_text_init();
	if(isset($_GET['send_mail']) && $_GET['send_mail'] == 'yes'){
		$subject =$_POST['subject'];
		$email = $_POST['email'];
		$message = $_POST['message'];
		$attachment = array( $_POST['actual_name'] => $_POST['full_path']);
		echo kv_mail($email, $subject, $message, "html", $attachment);
		exit;
	} else {	
		//if(isset($current_user['pdf_template']) &&$current_user['pdf_template'] != '')
			$path = ABSPATH.'/includes/reporting/rep/';
		//else 
		//	$path = dirname(__FILE__) ."/reporting/";
		if(isset($_GET['rep']) && $_GET['rep'] == '113')
			$rep_file = $path."rep113.php"; 
		elseif(isset($_GET['rep']) && $_GET['rep'] == '114')
			$rep_file = $path."rep114.php"; 
		elseif(isset($_GET['rep']) && $_GET['rep'] == '110')
			$rep_file = $path. "rep110.php"; 
		else
			$rep_file = $path."rep107.php"; 
		if(file_exists($rep_file))
			require_once($rep_file);			
	}
}

if(isset($_GET['PreparePosReport']) && $_GET['PreparePosReport'] == 'yes'){
	//include(ABSPATH."/includes/reporting/pdf_report.inc");
	get_text_init();

	$path = ABSPATH.'/includes/reporting/kot/';

	if(isset($_GET['Rep']) && $_GET['Rep'] == 114)
			$rep_file = $path."rep114.php"; 
	elseif(isset($_GET['Rep']) && $_GET['Rep'] == 110)
			$rep_file = $path."rep110.php"; 
	else
		$rep_file = ABSPATH.'/includes/reporting/rep/rep107.php'; 
	
		if(file_exists($rep_file))
			require_once($rep_file);			
	
}
if(isset($_GET['RemoveItemFromCart']) && $_GET['RemoveItemFromCart'] == 'Yes') {
	$cart_id =  $_POST['cart_id'];
	$total_amt=0;
	if(!empty($_SESSION["cart_item"][$cart_id])) {
		unset($_SESSION["cart_item"][$cart_id]);		
		foreach($_SESSION["cart_item"] as $k => $v) {
			$total_amt += $v['line_total'];
		}
	}
	$_SESSION['subtotal_price'] = $total_amt;
	$tax_val = fa_get_taxes($_SESSION);
	$_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.','');
	 if($_SESSION['tax_included'] == 1)
    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
	$_SESSION['grand_total'] = number_format(floatval($total_amt),$price_dec, '.','');
	echo json_encode(array('currency' => $_SESSION['currency'], 'cart_count' => count($_SESSION['cart_item']), 'last_id' => $cart_id, 'name' => $name, 'subtotal_price' => $_SESSION['subtotal_price'], 'tax_val' => $_SESSION['tax_val'], 'grand_total' => $_SESSION['grand_total']));	
}
if(isset($_GET['ClearAllFromCart']) && $_GET['ClearAllFromCart'] == 'Yes'){
	UnsetCart();
}

function UnsetCart() {
	unset($_SESSION['cart_item']);
	unset($_SESSION['subtotal_price']);
	unset($_SESSION['tax_val']);
	unset($_SESSION['grand_total']);
	unset($_SESSION['tax_details']); 
	unset($_SESSION['TableNo']);
	unset($_SESSION['token_no']);
	unset($_SESSION['del_no']);
	unset($_SESSION['status']);
	unset($_SESSION['cart_count']);
	unset($_SESSION['order_id']);
	unset($_SESSION['delivary_id']);
	unset($_SESSION['deliverID']);
	unset($_SESSION['CustomerId']);
	unset($_SESSION['bankpay']);
	unset($_SESSION['freight_cost']);
	unset($_SESSION['customer_ref']);
	unset($_SESSION['client_id']);
	unset($_SESSION['contact_phone']);
	unset($_SESSION['delivery_address']);
	unset($_SESSION['delivery_to']);

}

if(isset($_GET['reference_load'])){
	echo  $Refs->get_next(ST_SALESINVOICE);
}

if(isset($_GET['get_price'])){
	$itemid = $_POST['itemid'];
	$sales_type_id = $_POST['sales_type_id'];
	$loc_code = $_SESSION['pos_details']['pos_location'];
	// $curr_code = $_POST['curr_code'];
	if($_POST['curr_code']){
		$curr_code = $_POST['curr_code'];
	}else{
		$curr_code = $_SESSION['curr_code'];
	}
	$sql = "SELECT sum(round(s.qty, 2)) as qty,  mb_flag, m.units FROM ".TB_PREF."stock_master as m LEFT JOIN ".TB_PREF."stock_moves as s ON m.stock_id = s.stock_id where m.stock_id = ".fadb_escape($itemid);

	if($loc_code != false)
		$sql .=" AND loc_code=".fadb_escape($loc_code)." ";

	$price_typ_res= fadb_query($sql, "can't get results");
	//if($price_typ_res)
	if(fadb_num_rows($price_typ_res) > 0 )
		$row = fadb_fetch($price_typ_res);
	else
		$row = ['qty' => 0 , 'mb_flag' => 'B'];
	//var_dump($_SESSION['sales_type_id']  );

	// $price = get_price ($itemid, $curr_code, $sales_type_id);
	$price = get_kit_price($itemid, $curr_code,$sales_type_id);
	$price_array = array('price' => $price, 'quantity' => $row['qty'], 'type' => $row['mb_flag']);
	if(isset($row['units']))
		$price_array['units'] = $row['units'];
	else
		$price_array['units'] = '';

	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
   	//var_dump($_SESSION['pos_details']);
	if($kv_exp_date || $kv_batch){
		
		$sql = " SELECT batch_no, IF(SUM(qty) >= 0, ROUND(SUM(qty), ".$price_dec."), 0)AS qty, exp_date FROM ".TB_PREF."stock_moves WHERE  stock_id=".fadb_escape($itemid);
		
		if($loc_code != false)
			$sql .=" AND loc_code=".fadb_escape($loc_code)." ";
		$sql .= " GROUP BY batch_no HAVING SUM(qty) > 0 ";
		$batch_list= fadb_query($sql, "can't get results");
		if(fadb_num_rows($batch_list) > 0 ){
			$final_batch_list = [];
			while($row = fadb_fetch($batch_list)){
				$final_batch_list[] = $row;

			}
			$price_array['batch_list'] = $final_batch_list;
		}
	}
	echo json_encode($price_array);
}

//Category 

if(isset($_GET['submit_category']) && $_GET['submit_category'] == 'yes'){
	$default_inv_sales_act = get_company_details('default_inv_sales_act');	
	$default_cogs_act = get_company_details('default_cogs_act');
	$default_inventory_act = get_company_details('default_inventory_act');
	$default_adj_act = get_company_details('default_adj_act');
	$default_wip_act = get_company_details('default_wip_act');
	
	$insert = array('description' => $_POST['cat_name'],'dflt_tax_type' => $_POST['ItemTaxTypes'],'dflt_mb_flag' => $_POST['ItemType'],'dflt_units' => $_POST['cat_units'],'dflt_sales_act' => $default_inv_sales_act,'dflt_cogs_act' => $default_cogs_act,'dflt_inventory_act' => $default_inventory_act,'dflt_adjustment_act' => $default_adj_act,'dflt_wip_act' => $default_wip_act, 'dflt_dim1' => 0, 'dflt_dim2' => 0, 'parent_id' => $_POST['parent_id']);
	if(isset($_POST['icon_code']))
		$insert['icon_name'] = $_POST['icon_code'];
	if(isset($_POST['color_code']))
		$insert['color_code'] = $_POST['color_code'];
	begin_transaction();
	if($_POST['category_id'] == 0){
		FAInsert('stock_category',  $insert);
		$msg = json_encode(array('id' => 11, 'name' => $_POST['cat_name'], 'msg' => 'Successfully Inserted Category'));
	
	}else{
		$id = $_POST['category_id'];// if exists update if not insert new
		FAUpdate('stock_category',  array('category_id' => $id), $insert);									
		$msg = json_encode(array('msg' => 'Successfully Updated Category'));
	}
	commit_transaction();	
		die($msg);
}

if(isset($_GET['submit_saleskit_info']) && $_GET['submit_saleskit_info'] == 'yes'){
	$name = $_POST['kit_description'];
	$category = $_POST['category_id'];
	$kit_code = $_POST['kit_item_id'];
	
	$sql = "UPDATE ".TB_PREF."item_codes SET description=".fadb_escape($name).",category_id=".fadb_escape($category)." WHERE item_code=".fadb_escape($kit_code);
	fadb_query($sql, "kit name update failed");
	echo json_encode(array('msg' => 'Successfully Updated Kit'));
	
}

//-------------------------------------
// Inventory
//-------------------------------------
if(isset($_GET['submit_inventory']) && $_GET['submit_inventory'] == 'yes'){
	
	$default_inv_sales_act = get_company_details('default_inv_sales_act');	
		$default_cogs_act = get_company_details('default_cogs_act');
		$insert = array('stock_id' => $_POST['stock_code'],'category_id' => $_POST['in_category_id'],'tax_type_id' => $_POST['in_ItemTaxTypes'],'description' => $_POST['description'],'long_description' => $_POST['long_description'],'mb_flag' => $_POST['ItemType'],'units' => $_POST['units'],'sales_account' => $default_inv_sales_act,'cogs_account' => $default_cogs_act,'inventory_account' => '','adjustment_account' => '','wip_account' => '','depreciation_method' => '','depreciation_factor' => '0','editable' => $_POST['EditableDesc']);
		$sales_types = Salestypes(null);
		begin_transaction();
		
		if($_POST['stock_id'] == '' || (is_numeric($_POST['stock_id']) && $_POST['stock_id'] == 0 )){

			if(key_in_foreign_table($_POST['stock_code'], 'stock_master', 'stock_id') > 0){		
				$msg = json_encode(['msg' => _("The Item Already exist in database.")]);
			} elseif(key_in_foreign_table($_POST['stock_code'], 'item_codes', 'item_code') > 0){			
				$msg = json_encode(['msg' => _("The Item Already exist in database.")]);
			} else {
				FAInsert('stock_master',  $insert);		
				FAInsert('item_codes' , array('category_id' => $_POST['in_category_id'],'item_code' => $_POST['stock_code'],'stock_id' => $_POST['stock_code'],'description' => $_POST['description']));
				foreach($sales_types as $type){
					if((float)$_POST['price_'.$type['id']] > 0 )
						FAInsert('prices',  array('stock_id' => $_POST['stock_code'], 'sales_type_id' => $type['id'], 'curr_abrev' => $_POST['curr_code'], 'price' => (float)$_POST['price_'.$type['id']]));
				}
				$msg = json_encode(array('id' => $_POST['stock_code'], 'name' => $_POST['description'], 'msg' => 'Successfully Inserted Inventory'));
			}
		}else{
			$id = $_POST['stock_id'];// if exists update if not insert new
			$subid = $_POST['in_sub_id'];
			FAUpdate('stock_master',  array('stock_id' => $_POST['stock_id']), $insert);	
								
			FAUpdate('item_codes', array('stock_id' => $_POST['stock_id']), array('description' => $_POST['description'], 'category_id' => $_POST['in_category_id']));
			if(is_array($sales_types) && count($sales_types) > 0){
				foreach($sales_types as $type){
				 	if((float)$_POST['price_'.$type['id']] > 0 ){
						FAUpdate('prices',  array('stock_id' => $_POST['stock_id'], 'sales_type_id' => $type['id']), array('curr_abrev' => $_POST['curr_code'], 'price' => (float)$_POST['price_'.$type['id']]));
					}else{
						FAInsert('prices',  array('stock_id' => $_POST['stock_code'], 'sales_type_id' => $type['id'], 'curr_abrev' => $_POST['curr_code'], 'price' => (float)$_POST['price_'.$type['id']]));

					}
				}
			}
			$msg = json_encode(array('msg' => 'Successfully Updated Inventory'));
		}			
		commit_transaction();	
		die($msg);
	}

if(isset($_GET['edit_stock_category'])){
	$id = $_POST['id'];
	$data = FAGetRow('stock_category', array('category_id' => $id));
	echo json_encode($data);

}

if(isset($_GET['Edit_Inventory'])){
	global $price_dec;
	$tbpref = FA_PREF;
	// in
	$curr_default = get_company_details('curr_default');
	$id = $_POST['id'];
	$return = FAGetRow('stock_master', array('stock_id' => $id));
		$sql = "SELECT price, curr_abrev, sales_type_id FROM ".$tbpref."prices  WHERE stock_id = ".fadb_escape($id);	
		$data = fadb_query($sql, "Cannot Connect data");
		if(fadb_num_rows($data) > 0 ){
			while($row = fadb_fetch_assoc($data)){
				$return['curr_code'] = $row['curr_abrev'];
				$return['price_'.$row['sales_type_id']] = number_format($row['price'], $price_dec);

			}
		}
		echo json_encode($return);

}
if(isset($_GET['delete_stock_category'])){
	$cancel_delete = 0;
	$selected_id = $_GET["delete_stock_category"];
	if(key_in_foreign_table($selected_id, 'stock_master', 'category_id') > 0){
		$cancel_delete = 1;
		$msg = _("This item cannot be deleted because there are transactions that refer to it.");
	} elseif(key_in_foreign_table($selected_id, 'item_codes', 'category_id') > 0){
			$cancel_delete = 1;
			$msg = _("This item cannot be deleted because there are transactions that refer to it.");
	}
	begin_transaction();
		if ($cancel_delete == 0) { 	//ie not cancelled the delete as a result of above tests	
			$sql0 = "DELETE FROM ".TB_PREF."stock_category WHERE category_id=".fadb_escape($selected_id);
			$sql1 = "DELETE FROM ".TB_PREF."item_codes  WHERE category_id = ".fadb_escape($selected_id);
			
			fadb_query($sql0, "Cannot connected");
			fadb_query($sql1, "Cannot Connect");
			echo '1';				
		}		
		commit_transaction();
		die($msg);

}

if(isset($_GET['delete_Inventory'])){

	$cancel_delete = 0;	// PREVENT DELETES IF DEPENDENT RECORDS IN 'debtor_trans'
		$selected_id = $_GET["delete_Inventory"];
		if (key_in_foreign_table($selected_id, 'sales_order_details', 'stk_code') > 0){
			$cancel_delete = 1;
			$msg = _("This item cannot be deleted because there are transactions that refer to it.");
		} elseif (key_in_foreign_table($selected_id, 'purch_order_details', 'item_code') > 0){
			$cancel_delete = 1;
			$msg = _("This item cannot be deleted because there are transactions that refer to it.");
		} else {
			if (key_in_foreign_table($selected_id, 'stock_moves', 'stock_id')){
				$cancel_delete = 1;
				$msg = _("Cannot delete the item record because orders have been created against it.");
			} 
		}	
		begin_transaction();
		if ($cancel_delete == 0) { 	//ie not cancelled the delete as a result of above tests	
			$sql0 = "DELETE FROM ".TB_PREF."stock_master WHERE stock_id=".fadb_escape($selected_id);
			$sql1 = "DELETE FROM ".TB_PREF."item_codes  WHERE stock_id = ".fadb_escape($selected_id);
			$sql2 = "DELETE FROM ".TB_PREF."prices  WHERE stock_id = ".fadb_escape($selected_id);
			
			fadb_query($sql0, "Cannot connected");
			fadb_query($sql1, "Cannot Connect");
			fadb_query($sql2, "Cannot Connect");
			echo '1';				
		}		
		commit_transaction();
}


//----------------------------------
// Customers 
//----------------------------------
if(isset($_GET['submit_customer']) && $_GET['submit_customer'] == 'yes'){
	
	$default_sales_discount_act = get_company_details('default_sales_discount_act');
	$debtors_act = get_company_details('debtors_act');
	$default_prompt_payment_act = get_company_details('default_prompt_payment_act');
		
	if(!isset($_POST['tax_group_id']) || $_POST['tax_group_id'] == ''  || $_POST['tax_group_id'] == 0){
		$_POST['tax_group_id'] = FAGetSingleValue('tax_groups', 'id', [], array('id' => 'ASC'));
	}

	$loc = (isset($_SESSION['pos_details']['pos_location'])? $_SESSION['pos_details']['pos_location'] : 'DEF');

	begin_transaction();
	if($_POST['customer_id'] == 0){
		add_customer( $_POST['client_name'], $_POST['cust_ref'], $_POST['address'], $_POST['tax_id'], $_POST['curr_code'], 0, 0,	1, $_POST['payment_terms'], 0, 0, 1000, $_POST['sales_type'],'');
		$selected_customer_id = $_POST['customer_id'] = fadb_insert_id();  
        add_branch($selected_customer_id, $_POST['client_name'], $_POST['cust_ref'], $_POST['address'], 1, 1, $_POST['tax_group_id'], '', $default_sales_discount_act, $debtors_act, $default_prompt_payment_act,
                $loc, $_POST['address'], 0, 1, '', $_POST['bank_account']);
        $selected_branch = fadb_insert_id();
		add_crm_person($_POST['cust_ref'], $_POST['client_name'], '', $_POST['address'], $_POST['phone'], '', '', $_POST['client_email'], '', '');
		$pers_id = fadb_insert_id();
		add_crm_contact('cust_branch', 'general', $selected_branch, $pers_id);
		add_crm_contact('customer', 'general', $selected_customer_id, $pers_id);
		if(isset($_POST['pos_customer']))
			$msg = json_encode(array( 'id' => $selected_customer_id, 'name'  => $_POST['cust_ref']));
		else
			$msg = _("New Customer Added Successfully"); 
	}else { 		
		update_customer($_POST['customer_id'], $_POST['client_name'], $_POST['cust_ref'], $_POST['address'],$_POST['tax_id'], $_POST['curr_code'], 0, 0, 1, $_POST['payment_terms'], 0, 0, 1000, $_POST['sales_type'], '');
		update_branch($_POST['customer_id'], $_POST['client_name'], $_POST['cust_ref'], $_POST['address'], 1, 1, $_POST['tax_group_id'], '', $default_sales_discount_act, $debtors_act, $default_prompt_payment_act, $loc, $_POST['address'], 0, 1, '', $_POST['bank_account']);
		$sql="SELECT person_id FROM ".TB_PREF."crm_contacts WHERE type='customer' AND entity_id=".$_POST['customer_id']." LIMIT 1" ; 
		$debtor_row =  fadb_query($sql, "Can't get email validations");
		if($row = fadb_fetch_row($debtor_row)){		
			update_crm_person($row[0], $_POST['cust_ref'], $_POST['client_name'], '', $_POST['address'], $_POST['phone'], '', '', $_POST['client_email'], '', '');
		}
		$msg = _("Selected Customer Updated Successfully"); 
	}
	commit_transaction();	
	die($msg);
}

if(isset($_GET['Edit_Customer'])){
	$sql ="SELECT debtor.*, branch.*, persons.email As client_email, persons.phone as client_phone FROM ".TB_PREF."debtors_master AS debtor, ".TB_PREF."cust_branch AS branch, ".TB_PREF."crm_persons AS persons, ".TB_PREF."crm_contacts AS contact WHERE debtor.debtor_no=".$_GET['Edit_Customer']." AND debtor.debtor_no = branch.debtor_no AND contact.entity_id=".$_GET['Edit_Customer']." AND contact.person_id = persons.id LIMIT 1 ";
	$debtor_row =  fadb_query($sql, "Can't get debtors list");
	if($row =  fadb_fetch_assoc($debtor_row)){
		$sql2 = "SELECT email, phone FROM ".TB_PREF."crm_persons AS person, ".TB_PREF."crm_contacts AS contact WHERE contact.entity_id=".$row['debtor_no']." AND contact.type='customer' AND contact.person_id=person.id";
		$debtor_row2 =  fadb_query($sql2, "Can't get debtors list");
		if($row2 =  fadb_fetch_assoc($debtor_row2)){
			$row['email'] = $row2['email'];
			$row['phone'] = $row2['phone'];
		}			
		echo json_encode($row);
	}else
		echo '1';
}

if(isset($_GET['delete_Customer'])){
	$cancel_delete = 0;	// PREVENT DELETES IF DEPENDENT RECORDS IN 'debtor_trans'
	$selected_id = $_GET['delete_Customer'];
	if (key_in_foreign_table($selected_id, 'debtor_trans', 'debtor_no') > 0){
		$cancel_delete = 1;
		echo _("This customer cannot be deleted because there are transactions that refer to it.");
	} else {
		if (key_in_foreign_table($selected_id, 'sales_orders', 'debtor_no')){
			$cancel_delete = 1;
			echo _("Cannot delete the customer record because orders have been created against it.");
		} 
	}
	if ($cancel_delete == 0) { 	//ie not cancelled the delete as a result of above tests	
		delete_customer($selected_id);
		echo '1';	
	}		
}

if(isset($_GET['user_dashboard'])){
	if($_POST['item']){
		$users_desired_items = array(); 
		foreach($_POST['item'] as $grid_order=>$grid_id) {
			$users_desired_items[$grid_id] = $grid_order;
		}
		echo add_user_meta($_GET['user_dashboard'], 'user_dashboard', $users_desired_items) .json_encode($users_desired_items);
	}
}

if(isset($_GET['user_dashboard_reset'])){
	echo delete_user_meta($_GET['user_dashboard_reset'], 'user_dashboard');
}

if(isset($_GET['Area_chart'])){
	 $top_selling_items =  Top_selling_items($_GET['Area_chart']); 
	 $area_chart =  array(); 
	 foreach($top_selling_items as $top) { $area_chart[] =   array("y" => $top['description'] , "a" => round($top['total'], 2), "b" => round($top['costs'], 2));  } echo json_encode($area_chart); exit; 
}

if(isset($_GET['Line_chart'])){
	 $top_selling_items =  class_balances($_GET['Line_chart']); 
	 $area_chart =  array(); 
	 foreach($top_selling_items as $top) { 
	 	$area_chart[] =   array("class" => $top['class_name'] , "value" => round(abs($top['total']), 2));  
	 } 
	 echo json_encode($area_chart); exit; 
}
if(isset($_GET['Supplier_chart'])){
	$suppliers = get_top_suppliers($_GET['Supplier_chart']);
	$donut_chart =  array(); 
	 foreach($suppliers as $top) { 
	 	$donut_chart[] =   array("label" => $top['supp_name'] , "value" => round($top['total'], 2));  
	 } 
	 echo json_encode($donut_chart); exit;
}

if(isset($_GET['Tax_chart'])){
	$suppliers = get_tax_reports($_GET['Tax_chart']);
	$donut_chart =  array(); 
	 foreach($suppliers as $top) { 
	 	$donut_chart[] =   array("label" => $top['name'] , "value" => abs(round($top['total'], 2)));  
	 } 
	// $donut_chart['grandtotal'] = abs(round($suppliers['grandtotal'],2));
	 echo json_encode($donut_chart); exit;
}

if(isset($_GET['Customer_chart'])){
	$cutomers = get_top_customers($_GET['Customer_chart']);
	$donut_chart =  array(); 
	 foreach($cutomers as $top) { 
	 	$donut_chart[] =   array("label" => $top['name'] , "value" => round($top['total'], 2));  
	 } 
	 echo json_encode($donut_chart); exit;
}

if(isset($_GET['Employees_chart'])){
	$cutomers = EmployeeCost($_GET['Employees_chart']);
	$donut_chart =  array(); 
	 foreach($cutomers as $top) { 
	 	$donut_chart[] =   array("class" => $top['account_code'] , "value" => round($top['total'], 2), 'labels' => $top['account_name']);  
	 } 
	 echo json_encode($donut_chart); exit;
}
if(isset($_GET['Expense_chart'])){
	$cutomers = Expenses($_GET['Expense_chart']);
	$bar_chart =  array(); 
	 foreach($cutomers as $top) { 
	 	$bar_chart[] =   array("y" => htmlspecialchars_decode($top['name']) , "a" => round($top['balance'], 2));  
	 } 
	 if(empty($bar_chart)){
		$bar_chart[] = array("y" => "nothing" , "a" => 0);
	}
	 echo json_encode($bar_chart); exit;
}

if(isset($_GET['ChangeColorScheme'])){
	$ColorScheme = stripslashes(trim($_GET['ChangeColorScheme']));
	echo add_user_meta($current_user['ID'], 'ColorScheme', $ColorScheme);
}

if(isset($_GET['ChangeUserLang'])){
	$ChangeUserLang = stripslashes(trim($_GET['ChangeUserLang']));
	echo Update('users', array('ID' => $current_user['ID']), array('language' => $ChangeUserLang)); 
}

if(isset($_GET['saveposorder']) && $_GET['saveposorder'] == 'completed'){
	if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){
		$id = save_sales_order();
		echo json_encode($id);
	
	}
}

if(isset($_GET['load_pos_Item'])){
	$date = date('Y-m-d');
	if(isset($_GET['pos']) && $_GET['pos']==true)
	$sql = "SELECT * FROM ".TB_PREF."sales_orders WHERE trans_type =30 AND version = 0 AND ord_date ='".$date."' ORDER BY order_no ASC";
	else
		$sql = "SELECT * FROM ".TB_PREF."sales_orders WHERE table_no | token_no | delivery_no = 0 AND trans_type =30 AND version = 0 AND ord_date ='".$date."' ORDER BY order_no ASC";

	// $sql = "SELECT * FROM ".TB_PREF."sales_orders WHERE table_no | token_no | delivery_no = 0 AND trans_type =30 AND version = 0 AND ord_date ='".$date."' ORDER BY order_no ASC";
	fadb_query("SET NAMES UTF8", '');
	$result = fadb_query($sql, "can't get results");
	$output = [];
	if(fadb_num_rows($result) > 0){
		while ($row = fadb_fetch($result)) {
			$output[] = ['order_id' => $row['order_no'], 'reference' => $row['reference']];
		}
	}
	echo json_encode($output);
}

if(isset($_GET['load_orderdetails_data']) && $_GET['load_orderdetails_data'] == 'Yes'){
	$price_dec = user_price_dec();

	$saved_item = get_saved_item((isset($_GET['pos']) ? $_GET['pos'] : false));
	$date = date('Y-m-d');
	$order_details = FAGetDataJoin('sales_orders AS so', array( array('join' => 'LEFT', 'table_name' => 'debtors_master AS info', 'conditions' => '`info`.`debtor_no` = `so`.`debtor_no`'),
			array('join' => 'LEFT', 'table_name' => 'cust_branch AS br', 'conditions' => '`br`.`debtor_no` = `so`.`debtor_no`'), //`br`.`branch_code` = `so`.`branch_code` AND 
			array('join' => 'LEFT', 'table_name' => 'currencies AS cr', 'conditions' => '`cr`.`curr_abrev` = `info`.`curr_code`')), 
			array('so.*, info.*, br.* , cr.curr_symbol'), array('`so`.`trans_type`' => 30, '`so`.`version`' => 0,'`so`.`ord_date`' => $date, '`so`.`order_no`' => $_POST['orderid']), null,true, false);
	//var_dump($order_details);
	if(is_array($order_details)){		
		$total_amt = number_format(floatval($order_details['total']),$price_dec, '.', '');	
		// $order_items = FAGetDataJoin('sales_order_details as m', array(array('JOIN' => 'LEFT', 'table_name' => 'stock_moves AS s', 'conditions' =>'`s`.`stock_id` = `m`.`stk_code`')),
		// 	array('m.*, sum(s.qty) as stock_quantity'),array('order_no' => $order_details['order_no'], 'trans_type' => $order_details['trans_type']), null, true, false );		
		// $order_items = FAGetAll('sales_order_details', array('order_no' => $order_details['order_no'], 'trans_type' => $order_details['trans_type']));
		$order_items = "SELECT m.*, sum(s.qty) as stock_quanity from ".TB_PREF."sales_order_details as m LEFT join ".TB_PREF."stock_moves as s on s.stock_id = m.stk_code where m.order_no =".$order_details['order_no']." AND m.trans_type = ".$order_details['trans_type']." group by s.stock_id order by m.order_no DESC";
		$order_items_query = fadb_query($order_items, "can't get connected");
		$cart_count = fadb_num_rows($order_items_query);
		$data =[];
		while ($row = fadb_fetch_assoc($order_items_query)){
		// foreach($order_items as $key => $row){
			$tota_price = number_format(floatval($row['quantity'] * $row['unit_price']), $price_dec, '.', '');
			$data[] = ['last_id' => $key, 'id' => $row['id'], 'name'=>$row['description'], 'stock_id' => $row['stk_code'],'stock_quantity' => $row['stock_quanity'], 'qty' => $row['quantity'], 'price' => number_format(floatval($row['unit_price']), $price_dec, '.', ''),'amount' => $tota_price,'discount' =>$row['discount_percent'],'line_total' => $tota_price];
		}
		$_SESSION["CustomerName"] 		= $order_details['name'];
		$_SESSION["currency"] 			= $order_details['curr_symbol'];
		$_SESSION["sales_type_id"] 		= $order_details['sales_type'];;
		$_SESSION["tax_included"] 		= $order_details['tax_included'];;
		$_SESSION["old_curr_code"] 		= $order_details['curr_code'];
		$_SESSION["curr_code"] 			= $order_details['curr_code'];
		$_SESSION["tax_group_id"] 		= $order_details['tax_group_id'];;
		$_SESSION["date"] 				= $order_details['ord_date'];;
		$_SESSION["order_id"] 			= $order_details['order_no']; //needed
		$_SESSION["trans_type"] 		= 30;			
		$_SESSION["cart_item"] 			= $data;
		$_SESSION['cart_count'] 		= $cart_count;
		$_SESSION['freight_cost'] 		= $order_details['freight_cost'];
		$_SESSION['customer_ref'] 		= $order_details['customer_ref'];
		$_SESSION['client_id'] 			= $order_details['client_id'];
		$_SESSION['contact_phone'] 		= $order_details['contact_phone'];
		$_SESSION['delivery_address'] 	= $order_details['delivery_address'];
		$_SESSION['delivery_to'] 		= $order_details['delivery_to'];
		$_SESSION['grand_total'] 		= $total_amt;
		$_SESSION['items_count'] 		= $saved_item;
		$_SESSION['CustomerId'] 		= $order_details['debtor_no'];
		$tax_val 						= fa_get_taxes($_SESSION);
		$_SESSION["subtotal_price"] 	= $order_details['total']- $tax_val;
		$_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');
		$f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
		
		$output = array(
				   'cart_count'  => $cart_count,
				   'items_count' => $saved_item,
				   'subtotal_price' => $f_subtotal_price,
				   'grand_total'  => $total_amt,
				   'tax_val' => $tax_val,
				   'cart_data'   => $data,
				   'CustomerId' => $order_details['debtor_no'],
				   'CustomerName' => $order_details['name'],
				   'order_id' => $order_details['order_no'],
		);
		
		echo json_encode($output);
	}
}

//Inventory
if(isset($_GET['load_item_info']) && $_GET['load_item_info'] == 'yes'){
	$itemid = $_POST['itemid'];
	$result = get_item_kit($itemid);
	$iteminfo = get_kit_props($itemid);
	
	$data = array();
	while ($row = fadb_fetch_assoc($result)) {
		$data[] = ['id' =>$row['id'], 'stock_id' => $row['stock_id'], 'description' => $row['comp_name'], 'quantity' => $row['quantity'], 'units' => ($row["units"] == '' ? _('kit') : $row["units"])];
	}
	echo json_encode(array('item_data'   => $data, 'item_code' => $itemid, 'item_inf' => $iteminfo));
}
if(isset($_GET['load_itemto_table']) && $_GET['load_itemto_table'] == 'yes'){
	$id= $_POST['id'];
	$result = get_itemkit_byid($id);
	$data = array();
	while ($row = fadb_fetch_assoc($result)) {
		$data[] = ['id' =>$row['id'], 'stock_id' => $row['stock_id'], 'description' => $row['comp_name'], 'quantity' => $row['quantity'], 'units' => ($row["units"] == '' ? _('kit') : $row["units"])];
	}
	echo json_encode($data);
}
if(isset($_GET['UpdateItemQuantity']) && $_GET['UpdateItemQuantity'] == 'Yes'){
	$item_id = $_POST['item_id'];
	$qty = $_POST['qty'];
	$sql = "UPDATE ".TB_PREF."item_codes SET quantity = ".fadb_escape($qty)." WHERE id = ".fadb_escape($item_id);
	fadb_query($sql,"an item code could not be updated");
	echo json_encode(array('item_id' => $item_id, 'qty' => $qty));
}
if(isset($_GET['Remove_FromItemCodes']) && $_GET['Remove_FromItemCodes'] == 'Yes'){
	$id = $_POST['id'];
	$sql="DELETE FROM ".TB_PREF."item_codes WHERE id=".fadb_escape($id);
	fadb_query($sql,"an item code could not be deleted");
	echo json_encode(array('id' => $id));	

}
if(isset($_GET['edit_sales_kit'])){
	
	$id = $_POST['id'];
	$data = FAGetRow('item_codes', array('id' => $id));
	echo json_encode($data);

}

if(isset($_GET['check_items_IN_KIT']) && $_GET['check_items_IN_KIT'] == 'Yes'){
	$kit_code = $_POST['kit_id'];
	$item_code = $_POST['item_id'];
	echo check_items_in_kit($kit_code, $item_code, true);
	
}
if(isset($_GET['get_subcategory_id'])){
	$id = $_POST["categoryid"];
	$sql = "SELECT category_id, description, inactive FROM ".TB_PREF."stock_category where parent_id = ".fadb_escape($id);
	$res= fadb_query($sql, "can't get results");
	$json = [];
	while($row = fadb_fetch($res)){
		// $json[] = ['id'=>$row['debtor_no'], 'text'=> _($row["debtor_ref"])]; // text mayb running problem
		$json[] = ['id'=>$row['category_id'], 'text'=> $row["description"]];
	}
	echo json_encode($json);     
}


// Permissions settings on backend
if(isset($_GET['get_pageContent']) && $_GET['get_pageContent'] == "Yes"){
	$c_id = $_POST['c_id'];
	$users_arr = array();
	$sql = "SELECT page_id, page_permit FROM ".TB_PREF."permission where page_id = ".$c_id;
	$result = db_query($sql, "can't get any data");
	$data = array();
	while($row = db_fetch($result)){
		$data[] = ['page_id'=>$row['page_id'], 'page_permit'=> $row["page_permit"]];
	}
	echo json_encode($data);  
}

if(isset($_GET['validate_gst'])){
	
	$tax_id = $_POST['tax_id'];
	$data = FAGetRow('debtors_master', array('tax_id' => $tax_id));
	if(is_array($data) && count($data) >= 1)
		echo 1; 
	else
		echo 0;
}

require_once("ajax_kot.php");
?>
