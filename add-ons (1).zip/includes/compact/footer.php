<!-- Footer -->
				<div id="footer">			
					 
					<!-- Copyright -->
						<div class="copyright">
							<div class="container">
								<ul class="menu">
									<li style="float:left;"> &copy; <a href="#" > Compact Theme <?php echo get_site_title().' '. date('Y'); ?> </a>. All rights reserved</li>
									<li style="float:right;">Design and Development: <a href="http://www.spacemac.us">POS</a></li>
								</ul>
							</div>
						</div>

				</div>            

		</div>

		
	</body>
</html>
