<?php 
global $shortcut_keys;

$shortcut_keys = [
	'ctrl + b' => 'BarcodeScan',
	'shift + p' => 'Product List',
	'shift + n'  => 'New Customer',
	'shift + c'  => 'Search Customer',
	'shift + down'  => 'Customers List',
	'shift + up'  => 'Previous customer',
	'shift + r'   => 'Print receipt',
	'shift + t'  => 'Tender Amount',
	'ctrl + up'  => 'Increase QTY',
	'ctrl + down'  => 'Decrease QTY',
	'ctrl + del'  => 'Remove Item',
	'ctrl + q'  => 'Logout',
	'enter'  => 'Tender Amount',
	'alt + f1'  => 'ShortCuts Keys',
	'alt + h'  => 'Home Page',
	'alt + p'  => 'POS Page',
	'alt + c'  => 'Customers Page',
	'alt  + s'  => 'Sales Page',
	'alt + r'  => 'Profile Page',
	'alt + e'  => 'Sales Return Page'];