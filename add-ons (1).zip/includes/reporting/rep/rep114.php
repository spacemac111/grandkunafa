<?php

$page_security = 'SA_OPEN';

// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Varadha
// date_:	2020-01-14
// Title:	Print Token or Delivery No
// ----------------------------------------------------------------

include_once(ABSPATH . "/includes/erp/customers_db.inc");


//----------------------------------------------------------------------------------------------------
function get_invoice_range($from){

	$sql = "SELECT trans.trans_no, trans.reference	FROM ".TB_PREF."debtor_trans trans LEFT JOIN ".TB_PREF."voided voided ON trans.type=voided.type AND trans.trans_no=voided.id
		WHERE trans.type=".ST_CUSTDELIVERY." AND ISNULL(voided.id) AND trans.trans_no=".fadb_escape($from)
		." ORDER BY trans.tran_date, trans.trans_no";

	return fadb_query($sql, "Cant retrieve invoice range");
}
print_token();

//----------------------------------------------------------------------------------------------------

function print_token()
{
	global  $SysPrefs, $current_user;
	$show_this_payment = true; 
	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");
	$from = $_GET['trans_no'];
	$to = '4';	
	$email = 0;
	$packing_slip = '';
	$comments = '';
	$customer = '';
	$orientation = 'P';
	$dec = user_price_dec();
	if (!$from || !$to) return;
	$dec = user_price_dec();
	$cols = array(4, 45,  220, 225);
	$aligns = array('center',	'center',	'center');
	$header =array('SNO','ITEM NAME','QTY');
	$params = array('comments' => $comments, 'packing_slip' => $packing_slip);
	$cur = get_company_Pref('curr_default');
	if ($email == 0){
		$rep = new FrontReport(_("Token/Delivery"), _("Token/Delivery")." - ".$_GET['trans_no'], $current_user['pdf_template'], 9, $orientation);			
	}
    $range = get_invoice_range($from);
   	
    while($row = fadb_fetch($range)){
		if (!exists_customer_trans(ST_CUSTDELIVERY, $row['trans_no']))
			continue;
		
		$myrow = Kvcodes_get_customer_trans($row['trans_no'], ST_CUSTDELIVERY);
		$branch = Kvcodes_get_branch($myrow["branch_code"]);
		$sales_order = Kvcodes_get_sales_order_header($myrow["order_"], ST_SALESORDER);
		$rep->currency = $cur;
		$rep->Font();
		$rep->Info($params, $cols,null, $aligns);
		$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'delivery', $branch['debtor_no'], true);
		$myrow['token']='yes';
		$rep->SetCommonData($myrow, $branch, $sales_order, '', ST_CUSTDELIVERY, $contacts);
		$rep->SetHeaderType('Headerkvcodes');
		$rep->NewPage();
		$result = Kvcodes_get_customer_trans_details(ST_CUSTDELIVERY, $row['trans_no']);
		$sno =0;
		$total_items =0;	
		$summary_start_row = $rep->bottomMargin +6.5;
		while ($myrow2=fadb_fetch($result))	{
			if ($myrow2["quantity"] == 0)
				continue;
			$sno ++;
			$c=0;
			// $DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
			$total_items +=$myrow2["quantity"];
			$rep->TextCol($c++, $c,	$sno, -2);
			$oldrow = $rep->row;
			$rep->TextColLines($c++, $c, $myrow2['StockDescription'], -2);
			
			$newrow = $rep->row;
			$rep->row = $oldrow;
			$rep->TextCol($c++, $c,	$myrow2["quantity"], -2);
			$rep->row = $newrow;
			if ($rep->row < $summary_start_row)
					$rep->NewPage();
		}

		// $DisplayTotal = number_format2($myrow["ov_freight"] +$myrow["ov_freight_tax"] + $myrow["ov_gst"] +
		// 			$myrow["ov_amount"],$dec);
		$rep->Line($rep->row);
		$rep->NewLine(2);
		$rep->Font('bold');	
		$rep->fontSize += 3;
		$rep->aligns[0] = 'center';	
		$words = price_in_words($myrow['Total'], ST_CUSTDELIVERY);
		$rep->TextCol(1, 2, "TOTAL ITEMS",-2);
		$rep->TextCol(2, 3, $total_items,-2);
		$rep->fontSize -= 3;
		if ($words != "")
		{
			$rep->NewLine(1);
			$rep->TextCol(1, 5, $myrow['curr_code'] . ": " . $words, - 2);
		}

		$rep->Font('italic');
		$rep->NewLine();
		$rep->Line($rep->row);
		$rep->NewLine();
		foreach ($rep->Footer as $line => $txt){
			if (!is_numeric($line))	// title => link
			{
				$rep->NewLine();
				$rep->fontSize -= 2;
				$rep->TextCol(0, 6,$line, - 2);
				$rep->NewLine();
				$rep->SetTextColor(0, 0, 255);
				$rep->TextCol(0, 6,$txt, - 2);
				$rep->SetTextColor(0, 0, 0);
				$rep->fontSize += 2;
			}
			else{
				$rep->NewLine();
				$rep->aligns[0] = 'center';
				$rep->TextCol(0, 6,$txt, - 2);
			}
		}
		$rep->Font();
	}	
	if ($email == 1){
		$rep->End($email,'',2);
	}
	if ($email == 0)
		$rep->End(0,'',2);
}

