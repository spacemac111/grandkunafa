<?php
$page_security = 'SA_OPEN';
// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Varadha
// date_:	2019-03-19
// Title:	Print Credit Notes
// ----------------------------------------------------------------

//----------------------------------------------------------------------------------------------------

print_credits();

//----------------------------------------------------------------------------------------------------

function print_credits(){
	global  $SysPrefs, $current_user;
	
	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");

	$i = $_GET['trans_no'];
	//$to = $_POST['PARAM_1'];
	//$currency = $_POST['PARAM_2'];
	//$email = $_POST['PARAM_3'];
	//$paylink = $_POST['PARAM_4'];
	//$comments = $_POST['PARAM_5'];
	$orientation = $_POST['PARAM_6'];

	if (!$i ) return;

	$orientation = ($orientation ? 'L' : 'P');
	$dec = user_price_dec();
		
	//$cols = array(4, 60, 225, 300, 325, 385, 450, 515);

	// $headers in doctext.inc
	//$aligns = array('left',	'left',	'right', 'left', 'right', 'right', 'right');
	
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
   	$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
	//-------------code-Descr-Qty--uom--tax--prc--Disc-Tot--//
	// $cols = array(4, 25,  135, 165, 210, 300);
	// if($kv_batch || $kv_exp_date){
	// 	$cols = array(4, 35, 160, 195, 225);
	// 	$aligns = array('center', 'center', 'center',	'right');
	// 	if($kv_exp_date){
	// 		$cols = array(4, 25, 150, 175, 220, 235);
	// 		$aligns = array('center', 'center', 'center', 'center',	'right');
	// 	}
	// } else {
	// 	$cols = array(4, 45,  220, 225);
	// 	$aligns = array('center',	'center',	'right');
	// }
	if($kv_batch || $kv_exp_date ){
		if($current_user['pdf_template'] == 'A6') {
			$cols = array(4, 25, 160, 195, 225);
			$aligns = array('center', 'center', 'left',	'right');
			if($kv_exp_date){
				$cols = array(4, 25, 150, 195, 250, 295);
				$aligns = array('center', 'left', 'center', 'center',	'right');
			}
		}
		elseif($current_user['pdf_template'] == 'A7') {
			$cols = array(4, 25, 130, 150, 185);
			$aligns = array('center', 'left', 'left',	'right');
			// if($kv_exp_date){
			// 	$cols = array(4, 20, 150, 195, 230, 235);
			// 	$aligns = array('center', 'left', 'center', 'center',	'right');
			// }
		}elseif($current_user['pdf_template'] == 'A8') {
			$cols = array(4, 125);
			$aligns = array('left');
		}
	} else {
		if($current_user['pdf_template'] == 'A6') {
			$cols = array(4, 45,  220, 225);
			$aligns = array('center',	'left',	'right');
		} elseif($current_user['pdf_template'] == 'A7') {
			$cols = array(4, 150,195);
			$aligns = array('left',	'right');
		} elseif($current_user['pdf_template'] == 'A8') {
			$cols = array(4, 125);
			$aligns = array('left');
		}
	}
	//$params = array('comments' => $comments);
	$cur = get_company_Pref('curr_default');	
	$rep = new FrontReport(_("RETURN NOTE"), _("Return"). " - ".$_GET['trans_no'] , $current_user['pdf_template'], 9, 'P');

		if (!exists_customer_trans(ST_CUSTCREDIT, $i))
			die();
		$sign = -1;
		$myrow = Kvcodes_get_customer_trans($i, ST_CUSTCREDIT);
		/*if ($currency != ALL_TEXT && $myrow['curr_code'] != $currency) {
			continue;
		}*/
		$baccount = Kvcodes_get_default_bank_account($myrow['curr_code']);
		$params['bankaccount'] = $baccount['id'];

		$branch = Kvcodes_get_branch($myrow["branch_code"]);
		$branch['disable_branch'] = ''; //$paylink; // helper
		$sales_order = null;

		$rep->currency = $myrow['curr_code'];
		$rep->Font();
		$rep->Info($params, $cols, null, $aligns);

		$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'invoice', $branch['debtor_no'], true);
		$rep->SetCommonData($myrow, $branch, $sales_order, $baccount, ST_CUSTCREDIT, $contacts);
		$rep->SetHeaderType('Header2');
		$rep->NewPage();

		$result = Kvcodes_get_customer_trans_details(ST_CUSTCREDIT, $i);
		$SubTotal = 0;
		$trans_details = [];
			while ($myrow2=fadb_fetch($result)){ 
				$trans_details[] = $myrow2;
			}
			$Kit_Net = 0;
			$current_kit = '';
			foreach($trans_details as $key => $myrow2) {

			if ($myrow2["quantity"] == 0)
				continue;

			$Net = round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),
			   user_price_dec());
			$SubTotal += $Net;
			$DisplayPrice = number_format2($myrow2["unit_price"],$dec);
			$DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
			$DisplayNet = number_format2($Net,$dec);
			
			if($non_detailed_sales_kit && $myrow2['kit'] != ''){
				//echo "TesT";
				if($current_kit == '')
	    			$current_kit = $myrow2['kit'];
	    				
				if($current_kit == $myrow2['kit']){
					$Kit_Net += round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),   user_price_dec());
					if($myrow2['kit'] == $trans_details[$key+1]['kit'])
						continue;
				} else
					$current_kit = '';
					
				$DisplayNet = number_format2($Kit_Net, $dec);
				$Kit_Net = 0;
				$item_detail = FAGetRow('item_codes', ['item_code' => $myrow2['kit'], 'stock_id' => $myrow2['stock_id']]);
				$myrow2['StockDescription'] = $item_detail['description'];
					//echo $myrow2['quantity'].'_'.$item_detail['quantity'];
				$DisplayQty = number_format2($myrow2['quantity']/$item_detail['quantity'], get_qty_dec($myrow2['kit']));
			}

			$c=0;
			//$rep->TextCol($c++, $c, abs($DisplayQty), -2);
			//$rep->TextCol(0, 1,	$myrow2['stock_id'], -2);
			$stock_Description = $myrow2['StockDescription'];
				if($current_user['pdf_template'] == 'A6')
					$rep->TextCol($c++, $c,	$DisplayQty, -2);
				elseif($current_user['pdf_template'] == 'A7'){
					if($kv_batch|| $kv_exp_date){
						$stock_Description = $myrow2['StockDescription'];
						$rep->TextCol($c++, $c,	$DisplayQty, -2);
					} else 
						$stock_Description = $DisplayQty.'x '.$myrow2['StockDescription'];
				}
				elseif($current_user['pdf_template'] == 'A8')
					$stock_Description = $DisplayQty.'x '.$myrow2['StockDescription']."     ".$DisplayNet;

			$oldrow = $rep->row;
			$rep->TextColLines($c++, $c, $stock_Description, -2);
			$newrow = $rep->row;
			$rep->row = $oldrow;
			if ($Net != 0.0 || !is_service($myrow2['mb_flag']) || get_company_details('no_zero_lines_amount'))		{
					// $rep->TextCol($c++, $c,	$DisplayQty, -2);
					if($kv_batch|| $kv_exp_date){
						$rep->TextColLines($c++, $c,	$myrow2['batch_no'], -2);
						if($kv_exp_date && $current_user['pdf_template'] != 'A8' && $current_user['pdf_template'] != 'A7'){
							$rep->row = $oldrow;
							$rep->TextColLines($c++, $c, ($myrow2['exp_date'] != '0000-00-00' ? date('d-m-Y', strtotime($myrow2['exp_date']))  : ''), -2);
						}
					}

					$newrow = $rep->row;
					$rep->row = $oldrow;
					//$rep->TextCol($c++, $c,	$DisplayDiscount, -2);
					if($current_user['pdf_template'] != 'A8')
						$rep->TextCol($c++, $c,	$DisplayNet, -2);
			}
			$rep->row = $newrow;
			$rep->NewLine(0.5);
			if ($rep->row < $summary_start_row){
				$rep->NewPage();
					//echo $rep->row.'_'.$summary_start_row.'-->'.$rep->pageNumber.'<br>';
			}
		}

		$rep->lineHeight = 10;
			// if(!$kv_batch && !$kv_exp_date) {
			// 	if($current_user['language'] != 'ar_EG') {
			// 		if($current_user['pdf_template'] == 'A7' || $current_user['pdf_template'] == 'A8')
			// 			$rep->SetFont('dejavu', '', 8);
			// 		else
			// 			$rep->SetFont('dejavu', '', 9);
			// 	}
			// } elseif($current_user['pdf_template'] == 'A8')
			// 		$rep->SetFont('helvetica', '', 7);
			$memo = Kvcodes_get_comments_string(ST_CUSTCREDIT, $row['trans_no']);	
   			$DisplaySubTot = number_format2($SubTotal,$dec);

			// set to start of summary line:
    		// $rep->row = $summary_start_row;


			$doctype = ST_CUSTCREDIT;
    		// $rep->row = $summary_start_row;
			// $rep->cols[2] += 20;
			// $rep->cols[3] += 20;
			// $rep->aligns[3] = 'left';
    		$rep->Line($rep->row);
    		$rep->NewLine();
    		//$rep->Font();

    		if($current_user['pdf_template'] == 'A6'){
				$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Sub-total"), -2);
				$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplaySubTot, -2);
			} elseif($current_user['pdf_template'] == 'A7'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 3, _("Sub-total"), -2);
					$rep->TextCol(3, 4,	$DisplaySubTot, -2);
				} else {
					$rep->TextCol(0, 1, _("Sub-total"), -2);
					$rep->TextCol(1, 2, $DisplaySubTot, -2);
				}
			}elseif($current_user['pdf_template'] == 'A8'){
				$rep->TextCol(0, 1, _("Sub-total"). " : ". $DisplaySubTot, -2);
			}

			$rep->NewLine(0.7);
			$rep->Line($rep->row);	
			$rep->NewLine();

			$tax_items = Kvcodes_get_trans_tax_details(ST_CUSTCREDIT, $row['trans_no']);
			$first = true;
    		while ($tax_item = fadb_fetch($tax_items))		{

    			if ($tax_item['amount'] == 0)
    				continue;
    			$DisplayTax = number_format2($sign*$tax_item['amount'], $dec);

    			if (get_company_details('suppress_tax_rates') == 1)
    				$tax_type_name = $tax_item['tax_type_name'];
    			else
    				$tax_type_name = $tax_item['tax_type_name']." (".$tax_item['rate']."%) ";

    			if ($myrow['tax_included'])	{
    				if (get_company_details('alternative_tax_include_on_docs') == 1)	{
    					if ($first)	{
    						if($current_user['pdf_template'] == 'A6'){
								$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), _("Total Tax Excluded"), -2);
								$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), 5,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
							} elseif($current_user['pdf_template'] == 'A7'){
								if($kv_batch || $kv_exp_date){
									$rep->TextCol(1, 3, _("Total Tax Excluded"), -2);
									$rep->TextCol(3, 4,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
								} else {
									$rep->TextCol(0,1,   _("Total Tax Excluded"), -2);
									$rep->TextCol(1,2,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
								}
							}
							elseif($current_user['pdf_template'] == 'A8'){
								$rep->TextCol(0, 1,  _("Total Tax Excluded") ." : ".number_format2($sign*$tax_item['net_amount'], $dec), -2);
							}
							$rep->NewLine();
    					}
    					if($current_user['pdf_template'] == 'A6'){
							$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $tax_type_name, -2);
							$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplayTax, -2);
						} elseif($current_user['pdf_template'] == 'A7'){
							if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 3, $tax_type_name . _("Amt"), -2);
								$rep->TextCol(3, 4,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,1,  $tax_type_name . _("Amt"), -2);
								$rep->TextCol(1,2,	$DisplayTax, -2);
							}
						}
						elseif($current_user['pdf_template'] == 'A8'){
							$rep->TextCol(0, 1, $tax_type_name . _("Amt") ." : ".$DisplayTax, -2);
						}
						$first = false;
    				}
    				else{
    					
						$rep->fontSize = 8;
						if($current_user['pdf_template'] == 'A6'){
							$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
							$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),$DisplayTax, -2);
						} elseif($current_user['pdf_template'] == 'A7'){
							if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 3, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
								$rep->TextCol(3, 4,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,1, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
								$rep->TextCol(1,2,	$DisplayTax, -2);
							}
						}
						elseif($current_user['pdf_template'] == 'A8'){
							$rep->TextCol(0, 1, _("Incld.") . " " . $tax_type_name . _("Amt") ." : ".$DisplayTax, -2);
						}
						if($current_user['pdf_template'] == 'A7' || $current_user['pdf_template'] == 'A8')
							$rep->fontSize = 8;
						else
							$rep->fontSize = 9;
					}
				}	else	{
					if($current_user['pdf_template'] == 'A6'){
						$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $tax_type_name, -2);
						$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplayTax, -2);
					} elseif($current_user['pdf_template'] == 'A7'){
						if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 3,  $tax_type_name, -2);
								$rep->TextCol(3, 4,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,1, $tax_type_name, -2);
								$rep->TextCol(1,2,	$DisplayTax, -2);
							}
					}
					elseif($current_user['pdf_template'] == 'A8'){
						$rep->TextCol(0, 1, $tax_type_name ." : ".$DisplayTax, -2);
					}
				}
				$rep->NewLine(0.7);
    		}
    		$rep->Line($rep->row);
    		$rep->NewLine();

			$DisplayTotal = number_format2($sign*($myrow["ov_freight"] + $myrow["ov_gst"] +
				$myrow["ov_amount"]+$myrow["ov_freight_tax"]),$dec);
			$rep->Font('bold');
			$rep->aligns[1] = 'center';
			//if (!$myrow['prepaid']) $rep->Font('bold');
			if($current_user['pdf_template'] == 'A6'){
				$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $rep->formData['prepaid'] ? _("TOTAL ORDER VAT INCL.") : _("TOTAL CREDIT"), - 2);
				$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $DisplayTotal, -2);
			} elseif($current_user['pdf_template'] == 'A7'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 3, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL CREDIT"), -2);
					$rep->TextCol(3, 4,	$DisplayTotal, -2);
				} else {
					$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL CREDIT"), - 2);
					$rep->TextCol(1,2, $DisplayTotal, -2);
				}
			}elseif($current_user['pdf_template'] == 'A8'){
				$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL CREDIT") ." : ". $DisplayTotal, -2);
			}
			if ($rep->formData['prepaid'])	{
				$rep->NewLine();
				//$rep->Font('bold');
				if($current_user['pdf_template'] == 'A6'){
					$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $rep->formData['prepaid']=='final' ? _("THIS CREDIT") : _("TOTAL CREDIT"), - 2);
					$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), number_format2($myrow['prep_amount'], $dec), -2);
				}elseif($current_user['pdf_template'] == 'A7'){
					if($kv_batch || $kv_exp_date){
						$rep->TextCol(1, 3, $rep->formData['prepaid']=='final' ? _("THIS CREDIT") : _("TOTAL CREDIT"), -2);
						$rep->TextCol(3, 4,	number_format2($myrow['prep_amount'], $dec), -2);
					} else {
						$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("THIS CREDIT") : _("TOTAL CREDIT"), - 2);
						$rep->TextCol(1,2, number_format2($myrow['prep_amount'], $dec), -2);
					}
				}
				elseif($current_user['pdf_template'] == 'A8'){
					$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("THIS CREDIT") : _("TOTAL CREDIT") ." : ". number_format2($myrow['prep_amount'], $dec), -2);
				}
			}
			$words = price_in_words($rep->formData['prepaid'] ? $myrow['prep_amount'] : $myrow['Total'], array( 'type' => ST_CUSTCREDIT, 'currency' => $myrow['curr_code']));
			$rep->NewLine(0.7);
			$rep->Font();
			if ($memo != "")	{
				$rep->NewLine();
				
				$rep->aligns[3] = 'center';
				if($current_user['pdf_template'] == 'A6')
					$rep->TextColLines(0, 3,'Paid Through '. $memo, -2);
				elseif($current_user['pdf_template'] == 'A7'){
					$rep->TextColLines(0, ($kv_batch || $kv_exp_date ? 3 : 2), 'Paid Through '. $memo, -2);
				}
				elseif($current_user['pdf_template'] == 'A8')
					$rep->TextColLines(0, 1, 'Paid Through '. $memo, -2);
			}
			if ($words != "")	{
				$rep->NewLine(1);
				if($current_user['pdf_template'] == 'A6')
					$rep->TextColLines(1, 3, $myrow['curr_code'] . ": " . $words, - 2);
				elseif($current_user['pdf_template'] == 'A7')
					$rep->TextColLines(0, ($kv_batch || $kv_exp_date ? 3 : 2), $myrow['curr_code'] . ": " . $words, - 2);
				elseif($current_user['pdf_template'] == 'A8')
					$rep->TextColLines(0, 1, $myrow['curr_code'] . ": " . $words, - 2);
			}

			// Footer
			$rep->Font('italic');
			$rep->Line($rep->row);
			if($current_user['pdf_template'] == 'A6')
				$col_End = 6;
			elseif($current_user['pdf_template'] == 'A7'){
				$col_End = ($kv_batch || $kv_exp_date ? 3 : 2);
			}
			elseif($current_user['pdf_template'] == 'A8')
				$col_End = 1;
			foreach ($rep->Footer as $line => $txt){
				if (!is_numeric($line))	{// title => link
					$rep->NewLine();
					$rep->aligns[0] = 'center';
					$rep->fontSize = 6;
					$rep->TextCol(0, $col_End,$line, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 255);
					$rep->TextCol(0, $col_End,$txt, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 0);
					// $this->addLink($txt, $ccol, $this->row, $this->pageWidth - $this->rightMargin, $this->row + $this->lineHeight);
					$rep->fontSize = 7;
				}	else{
					$rep->NewLine();
					$rep->aligns[0] = 'center';
					// $rep->TextWrap(0, $rep->row,5,$txt,'C');
					$rep->TextCol(0, $col_End,$txt, - 2);
				}
			}

			$rep->Font();
			if ($email == 1){
				$rep->End($email);
			}
	
	if ($email == 0)
		$rep->End();
}
/*
		// $memo = '';//get_comments_string(ST_CUSTCREDIT, $i);
		// if ($memo != "")	{
		// 	$rep->NewLine();
		// 	$rep->TextColLines(1, 3, $memo, -2);
		// }

		$DisplaySubTot = number_format2($SubTotal,$dec);

		$rep->row = $rep->bottomMargin + (15 * $rep->lineHeight);
		$doctype = ST_CUSTCREDIT;

		//$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Sub-total"), -2);
		//$rep->TextCol(2, 3,	$DisplaySubTot, -2);

		$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Sub-total"), -2);
		$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplaySubTot, -2);
		$rep->NewLine();
		if ($myrow['ov_freight'] != 0.0)	{
			$DisplayFreight = number_format2($sign*$myrow["ov_freight"],$dec);
			$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Shipping"), -2);
			$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplayFreight, -2);
			$rep->NewLine();
		}
		$tax_items = Kvcodes_get_trans_tax_details(ST_CUSTCREDIT, $i);
		$first = true;
		while ($tax_item = fadb_fetch($tax_items))	{
			//echo $tax_item['amount'].'<br>';
			if ($tax_item['amount'] == 0)
				continue;
			$DisplayTax = number_format2($sign*$tax_item['amount'], $dec);

			if (get_company_details('suppress_tax_rates') == 1)
				$tax_type_name = $tax_item['tax_type_name'];
			else
				$tax_type_name = $tax_item['tax_type_name']." (".$tax_item['rate']."%) ";

			if ($myrow['tax_included'])	{
				if (get_company_details('alternative_tax_include_on_docs') == 1)	{
					if ($first)	{
						$rep->TextCol(0, 2, _("Total Tax Excluded"), -2);
						$rep->TextCol(2, 3,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
						$rep->NewLine();
					}
					$rep->TextCol(0, 2, $tax_type_name, -2);
					$rep->TextCol(2, 3,	$DisplayTax, -2);
					$first = false;
				}
				else
					$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), _("Included") . " " . $tax_type_name . _("Amount") . ": " . $DisplayTax, -2);
			}	else {
				$rep->TextCol(0, 2, $tax_type_name, -2);
				$rep->TextCol(2, 3,	$DisplayTax, -2);
			}
			$rep->NewLine();
		}
		$rep->NewLine();
		$DisplayTotal = number_format2($sign*($myrow["ov_freight"] + $myrow["ov_gst"] +
			$myrow["ov_amount"]+$myrow["ov_freight_tax"]),$dec);
		$rep->Font('bold');
		$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("TOTAL CREDIT"), - 2);
		$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $DisplayTotal, -2);
		$words = price_in_words($myrow['Total'], ST_CUSTCREDIT);
		if ($words != ""){
			$rep->NewLine(1);
			$rep->TextCol(0, 3, $myrow['curr_code'] . ": " . $words, - 2);
		}	
		$rep->Font();
		
	$rep->End();
}

*/