<?php

$page_security = 'SA_OPEN';
// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Varadha
// date_:	2019-02-19
// Title:	Print Invoices
// ----------------------------------------------------------------
//$path_to_root=dirname(dirname(__FILE__));

include_once(ABSPATH . "/includes/erp/customers_db.inc");

//----------------------------------------------------------------------------------------------------
function get_invoice_range($from){

	$sql = "SELECT trans.trans_no, trans.reference	FROM ".TB_PREF."debtor_trans trans LEFT JOIN ".TB_PREF."voided voided ON trans.type=voided.type AND trans.trans_no=voided.id
		WHERE trans.type=".ST_SALESINVOICE." AND ISNULL(voided.id) AND trans.trans_no=".fadb_escape($from)
		." ORDER BY trans.tran_date, trans.trans_no";
//echo $from;
	return fadb_query($sql, "Cant retrieve invoice range");
}

print_invoices();

//----------------------------------------------------------------------------------------------------

function print_invoices(){
	global $path_to_root, $SysPrefs, $current_user;
	
	 if($current_user['pdf_template'] == 'A4' ){
	 	print_invoice_a4();
	 	exit;
	 } /*elseif($current_user['pdf_template'] == 'A7' ){
	 	print_invoice_a7();
	 	exit;
	 }elseif($current_user['pdf_template'] == 'A8'){
	 	print_invoice_a8();
	 	exit;
	 }*/

	$show_this_payment = true; // include payments invoiced here in summary

	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");

	$from = $_GET['trans_no'];
	//$to = $_GET['trans_no'];
	$currency =  $pay_service = $comments = 	$customer = '';
	$email = 0;
	$orientation = 'P';
	$dec = user_price_dec();
	
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
   	$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');

	//-------------code-Descr-Qty--uom--tax--prc--Disc-Tot--//
	// $cols = array(4, 25,  135, 165, 210, 300);
	if($kv_batch || $kv_exp_date ){
		if($current_user['pdf_template'] == 'A6D') {
			$cols = array(4, 135, 150, 195, 225, 295);
			$aligns = array('center', 'center', 'left',	'right', 'right');
			if($kv_exp_date){
				$cols = array(4, 25, 150, 195, 230, 255, 295);
				$aligns = array('center', 'left', 'center', 'center','right','right');
			}
		}
		elseif($current_user['pdf_template'] == 'A6') {
			$cols = array(4, 35, 160, 195, 225);
			$aligns = array('center', 'center', 'left',	'right');
			if($kv_exp_date){
				$cols = array(4, 25, 150, 195, 250, 295);
				$aligns = array('center', 'left', 'center', 'center',	'right');
			}
		}
		elseif($current_user['pdf_template'] == 'A7') {
			$cols = array(4, 25, 130, 150, 185);
			$aligns = array('center', 'left', 'left',	'right');
			// if($kv_exp_date){
			// 	$cols = array(4, 20, 150, 195, 230, 235);
			// 	$aligns = array('center', 'left', 'center', 'center',	'right');
			// }
		}elseif($current_user['pdf_template'] == 'A8') {
			$cols = array(4, 125);
			$aligns = array('left');
		}
	} else {
		if($current_user['pdf_template'] == 'A6D' ) {
			$cols = array(4, 145, 180, 230, 255);
			$aligns = array('left', 'center', 'right', 'right');
		} elseif($current_user['pdf_template'] == 'A6') {
			$cols = array(4, 45,  220, 225);
			$aligns = array('center',	'left',	'right');
		} elseif($current_user['pdf_template'] == 'A7') {
			$cols = array(4, 150,195);
			$aligns = array('left',	'right');
		} elseif($current_user['pdf_template'] == 'A7D') {
			$cols = array(4, 115,  125, 155, 199);
			$aligns = array('left',	'right','right', 'right');
		} elseif($current_user['pdf_template'] == 'A8') {
			$cols = array(4, 125);
			$aligns = array('left');
		}
	}
	$pdf_template = $current_user['pdf_template'];
	if($current_user['pdf_template'] == 'A6D')
		$pdf_template = 'A6';
	elseif($current_user['pdf_template'] == 'A7D')
		$pdf_template = 'A7';
	//var_dump($cols);
	// $headers in doctext.inc
	// $aligns = array('left',	'left',	'right', 'center', 'right', 'right');

	$params = array('comments' => $comments);

	$cur = get_company_details('curr_default');

	if ($email == 0)
		$rep = new FrontReport(_("INVOICE"), _("Invoice")." - ".$_GET['trans_no'], $pdf_template, 7, $orientation);	
	
	$range = get_invoice_range($from);
	//echo $rep->fontSize;
	while($row = fadb_fetch($range)){
		
		if (!exists_customer_trans(ST_SALESINVOICE, $row['trans_no']))
			continue;
			
			$sign = 1;
			$myrow = Kvcodes_get_customer_trans($row['trans_no'], ST_SALESINVOICE);
			//print_r($myrow);
			if ($customer && $myrow['debtor_no'] != $customer) {
				continue;
			}
			if ($currency != ALL_TEXT && $myrow['curr_code'] != $currency) {
				continue;
			}
			$baccount = Kvcodes_get_default_bank_account($myrow['curr_code']);
			$params['bankaccount'] = $baccount['id'];

			$branch = Kvcodes_get_branch($myrow["branch_code"]);
			$sales_order = Kvcodes_get_sales_order_header($myrow["order_"], ST_SALESORDER);
	
			$rep->currency = $cur;
			$rep->Font();
			$rep->Info($params, $cols, null, $aligns);
			if($myrow['SalesMen'] > 0)
				$branch['salesman'] = $myrow['SalesMen'];
			//echo $branch['salesman'] .'='. $myrow['SalesMen'];
			$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'invoice', $branch['debtor_no'], true);
			$baccount['payment_service'] = $pay_service;
			
			$rep->SetCommonData($myrow, $branch, $sales_order, $baccount, ST_SALESINVOICE, $contacts);
			$rep->SetHeaderType('Headerkvcodes');
			$rep->NewPage();
			//$rep->row;
			//if($rep->pageNumber>2)
    		//	$rep->fontSize=-14;
			// calculate summary start row for later use
			// $summary_start_row = $rep->bottomMargin + (6.5 * $rep->lineHeight);
			$summary_start_row = $rep->bottomMargin +6.5;

			if ($rep->formData['prepaid']){
				$result = Kvcodes_get_sales_order_invoices($myrow['order_']);
				$prepayments = array();
				while($inv = fadb_fetch($result)){
					$prepayments[] = $inv;
					if ($inv['trans_no'] == $row['trans_no'])
					break;
				}
				if (count($prepayments) > ($show_this_payment ? 0 : 1))
					$summary_start_row += (count($prepayments)) * $rep->lineHeight;
				else
					unset($prepayments);	
			}

   			$result = Kvcodes_get_customer_trans_details(ST_SALESINVOICE, $row['trans_no']);
			$SubTotal = 0;
			if($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7' || $current_user['pdf_template'] == 'A7D' || $current_user['pdf_template'] == 'A8'){
				$rep->lineHeight = 20;
			}elseif($current_user['pdf_template'] == 'A6'){
				$rep->lineHeight = 29;
			}
			$trans_details = [];
			while ($myrow2=fadb_fetch($result)){ 
				$trans_details[] = $myrow2;
			}
			$Kit_Net = 0;
			$current_kit = '';
			foreach($trans_details as $key => $myrow2) {


				if($current_user['pdf_template'] == 'A6D')
					$rep->lineHeight = 35;
				elseif($current_user['pdf_template'] == 'A7D'){
					$rep->fontSize = 6;
					$rep->lineHeight = 25;
				}
				//$rep->lineHeight = 9;
				if ($myrow2["quantity"] == 0)
					continue;
				$sign = 1;
				$Net = round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),  user_price_dec());
				$SubTotal += $Net;
	    		$DisplayPrice = number_format2($myrow2["unit_price"],$dec);
	    		$DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
	    		$DisplayNet = number_format2($Net,$dec);
	    		
	    		if($non_detailed_sales_kit && $myrow2['kit'] != ''){
				//echo "TesT";
					if($current_kit == '')
	    				$current_kit = $myrow2['kit'];
	    				
					if($current_kit == $myrow2['kit']){
						$Kit_Net += round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),   user_price_dec());
						if($myrow2['kit'] == $trans_details[$key+1]['kit'])
							continue;
					} else
						$current_kit = '';
					
					$DisplayNet = number_format2($Kit_Net, $dec);
					$Kit_Net = 0;
					$item_detail = FAGetRow('item_codes', ['item_code' => $myrow2['kit'], 'stock_id' => $myrow2['stock_id']]);
					$myrow2['StockDescription'] = $item_detail['description'];
					//echo $myrow2['quantity'].'_'.$item_detail['quantity'];
					$DisplayQty = number_format2($myrow2['quantity']/$item_detail['quantity'], get_qty_dec($myrow2['kit']));
				}

				$c=0;
				$stock_Description = $myrow2['StockDescription'];
				if($current_user['pdf_template'] == 'A6' )
					$rep->TextCol($c++, $c,	$DisplayQty, -2);
				
				elseif($current_user['pdf_template'] == 'A7'){
					if($kv_batch|| $kv_exp_date){
						$stock_Description = $myrow2['StockDescription'];
						$rep->TextCol($c++, $c,	$DisplayQty, -2);
					} else 
						$stock_Description = $DisplayQty.'x '.$myrow2['StockDescription'];
				}
				elseif($current_user['pdf_template'] == 'A8')
					$stock_Description = $DisplayQty.'x '.$myrow2['StockDescription']."     ".$DisplayNet;
				// $rep->TextCol($c++, $c,	$myrow2['stock_id'], -2);
				$oldrow = $rep->row;
				// $rep->fontSize =7;
				$rep->TextColLines($c++, $c, $stock_Description, -2);
				$rep->row = $oldrow;

				if($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D'){
					$rep->TextCol($c++, $c,	$DisplayQty, -2);
					$rep->TextCol($c++, $c,	$DisplayPrice, -2);
				}

				if ($Net != 0.0 || !is_service($myrow2['mb_flag']) || get_company_details('no_zero_lines_amount'))		{
					// $rep->TextCol($c++, $c,	$DisplayQty, -2);
					if($kv_batch|| $kv_exp_date){
						$rep->TextColLines($c++, $c,	$myrow2['batch_no'], -2);
						if($kv_exp_date && $current_user['pdf_template'] != 'A8' && $current_user['pdf_template'] != 'A7'){
							$rep->row = $oldrow;
							$rep->TextColLines($c++, $c, ($myrow2['exp_date'] != '0000-00-00' ? date('d-m-Y', strtotime($myrow2['exp_date']))  : ''), -2);
						}
					}

					$newrow = $rep->row;
					$rep->row = $oldrow;
					//$rep->TextCol($c++, $c,	$DisplayDiscount, -2);
					if($current_user['pdf_template'] != 'A8')
						$rep->TextCol($c++, $c,	$DisplayNet, -2);
				}
				$rep->row = $newrow;
				$rep->NewLine(0.5);
				if ($rep->row < $summary_start_row){
					$rep->NewPage();
					//echo $rep->row.'_'.$summary_start_row.'-->'.$rep->pageNumber.'<br>';
				}
			}
			$rep->lineHeight = 10;
			// if(!$kv_batch && !$kv_exp_date) {
			// 	if($current_user['language'] != 'ar_EG') {
			// 		if($current_user['pdf_template'] == 'A7' || $current_user['pdf_template'] == 'A8')
			// 			$rep->SetFont('dejavu', '', 8);
			// 		else
			// 			$rep->SetFont('dejavu', '', 9);
			// 	}
			// } elseif($current_user['pdf_template'] == 'A8')
			// 		$rep->SetFont('helvetica', '', 7);
			$memo = Kvcodes_get_comments_string(ST_SALESINVOICE, $row['trans_no']);	
   			$DisplaySubTot = number_format2($SubTotal,$dec);

			// set to start of summary line:
    		// $rep->row = $summary_start_row;
    		
			if (isset($prepayments)){
				$rep->NewLine();
				// Partial invoices table
				$rep->TextCol(0, 3,_("Prepayments invoiced to this order up to day:"));
				$rep->TextCol(0, 3,	str_pad('', 150, '_'));
				$rep->cols[2] -= 20;
				$rep->aligns[2] = 'right';
				$rep->NewLine(); $c = 0; $tot_pym=0;
				$rep->TextCol(0, 3,	str_pad('', 150, '_'));
				$rep->TextCol($c++, $c, _("Date"));
				$rep->TextCol($c++, $c,	_("Invoice reference"));
				$rep->TextCol($c++, $c,	_("Amount"));

				foreach ($prepayments as $invoice)	{
					if ($show_this_payment || ($invoice['reference'] != $myrow['reference'])){
						$rep->NewLine();
						$c = 0; $tot_pym += $invoice['prep_amount'];
						$rep->TextCol($c++, $c,	sql2date($invoice['tran_date']));
						$rep->TextCol($c++, $c,	$invoice['reference']);
						$rep->TextCol($c++, $c, number_format2($invoice['prep_amount'], $dec));
					}
					if ($invoice['reference']==$myrow['reference']) break;
				}
				$rep->TextCol(0, 3,	str_pad('', 150, '_'));
				$rep->NewLine();
				$rep->TextCol(1, 2,	_("Total payments:"));
				$rep->TextCol(2, 3,	number_format2($tot_pym, $dec));
			}

			$doctype = ST_SALESINVOICE;
    		// $rep->row = $summary_start_row;
			// $rep->cols[2] += 20;
			// $rep->cols[3] += 20;
			// $rep->aligns[3] = 'left';
    		$rep->Line($rep->row+5);
    		$rep->NewLine(0.6);
    		//$rep->Font();

    		if($current_user['pdf_template'] == 'A6'){
				$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Sub-total"), -2);
				$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplaySubTot, -2);
			} elseif($current_user['pdf_template'] == 'A6D'){
				$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 6 : 3)), _("Sub-total"), -2);
				$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 6 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 6 : 4)),	$DisplaySubTot, -2);
			} elseif($current_user['pdf_template'] == 'A7'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 3, _("Sub-total"), -2);
					$rep->TextCol(3, 4,	$DisplaySubTot, -2);
				} else {
					$rep->TextCol(0, 1, _("Sub-total"), -2);
					$rep->TextCol(1, 2, $DisplaySubTot, -2);
				}
			} elseif($current_user['pdf_template'] == 'A7D'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 5, _("Sub-total"), -2);
					$rep->TextCol(5, 6,	$DisplaySubTot, -2);
				} else {
					$rep->TextCol(0, 3, _("Sub-total"), -2);
					$rep->TextCol(3, 4, $DisplaySubTot, -2);
				}
			} elseif($current_user['pdf_template'] == 'A8'){
				$rep->TextCol(0, 1, _("Sub-total"). " : ". $DisplaySubTot, -2);
			}

			$rep->NewLine(0.8);
			if ($myrow['ov_freight'] != 0.0 || $myrow['ov_gst'] != 0.0){
				//$rep->Line($rep->row);	
				$rep->NewLine();
			}
			if ($myrow['ov_freight'] != 0.0){
   				$DisplayFreight = number_format2($sign*$myrow["ov_freight"],$dec);
   				if($current_user['pdf_template'] == 'A6' ){
					$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Shipping"), -2);
					$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplayFreight, -2);
				} elseif($current_user['pdf_template'] == 'A6D'){
					$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), _("Shipping"), -2);
					$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 2)), ($kv_batch ? 5 : ($kv_exp_date ? 6 : 3)),	$DisplayFreight, -2);
				} elseif($current_user['pdf_template'] == 'A7'){

					if($kv_batch || $kv_exp_date){
						$rep->TextCol(1, 3, _("Shipping"), -2);
						$rep->TextCol(3, 4,	$DisplayFreight, -2);
					} else {
						$rep->TextCol(0, 1, _("Shipping"), -2);
						$rep->TextCol(1, 2, $DisplayFreight, -2);
					}
				}elseif($current_user['pdf_template'] == 'A7D'){

					if($kv_batch || $kv_exp_date){
						$rep->TextCol(1, 5, _("Shipping"), -2);
						$rep->TextCol(5, 6,	$DisplayFreight, -2);
					} else {
						$rep->TextCol(0, 3, _("Shipping"), -2);
						$rep->TextCol(3, 4, $DisplayFreight, -2);
					}
				}elseif($current_user['pdf_template'] == 'A8'){
					$rep->TextCol(0, 1, _("Shipping"). " : ". $DisplayFreight, -2);
				}
				$rep->NewLine(0.6);
			}

			$tax_items = Kvcodes_get_trans_tax_details(ST_SALESINVOICE, $row['trans_no']);
			$first = true;
    		while ($tax_item = fadb_fetch($tax_items))		{

    			if ($tax_item['amount'] == 0)
    				continue;
    			$DisplayTax = number_format2($sign*$tax_item['amount'], $dec);

    			if (get_company_details('suppress_tax_rates') == 1)
    				$tax_type_name = $tax_item['tax_type_name'];
    			else
    				$tax_type_name = $tax_item['tax_type_name']." (".$tax_item['rate']."%) ";

    			if ($myrow['tax_included'])	{
    				if (get_company_details('alternative_tax_include_on_docs') == 1)	{
    					if ($first)	{
    						if($current_user['pdf_template'] == 'A6' ){
								$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), _("Total Tax Excluded"), -2);
								$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), 5,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
							} elseif($current_user['pdf_template'] == 'A6D'){
								$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 5 : 3)), ($kv_batch ? 4 : ($kv_exp_date ? 6 : 4)), _("Total Tax Excluded"), -2);
								$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 6 : 4)), 5,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
							} elseif($current_user['pdf_template'] == 'A7'){
								if($kv_batch || $kv_exp_date){
									$rep->TextCol(1, 3, _("Total Tax Excluded"), -2);
									$rep->TextCol(3, 4,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
								} else {
									$rep->TextCol(0,1,   _("Total Tax Excluded"), -2);
									$rep->TextCol(1,2,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
								}
							}elseif($current_user['pdf_template'] == 'A7d'){
								if($kv_batch || $kv_exp_date){
									$rep->TextCol(1, 5, _("Total Tax Excluded"), -2);
									$rep->TextCol(5, 6,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
								} else {
									$rep->TextCol(0,3,   _("Total Tax Excluded"), -2);
									$rep->TextCol(3,4,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
								}
							}
							elseif($current_user['pdf_template'] == 'A8'){
								$rep->TextCol(0, 1,  _("Total Tax Excluded") ." : ".number_format2($sign*$tax_item['net_amount'], $dec), -2);
							}
							$rep->NewLine(0.7);
    					}
    					if($current_user['pdf_template'] == 'A6' ){
							$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $tax_type_name, -2);
							$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplayTax, -2);
						} elseif($current_user['pdf_template'] == 'A6D'){
							$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $tax_type_name, -2);
							$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 2)), ($kv_batch ? 5 : ($kv_exp_date ? 6 : 4)),	$DisplayTax, -2);
						} elseif($current_user['pdf_template'] == 'A7'){
							if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 3, $tax_type_name . _("Amt"), -2);
								$rep->TextCol(3, 4,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,1,  $tax_type_name . _("Amt"), -2);
								$rep->TextCol(1,2,	$DisplayTax, -2);
							}
						}elseif($current_user['pdf_template'] == 'A7D'){
							if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 5, $tax_type_name . _("Amt"), -2);
								$rep->TextCol(5, 6,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,3,  $tax_type_name . _("Amt"), -2);
								$rep->TextCol(3,4,	$DisplayTax, -2);
							}
						}
						elseif($current_user['pdf_template'] == 'A8'){
							$rep->TextCol(0, 1, $tax_type_name . _("Amt") ." : ".$DisplayTax, -2);
						}
						$first = false;
    				}
    				else{
    					
						$rep->fontSize = 8;
						if($current_user['pdf_template'] == 'A6' ){
							$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
							$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),$DisplayTax, -2);
						} elseif($current_user['pdf_template'] == 'A6D'){
							$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
							$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 2)), ($kv_batch ? 5 : ($kv_exp_date ? 6 : 4)),$DisplayTax, -2);
						} elseif($current_user['pdf_template'] == 'A7'){
							if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 3, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
								$rep->TextCol(3, 4,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,1, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
								$rep->TextCol(1,2,	$DisplayTax, -2);
							}
						} elseif($current_user['pdf_template'] == 'A7D'){
							if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 5, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
								$rep->TextCol(5, 6,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,3, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
								$rep->TextCol(3,4,	$DisplayTax, -2);
							}
						}
						elseif($current_user['pdf_template'] == 'A8'){
							$rep->TextCol(0, 1, _("Incld.") . " " . $tax_type_name . _("Amt") ." : ".$DisplayTax, -2);
						}
						if($current_user['pdf_template'] == 'A7' || $current_user['pdf_template'] == 'A8')
							$rep->fontSize = 8;
						else
							$rep->fontSize = 9;
					}
				}	else	{
					if($current_user['pdf_template'] == 'A6' ){
						$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $tax_type_name, -2);
						$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplayTax, -2);
					} elseif($current_user['pdf_template'] == 'A6D'){
						$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $tax_type_name, -2);
						$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 2)), ($kv_batch ? 5 : ($kv_exp_date ? 6 : 4)),	$DisplayTax, -2);
					} elseif($current_user['pdf_template'] == 'A7'){
						if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 3,  $tax_type_name, -2);
								$rep->TextCol(3, 4,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,1, $tax_type_name, -2);
								$rep->TextCol(1,2,	$DisplayTax, -2);
							}
					}elseif($current_user['pdf_template'] == 'A7D'){
						if($kv_batch || $kv_exp_date){
								$rep->TextCol(1, 5,  $tax_type_name, -2);
								$rep->TextCol(5, 6,	$DisplayTax, -2);
							} else {
								$rep->TextCol(0,3, $tax_type_name, -2);
								$rep->TextCol(3,4,	$DisplayTax, -2);
							}
					}
					elseif($current_user['pdf_template'] == 'A8'){
						$rep->TextCol(0, 1, $tax_type_name ." : ".$DisplayTax, -2);
					}
				}
				$rep->NewLine(0.7);
    		}
    		//$rep->Line($rep->row);
    		$rep->NewLine(0.7);

			$DisplayTotal = number_format2($sign*($myrow["ov_freight"] + $myrow["ov_gst"] +
				$myrow["ov_amount"]+$myrow["ov_freight_tax"]),$dec);
			$rep->Font('bold');
			$rep->aligns[1] = 'center';
			//if (!$myrow['prepaid']) $rep->Font('bold');
			$rep->row -= 5;
			if($current_user['pdf_template'] == 'A6' ){
				$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $rep->formData['prepaid'] ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), - 2);
				$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $DisplayTotal, -2);
			} elseif($current_user['pdf_template'] == 'A6D'){
				$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $rep->formData['prepaid'] ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), - 2);
				$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 2)), ($kv_batch ? 5 : ($kv_exp_date ? 6 : 4)), $DisplayTotal, -2);
			} elseif($current_user['pdf_template'] == 'A7'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 3, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), -2);
					$rep->TextCol(3, 4,	$DisplayTotal, -2);
				} else {
					$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), - 2);
					$rep->TextCol(1,2, $DisplayTotal, -2);
				}
			} elseif($current_user['pdf_template'] == 'A7D'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 5, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), -2);
					$rep->TextCol(5, 6,	$DisplayTotal, -2);
				} else {
					$rep->TextCol(0, 3, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), - 2);
					$rep->TextCol(3, 4, $DisplayTotal, -2);
				}
			}elseif($current_user['pdf_template'] == 'A8'){
				$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE") ." : ". $DisplayTotal, -2);
			}
			if ($rep->formData['prepaid'])	{
				$rep->NewLine();
				//$rep->Font('bold');
				if($current_user['pdf_template'] == 'A6'){
					$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), - 2);
					$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), number_format2($myrow['prep_amount'], $dec), -2);
				}elseif($current_user['pdf_template'] == 'A6D'){
					$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)), $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), - 2);
					$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 5 : 2)), ($kv_batch ? 5 : ($kv_exp_date ? 6 : 3)), number_format2($myrow['prep_amount'], $dec), -2);
				}elseif($current_user['pdf_template'] == 'A7'){
					if($kv_batch || $kv_exp_date){
						$rep->TextCol(1, 3, $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), -2);
						$rep->TextCol(3, 4,	number_format2($myrow['prep_amount'], $dec), -2);
					} else {
						$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), - 2);
						$rep->TextCol(1,2, number_format2($myrow['prep_amount'], $dec), -2);
					}
				}elseif($current_user['pdf_template'] == 'A7D'){
					if($kv_batch || $kv_exp_date){
						$rep->TextCol(1, 5, $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), -2);
						$rep->TextCol(5, 6,	number_format2($myrow['prep_amount'], $dec), -2);
					} else {
						$rep->TextCol(0, 3, $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), - 2);
						$rep->TextCol(3,4, number_format2($myrow['prep_amount'], $dec), -2);
					}
				}
				elseif($current_user['pdf_template'] == 'A8'){
					$rep->TextCol(0, 1, $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE") ." : ". number_format2($myrow['prep_amount'], $dec), -2);
				}
			}
			$words = price_in_words($rep->formData['prepaid'] ? $myrow['prep_amount'] : $myrow['Total'], array( 'type' => ST_SALESINVOICE, 'currency' => $myrow['curr_code']));
			$rep->NewLine(0.7);
			$rep->Font();

			$bank_name = get_invoice_payment_informations($row['trans_no']);
			$rep->Line($rep->row);
			if($bank_name != ''){		
				
				if($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D'){
					$rep->NewLine();
					$rep->TextCol(0, 1, _("Payment Modes"), -2);
					$rep->TextCol(1,4, $bank_name, -2);
				}elseif($current_user['pdf_template'] == 'A7'){
					$rep->NewLine();
					$rep->TextCol(0, 1, _("Payment Modes"), -2);
					$rep->TextCol(1,2, $bank_name, -2);
				}elseif($current_user['pdf_template'] == 'A6'){
					$rep->NewLine();
					$rep->TextCol(1, 2, _("Payment Modes"), -2);
					$rep->TextCol(2,3, $bank_name, -2);
				}elseif($current_user['pdf_template'] == 'A8'){
					$rep->NewLine(0.9);
					$rep->TextCol(0, 1, _("Payment Modes")." ".$bank_name, -2);
				}
				$rep->NewLine(0.7);
				//$rep->Line($rep->row);
			}
			if($myrow['Total'] > 0){			
				
				if($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D'){
					$rep->NewLine();
					$rep->TextCol(0, 1, _("Tendered Amount"), -2);
					$rep->TextCol(3,4, number_format2($myrow['ov_change']+$myrow['Total'], $dec), -2);
				}elseif($current_user['pdf_template'] == 'A6'){
					$rep->NewLine();
					$rep->TextCol(1, 2, _("Tendered Amount"), -2);
					$rep->TextCol(2,3, number_format2($myrow['ov_change']+$myrow['Total'], $dec), -2);
				}elseif($current_user['pdf_template'] == 'A7'){
					$rep->NewLine();
					$rep->TextCol(0, 1, _("Tendered Amount"), -2);
					$rep->TextCol(1,2, number_format2($myrow['ov_change']+$myrow['Total'], $dec), -2);
				}elseif($current_user['pdf_template'] == 'A8'){
					$rep->NewLine(0.8);
					$rep->TextCol(0, 1, _("Tendered Amount")." ".number_format2($myrow['ov_change']+$myrow['Total'], $dec), -2);
				}
				$rep->NewLine(0.7);
				//$rep->Line($rep->row);
			}
			if($myrow['ov_change'] > 0){
				
				if($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D'){
					$rep->NewLine();
					$rep->TextCol(0, 1, _("Change"), -2);
					$rep->TextCol(3,4, number_format2($myrow['ov_change'], $dec), -2);
					$rep->NewLine(0.7);
				}elseif($current_user['pdf_template'] == 'A7'){
					$rep->NewLine();
					$rep->TextCol(0, 1, _("Change"), -2);
					$rep->TextCol(1,2, number_format2($myrow['ov_change'], $dec), -2);
					$rep->NewLine(0.7);
				}elseif($current_user['pdf_template'] == 'A6'){
					$rep->NewLine();
					$rep->TextCol(1, 2, _("Change"), -2);
					$rep->TextCol(2,3, number_format2($myrow['ov_change'], $dec), -2);
					$rep->NewLine(0.7);
				}elseif($current_user['pdf_template'] == 'A8'){
					$rep->NewLine(0.7);
					$rep->TextCol(0, 1, _("Change")." ".number_format2($myrow['ov_change'], $dec), -2);
					$rep->NewLine(0.3);
				}
				//$rep->NewLine(0.7);
				//$rep->Line($rep->row);
			}
			$rep->Line($rep->row);
			if ($memo != "")	{
				$rep->NewLine();
				
				$rep->aligns[3] = 'center';
				if($current_user['pdf_template'] == 'A6' || $current_user['pdf_template'] == 'A6D')
					$rep->TextColLines(0, 3,'Paid Through '. $memo, -2);
				elseif($current_user['pdf_template'] == 'A7'){
					$rep->TextColLines(0, ($kv_batch || $kv_exp_date ? 3 : 2), 'Paid Through '. $memo, -2);
				}elseif($current_user['pdf_template'] == 'A7D'){
					$rep->TextColLines(0, ($kv_batch || $kv_exp_date ? 5 : 4), 'Paid Through '. $memo, -2);
				}
				elseif($current_user['pdf_template'] == 'A8')
					$rep->TextColLines(0, 1, 'Paid Through '. $memo, -2);
			}
			if ($words != "")	{
				$rep->NewLine(1);
				if($current_user['pdf_template'] == 'A6' || $current_user['pdf_template'] == 'A6D')
					$rep->TextColLines(1, 3, $myrow['curr_code'] . ": " . $words, - 2);
				elseif($current_user['pdf_template'] == 'A7')
					$rep->TextColLines(0, ($kv_batch || $kv_exp_date ? 3 : 2), $myrow['curr_code'] . ": " . $words, - 2);
				elseif($current_user['pdf_template'] == 'A7D')
					$rep->TextColLines(0, ($kv_batch || $kv_exp_date ? 5 : 4), $myrow['curr_code'] . ": " . $words, - 2);
				elseif($current_user['pdf_template'] == 'A8')
					$rep->TextColLines(0, 1, $myrow['curr_code'] . ": " . $words, - 2);
			}

			// Footer
			$rep->Font('italic');
			$rep->Line($rep->row);
			if($current_user['pdf_template'] == 'A6' || $current_user['pdf_template'] == 'A6D')
				$col_End = 6;
			elseif($current_user['pdf_template'] == 'A7'){
				$col_End = ($kv_batch || $kv_exp_date ? 3 : 2);
			}elseif($current_user['pdf_template'] == 'A7d'){
				$col_End = ($kv_batch || $kv_exp_date ? 5 : 4);
			}
			elseif($current_user['pdf_template'] == 'A8')
				$col_End = 1;
			foreach ($rep->Footer as $line => $txt){
				if (!is_numeric($line))	{// title => link
					$rep->NewLine();
					$rep->aligns[0] = 'center';
					$rep->fontSize = 6;
					$rep->TextCol(0, $col_End,$line, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 255);
					$rep->TextCol(0, $col_End,$txt, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 0);
					// $this->addLink($txt, $ccol, $this->row, $this->pageWidth - $this->rightMargin, $this->row + $this->lineHeight);
					$rep->fontSize = 7;
				}	else{
					if($current_user['pdf_template'] == 'A6'){
						$rep->NewLine(1.7);
					} else 
						$rep->NewLine();
					$rep->aligns[0] = 'center';
					// $rep->TextWrap(0, $rep->row,5,$txt,'C');
					$rep->TextCol(0, $col_End,$txt, - 2);
				}
			}

			$rep->Font();
			if ($email == 1){
				$rep->End($email);
			}
	}
	if ($email == 0)
		$rep->End();
}


function get_invoice_payment_informations($trans_no) {

	$sql = "SELECT   bnk.bank_act,    bnk_acc.*
	 FROM  ".TB_PREF."debtor_trans as trans,".TB_PREF."debtors_master as debtor,".TB_PREF."cust_allocations as alloc LEFT JOIN ".TB_PREF."bank_trans as bnk ON bnk.trans_no = alloc.trans_no_from	AND bnk.type = alloc.trans_type_from
            LEFT JOIN ".TB_PREF."bank_accounts AS bnk_acc ON bnk.bank_act = bnk_acc.id
	 WHERE trans.debtor_no=debtor.debtor_no
			AND trans.trans_no = alloc.trans_no_from
			AND trans.type = alloc.trans_type_from            
            
			AND trans.debtor_no = alloc.person_id AND alloc.trans_no_to=".fadb_escape($trans_no)."
		  		  AND alloc.trans_type_to=".ST_SALESINVOICE."  ORDER BY trans.trans_no";

	$res = fadb_query($sql, "Can't get bank details");
	$names = '';

	if(fadb_num_rows($res) > 0){
		while($row = fadb_fetch($res)){
			$names .= $row['bank_account_name'].', ';
		}
	}
	$names = substr($names, 0, -2);
	return $names;
}