<?php

$page_security = 'SA_OPEN';
// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Varadha
// date_:	2019-02-19
// Title:	Print Invoices
// ----------------------------------------------------------------
//$path_to_root=dirname(dirname(__FILE__));

include_once(ABSPATH . "/includes/erp/customers_db.inc");

//----------------------------------------------------------------------------------------------------
function get_invoice_range($from){

	$sql = "SELECT trans.trans_no, trans.reference	FROM ".TB_PREF."debtor_trans trans LEFT JOIN ".TB_PREF."voided voided ON trans.type=voided.type AND trans.trans_no=voided.id
		WHERE trans.type=".ST_SALESINVOICE." AND ISNULL(voided.id) AND trans.trans_no=".fadb_escape($from)
		." ORDER BY trans.tran_date, trans.trans_no";
//echo $from;
	return fadb_query($sql, "Cant retrieve invoice range");
}

print_invoices();

//----------------------------------------------------------------------------------------------------

function print_invoices(){
	global $path_to_root, $SysPrefs;
	
	$show_this_payment = true; // include payments invoiced here in summary

	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");

	$from = $_GET['trans_no'];
	//$to = $_GET['trans_no'];
	$currency =  $pay_service = $comments = 	$customer = '';
	$email = 0;
	$orientation = 'P';
	$dec = user_price_dec();

	//-------------code-Descr-Qty--uom--tax--prc--Disc-Tot--//
	// $cols = array(4, 25,  135, 165, 210, 300);
	$cols = array(4, 45,  220, 225);
	$aligns = array('center',	'center',	'center');
	// $headers in doctext.inc
	// $aligns = array('left',	'left',	'right', 'center', 'right', 'right');

	$params = array('comments' => $comments);

	$cur = get_company_details('curr_default');

	if ($email == 0)
		$rep = new FrontReport(_('INVOICE'), "Invoice - ".$_GET['trans_no'], 'A6', 9, $orientation);	
	
	$range = get_invoice_range($from);

	while($row = fadb_fetch($range)){
		
		if (!exists_customer_trans(ST_SALESINVOICE, $row['trans_no']))
			continue;
			
			$sign = 1;
			$myrow = Kvcodes_get_customer_trans($row['trans_no'], ST_SALESINVOICE);
			//print_r($myrow);
			if ($customer && $myrow['debtor_no'] != $customer) {
				continue;
			}
			if ($currency != ALL_TEXT && $myrow['curr_code'] != $currency) {
				continue;
			}
			$baccount = Kvcodes_get_default_bank_account($myrow['curr_code']);
			$params['bankaccount'] = $baccount['id'];

			$branch = Kvcodes_get_branch($myrow["branch_code"]);
			$sales_order = Kvcodes_get_sales_order_header($myrow["order_"], ST_SALESORDER);
	
			$rep->currency = $cur;
			$rep->Font();
			$rep->Info($params, $cols, null, $aligns);
			if($myrow['SalesMen'] > 0)
				$branch['salesman'] = $myrow['SalesMen'];
			//echo $branch['salesman'] .'='. $myrow['SalesMen'];
			$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'invoice', $branch['debtor_no'], true);
			$baccount['payment_service'] = $pay_service;
			
			$rep->SetCommonData($myrow, $branch, $sales_order, $baccount, ST_SALESINVOICE, $contacts);
			$rep->SetHeaderType('Headerkvcodes');
			$rep->NewPage();
			$rep->row;
			// calculate summary start row for later use
			// $summary_start_row = $rep->bottomMargin + (6.5 * $rep->lineHeight);
			$summary_start_row = $rep->bottomMargin +6.5;

			if ($rep->formData['prepaid']){
				$result = Kvcodes_get_sales_order_invoices($myrow['order_']);
				$prepayments = array();
				while($inv = fadb_fetch($result)){
					$prepayments[] = $inv;
					if ($inv['trans_no'] == $row['trans_no'])
					break;
				}
				if (count($prepayments) > ($show_this_payment ? 0 : 1))
					$summary_start_row += (count($prepayments)) * $rep->lineHeight;
				else
					unset($prepayments);	
			}

   			$result = Kvcodes_get_customer_trans_details(ST_SALESINVOICE, $row['trans_no']);
			$SubTotal = 0;
			while ($myrow2=fadb_fetch($result))	{
				if ($myrow2["quantity"] == 0)
					continue;

				$Net = round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),
				   user_price_dec());
				$SubTotal += $Net;
	    		$DisplayPrice = number_format2($myrow2["unit_price"],$dec);
	    		$DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
	    		$DisplayNet = number_format2($Net,$dec);
	    		if ($myrow2["discount_percent"]==0)
		  			$DisplayDiscount ="";
	    		else
		  			$DisplayDiscount = number_format2($myrow2["discount_percent"]*100,user_percent_dec()) . "%";
				$c=0;
				$rep->TextCol($c++, $c,	$DisplayQty, -2);
				// $rep->TextCol($c++, $c,	$myrow2['stock_id'], -2);
				$oldrow = $rep->row;
				$rep->TextColLines($c++, $c, $myrow2['StockDescription'], -2);
				$newrow = $rep->row;
				$rep->row = $oldrow;
				if ($Net != 0.0 || !is_service($myrow2['mb_flag']) || get_company_details('no_zero_lines_amount'))		{
					// $rep->TextCol($c++, $c,	$DisplayQty, -2);
					//$rep->TextCol($c++, $c,	$myrow2['units'], -2);
					// $rep->TextCol($c++, $c,	$DisplayPrice, -2);
					//$rep->TextCol($c++, $c,	$DisplayDiscount, -2);
					$rep->TextCol($c++, $c,	$DisplayNet, -2);
				}
				$rep->row = $newrow;
				//$rep->NewLine(1);
				if ($rep->row < $summary_start_row)
					$rep->NewPage();
			}

			$memo = Kvcodes_get_comments_string(ST_SALESINVOICE, $row['trans_no']);
			

   			$DisplaySubTot = number_format2($SubTotal,$dec);

			// set to start of summary line:
    		// $rep->row = $summary_start_row;
    		
			if (isset($prepayments)){
				$rep->NewLine();
				// Partial invoices table
				$rep->TextCol(0, 3,_("Prepayments invoiced to this order up to day:"));
				$rep->TextCol(0, 3,	str_pad('', 150, '_'));
				$rep->cols[2] -= 20;
				$rep->aligns[2] = 'right';
				$rep->NewLine(); $c = 0; $tot_pym=0;
				$rep->TextCol(0, 3,	str_pad('', 150, '_'));
				$rep->TextCol($c++, $c, _("Date"));
				$rep->TextCol($c++, $c,	_("Invoice reference"));
				$rep->TextCol($c++, $c,	_("Amount"));

				foreach ($prepayments as $invoice)	{
					if ($show_this_payment || ($invoice['reference'] != $myrow['reference'])){
						$rep->NewLine();
						$c = 0; $tot_pym += $invoice['prep_amount'];
						$rep->TextCol($c++, $c,	sql2date($invoice['tran_date']));
						$rep->TextCol($c++, $c,	$invoice['reference']);
						$rep->TextCol($c++, $c, number_format2($invoice['prep_amount'], $dec));
					}
					if ($invoice['reference']==$myrow['reference']) break;
				}
				$rep->TextCol(0, 3,	str_pad('', 150, '_'));
				$rep->NewLine();
				$rep->TextCol(1, 2,	_("Total payments:"));
				$rep->TextCol(2, 3,	number_format2($tot_pym, $dec));
			}

			$doctype = ST_SALESINVOICE;
    		// $rep->row = $summary_start_row;
			// $rep->cols[2] += 20;
			// $rep->cols[3] += 20;
			// $rep->aligns[3] = 'left';
    		$rep->Line($rep->row);
    		$rep->NewLine();
			$rep->TextCol(1, 2, _("Sub-total"), -2);
			$rep->TextCol(2, 3,	$DisplaySubTot, -2);
			$rep->NewLine();
			$rep->Line($rep->row);	
			$rep->NewLine();
			if ($myrow['ov_freight'] != 0.0){
   				$DisplayFreight = number_format2($sign*$myrow["ov_freight"],$dec);
				$rep->TextCol(1, 2, _("Shipping"), -2);
				$rep->TextCol(2, 3,	$DisplayFreight, -2);
				$rep->NewLine();
			}
			$tax_items = Kvcodes_get_trans_tax_details(ST_SALESINVOICE, $row['trans_no']);
			$first = true;
    		while ($tax_item = fadb_fetch($tax_items))		{
    			if ($tax_item['amount'] == 0)
    				continue;
    			$DisplayTax = number_format2($sign*$tax_item['amount'], $dec);

    			if (get_company_details('suppress_tax_rates') == 1)
    				$tax_type_name = $tax_item['tax_type_name'];
    			else
    				$tax_type_name = $tax_item['tax_type_name']." (".$tax_item['rate']."%) ";

    			if ($myrow['tax_included'])	{
    				if (get_company_details('alternative_tax_include_on_docs') == 1)	{
    					if ($first)	{
							$rep->TextCol(2, 4, _("Total Tax Excluded"), -2);
							$rep->TextCol(4, 5,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
							$rep->NewLine();
    					}
						$rep->TextCol(1, 2, $tax_type_name, -2);
						$rep->TextCol(2, 3,	$DisplayTax, -2);
						$first = false;
    				}
    				else{
						$rep->fontSize -= 1;
						$rep->TextCol(1, 2, _("Incld.") . " " . $tax_type_name . _("Amt"), -2);
						$rep->TextCol(2, 3,$DisplayTax, -2);
						$rep->fontSize += 1;
					}
				}	else	{
					$rep->TextCol(1, 2, $tax_type_name, -2);
					$rep->TextCol(2, 3,	$DisplayTax, -2);
				}
				$rep->NewLine();
    		}
    		$rep->Line($rep->row);
    		$rep->NewLine();

			$DisplayTotal = number_format2($sign*($myrow["ov_freight"] + $myrow["ov_gst"] +
				$myrow["ov_amount"]+$myrow["ov_freight_tax"]),$dec);
			$rep->Font('bold');
			$rep->aligns[1] = 'center';
			if (!$myrow['prepaid']) $rep->Font('bold');
				$rep->TextCol(1, 2, $rep->formData['prepaid'] ? _("TOTAL ORDER VAT INCL.") : _("TOTAL INVOICE"), - 2);
			$rep->TextCol(2, 3, $DisplayTotal, -2);
			if ($rep->formData['prepaid'])	{
				$rep->NewLine();
				$rep->Font('bold');
				$rep->TextCol(1, 2, $rep->formData['prepaid']=='final' ? _("THIS INVOICE") : _("TOTAL INVOICE"), - 2);
				$rep->TextCol(2, 3, number_format2($myrow['prep_amount'], $dec), -2);
			}
			$words = price_in_words($rep->formData['prepaid'] ? $myrow['prep_amount'] : $myrow['Total']
				, array( 'type' => ST_SALESINVOICE, 'currency' => $myrow['curr_code']));
			$rep->NewLine();
			if ($memo != "")	{
				$rep->NewLine();
				$rep->Font();
				$rep->aligns[3] = 'center';
				$rep->TextColLines(0, 3,'Paid Through '. $memo, -2);
			}
			if ($words != "")	{
				$rep->NewLine(1);
				$rep->TextColLines(1, 3, $myrow['curr_code'] . ": " . $words, - 2);
			}




			// Footer
			$rep->Font('italic');
			$rep->Line($rep->row);
			foreach ($rep->Footer as $line => $txt){
				if (!is_numeric($line))	// title => link
				{
					$rep->NewLine();
					$rep->aligns[0] = 'center';
					$rep->fontSize -= 2;
					$rep->TextCol(0, 6,$line, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 255);
					$rep->TextCol(0, 6,$txt, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 0);
					// $this->addLink($txt, $ccol, $this->row, $this->pageWidth - $this->rightMargin, $this->row + $this->lineHeight);
					$rep->fontSize += 2;
				}
				else{
					$rep->NewLine();
					$rep->aligns[0] = 'center';
					// $rep->TextWrap(0, $rep->row,5,$txt,'C');
					$rep->TextCol(0, 6,$txt, - 2);
				}
			}

			$rep->Font();
			if ($email == 1){
				$rep->End($email);
			}
	}
	if ($email == 0)
		$rep->End();
}