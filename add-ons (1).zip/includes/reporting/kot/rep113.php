<?php
$page_security = 'SA_OPEN';
// ----------------------------------------------------------------
// $ Revision:	2.0 $
// Creator:	Varadha
// date_:	2019-03-19
// Title:	Print Credit Notes
// ----------------------------------------------------------------

//----------------------------------------------------------------------------------------------------

print_credits();

//----------------------------------------------------------------------------------------------------

function print_credits(){
	global  $SysPrefs;
	
	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");

	$i = $_GET['trans_no'];
	//$to = $_POST['PARAM_1'];
	//$currency = $_POST['PARAM_2'];
	//$email = $_POST['PARAM_3'];
	//$paylink = $_POST['PARAM_4'];
	//$comments = $_POST['PARAM_5'];
	$orientation = $_POST['PARAM_6'];

	if (!$i ) return;

	$orientation = ($orientation ? 'L' : 'P');
	$dec = user_price_dec();
		
	//$cols = array(4, 60, 225, 300, 325, 385, 450, 515);

	// $headers in doctext.inc
	//$aligns = array('left',	'left',	'right', 'left', 'right', 'right', 'right');
	
	$cols = array(4, 45,  220, 225);

	// $headers in doctext.inc
	$aligns = array('left',	'center', 'right');	
	
	//$params = array('comments' => $comments);
	$cur = get_company_Pref('curr_default');	
	$rep = new FrontReport(_('RETURN NOTE'), "Return- ".$_GET['trans_no'] , 'A6', 9, 'P');

		if (!exists_customer_trans(ST_CUSTCREDIT, $i))
			die();
		$sign = -1;
		$myrow = Kvcodes_get_customer_trans($i, ST_CUSTCREDIT);
		/*if ($currency != ALL_TEXT && $myrow['curr_code'] != $currency) {
			continue;
		}*/
		$baccount = Kvcodes_get_default_bank_account($myrow['curr_code']);
		$params['bankaccount'] = $baccount['id'];

		$branch = Kvcodes_get_branch($myrow["branch_code"]);
		$branch['disable_branch'] = ''; //$paylink; // helper
		$sales_order = null;

		$rep->currency = $myrow['curr_code'];
		$rep->Font();
		$rep->Info($params, $cols, null, $aligns);

		$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'invoice', $branch['debtor_no'], true);
		$rep->SetCommonData($myrow, $branch, $sales_order, $baccount, ST_CUSTCREDIT, $contacts);
		$rep->SetHeaderType('Header2');
		$rep->NewPage();

		$result = Kvcodes_get_customer_trans_details(ST_CUSTCREDIT, $i);
		$SubTotal = 0;
		while ($myrow2=db_fetch($result)){
			if ($myrow2["quantity"] == 0)
				continue;

			$Net = round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),
			   user_price_dec());
			$SubTotal += $Net;
			$DisplayPrice = number_format2($myrow2["unit_price"],$dec);
			$DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
			$DisplayNet = number_format2($Net,$dec);
			if ($myrow2["discount_percent"]==0)
				$DisplayDiscount ="";
			else
				$DisplayDiscount = number_format2($myrow2["discount_percent"]*100,user_percent_dec()) . "%";
			$rep->TextCol(0, 1,abs($DisplayQty), -2);
			//$rep->TextCol(0, 1,	$myrow2['stock_id'], -2);
			$oldrow = $rep->row;
			$rep->TextColLines(1, 2, $myrow2['StockDescription'], -2);
			$newrow = $rep->row;
			$rep->row = $oldrow;
			//$rep->TextCol(2, 3,	$DisplayQty, -2);
			//$rep->TextCol(3, 4,	$myrow2['units'], -2);
			//$rep->TextCol(3, 4,	$DisplayPrice, -2);
			//$rep->TextCol(5, 6,	$DisplayDiscount, -2);
			$rep->TextCol(2, 3,	abs($DisplayNet), -2);
			$rep->row = $newrow;
			if ($rep->row < $rep->bottomMargin + (15 * $rep->lineHeight))
				$rep->NewPage();
		}

		$memo = '';//get_comments_string(ST_CUSTCREDIT, $i);
		if ($memo != "")	{
			$rep->NewLine();
			$rep->TextColLines(1, 3, $memo, -2);
		}

		$DisplaySubTot = number_format2($SubTotal,$dec);

		$rep->row = $rep->bottomMargin + (15 * $rep->lineHeight);
		$doctype = ST_CUSTCREDIT;

		$rep->TextCol(1, 2, _("Sub-total"), -2);
		$rep->TextCol(2, 3,	$DisplaySubTot, -2);
		$rep->NewLine();
		if ($myrow['ov_freight'] != 0.0)	{
			$DisplayFreight = number_format2($sign*$myrow["ov_freight"],$dec);
			$rep->TextCol(0, 2, _("Shipping"), -2);
			$rep->TextCol(2, 3,	$DisplayFreight, -2);
			$rep->NewLine();
		}
		$tax_items = Kvcodes_get_trans_tax_details(ST_CUSTCREDIT, $i);
		$first = true;
		while ($tax_item = fadb_fetch($tax_items))	{
			//echo $tax_item['amount'].'<br>';
			if ($tax_item['amount'] == 0)
				continue;
			$DisplayTax = number_format2($sign*$tax_item['amount'], $dec);

			if (get_company_details('suppress_tax_rates') == 1)
				$tax_type_name = $tax_item['tax_type_name'];
			else
				$tax_type_name = $tax_item['tax_type_name']." (".$tax_item['rate']."%) ";

			if ($myrow['tax_included'])	{
				if (get_company_details('alternative_tax_include_on_docs') == 1)	{
					if ($first)	{
						$rep->TextCol(0, 2, _("Total Tax Excluded"), -2);
						$rep->TextCol(2, 3,	number_format2($sign*$tax_item['net_amount'], $dec), -2);
						$rep->NewLine();
					}
					$rep->TextCol(0, 2, $tax_type_name, -2);
					$rep->TextCol(2, 3,	$DisplayTax, -2);
					$first = false;
				}
				else
					$rep->TextCol(1, 3, _("Included") . " " . $tax_type_name . _("Amount") . ": " . $DisplayTax, -2);
			}	else {
				$rep->TextCol(0, 2, $tax_type_name, -2);
				$rep->TextCol(2, 3,	$DisplayTax, -2);
			}
			$rep->NewLine();
		}
		$rep->NewLine();
		$DisplayTotal = number_format2($sign*($myrow["ov_freight"] + $myrow["ov_gst"] +
			$myrow["ov_amount"]+$myrow["ov_freight_tax"]),$dec);
		$rep->Font('bold');
		$rep->TextCol(1, 2, _("TOTAL CREDIT"), - 2);
		$rep->TextCol(2, 3, $DisplayTotal, -2);
		$words = price_in_words($myrow['Total'], ST_CUSTCREDIT);
		if ($words != ""){
			$rep->NewLine(1);
			$rep->TextCol(0, 3, $myrow['curr_code'] . ": " . $words, - 2);
		}	
		$rep->Font();
		
	$rep->End();
}

