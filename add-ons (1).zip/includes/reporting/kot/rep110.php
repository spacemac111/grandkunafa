<?php

// ----------------------------------------------------------------
// Title:	Print Delivery Notes
// ----------------------------------------------------------------

include_once(ABSPATH . "/includes/erp/customers_db.inc");


//----------------------------------------------------------------------------------------------------
function get_invoice_range($from){

	$sql = "SELECT trans.trans_no, trans.reference	FROM ".TB_PREF."debtor_trans trans LEFT JOIN ".TB_PREF."voided voided ON trans.type=voided.type AND trans.trans_no=voided.id
		WHERE trans.type=".ST_CUSTDELIVERY." AND ISNULL(voided.id) AND trans.trans_no=".fadb_escape($from)
		." ORDER BY trans.tran_date, trans.trans_no";

	return fadb_query($sql, "Cant retrieve invoice range");
}
 print_deliveries();
//print_token();

//----------------------------------------------------------------------------------------------------

function print_deliveries()
{
	global $SysPrefs, $current_user;

	// include_once($path_to_root . "/reportingincludes/reporting/pdf_report.inc");
	$show_this_payment = true; // include payments invoiced here in summary

	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");

	// $from = $_POST['PARAM_0'];
	// $to = $_POST['PARAM_1'];
	// $email = $_POST['PARAM_2'];
	// $packing_slip = $_POST['PARAM_3'];
	// $comments = $_POST['PARAM_4'];
	// $orientation = $_POST['PARAM_5'];

	$from = $_GET['trans_no'];
	$to = '4';	
	$email = 0;
	$packing_slip = '';
	$comments = '';
	$customer = '';
	
	$orientation = 'P';
	$dec = user_price_dec();

	if (!$from || !$to) return;
	
	$dec = user_price_dec();

	// $fno = explode("-", $from);
	// $tno = explode("-", $to);
	// $from = min($fno[0], $tno[0]);
	// $to = max($fno[0], $tno[0]); 

	if($current_user['pdf_template'] == 'A6D' ) {
			$cols = array(4, 145, 180, 230, 255);
			$aligns = array('left', 'center', 'right', 'right');
		} elseif($current_user['pdf_template'] == 'A6') {
			$cols = array(4, 45,  220, 225);
			$aligns = array('center',	'left',	'right');
		} elseif($current_user['pdf_template'] == 'A7') {
			$cols = array(4, 150,195);
			$aligns = array('left',	'right');
		} elseif($current_user['pdf_template'] == 'A7D') {
			$cols = array(4, 115,  125, 155, 199);
			$aligns = array('left',	'right','right', 'right');
		} elseif($current_user['pdf_template'] == 'A8') {
			$cols = array(4, 125);
			$aligns = array('left');
		}

	// $headers in doctext.inc
	$pdf_template = $current_user['pdf_template'];
	if($current_user['pdf_template'] == 'A6D')
		$pdf_template = 'A6';
	elseif($current_user['pdf_template'] == 'A7D')
		$pdf_template = 'A7';

	$params = array('comments' => $comments, 'packing_slip' => $packing_slip);

	$cur = get_company_Pref('curr_default');

	if ($email == 0){
		$rep = new FrontReport(_('DELIVERY'), "DeliveryNote - ".$_GET['trans_no'], $pdf_template, 9, $orientation);			
	}
    $range = get_invoice_range($from);
    $non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
    while($row = fadb_fetch($range)){

	// for ($i = $from; $i <= $to; $i++)
	// {
			if (!exists_customer_trans(ST_CUSTDELIVERY, $row['trans_no']))
				continue;
			$myrow = Kvcodes_get_customer_trans($row['trans_no'], ST_CUSTDELIVERY);
			//var_dump($myrow);
			// $myrow = get_customer_trans($row['trans_no'], ST_CUSTDELIVERY);
			// $branch = get_branch($myrow["branch_code"]);
			$branch = Kvcodes_get_branch($myrow["branch_code"]);
			// $sales_order = get_sales_order_header($myrow["order_"], ST_SALESORDER); // ?
			$sales_order = Kvcodes_get_sales_order_header($myrow["order_"], ST_SALESORDER);
			
			$rep->currency = $cur;
			$rep->Font();
			$rep->Info($params, $cols, null, $aligns);
			$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'delivery', $branch['debtor_no'], true);
			$myrow['token']='no';
			$rep->SetCommonData($myrow, $branch, $sales_order, '', ST_CUSTDELIVERY, $contacts);
			$rep->SetHeaderType('Headerkvcodes');
			$rep->NewPage();
   			$result = Kvcodes_get_customer_trans_details(ST_CUSTDELIVERY, $row['trans_no']);

			$SubTotal = 0;
			$summary_start_row = $rep->bottomMargin +6.5;
			$trans_details = [];
			while ($myrow2=fadb_fetch($result)){ 
				$trans_details[] = $myrow2;
			}
			$Kit_Net = 0;
			$current_kit = '';
			foreach($trans_details as $key => $myrow2) {
				if ($myrow2["quantity"] == 0)
					continue;
				$sign = 1;
				//echo $myrow2["quantity"];
				$Net = round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),   user_price_dec());
				$SubTotal += $Net;
	    		$DisplayPrice = number_format2($myrow2["unit_price"],$dec);
	    		$DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
	    		$DisplayNet = number_format2($Net,$dec);
	    		
	    		if($non_detailed_sales_kit && $myrow2['kit'] != ''){
	    			if($current_kit == '')
	    				$current_kit = $myrow2['kit'];
	    				
					if($current_kit == $myrow2['kit']){
						$Kit_Net += round2($sign * ((1 - $myrow2["discount_percent"]) * $myrow2["unit_price"] * $myrow2["quantity"]),   user_price_dec());
						if($myrow2['kit'] == $trans_details[$key+1]['kit'])
							continue;
					} else
						$current_kit = '';
							
					$DisplayNet = number_format2($Kit_Net, $dec);
					$Kit_Net = 0;
					$item_detail = FAGetRow('item_codes', ['item_code' => $myrow2['kit'], 'stock_id' => $myrow2['stock_id']]);
					$myrow2['StockDescription'] = $item_detail['description'];
					//echo $myrow2['quantity'].'_'.$item_detail['quantity'];
					$DisplayQty = number_format2($myrow2['quantity']/$item_detail['quantity'], get_qty_dec($myrow2['kit']));
				}

				$c=0;
				$stock_Description = $myrow2['StockDescription'];
				if($current_user['pdf_template'] == 'A6' )
					$rep->TextCol($c++, $c,	$DisplayQty, -2);
				
				elseif($current_user['pdf_template'] == 'A7'){
					if($kv_batch|| $kv_exp_date){
						$stock_Description = $myrow2['StockDescription'];
						$rep->TextCol($c++, $c,	$DisplayQty, -2);
					} else 
						$stock_Description = $DisplayQty.'x '.$myrow2['StockDescription'];
				}
				elseif($current_user['pdf_template'] == 'A8')
					$stock_Description = $DisplayQty.'x '.$myrow2['StockDescription']."     ".$DisplayNet;
				// $rep->TextCol($c++, $c,	$myrow2['stock_id'], -2);
				$oldrow = $rep->row;
				// $rep->fontSize =7;
				$rep->TextColLines($c++, $c, $stock_Description, -2);
				$rep->row = $oldrow;

				if($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D'){
					$rep->TextCol($c++, $c,	$DisplayQty, -2);
					$rep->TextCol($c++, $c,	$DisplayPrice, -2);
				}

				if ($Net != 0.0 || !is_service($myrow2['mb_flag']) || get_company_details('no_zero_lines_amount'))		{
					// $rep->TextCol($c++, $c,	$DisplayQty, -2);
					if($kv_batch|| $kv_exp_date){
						$rep->TextColLines($c++, $c,	$myrow2['batch_no'], -2);
						if($kv_exp_date && $current_user['pdf_template'] != 'A8' && $current_user['pdf_template'] != 'A7'){
							$rep->row = $oldrow;
							$rep->TextColLines($c++, $c, ($myrow2['exp_date'] != '0000-00-00' ? date('d-m-Y', strtotime($myrow2['exp_date']))  : ''), -2);
						}
					}

					$newrow = $rep->row;
					$rep->row = $oldrow;
					//$rep->TextCol($c++, $c,	$DisplayDiscount, -2);
					if($current_user['pdf_template'] != 'A8')
						$rep->TextCol($c++, $c,	$DisplayNet, -2);
				}
				$rep->row = $newrow;
				$rep->NewLine(1);
				if ($rep->row < $summary_start_row)
					$rep->NewPage();
			}

			$memo = Kvcodes_get_comments_string(ST_CUSTDELIVERY, $row['trans_no']);
			if ($memo != "")	{
				$rep->NewLine();
				$rep->TextColLines(1, 3, $memo, -2);
			}
			$tax_items = Kvcodes_get_trans_tax_details(ST_CUSTDELIVERY, $row['trans_no']);
			$final_tax_Ar = [];
			$total_tax_amt_to_deduct = 0;
			while ($tax_item = db_fetch($tax_items)){
    			 $final_tax_Ar[] = $tax_item;
    			 if ($tax_item['amount'] == 0)
    					continue;
    			$total_tax_amt_to_deduct += $tax_item['amount'];
    			 
			}   
		
            $SubTotal = ($SubTotal-($myrow["tax_included"] == 1 ? $total_tax_amt_to_deduct : 0 ));
   			$DisplaySubTot = number_format2($SubTotal,$dec);

    		//$rep->NewLine();
			$doctype=ST_CUSTDELIVERY;
			if ($packing_slip == 0)
			{
				$rep->Line($rep->row+9);
    		$rep->NewLine(0.2);
    		//$rep->Font();

    		if($current_user['pdf_template'] == 'A6'){
				$rep->TextCol(1, ($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), _("Sub-total"), -2);
				$rep->TextCol(($kv_batch ? 3 : ($kv_exp_date ? 4 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 5 : 3)),	$DisplaySubTot, -2);
			} elseif($current_user['pdf_template'] == 'A6D'){
				$rep->TextCol(1, ($kv_batch ? 4 : ($kv_exp_date ? 6 : 3)), _("Sub-total"), -2);
				$rep->TextCol(($kv_batch ? 4 : ($kv_exp_date ? 6 : 2)), ($kv_batch ? 4 : ($kv_exp_date ? 6 : 4)),	$DisplaySubTot, -2);
			} elseif($current_user['pdf_template'] == 'A7'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 3, _("Sub-total"), -2);
					$rep->TextCol(3, 4,	$DisplaySubTot, -2);
				} else {
					$rep->TextCol(0, 1, _("Sub-total"), -2);
					$rep->TextCol(1, 2, $DisplaySubTot, -2);
				}
			} elseif($current_user['pdf_template'] == 'A7D'){
				if($kv_batch || $kv_exp_date){
					$rep->TextCol(1, 5, _("Sub-total"), -2);
					$rep->TextCol(5, 6,	$DisplaySubTot, -2);
				} else {
					$rep->TextCol(0, 3, _("Sub-total"), -2);
					$rep->TextCol(3, 4, $DisplaySubTot, -2);
				}
			} elseif($current_user['pdf_template'] == 'A8'){
				$rep->TextCol(0, 1, _("Sub-total"). " : ". $DisplaySubTot, -2);
			}

				$rep->NewLine();
				if ($myrow['ov_freight'] != 0.0)
				{
					$DisplayFreight = number_format2($myrow["ov_freight"],$dec);
					$rep->TextCol(1, 2, _("Shipping"), -2);
					$rep->TextCol(2, 3,	$DisplayFreight, -2);
					$rep->NewLine();
				}	

				
				$first = true;
				$rep->aligns[1] = 'right';
    		    foreach($final_tax_Ar as $tax_item)	{
    				if ($tax_item['amount'] == 0)
    					continue;
    				$DisplayTax = number_format2($tax_item['amount'], $dec);
 
    			if (get_company_details('suppress_tax_rates') == 1)
 		   				$tax_type_name = $tax_item['tax_type_name'];
 		   			else
 		   				$tax_type_name = $tax_item['tax_type_name']." (".$tax_item['rate']."%) ";

 					if ($myrow['tax_included'])	{
    					if (get_company_details('alternative_tax_include_on_docs') == 1)	{
    					
    						if ($first)	{
								$rep->TextCol(1, 2, _("Total Tax Excluded"), -2);
								$rep->TextCol(2, 3,	number_format2($tax_item['net_amount'], $dec), -2);
								$rep->NewLine();
    						}
							$rep->TextCol(1, 2, $tax_type_name, -2);
							$rep->TextCol(2, 3,	$DisplayTax, -2);
							$first = false;
    					}
    					else{
    						if($current_user['pdf_template'] == 'A6')
								$rep->TextCol(1, 3, _("Included") . " " . $tax_type_name . _("Amount") . ": " . $DisplayTax, -2);
							elseif($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D')
								$rep->TextCol(1, 4, _("Included") . " " . $tax_type_name . _("Amount") . ": " . $DisplayTax, -2);
							elseif($current_user['pdf_template'] == 'A7')
								$rep->TextCol(0, 2, _("Included") . " " . $tax_type_name . _("Amount") . ": " . $DisplayTax, -2);
							elseif($current_user['pdf_template'] == 'A8')
								$rep->TextCol(0, 1, _("Included") . " " . $tax_type_name . _("Amount") . ": " . $DisplayTax, -2);
    					}
					}
    				else
    				{
						$rep->TextCol(1, 2, $tax_type_name, -2);
						$rep->TextCol(2, 3,	$DisplayTax, -2);
					}
					$rep->NewLine();
    			}
    		    			
				$DisplayTotal = number_format2($myrow["ov_freight"] +$myrow["ov_freight_tax"] + $myrow["ov_gst"] +
					$myrow["ov_amount"],$dec);
				$rep->Font('bold');

				if($current_user['pdf_template'] == 'A6'){
					$rep->TextCol(1, 2, _("TOTAL"), - 2);
					$rep->TextCol(2, 3,	$DisplayTotal, -2);
				}
				elseif($current_user['pdf_template'] == 'A6D' || $current_user['pdf_template'] == 'A7D'){
					$rep->TextCol(1, 3, _("TOTAL"), - 2);
					$rep->TextCol(3,4,	$DisplayTotal, -2);
				}
				elseif($current_user['pdf_template'] == 'A7'){
					$rep->TextCol(0,1, _("TOTAL"), - 2);
					$rep->TextCol(1,2,	$DisplayTotal, -2);
				}
				elseif($current_user['pdf_template'] == 'A8'){
					$rep->TextCol(0,1, _("TOTAL") ." -".$DisplayTotal, -2);
				}
				$rep->Font();				
				
				$words = price_in_words($myrow['Total'], ST_CUSTDELIVERY);
				if ($words != ""){
					$rep->NewLine(1);
					$rep->TextCol(1, 3, $myrow['curr_code'] . ": " . $words, - 2);
				}

			$rep->Font('italic');
			$rep->NewLine(0.4);
			$rep->Line($rep->row);
			$rep->NewLine(0.2);
			foreach ($rep->Footer as $line => $txt){
				if (!is_numeric($line))	// title => link
				{
					$rep->NewLine();
					$rep->aligns[0] = 'center';
					$rep->fontSize -= 2;
					$rep->TextCol(0, 3,$line, - 2);
					$rep->NewLine();
					$rep->SetTextColor(0, 0, 255);
					$rep->TextCol(0, 3,$txt, - 2);
					$rep->SetTextColor(0, 0, 0);
					// $this->addLink($txt, $ccol, $this->row, $this->pageWidth - $this->rightMargin, $this->row + $this->lineHeight);
					$rep->fontSize += 2;
				}
				else{
					$rep->aligns[0] = 'center';
					$rep->NewLine();
					// $rep->TextWrap(0, $rep->row,5,$txt,'C');
					$rep->TextCol(0, count($aligns),$txt, - 2);
				}
			}
			$rep->Font();
		}	
			
	}
	if ($email == 0)
		$rep->End(0,'',1);
}

function print_token(){
	global $SysPrefs;
	$show_this_payment = true; 
	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");
	$from = $_GET['trans_no'];
	$to = '4';	
	$email = 0;
	$packing_slip = '';
	$comments = '';
	$customer = '';
	$orientation = 'P';
	$dec = user_price_dec();
	if (!$from || !$to) return;
	$dec = user_price_dec();
	$cols = array(4, 25,  135, 165, 210, 300);
	$aligns = array('left',	'left',	'right', 'center', 'right', 'right');
	$params = array('comments' => $comments, 'packing_slip' => $packing_slip);
	$cur = get_company_Pref('curr_default');
	if ($email == 0){
		$rep = new FrontReport(_('DELIVERY'), "DeliveryNote - ".$_GET['trans_no'], 'A6', 9, $orientation);			
	}
    $range = get_invoice_range($from);
    while($row = fadb_fetch($range)){
		if (!exists_customer_trans(ST_CUSTDELIVERY, $row['trans_no']))
			continue;
		$myrow = Kvcodes_get_customer_trans($row['trans_no'], ST_CUSTDELIVERY);
		$branch = Kvcodes_get_branch($myrow["branch_code"]);
		$sales_order = Kvcodes_get_sales_order_header($myrow["order_"], ST_SALESORDER);
		$rep->currency = $cur;
		$rep->Font();
		$rep->Info($params, $cols, null, $aligns);
		$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'delivery', $branch['debtor_no'], true);
		$myrow['token']='yes';
		$rep->SetCommonData($myrow, $branch, $sales_order, '', ST_CUSTDELIVERY, $contacts);
		$rep->SetHeaderType('Headerkvcodes');
		$rep->NewPage();
		$result = Kvcodes_get_customer_trans_details(ST_CUSTDELIVERY, $row['trans_no']);


		$DisplayTotal = number_format2($myrow["ov_freight"] +$myrow["ov_freight_tax"] + $myrow["ov_gst"] +
					$myrow["ov_amount"],$dec);
		$rep->Font('bold');	
		$rep->fontSize += 5;
		$rep->aligns[0] = 'center';	
		$words = price_in_words($myrow['Total'], ST_CUSTDELIVERY);
		$rep->TextCol(0, 6, "TOTAL AMOUNT  : ".$DisplayTotal,-2);
		$rep->fontSize -= 5;
		if ($words != "")
		{
			$rep->NewLine(1);
			$rep->TextCol(1, 5, $myrow['curr_code'] . ": " . $words, - 2);
		}

		$rep->Font('italic');
		$rep->NewLine();
		$rep->Line($rep->row);
		$rep->NewLine();
		foreach ($rep->Footer as $line => $txt){
			if (!is_numeric($line))	// title => link
			{
				$rep->NewLine();
				$rep->fontSize -= 2;
				$rep->TextCol(0, 6,$line, - 2);
				$rep->NewLine();
				$rep->SetTextColor(0, 0, 255);
				$rep->TextCol(0, 6,$txt, - 2);
				$rep->SetTextColor(0, 0, 0);
				$rep->fontSize += 2;
			}
			else{
				$rep->NewLine();
				$rep->aligns[0] = 'center';
				$rep->TextCol(0, 6,$txt, - 2);
			}
		}
		$rep->Font();
	}	
	if ($email == 1){
		$rep->End($email,'',2);
	}
	if ($email == 0)
		$rep->End(0,'',2);
}