<?php

$page_security = 'SA_OPEN';

// ----------------------------------------------------------------
// Title:	Print Token or Delivery No
// ----------------------------------------------------------------

include_once(ABSPATH . "/includes/erp/customers_db.inc");


//----------------------------------------------------------------------------------------------------

print_token();

//----------------------------------------------------------------------------------------------------

function print_token(){
	global  $SysPrefs;
	$show_this_payment = true; 
	include_once(ABSPATH . "/includes/reporting/pdf_report.inc");
	$order_no = $_GET['order_no'];
	$packing_slip = '';
	$comments = '';
	$customer = '';
	$orientation = 'P';
	$dec = user_price_dec();
	if (!$order_no) return;
	$dec = user_price_dec();
	$cols = array(4, 45,  220, 225);
	$aligns = array('center',	'center',	'center');
	$header =array('SNO','ITEM NAME','QTY');
	$params = array('comments' => $comments, 'packing_slip' => $packing_slip);
	$cur = get_company_Pref('curr_default');
	$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');

	$rep = new FrontReport(_('Token/Delivery'), "Token/Delivery - ".$_GET['order_no'], 'A6', 9, $orientation);			
	
   	$myrow = Kvcodes_get_sales_order_header($order_no, ST_SALESORDER);
	if ($currency != ALL_TEXT && $myrow['curr_code'] != $currency) {
		exit;
	}
		
	$branch = Kvcodes_get_branch($myrow["branch_code"]);
	
	$sales_order = Kvcodes_get_sales_order_header($order_no, ST_SALESORDER);
	
	$rep->currency = $cur;
	$rep->Font();
	$rep->Info($params, $cols,null, $aligns);
	$contacts = Kvcodes_get_branch_contacts($branch['branch_code'], 'delivery', $branch['debtor_no'], true);
	$myrow['token']='yes';
	$rep->SetCommonData($myrow, $branch, $sales_order, '', ST_CUSTDELIVERY, $contacts);
	$rep->SetHeaderType('Headerkvcodes');
	$rep->NewPage();
	
	$result =get_sales_order_details($order_no, ST_SALESORDER);

	$sno = $total_items =0;	
	$summary_start_row = $rep->bottomMargin +6.5;
	$rep->row +=5;
	$order_details = [];
	while ($myrow2=fadb_fetch($result)){
		$order_details[] = $myrow2;
	}

	foreach($order_details as $key => $myrow2) {
		$rep->lineHeight = 8;
		if ($myrow2["quantity"] == 0)
			continue;
		
		//var_dump($myrow2);
			// $DisplayQty = number_format2($sign*$myrow2["quantity"],get_qty_dec($myrow2['stock_id']));
		
		//var_dump($myrow2);
		if($non_detailed_sales_kit && $myrow2['kit'] != ''){
				//echo "TesT";
			if($order_details[$key+1]['kit'] == $myrow2['kit'])
				continue;
			$item_detail = FAGetRow('item_codes', ['item_code' => $myrow2['kit'], 'stock_id' => $myrow2['stk_code']]);
			$myrow2['description'] = $item_detail['description'];
			//echo $myrow2['quantity'].'_'.$item_detail['quantity'];
			$myrow2['quantity'] = round($myrow2['quantity']/$item_detail['quantity'], get_qty_dec($myrow2['kit']));
		}

		$total_items +=$myrow2["quantity"];

		$sno++;
		$c=0;

		$rep->TextCol($c++, $c,	$sno, -2);
		$oldrow = $rep->row;
		$rep->TextColLines($c++, $c, $myrow2['description'], -2);
			
		$newrow = $rep->row;
		$rep->row = $oldrow;
		$rep->TextCol($c++, $c,	$myrow2["quantity"], -2);
		$rep->row = $newrow;
		$rep->NewLine();
		if ($rep->row < $summary_start_row)
			$rep->NewPage();
	}

	$rep->Line($rep->row);
	$rep->NewLine(2);
	$rep->Font('bold');	
	//$rep->fontSize += 3;
	$rep->aligns[0] = 'center';	
	$words = price_in_words($myrow['Total'], ST_CUSTDELIVERY);
	$rep->TextCol(1, 2, "TOTAL ITEMS",-2);
	$rep->TextCol(2, 3, $total_items,-2);
	//$rep->fontSize -= 3;
	if ($words != ""){
		$rep->NewLine(1);
		$rep->TextCol(1, 5, $myrow['curr_code'] . ": " . $words, - 2);
	}
	$rep->Font('italic');
	$rep->NewLine();
	$rep->Line($rep->row);
	$rep->NewLine();
	$rep->lineHeight = 11;
	foreach ($rep->Footer as $line => $txt){
		if (!is_numeric($line)){	// title => link			
			$rep->NewLine();
			$rep->fontSize -= 2;
			$rep->TextCol(0, 6,$line, - 2);
			$rep->NewLine();
			$rep->SetTextColor(0, 0, 255);
			$rep->TextCol(0, 6,$txt, - 2);
			$rep->SetTextColor(0, 0, 0);
			$rep->fontSize += 2;
		} else{
			$rep->NewLine();
			$rep->aligns[0] = 'center';
			$rep->TextCol(0, 6,$txt, - 2);
		}
	}
	$rep->Font();
	$rep->End(0,'',2);
}