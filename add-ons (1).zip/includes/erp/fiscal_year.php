<?php 

include_once("types.php");
function get_all_fiscalyears()
{
	$sql = "SELECT * FROM ".TB_PREF."fiscal_year ORDER BY begin";

	return fadb_query($sql, "could not get all fiscal years");
}

function get_all_dimensions($type=1)
{
	$sql = "SELECT id, CONCAT(reference,' ',name) as ref FROM ".TB_PREF."dimensions WHERE (type_='".$type."') ORDER BY reference";

	return fadb_query($sql, "could not get all fiscal years");
}

function get_all_account_tags()
{
	$sql = "SELECT * FROM ".TB_PREF."tags WHERE type='1' AND !inactive ORDER BY name";

	return fadb_query($sql, "could not get all fiscal years");
}


function get_fiscalyear($id)
{
	$sql = "SELECT * FROM ".TB_PREF."fiscal_year WHERE id=".fadb_escape($id);

	$result = fadb_query($sql, "could not get fiscal year");

	return fadb_fetch($result);
}

function get_current_fiscalyear()
{
	$year = get_company_details('f_year');

	$sql = "SELECT * FROM ".TB_PREF."fiscal_year WHERE id=".fadb_escape($year);

	$result = fadb_query($sql, "could not get current fiscal year");

	return fadb_fetch($result);
}

function begin_fiscalyear(){
	$fiscal_year = get_current_fiscalyear();
	return date('Y-m-d', strtotime($fiscal_year['begin']));
}

function get_fiscalyear_begin_for_date($date)
{
 	$date = date2sql($date);
	$sql = "SELECT begin FROM ".TB_PREF."fiscal_year WHERE '$date' >= begin AND '$date' <= end";
	$result = fadb_query($sql, "could not get begin date of the fiscal year");
	$row = fadb_fetch_row($result);
	if ($row != false)
		return sql2date($row[0]);
	else
		return begin_fiscalyear();
}


function date1_greater_date2 ($date1, $date2) 
{

/* returns 1 true if date1 is greater than date_ 2 */

	$date1 = date2sql($date1);
	$date2 = date2sql($date2);

	@list($year1, $month1, $day1) = explode("-", $date1);
	@list($year2, $month2, $day2) = explode("-", $date2);

	if ($year1 > $year2)
	{
		return 1;
	}
	elseif ($year1 == $year2)
	{
		if ($month1 > $month2)
		{
			return 1;
		}
		elseif ($month1 == $month2)
		{
			if ($day1 > $day2)
			{
				return 1;
			}
		}
	}
	return 0;
}


function add_days($date, $days){
	date('Y-m-d', strtotime($days." days"));
}

//----------------------------------------------------------------------------------------------------
function get_balance($account, $dimension, $dimension2, $from, $to, $from_incl=true, $to_incl=true) 
{
	$from_date = date2sql($from);
	$to_date = date2sql($to);

	$sql = "SELECT	SUM(IF(amount >= 0, amount, 0)) as debit, 
					SUM(IF(amount < 0, -amount, 0)) as credit,
					SUM(amount) as balance 
		FROM ".TB_PREF."gl_trans trans,"
			.TB_PREF."chart_master coa,"
			.TB_PREF."chart_types act_type, "
			.TB_PREF."chart_class act_class
		WHERE trans.account=coa.account_code
			AND coa.account_type=act_type.id 
		AND act_type.class_id=act_class.cid"
		." AND ".($from_incl ? "tran_date >= '$from_date'" : "tran_date > IF(ctype>0 AND ctype<".CL_INCOME.", '0000-00-00', '$from_date')")
		." AND ".($to_incl ? "tran_date <= '$to_date'" : "tran_date < '$to_date'")
		.($account == null ? '' : " AND account=".fadb_escape($account))
		.($dimension == 0 ? ''  : " AND dimension_id = ".($dimension<0 ? 0 : fadb_escape($dimension)))
		.($dimension2 == 0 ? '' : " AND dimension2_id = ".($dimension2<0 ? 0 : fadb_escape($dimension2)));

	$result = fadb_query($sql,"No general ledger accounts were returned");

	return fadb_fetch($result);
}

function round2($number, $decimals=0){
	$delta = ($number < 0 ? -.0000000001 : .0000000001);
	return round($number+$delta, $decimals);
}
//--------------------------------------------------------------------------------------

function get_dimension($id, $allow_null=false)
{
    $sql = "SELECT * FROM ".TB_PREF."dimensions	WHERE id=".fadb_escape($id);

	$result = fadb_query($sql, "The dimension could not be retrieved");

	if (!$allow_null && fadb_num_rows($result) == 0){
		return 'error';
	}

	return fadb_fetch($result);
}

//--------------------------------------------------------------------------------------

function get_dimension_string($id, $html=false, $space=' '){
	if ($id <= 0){
		if ($html)
			$dim = "&nbsp;";
		else
			$dim = "";
	}else{
		$row = get_dimension($id, true);
		$dim = $row['reference'] . $space . $row['name'];
	}
	return $dim;
}


function find_custom_file($rep){
	global $installed_extensions, $path_to_root, $local_path_to_root;

	// customized per company version
	$path = company_path();
	$file = $path.$rep;
	if (file_exists($file)) {	// add local include path
		$local_path_to_root = $path;
		set_include_path(dirname($file).PATH_SEPARATOR.get_include_path());
		return $file;
	}

	// standard location
	$file = $path_to_root.$rep;
	if (file_exists($file))
		return $file;

	return null;
}

function company_path() {
	global $current_user;
	$current_user = kv_get_current_user();
	$user_path = substr($current_user['tbpref'], 0, -1);
	return ABSPATH.'pdftmp/'.$user_path;
}
function html_specials_encode($str){
	return htmlspecialchars($str, ENT_QUOTES, 'iso-8859-2');
}

function display_error($msg, $center=true){
	trigger_error($msg, E_USER_ERROR);
}

function display_notification($msg, $center=true){
	trigger_error($msg, E_USER_NOTICE);
}

function display_warning($msg, $center=true){
	trigger_error($msg, E_USER_WARNING);
}

function display_notification_centered($msg){
	display_notification($msg, true);
}
function Today(){
	return date('Y-m-d');
}

function Now(){
	//if (user_date_format() == 0)
		return date("h:i a");
	//else
		//return date("H:i");
}

function get_report_printer($profile, $report){
	$sql = "SELECT printer FROM ".TB_PREF."print_profiles WHERE profile=".fadb_escape($profile)." AND report=";

	$result = fadb_query($sql.fadb_escape($report), 'report printer lookup failed');

	if (!$result) return false;
	$ret = fadb_fetch($result);
	if ($ret === false) {
		$result = fadb_query($sql."''", 'default report printer lookup failed');
		if (!$result) return false;

		$ret = fadb_fetch($result);
		if (!$ret) return false;
	}
	return get_printer($ret['printer']);
}

function get_printer($id){
		$sql = "SELECT * FROM ".TB_PREF."printers WHERE id=".fadb_escape($id);
		$result = fadb_query($sql,"could not get printer definition");
		return  fadb_fetch($result);
}

function get_account_classes($all=false, $balance=-1){
	$sql = "SELECT * FROM ".TB_PREF."chart_class";

	if (!$all) 
		$sql .= " WHERE !inactive";
	if ($balance == 0) 
		$sql .= " AND ctype>".CL_EQUITY." OR ctype=0";
	elseif ($balance == 1) 
		$sql .= " AND ctype>0 AND ctype<".CL_INCOME; 
	$sql .= " ORDER BY ctype, cid";
	//echo $sql;
	return fadb_query($sql, "could not get account classes");
}

function date2sql($date){
	return date('Y-m-d', strtotime($date));
}

function get_gl_balance_from_to($from_date, $to_date, $account, $dimension=0, $dimension2=0)
{
	$from = date2sql($from_date);
	$to = date2sql($to_date);

    $sql = "SELECT SUM(amount) FROM ".TB_PREF."gl_trans
		WHERE account='$account'";
	if ($from_date != "")
		$sql .= "  AND tran_date > '$from'";
	if ($to_date != "")
		$sql .= "  AND tran_date < '$to'";
	if ($dimension != 0)
  		$sql .= " AND dimension_id = ".($dimension<0 ? 0 : fadb_escape($dimension));
	if ($dimension2 != 0)
  		$sql .= " AND dimension2_id = ".($dimension2<0 ? 0 : fadb_escape($dimension2));

	$result = fadb_query($sql, "The starting balance for account $account could not be calculated");

	$row = fadb_fetch_row($result);
	return $row[0];
}

//--------------------------------------------------------------------------------

function get_gl_trans_from_to($from_date, $to_date, $account, $dimension=0, $dimension2=0)
{
	$from = date2sql($from_date);
	$to = date2sql($to_date);

    $sql = "SELECT SUM(amount) FROM ".TB_PREF."gl_trans
		WHERE account='$account'";
	if ($from_date != "")
		$sql .= " AND tran_date >= '$from'";
	if ($to_date != "")
		$sql .= " AND tran_date <= '$to'";
	if ($dimension != 0)
  		$sql .= " AND dimension_id = ".($dimension<0 ? 0 : fadb_escape($dimension));
	if ($dimension2 != 0)
  		$sql .= " AND dimension2_id = ".($dimension2<0 ? 0 : fadb_escape($dimension2));

	$result = fadb_query($sql, "Transactions for account $account could not be calculated");

	$row = fadb_fetch_row($result);
	return (float)$row[0];
}

function get_class_type_convert($ctype){
	return ((($ctype >= CL_LIABILITIES && $ctype <= CL_INCOME) || $ctype == CL_NONE) ? -1 : 1);
}

function get_account_types($all=false, $class_id=false, $parent=false){
	$sql = "SELECT * FROM ".TB_PREF."chart_types";

	$where = array();
	
	if (!$all)
		$where[] = "!inactive";

	if ($class_id != false)  
		$where[] = "class_id=".fadb_escape($class_id);

	if ($parent == -1) 
		$where[] ="(parent = '' OR parent = '-1')";
	elseif ($parent !== false) 
		$where[] = "parent=".fadb_escape($parent);

	if (count($where))
		$sql .= ' WHERE '.implode(' AND ', $where);
	$sql .= " ORDER BY class_id, id, parent";

	return fadb_query($sql, "could not get account types");
}

function get_gl_accounts($from=null, $to=null, $type=null)
{
	$sql = "SELECT coa.*, act_type.name AS AccountTypeName
		FROM "
			.TB_PREF."chart_master coa,"
			.TB_PREF."chart_types act_type
		WHERE coa.account_type=act_type.id";
	if ($from != null)
		$sql .= " AND coa.account_code >= ".fadb_escape($from);
	if ($to != null)
		$sql .= " AND coa.account_code <= ".fadb_escape($to);
	if ($type != null)
		$sql .= " AND account_type=".fadb_escape($type);
	$sql .= " ORDER BY account_code";

	return fadb_query($sql, "could not get gl accounts");
}

function user_print_profile(){
	return '';
}

function user_percent_dec(){
	return 1;
}
function user_price_dec(){
	global $current_user;
	//var_dump($current_user['fa_user_id']);
	return FAGetSingleValue('users', 'prices_dec', array('id' => $current_user['fa_user_id']));
}
function user_dec_sep()
{
	return 0;
}
function number_format2($number, $decimals=0){
	$tsep = ",";
	$dsep = ".";

	if($decimals==='max')
		$dec = 15 - floor(log10(abs($number)));
	else {
		$delta = ($number < 0 ? -.0000000001 : .0000000001);
		$number += $delta;
		$dec = $decimals;
	}

	$num = number_format($number, $dec, $dsep, $tsep);
	return $decimals==='max' ? rtrim($num, '0') : $num;
}

function Fiscal_years_dropdown($name='f_year', $label ='Fiscal Year'){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._($label).'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
	$fiscal_years = get_all_fiscalyears(); 
	$current_year = get_company_details('f_year');
	foreach($fiscal_years as $f_year){
		echo '<option value="'.$f_year['id'].'" '.($f_year['id'] == $current_year ? 'selected' : '' ).'> '.$f_year['begin'].'-'.$f_year['end'].' '.($f_year['closed'] == 1 ? _("Closed") : _("Active")).' </option>';
	} 
	echo '</select></div></div>';
}

function Dimensions_dropdown($name='dimensions', $type=1,$show_label=true, $selected_id= 0, $show_default=false){
	echo '<div class="form-group">'.($show_label ? '<label for="'.$name.'" class="col-md-2 control-label">'._("Dimensions").'</label><div class="col-md-10">' : '' ).'<select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
   	$Dimensions = get_all_dimensions($type); 
   	if(!$show_default)
   		echo '<option value="0" '.($selected_id == 0 ? 'selected' : '' ).' > '._("No Dimension").' </option>'; 
    foreach($Dimensions as $Dimension){
        echo '<option value="'.$Dimension['id'].'" '.($selected_id == $Dimension['id']? 'selected' : '' ).'> '.$Dimension['ref'].'</option>';
    } 
    echo '</select>'.($show_label ? '</div></div>' : '' );
}

function Account_tags_dropdown($name='account_tags'){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Account Tags").'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'[]" class="form-control" _last="0" multiple="">';
	$Dimensions = get_all_account_tags(); 
    echo '<option value="" selected > '._("No active tags defined").' </option>'; 
    foreach($Dimensions as $Dimension){
        echo '<option value="'.$Dimension['id'].'" > '.$Dimension['ref'].'</option>';
    }
    echo '</select></div></div>';
}

function comments_box($name='comments'){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Comments").'</label><div class="col-md-10"><textarea class="form-control" rows="3" id="'.$name.'" name="'.$name.'" ></textarea></div></div>';
}

function Orientation_dropdown($name='Orientation'){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Orientation").'</label><div class="col-md-10"><select id="'.$name.'" name="'.$name.'" class="form-control"><option value="0">'._("Portrait").'</option><option value="1">'._("Landscape").'</option></select></div></div>';
}


function Destination_dropdown($name='Destination'){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Destination").'</label><div class="col-md-10"><select id="'.$name.'" name="'.$name.'" class="form-control"><option value="0">'._("PDF/Printer").'</option><option value="1">'._("Excel").'</option></select></div></div>';
}
function Reports_submit($name='submit', $label='Submit'){
	echo '<div class="col-md-10 col-md-offset-2"><input class="btn btn-raised btn-primary ReportFormProcess" data-target="#pdfModal" data-toggle="modal" type="button" aspect="default process" name="'.$name.'" id="'.$name.'" value="'.$label.'"></div>'; 
}
function Start_date($name="start_date", $label="Start Date", $date='Today'){

	if($date == 'Today')
		$dateRes = date('Y-m-d');
	elseif($date == 'ThisMonth')
		$dateRes = date("Y-m-d", strtotime("first day of this month"));
	elseif($date == 'FiscalBegin'){
		$dateRes = begin_fiscalyear();
	}

	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'.$label.'</label><div class="col-md-10"><input type="text" id="date" class="form-control StartDate" name="'.$name.'" value="'.$dateRes.'"></div></div>';
}

function End_date($name="start_date", $date='Today'){
	if($date == 'Today')
		$dateRes = date('Y-m-d');
	elseif($date == 'ThisMonth')
		$dateRes = date("Y-m-d", strtotime("last day of this month"));
	
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("End Date").'</label><div class="col-md-10"><input type="text" id="date" class="form-control EndDate" name="'.$name.'" value="'.$dateRes.'" ></div></div>';
}

function Graphics_dropdown($name="Graphics"){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Graphics").'</label><div class="col-md-10"><select id="'.$name.'" name="'.$name.'" class="form-control"><option value="0">'._("No Graphics").'</option><option value="1">'._("Vertical bars").'</option><option value="2">'._("Horizontal bars").'</option><option value="3">'._("Dots").'</option><option value="4">'._("Lines").'</option><option value="5">'._("Pie").'</option><option value="6">'._("Donut").'</option></select></div></div>';
}

function Compare_to_dropdown($name="Compare_to"){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Compare To").'</label><div class="col-md-10"><select id="'.$name.'" name="'.$name.'" class="form-control"><option value="0">'._("Accumulated").'</option><option value="1">'._("Period Y-1").'</option><option value="2">'._("Budget").'</option></select></div></div>';
}

function yes_no_dropdown($name="decimal_value", $label, $selected='0'){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'.$label.'</label><div class="col-md-10"><select id="'.$name.'" name="'.$name.'" class="form-control"><option value="0" '.($selected== 0 ? 'selected': '' ).'>'._("No").'</option><option value="1" '.($selected== 1 ? 'selected': '' ).'>'._("Yes").'</option></select></div></div>';
}

function Customers_list_dropdown($name='Customers', $label='Customer'){
	
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._($label).'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
	$customers = Get_customers(); 
    echo '<option value="" selected > '._("No Customer").' </option>'; 
    foreach($customers as $customer){
        echo '<option value="'.$customer['debtor_no'].'" > '.$customer['debtor_ref'].' - '.$customer['curr_code'].'</option>';
    }
    echo '</select></div></div>';
}

function Get_customers(){
	$sql = "SELECT debtor_no, debtor_ref, curr_code, inactive FROM ".TB_PREF."debtors_master  ORDER BY debtor_ref";
	return  fadb_query($sql, "The dimension could not be retrieved");
}

function Suppliers_list_dropdown($name='Suppliers', $label="Supplier"){
	
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._($label).'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
	$suppliers = Get_suppliers(); 
    echo '<option value="" selected > '._("No Supplier").' </option>'; 
    foreach($suppliers as $supplier){
        echo '<option value="'.$supplier['supplier_id'].'" > '.$supplier['supp_ref'].' - '.$supplier['curr_code'].'</option>';
    }
    echo '</select></div></div>';
}

function Get_suppliers(){
	$sql = "SELECT supplier_id, supp_ref, curr_code, inactive FROM ".TB_PREF."suppliers  ORDER BY supp_ref";
	return  fadb_query($sql, "The dimension could not be retrieved");
}

function Currencies_list_dropdown($name='Currences'){	
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Currencies Filter").'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
	$currencies = Get_currencies(); 
    echo '<option value="" selected > '._("No Currency").' </option>'; 
    foreach($currencies as $currency){
        echo '<option value="'.$currency['curr_abrev'].'" > '.$currency['name'].'</option>';
    }
    echo '</select></div></div>';
}

function Get_currencies(){
	$sql="SELECT curr_abrev, concat(curr_abrev,' - ', currency) AS name FROM ".TB_PREF."currencies";
	return  fadb_query($sql, "The dimension could not be retrieved");
}


function Get_sales_areas_dropdown($name='Sales_areas'){	
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Sales Areas").'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
	$sales_areas = Get_sales_areas(); 
    echo '<option value="" selected > '._("No Sales Area").' </option>'; 
    foreach($sales_areas as $sales_area){
    	if($sales_area['inactive'] == 0)
        echo '<option value="'.$sales_area['area_code'].'" > '.$sales_area['description'].'</option>';
    }
    echo '</select></div></div>';
}

function Get_sales_areas(){
	$sql="SELECT area_code, description, inactive FROM ".TB_PREF."areas ORDER BY description";
	return  fadb_query($sql, "The areas could not be retrieved");
}

function Get_sales_folks_dropdown($name='Sales_folks'){	
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'._("Sales Folks").'</label><div class="col-md-10"><select id="'.$name.'" autocomplete="off" name="'.$name.'" class="form-control">';
	$sales_folks = Get_sales_folks(); 
    echo '<option value="" selected > '._("No Sales Folks").' </option>'; 
    foreach($sales_folks as $sales_folk){
    	if($sales_folk['inactive'] == 0)
        echo '<option value="'.$sales_folk['salesman_code'].'" > '.$sales_folk['salesman_name'].'</option>';
    }
    echo '</select></div></div>';
}

function Get_sales_folks(){
	$sql="SELECT salesman_code, salesman_name, inactive FROM ".TB_PREF."salesman ORDER BY salesman_name";
	return  fadb_query($sql, "The salesman could not be retrieved");
}

function textbox_report($name="textbox", $label="Text"){
	echo '<div class="form-group"><label for="'.$name.'" class="col-md-2 control-label">'.$label.'</label><div class="col-md-10"><input type="text" id="'.$name.'" name="'.$name.'" class="form-control" value=""></div></div>';
}

function gregorian_to_jalali ($g_y, $g_m, $g_d)
{
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);

   	$gy = $g_y - 1600;
   	$gm = $g_m - 1;
   	$gd = $g_d - 1;

   	$g_day_no = 365 * $gy + div($gy + 3, 4) - div($gy + 99, 100) + div($gy + 399, 400);

   	for ($i = 0; $i < $gm; ++$i)
      	$g_day_no += $g_days_in_month[$i];
   	if ($gm > 1 && (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)))
      	/* leap and after Feb */
      	$g_day_no++;
   	$g_day_no += $gd;
   	$j_day_no = $g_day_no - 79;

   	$j_np = div($j_day_no, 12053); /* 12053 = 365*33 + 32/4 */
   	$j_day_no %= 12053;

   	$jy = 979 + 33 * $j_np + 4 * div($j_day_no, 1461); /* 1461 = 365*4 + 4/4 */

   	$j_day_no %= 1461;

   	if ($j_day_no >= 366) 
   	{
      	$jy += div($j_day_no - 1, 365);
      	$j_day_no = ($j_day_no - 1) % 365;
   	}

   	for ($i = 0; $i < 11 && $j_day_no >= $j_days_in_month[$i]; ++$i)
      	$j_day_no -= $j_days_in_month[$i];
   	$jm = $i + 1;
   	$jd = $j_day_no + 1;

   	return array($jy, $jm, $jd);
}

function jalali_to_gregorian($j_y, $j_m, $j_d)
{
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);

  	$jy = $j_y - 979;
   	$jm = $j_m - 1;
   	$jd = $j_d - 1;

   	$j_day_no = 365 * $jy + div($jy, 33) * 8 + div($jy % 33 + 3, 4);
   	for ($i = 0; $i < $jm; ++$i)
      	$j_day_no += $j_days_in_month[$i];

   	$j_day_no += $jd;

   	$g_day_no = $j_day_no + 79;

   	$gy = 1600 + 400 * div($g_day_no, 146097); /* 146097 = 365*400 + 400/4 - 400/100 + 400/400 */
   	$g_day_no %= 146097;

   	$leap = true;
   	if ($g_day_no >= 36525) /* 36525 = 365*100 + 100/4 */
   	{
      	$g_day_no--;
      	$gy += 100 * div($g_day_no,  36524); /* 36524 = 365*100 + 100/4 - 100/100 */
      	$g_day_no %= 36524;

      	if ($g_day_no >= 365)
         	$g_day_no++;
      	else
         	$leap = false;
   	}

   	$gy += 4 * div($g_day_no, 1461); /* 1461 = 365*4 + 4/4 */
   	$g_day_no %= 1461;

   	if ($g_day_no >= 366) 
   	{
      	$leap = false;

      	$g_day_no--;
      	$gy += div($g_day_no, 365);
      	$g_day_no %= 365;
   	}

   	for ($i = 0; $g_day_no >= $g_days_in_month[$i] + ($i == 1 && $leap); $i++)
      	$g_day_no -= $g_days_in_month[$i] + ($i == 1 && $leap);
   	$gm = $i + 1;
   	$gd = $g_day_no + 1;

   	return array($gy, $gm, $gd);
}

function get_company_currency()
{
	return get_company_details('curr_default');
}

//----------------------------------------------------------------------------------

function get_exchange_rate_from_home_currency($currency_code, $date_)
{
	if ($currency_code == get_company_currency() || $currency_code == null)
		return 1.0000;


	$rate = get_last_exchange_rate($currency_code, $date_);

	if (!$rate)
	{
		// no stored exchange rate, just return 1
		//display_error(
			//sprintf(_("Cannot retrieve exchange rate for currency %s as of %s. Please add exchange rate manually on Exchange Rates page."),
				// $currency_code, $date_));
		return 1.000;
	}

	return $rate['rate_buy'];
}

function get_last_exchange_rate($curr_code, $date_)
{
	$date = date2sql($date_);

	$sql = "SELECT rate_buy, max(date_) as date_
			FROM ".TB_PREF."exchange_rates
			WHERE curr_code = ".fadb_escape($curr_code)."
				AND date_ <= '$date' GROUP BY rate_buy ORDER BY date_ Desc LIMIT 1";

	$result = fadb_query($sql, "could not query exchange rates");


	if (fadb_num_rows($result) == 0)
		return false;

	return fadb_fetch_assoc($result);
}


define('FLOAT_COMP_DELTA', 0.004);

function floatcmp($a, $b)
{
    return $a - $b > FLOAT_COMP_DELTA ? 1 : ($b - $a > FLOAT_COMP_DELTA ? -1 : 0);
}

function get_area_name($id)
{
	$sql = "SELECT description FROM ".TB_PREF."areas WHERE area_code=".fadb_escape($id);

	$result = fadb_query($sql, "could not get sales type");

	$row = fadb_fetch_row($result);
	return $row[0];
}

function get_salesman_name($id)
{
	$sql = "SELECT salesman_name FROM ".TB_PREF."salesman WHERE salesman_code=".fadb_escape($id);

	$result = fadb_query($sql, "could not get sales type");

	$row = fadb_fetch_row($result);
	return $row[0];
}


function get_crm_persons($type=null, $action=null, $entity=null, $person=null, $unique=false)
{
	$sql = "SELECT t.*, p.*, r.id as contact_id FROM ".TB_PREF."crm_persons p,"
		.TB_PREF."crm_categories t, "
		.TB_PREF."crm_contacts r WHERE ";
	$sel = array('r.type=t.type', 'r.action=t.action', 'r.person_id=p.id');

	if ($type) 
		$sel[] = 't.type='.fadb_escape($type);

	if ($action) 
		$sel[] = 't.action='.fadb_escape($action);

	if ($entity) 
		$sel[] = 'r.entity_id='.fadb_escape($entity);

	if ($person)
		$sel[] = 'r.person_id='.fadb_escape($person);

	$sql .= implode (" AND ", $sel);

	if ($unique)
		$sql .= " GROUP BY person_id";
	else
	 	$sql .= " ORDER BY contact_id";

	$result = fadb_query($sql, "Can't get crm persons");
	// fallback to general contacts
	if (!fadb_num_rows($result) && $action && $action != 'general')
		return get_crm_persons($type, 'general', $entity, $person, $unique);
	else
		return $result;
}

?>
