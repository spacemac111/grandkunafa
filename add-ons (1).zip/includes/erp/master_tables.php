<?php 
require_once(FA_PATH.'config_db.php');
require_once(ABSPATH.'includes/master-table.php' );

global $current_user, $selected_user, $Refs, $price_dec, $db_connections, $sql_details; 


function CustomerInvoices(){
	global $price_dec, $sql_details;
	//$pric_dec = user_price_dec();
	var_dump($sql_details);
	$table = FA_PREF. 'debtor_trans';
	$table2= FA_PREF. 'debtors_master';
	$primaryKey = 'debtor_no';
	
	$columns = array(
		//array( 'db' => '`so`.`trans_no`', 	'dt' => 0,	'field' => 'trans_no'	),
		array( 'db' => '`so`.`reference`',  'dt' => 0,	'field' => 'reference', 'formatter' => function( $d, $row ) 	{ return '<a href="#" class="pdfModal PrintReceipt" data-trans_no="'.$row[7].'" data-type="10" data-target="#pdfModal" data-toggle="modal" style="font-weight: 600;text-decoration:none;" > '.$d.' </a>'; } ),
		array( 'db' => '`debtor`.`name`',  	'dt' => 1,	'field' => 'name'),
		array( 'db' => '`so`.`tran_date`',	'dt' => 2,	'field' => 'tran_date','formatter' => function( $d, $row ) 	{ return date( 'jS M y', strtotime($d)); } ),
		array( 'db' => '`so`.`due_date`',   'dt' => 3,	'field' => 'due_date', 'formatter' => function( $d, $row ) 	{ return date( 'jS M y', strtotime($d)); } ),
		array( 'db' => '`so`.`ov_amount`',  'dt' => 4,	'field' => 'ov_amount','formatter' => function( $d, $row )	{global $price_dec; return round(get_total_Amount($row[7]), $price_dec);} ),
		array( 'db' => '`so`.`alloc`',  	'dt' => 5,	'field' => 'alloc','formatter' => function( $d, $row )	{global $price_dec;  $alloc =  round((get_total_Amount($row[7])-$d ), $price_dec);
				return ($alloc > 0 ? '<a href="#" class="PaymentModal" data-trans_no="'.$row[7].'" data-target="#PaymentModal"  style="font-weight: 600;text-decoration:none;" > '.$alloc.' </a>' : 0 );} ),
		array( 'db' => '`so`.`trans_no`',   'dt' => 6,	'field' => 'trans_no','formatter' => function( $d, $row )	{ global $price_dec;  $alloc =  round((get_total_Amount($row[7])-$row[5] ), $price_dec);  return ($alloc == 0 ? '<a href="#" class="SalesReturn" data-trans_no="'.$row[7].'" data-type="10"  style="font-weight: 600;text-decoration:none;" > <i class="material-icons"> rotate_90_degrees_ccw</i> </a>' : '' );} 	),
		array( 'db' => '`so`.`trans_no`',   'dt' => 7,	'field' => 'trans_no','formatter' => function( $d, $row )	{ return get_invoice_status(10,$d);} 	)
	);

	$joinQuery = "FROM `{$table}` AS `so` LEFT JOIN {$table2} AS debtor ON so.debtor_no = debtor.debtor_no";  
	$extraWhere = ' `so`.`type` = 10 '; //AND `so`.`debtor_no` ='.$debtor_no; 
	if($current_user['role'] == 'Salesman')
		$extraWhere .= ' AND `so`.`salesman` ='.$current_user['s_id'];
	if(isset($_GET['FilterStatus'])){
		if($_GET['FilterStatus'] == 'Received'){
			$extraWhere .= " AND ROUND((so.ov_amount + so.ov_gst + so.ov_freight + so.ov_freight_tax + so.ov_discount), 2) = ROUND(so.alloc, 2) ";
		}elseif($_GET['FilterStatus'] == 'Overdue'){
			$extraWhere .=" AND CURDATE() > so.due_date AND ROUND((so.ov_amount + so.ov_gst + so.ov_freight + so.ov_freight_tax + so.ov_discount), 2) <> ROUND(so.alloc, 2)";
		}elseif($_GET['FilterStatus'] == 'Yet To Receive' ){
			$extraWhere .=" AND ROUND((so.ov_amount + so.ov_gst + so.ov_freight + so.ov_freight_tax + so.ov_discount), 2) <> ROUND(so.alloc, 2)";
		}
	}

	if(isset($_GET['FilterDate'])){
		if($_GET['FilterDate'] == 'Today'){
			$extraWhere .= " AND so.tran_date = '".date('Y-m-d')."'";
		}elseif($_GET['FilterDate'] == 'Yesterday'){
			$extraWhere .= " AND so.tran_date = '".date('Y-m-d',strtotime("-1 days"))."'";
		}elseif($_GET['FilterDate'] != -1) {
			if($_GET['FilterDate'] == 'LastMonth'){
		        $today1 = date('Y-m-d', strtotime('last day of previous month'));
		        $begin1 = date('Y-m-d', strtotime('first day of previous month'));
		    }elseif($_GET['FilterDate'] == 'ThisMonth'){
		        $begin1 = date("Y-m-d", strtotime("first day of this month"));
		        $today1 = date("Y-m-d", strtotime("last day of this month"));
		    }elseif($_GET['FilterDate'] =='LastWeek'){
		        $begin1 = date("Y-m-d", strtotime("last week monday"));
		        $today1 = date("Y-m-d", strtotime("last week sunday"));
		    } elseif($_GET['FilterDate'] =='ThisWeek'){
		        $begin1 = date("Y-m-d", strtotime("this week monday"));
		        $today1 = date("Y-m-d", strtotime("this week sunday"));
		    }
		    $extraWhere .= " AND so.tran_date >= '".$begin1."' AND so.tran_date <= '".$today1."'";
		}
	}
	if(isset($_GET['Salesman']) && $_GET['Salesman'] > 0 ){
		$extraWhere .=" AND so.salesman = ".$_GET['Salesman']." ";
	}

	$wigepa_sources = Master_Table::simple( $_GET, $sql_details, $table, $primaryKey, $columns, $joinQuery , $extraWhere, '', true );
}