<?php


function GetSalesTypeName($id){
	$sql ="SELECT sales_type FROM ".TB_PREF."sales_types WHERE id=".$id." LIMIT 1";
	$sale_type = fadb_query($sql, "Can't get sales type");
	if($row = fadb_fetch_row($sale_type)){
		return $row[0];
	} else
		return '';
}

function getPageTitle($id){
	$data = GetRow("pages", array("ID" => $id));
	return $data['pageTitle'];
}

function get_sales_order($tbl_no){
	$sql = "SELECT order_no FROM ".TB_PREF."sales_orders WHERE trans_type =30 AND version=0 AND table_no =".$tbl_no;
    $sales_order= fadb_query($sql, "can't get results");
    if($row = fadb_fetch_row($sales_order)){
		return $row[0];
	} else
		return '';
	
}

function get_customer_info($order_no){
	$sql = "SELECT deb.debtor_no, debtor_ref,  curr_code, cur.curr_symbol FROM ".TB_PREF."debtors_master as deb, ".TB_PREF."currencies as cur, ".TB_PREF."sales_orders as sorder WHERE  sorder.debtor_no=deb.debtor_no AND deb.curr_code = cur.curr_abrev AND sorder.order_no = ".$order_no." ORDER BY debtor_no";
	$res = fadb_query($sql, "can't get results");
	if($row = fadb_fetch_row($res)){

		return $row[0];
	}else 
	return '';
}


function input_num($input) {
    global $current_user, $thoseps, $decseps;

    $fa_user = FAGetRow('users', ['ID' => $current_user['fa_user_id']]);

    $num = trim($input);
    $sep =  $thoseps[$fa_user['tho_sep']];
    if ($sep!='')
    	$num = str_replace( $sep, '', $num);
   
    $sep = $decseps[$fa_user['dec_sep']];
    if ($sep!='.')
    	$num = str_replace( $sep, '.', $num);

    if (!is_numeric($num))
	  	return false;
    $num = (float)$num;
    if ($num == (int)$num)
	  	return (int)$num;
    else
	  	return $num;
}

function AddPOSItemToCart($TableNo,$token_no,$del_no,$status, $CustomerId,$deliverID, $currency, $tax_group_id, $stock_id, $price, $qty, $total_q, $total_am, $step = 0, $discount= 0, $date=null){
	global $current_user;

	$price_dec = user_price_dec();
	if($date == null)
		$date = date('Y-m-d');
	fadb_query("SET NAMES UTF8", '');
	// $stock_details = FAGetRow('stock_master', array('stock_id' => $stock_id));
	$final_result = ['details' => []];
	$kit = get_item_kit($stock_id);
	if(fadb_num_rows($kit) > 1)
		$price_vary = true;
	else
		$price_vary = false;
	$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
	$qty_dec = FAGetSingleValue('users', 'qty_dec', ['ID' => $current_user['fa_user_id']]);
	$kit_Added = false;
	while($stock_details = fadb_fetch($kit)) {
		if(($price_vary || $stock_details['stock_id'] != $stock_details['item_code'] ) && $non_detailed_sales_kit){
			$stock_details['stock_id'] = $stock_details['item_code'];
			$stock_details['comp_name'] = $stock_details['description'];
			$kit_Added = true;
		}
		if($step == 1){
			$discount = round(($discount / 100), $price_dec);
		}else{
			$discount = round($discount, $price_dec);
		}	
		$line_total1 = $price * $qty;
		$line_total = number_format(floatval($line_total1), $price_dec,'.', '');
		$total_am = number_format(floatval($total_am), $price_dec, '.', '');
		$_SESSION['CustomerId'] = $CustomerId;
		$_SESSION['deliverID'] = $deliverID;
		$_SESSION['status'] = $status;
		if($status == 'takeaway'){
			$_SESSION['TableNo'] = 0;
			$_SESSION['del_no'] = 0;

			if($token_no > 0){
				$_SESSION['token_no'] = $token_no;
			}else{
				$_SESSION['token_no'] = 'tokenno';
			}

		}elseif($status == 'doordelivary'){
			$_SESSION['TableNo'] = 0;
			$_SESSION['token_no'] = 0;
			if($del_no > 0){
				$_SESSION['del_no'] = $del_no;
			}else{
				$_SESSION['del_no'] = 'delivaryno';
			}
		}else{
			$_SESSION['TableNo'] = $TableNo;
			$_SESSION['token_no'] = 0;
			$_SESSION['del_no'] = 0;

		}
		$_SESSION['currency'] = $currency;
		if(!isset($_SESSION['currency']) || $_SESSION['CustomerId'] != $CustomerId ){
			$currency_code = FAGetSingleValue('debtors_master','curr_code', array('debtor_no'=>$CustomerId));
			$_SESSION['currency'] = FAGetSingleValue('currencies','curr_symbol', array('curr_abrev'=> $currency_code));
		}
		$_SESSION['tax_group_id'] = $tax_group_id;
		$_SESSION['date'] = $date;

		if($kit_Added && $non_detailed_sales_kit)
			$price_calculated = get_kit_price($stock_details['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false);
		else
			$price_calculated = ($stock_details['quantity'] > 1 ? get_price($stock_details['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false) : input_num($price)); 
		$itemArray = array(
			'stock_id' => $stock_details['stock_id'],
			'name' => $stock_details['comp_name'], 
			'stock_quantity' => (is_numeric((float)$total_q) && $total_q != 0  ? $total_q : Get_stock_quantity($stock_details['stock_id'])),
			'qty' => round($qty, ($qty_dec > 0 ? $qty_dec : 2)),  //*$stock_details['quantity']
			'price' => $price_calculated, 
			'standard_cost' => $stock_details['material_cost'], 
			'amount' => round(($qty), ($qty_dec > 0 ? $qty_dec : 2))*$price_calculated, //*$stock_details['quantity']
			'discount' => $discount,
			'line_total' => round(($qty), ($qty_dec > 0 ? $qty_dec : 2))*$price_calculated //*$stock_details['quantity']
		);
		if($kit_Added && $non_detailed_sales_kit){
			$itemArray['kit'] = 'yes';
		} else 
			$itemArray['kit'] = '';
		$stock_details['exist'] = $exist = 'no';

		if(isset($_SESSION["cart_item"])){
			$kit_found = false;
			$found=true;
			foreach($_SESSION["cart_item"] as $keys => $values){
				if($_SESSION["cart_item"][$keys]['stock_id'] == $stock_details['stock_id'])  {		     
			     	$_SESSION["cart_item"][$keys]['qty'] = $_SESSION["cart_item"][$keys]['qty'] + ($qty); //*$stock_details['quantity']);
			     	$_SESSION["cart_item"][$keys]['amount'] = $_SESSION["cart_item"][$keys]['qty'] *( $_SESSION["cart_item"][$keys]['price']);
			     	if($discount > 0 )
					 	$_SESSION["cart_item"][$keys]['discount'] = $discount;		     
			     	$_SESSION["cart_item"][$keys]['line_total'] = $_SESSION["cart_item"][$keys]['amount'] -($_SESSION["cart_item"][$keys]['amount']* $_SESSION["cart_item"][$keys]['discount']);
			     	$final_qty = $_SESSION["cart_item"][$keys]['qty'];
			     	$final_amount = number_format(floatval($_SESSION["cart_item"][$keys]['amount']), $price_dec, '.', '');
			     	$final_discount = number_format(floatval($_SESSION["cart_item"][$keys]['discount']), $price_dec, '.', '');
			     	$final_line_total = number_format(floatval($_SESSION["cart_item"][$keys]['line_total']), $price_dec, '.', ''); 			     				     	
				 	$stock_details['key'] = $last_id = $keys;					
					$stock_details['exist'] = $exist = 'yes';
					$found = false;
					
			    }
			}
			if($found) {	    
			    $_SESSION["cart_item"][] = $itemArray;
			    $final_qty = $qty;
				$final_amount = number_format(floatval($total_am), $price_dec, '.', '');
				$final_discount = $discount;
				$final_line_total = number_format(floatval($line_total), $price_dec, '.', '');
		   }
		} else {
			$_SESSION["cart_item"][] = $itemArray;
			$final_qty = $qty;
			$final_amount = number_format(floatval($total_am), $price_dec, '.', '');
			$final_discount = $discount;
			$final_line_total = number_format(floatval($line_total), $price_dec, '.', '');
		}

		$_SESSION['trans_no'] =  0;
		if(isset($_POST['order_id']) && $_POST['order_id'] > 0 )
			$_SESSION['items_count'] =  FAGetSingleValue('sales_order_details', 'COUNT("*")', array('trans_type' => 30, 'order_no' => $_POST['order_id']), null,false);
		else
			$_SESSION['items_count'] = 0 ;
		$_SESSION['trans_type'] =  ST_SALESINVOICE;
		
		end($_SESSION["cart_item"]);
	    if($exist == 'no')
		    // $last_id=key($_SESSION["cart_item"]);
		   $stock_details['key'] = $last_id=key($_SESSION["cart_item"]);

		$_SESSION['subtotal_price'] = 0;       
	    foreach ($_SESSION['cart_item'] as $k => $value) {       
	       $_SESSION['subtotal_price'] += $value["line_total"];       
	    }    
	    $tax_val = fa_get_taxes($_SESSION);
	    $_SESSION['tax_val'] = $tax_val = number_format(floatval($tax_val), $price_dec, '.', '');   
	    if($_SESSION['tax_included'] == 1) {		
	    	$_SESSION['subtotal_price'] -= $_SESSION['tax_val']; 
			$f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
			$tl_price = $f_subtotal_price + $_SESSION['tax_val'];
		} else {
			$tl_price = $f_subtotal_price = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');
		}
	    
	    $_SESSION['grand_total']  = number_format(floatval($tl_price), $price_dec, '.', '');
	    $_SESSION['freight_cost']  = number_format(floatval($_SESSION['freight_cost']), $price_dec, '.', '');
	    $_SESSION['subtotal_price'] = number_format(floatval($_SESSION['subtotal_price']), $price_dec, '.', '');

	    /*if($non_detailed_sales_kit && $itemArray['kit'] != '') {
	    	if(!$kit_Added){

	    		$this_qty = $_SESSION['cart_item'][$stock_details['key']]['qty'];
	    		$stock_details = get_item_kit($itemArray['kit'], true);	    		
	    		
	    		if(!isset($stock_details['stock_id']))
	    			$stock_details = $stock_details[0];

	    		//var_dump($stock_details);
	    		//var_dump($itemArray);

	    		$stock_details['price'] = get_kit_price($stock_details['item_code'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false);

	    		$this_qty = round($this_qty/$stock_details['quantity'], ($qty_dec > 0 ? $qty_dec : 2));

	    		$final_result['details'][] = array('stock_id' => $stock_details['item_code'], 
	    				'name' 			=> $stock_details['description'], 
	    				'price'			=> number_format2($stock_details['price'], $price_dec), 
	    				'stock_quantity' => $stock_details['stock_quantity'], 
	    				'qty' 			=> $this_qty, 
	    				'amount' 		=> number_format2($stock_details['price']*$this_qty, $price_dec), 
	    				'discount'		=> $final_discount*100, 
	    				'line_total' 	=> number_format2($_SESSION['cart_item'][$stock_details['key']]['line_total'], $price_dec), 
	    				'last_id' 		=> $stock_details['key'], 
	    				'exist' 		=> ($kit_found ? 'yes' : 'no'),
	  					'kit' 			=> $itemArray['kit']);
	    		$kit_Added = true;
	    	}
	    } else */
	  		$final_result['details'][] = array('stock_id' => $stock_details['stock_id'], 'name' => $stock_details['comp_name'], 'price' => number_format2($itemArray['price'], $price_dec), 'stock_quantity' => $itemArray['stock_quantity'], 'qty' => $_SESSION['cart_item'][$stock_details['key']]['qty'], 'amount' => number_format2($_SESSION['cart_item'][$stock_details['key']]['amount'], $price_dec), 'discount' => $final_discount*100, 'line_total' => number_format2($_SESSION['cart_item'][$stock_details['key']]['line_total'], $price_dec), 'last_id' => $stock_details['key'], 'exist' => $stock_details['exist'],
	  		'kit' => $itemArray['kit']); 
	  	if($non_detailed_sales_kit)
	  			break;
	  		
	}

	$final_result['subtotal_price'] = $f_subtotal_price;
	$final_result['tax_val'] = $tax_val; 
	$final_result['grand_total'] = $_SESSION['grand_total']+($_SESSION['tax_included'] == 1 ? 0 : $tax_val);
	$final_result['currency'] = trim($_SESSION['currency']);
	$final_result['table_no'] = $_SESSION['TableNo'];
  	$final_result['token_no'] = $_SESSION['token_no']; 
  	$final_result['del_no'] = $_SESSION['del_no'];
  	$final_result['freight_cost'] = $_SESSION['freight_cost'];
  	$final_result['cart_count'] = count($_SESSION['cart_item']);
	return json_encode($final_result);
}


function check_items_in_kit($kit_code, $item_code, $recurse=false){
	$result = get_item_kit($kit_code);
	if ($result){
		while ($myrow = fadb_fetch($result)){

			if ($myrow['stock_id'] == $item_code){
				return 1;
			}

			if ($recurse && $myrow['item_code'] != $myrow['stock_id'] && check_items_in_kit($item_code, $myrow['stock_id'], true)){
				return 1;
			}
		}
	}
	return 0;
}
function get_kit_props($kit_code){
	$sql = "SELECT description, category_id FROM ".TB_PREF."item_codes WHERE item_code=".fadb_escape($kit_code);
	$res = fadb_query($sql, "kit name query failed");
	return fadb_fetch($res);
}

if(isset($_GET['change_sys_prefs']) && $_GET['change_sys_prefs'] == 'yes'){
	echo FAUpdate('sys_prefs', ['name' => $_POST['name']], ['value' => $_POST['value'], 'category' => 'setup.company', 'type' => 1 ]);
}

if(isset($_GET['update_dimension']) && $_GET['update_dimension'] == 'yes'){
	$_SESSION[$_POST['name']]= $_POST['value'];
}

if(isset($_GET['ChangePDFSize']) ){
	//$_SESSION[$_POST['name']]= $_POST['ChangePDFSize'];
	echo Update('users', ['ID' => $_SESSION['user_id']], ['pdf_template' => $_GET['ChangePDFSize']]);
}

if(isset($_GET['submit_newsaleskit']) && $_GET['submit_newsaleskit'] == 'yes'){
	
	$kit_code = $_POST['item_id'];

	$item_code = $_POST['component_itemcode'];
	if(check_items_in_kit($kit_code, $item_code, true)){

		echo json_encode(array('msg' => "Item already Presents", 'data' => 0));
	}else{
		echo add_item_code($kit_code, $item_code, $_POST['kit_desc'], $_POST['kit_catid'], $_POST['quantity'], $foreign=0);

	}

	// echo add_item_code($_POST['kit_code'], $_POST['component_sel'], $_POST['kit_description'], $_POST['category_id'], $_POST['qty'], $foreign=0);

	// echo add_item_code($selected_kit, get_post('component'), get_post('description'),
	// 		 get_post('category'), input_num('quantity'), 0);
}


function add_item_code($item_code, $stock_id, $description, $category, $qty, $foreign=0){
	// fadb_query("SET NAMES UTF8", 'Cant execute');
	//Check if item code already exits?
	$sql = "INSERT INTO ".TB_PREF."item_codes
			(item_code, stock_id, description, category_id, quantity, is_foreign) 
			VALUES( ".fadb_escape($item_code).",".fadb_escape($stock_id).",
	  		".fadb_escape($description).",".fadb_escape($category)
	  		.",".fadb_escape($qty).",".fadb_escape($foreign).")";

	fadb_query($sql,"an item code could not be added");
	$id = fadb_insert_id();
	if($id > 0 )
		return json_encode(array('msg' => 'Successfully inserted', 'data' => 1, 'id' => $id));
	else
		return json_encode(['msg' => 'Failed to insert', 'data' => 0 ]);
}


function Get_AttachID_From_trans_no($trans_no){
	return GetSingleValue('attachments', 'id', ['type_no' => 20, 'trans_no' => $trans_no]);
}