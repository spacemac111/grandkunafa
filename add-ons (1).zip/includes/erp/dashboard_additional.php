<?php 

function fa_get_taxes(&$cart){
	$items = array();
	$prices = array();	
	$total_tax =0;
	$dec = user_price_dec();
	$cart_items = $cart['cart_item'];
	foreach ($cart_items as $ln_itm) {
		if(isset($ln_itm['kit']) && $ln_itm['kit'] == 'yes'){
			$kit = get_item_kit($ln_itm['stock_id'], true);
			//var_dump($kit);
			if(!empty($kit)){
				foreach($kit as $line_item){
					if(isset($line_item['stock_id'])){
						$price_calculated = get_price($line_item['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false); 
						$items[] = $line_item['stock_id'];
						$prices[] = ($ln_itm['qty'] * $price_calculated * (1 - $ln_itm['discount']));
					}
				}
			}
		} else {
			$items[] = $ln_itm['stock_id'];
			$prices[] = ($ln_itm['qty'] * $ln_itm['price']* (1 - $ln_itm['discount']));
		}
	}
	//echo $cart['tax_group_id'].'-';
	
	$cart['tax_details'] = $allTaxes = get_tax_for_items($items, $prices, $shipping_cost, $cart['tax_group_id'], $cart['tax_included']);
	//var_dump($allTaxes);
	foreach($allTaxes as $tax)
		$total_tax += round($tax['Value'], $dec);
	return $total_tax;
}


function get_customers_count(){
	//global $current_user;	
	$sql_cust_count = "SELECT COUNT(*) FROM ".TB_PREF."debtors_master AS debtors, ".TB_PREF."cust_branch AS branch WHERE debtors.debtor_no= branch.debtor_no" ;
	//if($current_user['role'] == 'Salesman')
		//$sql_cust_count .= " AND branch.salesman=".fadb_escape($current_user['s_id']);
	$sql_cust_count_result = fadb_query($sql_cust_count, "could not get sales type");
	$cust_coubt = fadb_fetch_row($sql_cust_count_result);
	return $cust_coubt[0];
}

function total_delivery_by_user($userid){
	$sql_del_count = "SELECT COUNT(*) FROM ".TB_PREF."debtor_trans where type = ".ST_SALESINVOICE." AND deliveryman = ".fadb_escape($userid);
	$sql_del_count_result = fadb_query($sql_del_count, "could not get sales type");
	$del_count = fadb_fetch_row($sql_del_count_result);
	return $del_count[0];	
}
function get_new_delivery($userid){
	$date = date('Y-m-d');
	$sql = "SELECT COUNT(*) FROM ".TB_PREF."sales_orders as so WHERE so.trans_type = 30 AND so.version = 0 AND so.delivery_no > 0 and so.ord_date =".fadb_escape($date)." and  
so.deliveryman='".$userid."' ORDER BY so.order_no DESC";
 fadb_query("SET NAMES UTF8", '');
    $result= fadb_query($sql, "can't get results");
    
       $del_count = fadb_fetch_row($result);
   
    return $del_count[0];
}
function today_sales_count_amount($date = null, $user_price_dec=null){
	global $current_user;
	
	if($date == null){ 
		$type = 1;
		$date = date('Y-m-d');
	} elseif($date == 1){
		$type = 1;
		$date = date('Y-m-d',strtotime("-1 days"));
	} elseif($date == 2) {
		$date = date('Y-m-01');
		$date2 = date('Y-m-t');
	}	
	if($user_price_dec == null)
		$user_price_dec = user_price_dec();
	$sql_cust_count = "SELECT COUNT(*), SUM((ov_amount+ov_freight+ov_discount)*rate) AS total FROM ".TB_PREF."debtor_trans WHERE type=10 AND ";
	
	if(isset($type) && $type == 1 ){
		$sql_cust_count .= "tran_date =".fadb_escape($date);
	} elseif(isset($date2)){
		$sql_cust_count .= "tran_date >=".fadb_escape($date)." AND tran_date <= ".fadb_escape($date2);
	}
	
	if($current_user['role'] == 'Salesman')
		$sql_cust_count .= " AND salesman=".fadb_escape($current_user['s_id']);

	$sql_cust_count_result = fadb_query($sql_cust_count, "could not get sales type");

	$cust_coubt = fadb_fetch_row($sql_cust_count_result);
	return array('count'  => $cust_coubt[0], 'amount' => number_format(($cust_coubt[1]== null ? 0 : $cust_coubt[1]), $user_price_dec));
	
}
function today_deliveries_count_amount($date = null, $user_price_dec=null){
	global $current_user;
		
	if($date == null){ 
		$type = 1;
		$date = date('Y-m-d');
	} elseif($date == 1){
		$type = 1;
		$date = date('Y-m-d',strtotime("-1 days"));
	} elseif($date == 2) {
		$date = date('Y-m-01');
		$date2 = date('Y-m-t');
	}	
	if($user_price_dec == null)
		$user_price_dec = user_price_dec();
	$sql_cust_count = "SELECT COUNT(*), SUM((ov_amount+ov_freight+ov_discount)*rate) AS total FROM ".TB_PREF."debtor_trans WHERE type=10 AND ";
	
	if(isset($type) && $type == 1 ){
		$sql_cust_count .= "tran_date =".fadb_escape($date);
	} elseif(isset($date2)){
		$sql_cust_count .= "tran_date >=".fadb_escape($date)." AND tran_date <= ".fadb_escape($date2);
	}
	
	if($current_user['role'] == 'Deliveryman')
		$sql_cust_count .= " AND deliveryman=".fadb_escape($current_user['ID']);

	$sql_cust_count_result = fadb_query($sql_cust_count, "could not get sales type");

	$cust_coubt = fadb_fetch_row($sql_cust_count_result);
	return array('count'  => $cust_coubt[0], 'amount' => number_format(($cust_coubt[1]== null ? 0 : $cust_coubt[1]), $user_price_dec));

}

function get_suppliers_count(){
	$sql_supp_count = "SELECT COUNT(*) FROM ".TB_PREF."suppliers" ;
	$sql_supp_count_result = fadb_query($sql_supp_count, "could not get sales type");
	$sup_count= fadb_fetch_row($sql_supp_count_result);
	return $sup_count[0];
}



function get_items_count(){
	$sql_item_count = "SELECT COUNT(*) FROM ".TB_PREF."stock_master WHERE mb_flag!='F'" ;
	$sql_item_count_result = fadb_query($sql_item_count, "could not get sales type");
	$item_count= fadb_fetch_row($sql_item_count_result);
	return $item_count[0];
}

function get_uploads_size($format=true){
	global $selected_user;
	$sql_item_count = "SELECT SUM(filesize) FROM ".TB_PREF."attachments " ;
	$sql_item_count_result = fadb_query($sql_item_count, "could not get attachment size");
	if(fadb_num_rows($sql_item_count_result) > 0) {        
		$item_count= fadb_fetch_row($sql_item_count_result);
	} else
		$item_count = 0; 
	if($format)
		return formatSizeUnits($item_count[0]);
	else
		return $item_count[0];
}

function get_uploaded_file_count(){
	global $selected_user;
	$sql_item_count = "SELECT COUNT(id) FROM ".TB_PREF."attachments"; // WHERE userid = ".$selected_user['ID'] ;
	$sql_item_count_result = fadb_query($sql_item_count, "could not get attachment size");
	$item_count= fadb_fetch_row($sql_item_count_result);
	return $item_count[0];
}

function get_processed_file_count(){
	global $selected_user;
	$sql_item_count = "SELECT COUNT(id) FROM ".TB_PREF."attachments WHERE userid = ".$selected_user['ID']." AND status='Processed'" ;
	$sql_item_count_result = db_query($sql_item_count, "could not get sales type");
	$item_count= db_fetch_row($sql_item_count_result);
	return $item_count[0];
}

function get_opening_balance(){
	$f_year = get_current_fiscalyear();	
	$sql_item_count = "SELECT SUM(amount) FROM ".TB_PREF."bank_trans WHERE trans_date < '".$f_year['begin']."'" ;
	$sql_item_count_result = fadb_query($sql_item_count, "could not get sales type");
	$item_count= fadb_fetch_row($sql_item_count_result);
	return round($item_count[0], 2);
}

function get_current_balance(){
	$f_year = get_current_fiscalyear();	
	$today1 = date('Y-m-d');	
	$sql_item_count = "SELECT SUM(amount) FROM ".TB_PREF."bank_trans WHERE trans_date >= '".$f_year['begin']."' AND trans_date <= '$today1'" ;
	$sql_item_count_result = fadb_query($sql_item_count, "could not get sales type");
	$item_count= fadb_fetch_row($sql_item_count_result);
	return round($item_count[0], 2)+get_opening_balance();
}

function get_company_details($detail='coy_name', $db=false){
	if($detail == 'kv_batch' || $detail == 'kv_exp_date'){
		$details = get_company_detailss();
		return $details[$detail];
	}
	$sql_item_count = "SELECT value FROM ".TB_PREF."sys_prefs WHERE name=".fadb_escape($detail) ;
	$sql_result = fadb_query($sql_item_count, "could not get Company Details");	
	if(fadb_num_rows($sql_result) > 0) {
		$item_count = fadb_fetch_assoc($sql_result);
		return $item_count['value'];
	} else {
		return false;
	}
}

function get_saved_item($pos=false){
	$date = date('Y-m-d');
	if($pos)
		$sql = "SELECT count(*) AS cnt FROM ".TB_PREF."sales_orders WHERE trans_type =30 AND version = 0 AND ord_date ='".$date."' ORDER BY order_no ASC";
	else 
		$sql = "SELECT count(*) AS cnt FROM ".TB_PREF."sales_orders WHERE table_no | token_no | delivery_no = 0 AND trans_type =30 AND version = 0 AND ord_date ='".$date."' ORDER BY order_no ASC";
	$sql_result = fadb_query($sql, "Count is less");
	//echo $sql_result;
	if(fadb_num_rows($sql_result) > 0) {
		$item_count = fadb_fetch_assoc($sql_result);
		return $item_count['cnt'];
	} else {
		return false;
	}
}


function InsertAttachment($description, $type_no, $trans_no, $unique_name, $trans_date, $filename, $filesize, $filetype){
	$sql = "INSERT INTO ".TB_PREF."attachments (description,type_no,trans_no, unique_name,tran_date, filename, filesize, filetype) VALUES (".fadb_escape($description).","
		.fadb_escape($type_no).",".fadb_escape($trans_no).",".fadb_escape($unique_name).",".fadb_escape($trans_date).",".fadb_escape($filename).",".fadb_escape($filesize).",".fadb_escape($filetype).")";
		
	fadb_query($sql, "could not add attachment");	
	return fadb_insert_id();
}

function DeleteAttachment($id){
	$sql ="DELETE FROM ".TB_PREF."attachments WHERE id=".$id." LIMIT 1";
	return fadb_query($sql, "could not add attachment"); 
}

function SalesTypes($id=null){ 
	$sql = "SELECT * FROM ".TB_PREF."sales_types WHERE !inactive";
	if($id){
		$sql .=" AND id = ".fadb_escape($id);
		$data = fadb_query($sql, "Cannot Get Data");
		return fadb_fetch($data);
	} 
	// else
		$result = fadb_query($sql, "Cannot Get Data");
        $final = [];
		while($row =  fadb_fetch($result)){
            $final[] = $row;
        }
    return $final; 
}

function GetAttachment($id){
	$sql = "SELECT * FROM ".TB_PREF."attachments WHERE id=".fadb_escape($id);
	$result = fadb_query($sql, "Could not retrieve attachments");
	return fadb_fetch($result);
}
function get_customer_total_amount($id){
	$sql ="SELECT SUM((ov_amount + ov_discount) * rate * IF(trans.type = 11, -1, 1)) AS total FROM ".TB_PREF."debtor_trans AS trans, ".TB_PREF."debtors_master AS d WHERE trans.debtor_no=d.debtor_no
		AND (trans.type = 10 OR trans.type = 11) AND d.debtor_no = ".$id; 
	$result = fadb_query($sql, "could not get Amount");
	$total_amount = fadb_fetch_row($result);
	return number_format(($total_amount[0]== null ? 0 : $total_amount[0]), $user_price_dec);
	
}
function get_customer_last_bill($id){
	$sql_pre = "SET sql_mode='';";
	fadb_query($sql_pre, "Can't Set Mode");
	$sql = "SELECT (trans.ov_amount + trans.ov_gst + trans.ov_freight + trans.ov_freight_tax + trans.ov_discount) AS TotalAmount FROM ".TB_PREF."debtor_trans as trans WHERE trans.debtor_no = ".$id." AND (trans.type = 10) GROUP BY trans.trans_no, trans.type ORDER BY trans.tran_date DESC limit 1";
	$result = fadb_query($sql, "Transactions could not be calculated");
	$cust_bill = fadb_fetch_row($result);
	return number_format(($cust_bill[0]== null ? 0 : $cust_bill[0]), $user_price_dec);
	
}
function get_customer_favorite_item($id){

	$sql = "SELECT s.stock_id, s.description,SUM(IF(`d`.`type` IN(11,12,2,0), -1, 1)*trans.quantity) AS qty FROM
			".TB_PREF."debtor_trans_details AS trans, ".TB_PREF."stock_master AS s, ".TB_PREF."debtor_trans AS d 
			WHERE trans.stock_id=s.stock_id AND trans.debtor_trans_type=d.type AND trans.debtor_trans_no=d.trans_no
			AND (d.type = 10 OR d.type = 11) and d.debtor_no =".$id." GROUP by s.stock_id ORDER BY qty DESC, s.stock_id 
		LIMIT 3";
	$result = fadb_query($sql) or die(_("Error getting weekly sales data"));

        $rows = array();
        while($r = fadb_fetch_assoc($result)) {
            $rows[] = $r; 
        }

        return $rows;
}
function get_top_customers($options=null){
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	
	$sql ="SELECT SUM((ov_amount + ov_discount) * rate * IF(trans.type = 11, -1, 1)) AS total,d.debtor_no, d.name FROM ".TB_PREF."debtor_trans AS trans, ".TB_PREF."debtors_master AS d WHERE trans.debtor_no=d.debtor_no
		AND (trans.type = 10 OR trans.type = 11)
		AND tran_date >= '$begin1' AND tran_date <= '$today1' GROUP by d.debtor_no ORDER BY total DESC, d.debtor_no 
		LIMIT 10";
	$result = fadb_query($sql, "could not get Company Details");

	$final= array();
	while($row = fadb_fetch_assoc($result)){
		$final[] = $row;
	}

	return $final;
}

function get_tax_reports($options=null){
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	
	$sql= "SELECT tt.name as taxname, taxrec.*, taxrec.amount*ex_rate AS amount,
	            taxrec.net_amount*ex_rate AS net_amount,
				IF(ISNULL(supp.supp_name), debt.name, supp.supp_name) as name,
				branch.br_name
		FROM ".TB_PREF."trans_tax_details taxrec
		LEFT JOIN ".TB_PREF."tax_types tt
			ON taxrec.tax_type_id=tt.id
		LEFT JOIN ".TB_PREF."supp_trans strans
			ON taxrec.trans_no=strans.trans_no AND taxrec.trans_type=strans.type
		LEFT JOIN ".TB_PREF."suppliers as supp ON strans.supplier_id=supp.supplier_id
		LEFT JOIN ".TB_PREF."debtor_trans dtrans
			ON taxrec.trans_no=dtrans.trans_no AND taxrec.trans_type=dtrans.type
		LEFT JOIN ".TB_PREF."debtors_master as debt ON dtrans.debtor_no=debt.debtor_no
		LEFT JOIN ".TB_PREF."cust_branch as branch ON dtrans.branch_code=branch.branch_code
		WHERE (taxrec.amount <> 0 OR taxrec.net_amount <> 0)
			AND taxrec.trans_type <> 13
			AND taxrec.tran_date >= '$begin1'
			AND taxrec.tran_date <= '$today1'
		ORDER BY taxrec.trans_type, taxrec.tran_date, taxrec.trans_no, taxrec.ex_rate" ;
	$result = fadb_query($sql, "could not get Company Details");

	$res = getTaxTypes();

	$taxes[0] = array('in'=>0, 'out'=>0, 'taxin'=>0, 'taxout'=>0);
	while ($tax=fadb_fetch($res))
		$taxes[$tax['id']] = array('in'=>0, 'out'=>0, 'taxin'=>0, 'taxout'=>0);
				
	$totalnet = $totaltax = 0.0;
	while($trans = fadb_fetch_assoc($result)){
		if (in_array($trans['trans_type'], array(11,20,0))) {
			$trans['net_amount'] *= -1;
			$trans['amount'] *= -1;
		}
	
		$tax_type = $trans['tax_type_id'];
		if ($trans['trans_type']==ST_JOURNAL && $trans['amount']<0) {
			$taxes[$tax_type]['taxin'] += $trans['amount'];
			$taxes[$tax_type]['in'] += $trans['net_amount'];
		}
		elseif ($trans['trans_type']==ST_JOURNAL && $trans['amount']>=0) {
			$taxes[$tax_type]['taxout'] += $trans['amount'];
			$taxes[$tax_type]['out'] += $trans['net_amount'];
		}
		elseif (in_array($trans['trans_type'], array(ST_BANKDEPOSIT,ST_SALESINVOICE,ST_CUSTCREDIT))) {
			$taxes[$tax_type]['taxout'] += $trans['amount'];
			$taxes[$tax_type]['out'] += $trans['net_amount'];
		} else {
			$taxes[$tax_type]['taxin'] += $trans['amount'];
			$taxes[$tax_type]['in'] += $trans['net_amount'];
		}
		$totalnet += $trans['net_amount'];
		$totaltax += $trans['amount'];
		$totalnet += $trans['net_amount'];
		$totaltax += $trans['amount'];	
	}
	$taxtotal = 0;
	$Taxesarray = array(); 
	foreach( $taxes as $id=>$sum){	
		$tax_array = array(); 
		if ($id){
			$tx = getTaxInfo($id);
			$tax_array['name'] =  $tx['name'];
		} else {
			$tax_array['name'] = _("Exempt");
		}
		$tax_array['out'] = $sum['taxout'];
		$tax_array['in'] = $sum['taxin'];
		$tax_array['total'] = $sum['taxout']+$sum['taxin'];
		$taxtotal += $sum['taxout']+$sum['taxin'];
		$Taxesarray[] = $tax_array;
	}
	$Taxesarray['grandtotal'] = $taxtotal;
	return $Taxesarray; 
}

function getTaxTypes() {
	$sql = "SELECT * FROM ".TB_PREF."tax_types ORDER BY id";
    return fadb_query($sql,"No transactions were returned");
}
function getTaxInfo($id)
{
	$sql = "SELECT * FROM ".TB_PREF."tax_types WHERE id=$id";
    $result = fadb_query($sql,"No transactions were returned");
    return fadb_fetch($result);
}

function get_top_suppliers($options=null){
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	$sql ="SELECT SUM((trans.ov_amount + trans.ov_discount) * rate) AS total, s.supplier_id, s.supp_name FROM
		".TB_PREF."supp_trans AS trans, ".TB_PREF."suppliers AS s WHERE trans.supplier_id=s.supplier_id
		AND (trans.type = 20 OR trans.type = 21)
		AND tran_date >= '$begin1' AND tran_date <= '$today1' GROUP by s.supplier_id ORDER BY total DESC, s.supplier_id 
		LIMIT 10";
	$result = fadb_query($sql, "could not get Company Details");

	$final= array();
	while($row = fadb_fetch_assoc($result)){
		$final[] = $row;
	}
	return $final;
}

function get_overdue_purchase_invoices(){
	$f_year = get_current_fiscalyear();
	$begin1 = $f_year['begin'];
	$today1 = date('Y-m-d');
		
	$sql ="SELECT * FROM ((SELECT trans.type, 
		trans.trans_no,
		trans.reference, 
		supplier.supp_name, 
		trans.supp_reference,
    	trans.tran_date, 
		trans.due_date,
		supplier.curr_code, 
    	(trans.ov_amount + trans.ov_gst  + trans.ov_discount) AS TotalAmount, 
		trans.alloc AS Allocated,
		((trans.type = 20 OR trans.type = 21) AND trans.due_date < '$today1') AS OverDue,
    	(ABS(trans.ov_amount + trans.ov_gst  + trans.ov_discount) - trans.alloc <= 0.004) AS Settled
    	FROM ".TB_PREF."supp_trans as trans, ".TB_PREF."suppliers as supplier
    	WHERE supplier.supplier_id = trans.supplier_id
     	AND trans.tran_date >= '$begin1'
    	AND trans.tran_date <= '$today1'
		AND trans.ov_amount != 0) UNION (SELECT 25 as type, 
		trans.id as trans_no,
		trans.reference, 
		supplier.supp_name, 
		po.requisition_no AS supp_reference,
    	delivery_date as tran_date, 
		'' as due_date,
		supplier.curr_code, 
    	'' AS TotalAmount,
		'' AS Allocated,
		0 as OverDue,
    	1 as Settled
    	FROM ".TB_PREF."grn_batch as trans, ".TB_PREF."suppliers as supplier, ".TB_PREF."purch_orders as po
    	WHERE supplier.supplier_id = trans.supplier_id
    	AND trans.purch_order_no = po.order_no
     	AND trans.delivery_date >= '$begin1'
    	AND trans.delivery_date <= '$today1')) as tr  WHERE tr.OverDue = 1 order by trans_no DESC LIMIT 10";

	$kv_overdue_list  = array();
	$ret = fadb_query($sql, "Can't get empl person degrees");
	
	while($cont = fadb_fetch_assoc($ret)) 
		$kv_overdue_list[] = $cont;
	//echo json_encode($cont);
	return $kv_overdue_list;
}

function kv_get_expenses_chartlists() { 
	$sql_collect_ID = "SELECT id FROM ".TB_PREF."chart_types WHERE class_id IN (5,6,7)";
	$kv_class_ids  = array();
	$ret_id = fadb_query($sql_collect_ID, "Can't get empl person degrees");
	
	while($cont_id = fadb_fetch_row($ret_id)) 
		$kv_class_ids[] = $cont_id[0];	

	$sql = "SELECT chart.account_code, chart.account_name FROM ".TB_PREF."chart_master chart,".TB_PREF."chart_types type WHERE chart.account_type=type.id AND type.id IN (".implode(",", $kv_class_ids).")"; 
	$kv_expenses_list  = array();
	$ret = fadb_query($sql, "Can't get empl person degrees");
	
	while($cont = fadb_fetch_row($ret)) 
		$kv_expenses_list[] = $cont;
	//echo json_encode($cont);
	return $kv_expenses_list;		
}

function Expenses($options=null){

	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	
	$charts_list = kv_get_expenses_chartlists();  
	$final= array();	
	foreach($charts_list as $single_char) {
		$sql = "SELECT SUM(IF(amount >= 0, amount, 0)) as debit, 
			SUM(IF(amount < 0, -amount, 0)) as credit, SUM(amount) as balance 
			FROM ".TB_PREF."gl_trans,".TB_PREF."chart_master,".TB_PREF."chart_types, ".TB_PREF."chart_class 
			WHERE ".TB_PREF."gl_trans.account=".TB_PREF."chart_master.account_code AND ".TB_PREF."chart_master.account_type=".TB_PREF."chart_types.id 
			AND ".TB_PREF."chart_types.class_id=".TB_PREF."chart_class.cid AND account='".$single_char[0]."' AND tran_date > IF(ctype>0 AND ctype<4, '0000-00-00', '".$begin1."') AND tran_date <= '".$today1."' "; 
		$result = fadb_query($sql, "could not get Company Details");
		
		while($row = fadb_fetch_assoc($result)){
			if($row['balance'] > 0){
				$row['code'] = $single_char[0];
				$row['name'] = $single_char[1];
				$final[] =  $row;
			}
		}		
	}	
	return $final;
}
function get_weekly_sales(){
	$sql = '';
        if (isset($orderby))
            $sql .= 'SELECT  `Week End`, `Week no`, `Gross Sales`, `Net Sales`, `Tax` '
                .'FROM (';
        $sql .= 'SELECT max(bt.trans_date) `Week End`, '
            .'concat(cast(case when weekofyear(bt.trans_date) = 1 and month(bt.trans_date)=12 then year(bt.trans_date) + 1 else year(bt.trans_date) end as char),cast(weekofyear(bt.trans_date) as char)) `Week no`, '
            .'sum((ttd.net_amount+ttd.amount)*ex_rate) `Gross Sales`, '
            .'sum(ttd.net_amount*ex_rate) `Net Sales`, '
            .'sum(ttd.amount*ex_rate) `Tax` '
        .'FROM '.TB_PREF.'bank_trans bt '
        .'INNER JOIN '.TB_PREF.'cust_allocations ca '
            .'ON bt.type = ca.trans_type_from '
            .'AND bt.trans_no = ca.trans_no_from '
        .'INNER JOIN '.TB_PREF.'debtor_trans dt '
            .'ON dt.type = ca.trans_type_from '
            .'AND dt.trans_no = ca.trans_no_from '
        .'INNER JOIN '.TB_PREF.'debtors_master dm '
            .'ON dt.debtor_no = dm.debtor_no '
        .'INNER JOIN '.TB_PREF.'trans_tax_details ttd '
            .'ON ttd.trans_type = ca.trans_type_to '
            .'AND ttd.trans_no = ca.trans_no_to '
        .'INNER JOIN '.TB_PREF.'tax_types tt '
            .'ON tt.id = ttd.tax_type_id ';
      //  if ($this->data_filter != '')
       //     $sql .= ' WHERE '.$this->data_filter;
        $sql .= ' GROUP BY concat(cast(case when weekofyear(bt.trans_date) = 1 and month(bt.trans_date)=12 then year(bt.trans_date) + 1 else year(bt.trans_date) end as char),cast(weekofyear(bt.trans_date) as char)) LIMIT 5';
       /* if (isset($this->orderby))
            $sql .= ') items order by `'.$this->orderby.'` '.$this->orderby_seq;
        if (isset($this->top))
            $sql .= ' limit '.$this->top;*/
        $result = fadb_query($sql) or die(_("Error getting weekly sales data"));

        $rows = array();
        while($r = fadb_fetch_assoc($result)) {
            $rows[] = $r; 
        }
        return $rows;
}


function Top_selling_items($options=null){

	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
		
	$sql = "SELECT SUM(IF(`d`.`type` IN(11,12,2,0), -1, 1)*((trans.unit_price * trans.quantity) * d.rate)) AS total, s.stock_id, s.description, 
			SUM(IF(`d`.`type` IN(11,12,2,0), -1, 1)*trans.quantity) AS qty, SUM((s.material_cost + s.overhead_cost + s.labour_cost) * trans.quantity) AS costs FROM
			".TB_PREF."debtor_trans_details AS trans, ".TB_PREF."stock_master AS s, ".TB_PREF."debtor_trans AS d 
			WHERE trans.stock_id=s.stock_id AND trans.debtor_trans_type=d.type AND trans.debtor_trans_no=d.trans_no
			AND (d.type = 10 OR d.type = 11) AND tran_date >= '$begin1' AND tran_date <= '$today1' GROUP by s.stock_id ORDER BY total DESC, s.stock_id 
		LIMIT 10";
	$result = fadb_query($sql) or die(_("Error getting weekly sales data"));

        $rows = array();
        while($r = fadb_fetch_assoc($result)) {
            $rows[] = $r; 
        }

        return $rows;
}

function kv_gl_top( &$pg=null, $options=null){
   	
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	
    $sql = "SELECT SUM(amount) AS total, c.class_name, c.ctype FROM
        ".TB_PREF."gl_trans,".TB_PREF."chart_master AS a, ".TB_PREF."chart_types AS t, 
        ".TB_PREF."chart_class AS c WHERE
        account = a.account_code AND a.account_type = t.id AND t.class_id = c.cid
        AND IF(c.ctype > 3, tran_date >= '$begin1', tran_date >= '0000-00-00') 
        AND tran_date <= '$today1' GROUP BY c.cid ORDER BY c.cid"; 
    $result = fadb_query($sql, "Transactions could not be calculated");
	
    $i = 0;
    $total = 0;
	$final_text = '';
    while ($myrow = fadb_fetch($result)){
        if ($myrow['ctype'] > 3){
            $total += $myrow['total'];
            $myrow['total'] = -$myrow['total'];
            if ($pg != null){
                $pg->x[$i] = $myrow['class_name']; 
                $pg->y[$i] = abs($myrow['total']);
            }   
            $i++;
        }  
		$final_text .= '<li>'.$myrow['class_name'].'<div class="text-success pull-right" style="font-weight: 500;" >'.number_format2($myrow['total'], user_price_dec()).'<i class="fa fa-level-up"></i></div></li>';
       // label_row($myrow['class_name'], number_format2($myrow['total'], user_price_dec()),  "class='label' style='font-weight:bold;'", "style='font-weight:bold;' align=right");
    }   	
   
    if ($pg != null){
        $pg->x[$i] = $calculated; 
        $pg->y[$i] = -$total;
    }
	$final_text .=  '<li> <span style="font-weight: 400;" > '._("Calculated Return").'</span> <div class="text-success pull-right"> <span style="font-weight: 500;" >'.number_format2(-$total, user_price_dec()).' </span><i class="fa fa-level-up"></i></div></li>'; 
	return array($final_text, -$total);
}

function display_balance_sheet(){
	global $path_to_root, $levelptr, $final_text;
	
	$f_year = get_current_fiscalyear();
	$from = $f_year['begin'];
	$to = date('Y-m-d');
	$date1=date_create(date('Y-01-01'));
	$date2=date_create($to);
	$diff=date_diff($date1,$date2);
	$passed_days = $diff->format("%a");
	
	$dimension = $dimension2 = 0;
	$lconvert = $econvert = 1;
	
	$drilldown = 0; // Root level	
	$final_text = ' <div class="panel-group wrap" id="accordion" role="tablist" aria-multiselectable="true"> ';		
		
		 //Root Level			
		$equityclose = $totalActiva = 0.0;
		$lclose = 0.0; 
		$calculateclose = 0.0;	
		$parent = -1;

		//Get classes for BS
		$classresult = Clientapp_get_account_classes(false, 1);
		$kv =$vj = 1;
		while ($class = fadb_fetch($classresult))	{
			$classclose = 0.0;
			$convert = get_class_type_convert($class["ctype"]); 		
			$ctype = $class["ctype"];
			$classname = $class["class_name"];	
			$final_text .= '<div class="ClassTitle" > '.$class["class_name"].' </div>';
			//Get Account groups/types under this group/type
			$typeresult = get_account_types(false, $class['cid'], -1);
					
			while ($accounttype= fadb_fetch($typeresult)){	
				$TypeTotal = kvcodes_display_type($accounttype["id"], $accounttype["name"], $from, $to, $convert, $dimension, $dimension2, $drilldown, $path_to_root);	
				//Print Summary 
				if ($TypeTotal != 0 ){
					$final_text .= '<div class="panel">
        <div class="panel-heading" role="tab" id="headingOne">
          <h4 class="panel-title">  <a  class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse'.$kv.'" aria-expanded="false" aria-controls="collapse'.$kv.'">'.$accounttype['id']." - ".$accounttype['name'] .' <span style="float:right">'.round(($TypeTotal * $convert), 2).'</span></a>  </h4> </div>
					<div id="collapse'.$kv.'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne"><div class="panel-body">';
					
					$levelptr = 0;
					$_POST["AccGrp"] = $accounttype['id']; 
					$classid = $accounttype["class_id"];
					$class = get_account_class($classid);
					$convert = get_class_type_convert($class["ctype"]); 
					
					//Print Class Name	
					$final_text .= ' <div class="content clearfix"> <ul>'.kvcodes_display_type($accounttype["id"], $accounttype["name"], $from, $to, $convert, $dimension, $dimension2, 1, $path_to_root).'</ul></div>';
					 
					$final_text .=  '
					 </div>
					 </div>
				  </div>  <!-- end of panel -->'; 
				  $kv++;
				}
				$classclose += $TypeTotal;
			}	
			if(	$vj == 1)		
				$totalActiva = $classclose;
			$vj++;
			//Print Class Summary		
			$final_text .=  ' <div class="accordion-frame"  style="font-weight:bold; ">'.
			_("Total") . " " . $class["class_name"]. '<span style="float:right; font-weight:bold"> '. round(($classclose * $convert),2).'</span></div>';	
			//if($class["class_name"] == 'Liabilities')
			//	echo ' <div class="accordion-frame"><a class="heading" href="#"><label style="font-weight:bold;  font-size: 15px; text-align:center;">'.	_('Assets') .'</label></a></div>';		
				
			if ($ctype == CL_EQUITY){
				$equityclose += $classclose;
				$econvert = $convert;
			}
			if ($ctype == CL_LIABILITIES){
				$lclose += $classclose;
				$lconvert = $convert;
			}	
			$calculateclose += $classclose;
		}
		
		if ($lconvert == 1)
			$calculateclose *= -1;
		//Final Report Summary
		//$url = "<a class='get_profit_loss' href=''>".."</a>";	
		//echo $equityclose * $econvert;
		$final_text .=  " <div class='accordion-frame' style='font-weight:bold' >"._("Calculated Return"). "<span style='float:right; '> ". round($calculateclose, 2)."</span></div>";		

		$final_text .=  ' <div class="accordion-frame" style="font-weight:bold">'._("Total") . " " . _("Liabilities") ." ". _("and") . " "._("Equities").'<span style="float:right;">'.
				round(($lclose * $lconvert + $equityclose * $econvert + $calculateclose),2).'</span></div>';	
		$final_text .=  ' </div> <!-- end of #accordion -->';
	
	return array($final_text, $passed_days, round($totalActiva, 2));
}


function Clientapp_get_account_classes($all=false, $balance=-1){
	$sql = "SELECT * FROM ".TB_PREF."chart_class";

	if (!$all) 
		$sql .= " WHERE !inactive";
	if ($balance == 0) 
		$sql .= " AND ctype>".CL_EQUITY." OR ctype=0";
	elseif ($balance == 1) 
		$sql .= " AND ctype>0 AND ctype<".CL_INCOME; 
	$sql .= " ORDER BY ctype, cid";

	return fadb_query($sql, "could not get account classes");
}

//----------------------------------------------------------------------------------------------------
function kvcodes_display_type ($type, $typename, $from, $to, $convert, $dimension, $dimension2, $drilldown){
	global $path_to_root, $levelptr, $k, $final_text;
	
	$acctstotal = 0;
	$typestotal = 0;
	 
	//Get Accounts directly under this group/type
	$result = get_gl_accounts(null, null, $type);	
 	while ($account=fadb_fetch($result))   {
        $net_balance = get_gl_trans_from_to("", $to, $account["account_code"], $dimension, $dimension2);
        if (!$net_balance)
            continue;
        
        if ($drilldown && $levelptr == 0)      {      
            $final_text .=  "<li>". $account['account_code']." ". $account['account_name'] ." <span style='float:right;' > ".round((($net_balance) * $convert),2).' </span></li>';
        }
        
        $acctstotal += $net_balance;
    }	
	 
	$levelptr = 1;

	//Get Account groups/types under this group/type
	$result = get_account_types(false, false, $type);
	while ($accounttype=fadb_fetch($result)){			
		$typestotal += kvcodes_display_type($accounttype["id"], $accounttype["name"], $from, $to, $convert, $dimension, $dimension2, $drilldown);
	}
	
	//Display Type Summary if total is != 0  
	if (($acctstotal + $typestotal) != 0){
		if ($drilldown && $type == $_POST["AccGrp"]){	
			$final_text .=  "<li>"._("Total")." ".$typename."  <span style='float:right;' > ".round((($acctstotal + $typestotal) * $convert), 2).' </span></li>'; 			
		}
		//START Patch#1 : Display  only direct child types
		$acctype1 = get_account_type($type);
		$parent1 = $acctype1["parent"];
		if ($drilldown && $parent1 == $_POST["AccGrp"]){
		//END Patch#2							
			$final_text .=  "<li>". $type . " " . $typename ." <span style='float:right;' >  ".round((($acctstotal + $typestotal) * $convert), 2).' </span></li>';			
		}
	}
	return ($acctstotal + $typestotal);
	//return $final_text; //($acctstotal + $typestotal);
}
function get_account_type($id){
	$sql = "SELECT * FROM ".TB_PREF."chart_types WHERE id = ".fadb_escape($id);

	$result = fadb_query($sql, "could not get account type");

	return fadb_fetch($result);
}

function get_account_class($id) {
	$sql = "SELECT * FROM ".TB_PREF."chart_class WHERE cid = ".fadb_escape($id);
	$result = fadb_query($sql, "could not get account type");
	return fadb_fetch($result);
}

function EmployeeCost($options =null){
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	
	$sql="SELECT master.account_code, master.account_name, COALESCE(SUM(trans.amount), 0) AS total 
			FROM  ".TB_PREF."chart_master AS master
			LEFT JOIN ".TB_PREF."gl_trans AS trans 
				   ON trans.account = master.account_code
				  AND trans.tran_date BETWEEN '{$begin1}' AND '{$today1}'
			WHERE     master.account_type IN (60,61,233)
			GROUP BY  master.account_code, master.account_name";
	
	$result = fadb_query($sql, "Transactions could not be calculated");
	
	$final= array();	
	while($row = fadb_fetch_assoc($result)){
		if ($row['total'] != 0){
			$final[] = $row;
		}	
	}	 
	return $final;
}

function class_balances($options=null){
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options == 'Last Quarter Year'){
		
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}

	$sql = "SELECT SUM(amount) AS total, c.class_name, c.ctype FROM
		".TB_PREF."gl_trans,".TB_PREF."chart_master AS a, ".TB_PREF."chart_types AS t, 
		".TB_PREF."chart_class AS c WHERE
		account = a.account_code AND a.account_type = t.id AND t.class_id = c.cid
		AND IF(c.ctype > 3, tran_date >= '$begin1', tran_date >= '0000-00-00') 
		AND tran_date <= '$today1' GROUP BY c.cid ORDER BY c.cid"; 
	$result = fadb_query($sql, "Transactions could not be calculated");
	
	$final= array();
	$total = 0;
	while($row = fadb_fetch_assoc($result)){
		if ($row['ctype'] > 3){
			$total += $row['total'];
		}
		$final[] = $row;
	}
	$final[] = array( 'class_name' => 'Calculated Return', 'total' => $total); 
	return $final;
}

function Top_five_invoices($type=10, $options=null){
	if($options == 'Last Month'){
		$today1 = date('Y-m-d', strtotime('last day of previous month'));
		$begin1 = date('Y-m-d', strtotime('first day of previous month'));
	}elseif($options == 'This Month'){
		$begin1 = date("Y-m-d", strtotime("first day of this month"));
		$today1 = date("Y-m-d", strtotime("last day of this month"));
	}elseif($options =='Last Week'){
		$begin1 = date("Y-m-d", strtotime("last week monday"));
		$today1 = date("Y-m-d", strtotime("last week sunday"));
	}elseif($options == 'Last Quarter Year'){
		
	}else{
		$f_year = get_current_fiscalyear();
		$begin1 = $f_year['begin'];
		$today1 = date('Y-m-d');
	}
	$today = date('Y-m-d');

	$sql_pre = "SET sql_mode='';";
	fadb_query($sql_pre, "Can't Set Mode");
	$sql ="
		SELECT 
  		trans.type, 
		trans.trans_no, 
		trans.order_, 
		trans.reference,
		trans.tran_date, 
		trans.due_date, 
		debtor.name, 
		branch.br_name,
		debtor.curr_code,
		debtor.debtor_no,
		(trans.ov_amount + trans.ov_gst + trans.ov_freight 
			+ trans.ov_freight_tax + trans.ov_discount)	AS TotalAmount, @bal := @bal+(trans.ov_amount + trans.ov_gst + trans.ov_freight + trans.ov_freight_tax + trans.ov_discount), trans.alloc AS Allocated,
		((trans.type = 10)
			AND trans.due_date < '$today') AS OverDue ,
		Sum(line.quantity-line.qty_done) AS Outstanding,
		Sum(line.qty_done) AS HasChild
		FROM "
			.TB_PREF."debtor_trans as trans
			LEFT JOIN ".TB_PREF."debtor_trans_details as line
				ON trans.trans_no=line.debtor_trans_no AND trans.type=line.debtor_trans_type
			LEFT JOIN ".TB_PREF."voided as v
				ON trans.trans_no=v.id AND trans.type=v.type
			LEFT JOIN ".TB_PREF."cust_branch as branch ON trans.branch_code=branch.branch_code,"
			.TB_PREF."debtors_master as debtor
		WHERE debtor.debtor_no = trans.debtor_no
			AND trans.tran_date >= '$begin1'
			AND trans.tran_date <= '$today1'
			AND trans.branch_code = branch.branch_code
			AND ISNULL(v.date_) AND ";
		if($type== 10)
			$sql .="(trans.type = 10) GROUP BY trans.trans_no, trans.type ORDER BY trans.tran_date DESC LIMIT 5";
		else
			$sql .="( trans.type = 12 OR trans.type = 2 OR trans.type = 1) GROUP BY trans.trans_no, trans.type ORDER BY trans.tran_date DESC LIMIT 5";
	$result = fadb_query($sql, "Transactions could not be calculated");
	//print_r($result);
	$final= array();
	$total = 0;
	while($row = fadb_fetch_assoc($result)){
		//if ($row['ctype'] > 3){
		//	$total += $row['total'];
		//}
		$final[] = $row;
	}
	
	return $final;
}

