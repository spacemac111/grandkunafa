<?php 

function get_price ($stock_id, $currency, $sales_type_id, $factor=null, $date=null, $no_numberformat=true){

	if ($date == null)
	    $date = date('Y-m-d');

	if ($factor === null) {
		$myrow = FAGetRow('sales_types', array('id' => $sales_type_id));
		$factor = $myrow['factor'];
	}

	$add_pct = get_company_details('add_pct');
	$base_id = get_company_details('base_sales');
	$home_curr = get_company_details('curr_default');
    
	//	AND (sales_type_id = $sales_type_id	OR sales_type_id = $base_id)
	$sql = "SELECT price, curr_abrev, sales_type_id	FROM ".TB_PREF."prices	WHERE stock_id = ".fadb_escape($stock_id)." AND (curr_abrev = ".fadb_escape($currency)." OR curr_abrev = ".fadb_escape($home_curr).")";

	$result = fadb_query($sql, "There was a problem retrieving the pricing information for the part $stock_id for customer");
	$num_rows = fadb_num_rows($result);
	$rate = 1 ; //round2(get_exchange_rate_from_home_currency($currency, $date),   user_exrate_dec());
	$round_to = get_company_details('round_to');
	$prices = array();
	while($myrow = fadb_fetch($result)) {
	    $prices[$myrow['sales_type_id']][$myrow['curr_abrev']] = $myrow['price'];
	}

	$price = false;
	if (isset($prices[$sales_type_id][$currency])) {
	    $price = $prices[$sales_type_id][$currency];
	}
	elseif (isset($prices[$base_id][$currency])) {
	    $price = $prices[$base_id][$currency] * $factor;
	}
	elseif (isset($prices[$sales_type_id][$home_curr])) {
	    $price = $prices[$sales_type_id][$home_curr] / $rate;
	}
	elseif (isset($prices[$base_id][$home_curr])){
	    $price = $prices[$base_id][$home_curr] * $factor / $rate;
	}
	elseif ($num_rows == 0 && $add_pct != -1){
		$price = get_calculated_price($stock_id, $add_pct);
		if ($currency != $home_curr)
			$price /= $rate;
		if ($factor != 0)
			$price *= $factor;
	}	
	if ($price === false)
		return 0;
	elseif ($round_to != 1)	
		return round_to_nearest($price, $round_to);
	else{
		if($no_numberformat)
			return round2($price, user_price_dec());
		else
			return round($price, user_price_dec());
	}
}

function get_item_kit($item_code, $direct = false) {

	$sql="SELECT DISTINCT kit.*, kit.quantity, item.units, comp.description as comp_name , item.material_cost
		FROM ".TB_PREF."item_codes kit,".TB_PREF."item_codes comp
		LEFT JOIN ".TB_PREF."stock_master item ON item.stock_id=comp.item_code WHERE	kit.stock_id=comp.item_code
			AND kit.item_code=".fadb_escape($item_code);

	$result = fadb_query($sql,"item kit could not be retrieved");
	if(!$direct)
		return $result;
	else {
		if(fadb_num_rows($result) == 1){
			return fadb_fetch($result);
		} elseif(fadb_num_rows($result) > 1){
			$final = [];
			while($stock_details = fadb_fetch($result)) {
				$final[] = $stock_details;
			}
			return $final;
		}
	}
	return false;
}

function get_kit_price($item_code, $currency, $sales_type_id, $factor=null, $date=null, $std = false){
	$kit_price = 0.00;
	if (!$std) {
		$kit_price = get_price( $item_code, $currency, $sales_type_id, $factor, $date);

		if ($kit_price !== 0) {
			return $kit_price;
		}
	}	
	// no price for kit found, get total value of all items
	$kit = get_item_kit($item_code);
	
	while($item = fadb_fetch($kit)) {
		if ($item['item_code'] != $item['stock_id']) {
			// foreign/kit code
			$kit_price += $item['quantity'] * get_kit_price( $item['stock_id'], 
				$currency, $sales_type_id, $factor, $date, $std);

		} else {
			// stock item
			$kit_price += $item['quantity'] * get_price( $item['stock_id'], 
				$currency, $sales_type_id, $factor, $date);
		}
	}
	return $kit_price;
}

function round_to_nearest($price, $round_to){
	if ($price == 0)
		return 0;
	$pow = pow(10, user_price_dec());
	if ($pow >= $round_to)
		$mod = ($pow % $round_to);
	else
		$mod = ($round_to % $pow);
	if ($mod != 0)
		$price = ceil($price) - ($pow - $round_to) / $pow;
	else	
    	$price = ceil($price * ($pow / $round_to)) / ($pow / $round_to);
    return $price;
}

function get_calculated_price($stock_id, $add_pct){
	$avg = get_unit_cost($stock_id);
	if ($avg == 0)
		return 0;
	return round2($avg * (1 + $add_pct / 100), user_price_dec());
}
function get_next_trans_no ($trans_type){
	$st = get_systype_db_info($trans_type);
	if (!($st && $st[0] && $st[2])) {	// this is in fact internal error condition.
		echo _('Internal error: invalid type passed to get_next_trans_no()');
		return 0;
	}
	$sql1 = "SELECT MAX(`$st[2]`) as last_no FROM $st[0]";
	if ($st[1] != null)
		 $sql1 .= " WHERE `$st[1]`=".fadb_escape($trans_type);
	// check also in voided transactions (some transactions like location transfer are removed completely)
	$sql2 = "SELECT MAX(`id`) as last_no FROM ".TB_PREF."voided WHERE `type`=".fadb_escape($trans_type);
	$sql = "SELECT max(last_no) last_no FROM ($sql1 UNION $sql2) a";
    $result = fadb_query($sql,"The next transaction number for $trans_type could not be retrieved");
    $myrow = fadb_fetch_row($result);

    return $myrow[0] + 1;
}

function save_sales_order(){ 
	global $current_user, $Refs;
	$fa_user_id = $current_user['fa_user_id'];
	$order_no = $_SESSION['order_id'];
	$date = date("Y-m-d");
	// if(isset($_SESSION['deliverID']) > 0){
	// 		$del_man = $_SESSION['deliverID'];
	// 	}else{
	// 		$del_man = 0;
	// 	}
	$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
	begin_transaction();
	if(isset($_SESSION['order_id']) && $_SESSION['order_id'] > 0 ) {

		//var_dump($_SESSION['cart_item']);
		//exit;
	
		$sales_order_where = array('order_no' => $order_no, 'trans_type' => ST_SALESORDER,); // 'version' => 0);

		// if(isset($_SESSION['TableNo']))
		// 	$sales_order_where['table_no'] = $_SESSION['TableNo'];

		// if(isset($_SESSION['token_no']))
		// 	$sales_order_where['token_no'] = $_SESSION['token_no'];
		
		// if(isset($_SESSION['delivery_no']))
		// 	$sales_order_where['delivery_no'] = $_SESSION['delivery_no'];


		$sales_order_update = array('total' => $_SESSION['grand_total']);

		if(isset($_SESSION['deliverID']))
			$sales_order_update['deliveryman'] = $_SESSION['deliverID'];
		
		$sales_order_update['debtor_no'] = $_SESSION['CustomerId'];

		if(isset($_SESSION['delivery_no']) && $_SESSION['delivery_no'] > 0 ){
			$sales_order_update['delivery_address'] = (isset($_SESSION['delivery_address']) ? $_SESSION['delivery_address'] : 'N/A');
			$sales_order_update['deliver_to'] = (isset($_SESSION['delivery_to']) ? $_SESSION['delivery_to'] : '');
			$sales_order_update['customer_ref'] = (isset($_SESSION['customer_ref']) ? $_SESSION['customer_ref'] : 'N/A');
			$sales_order_update['contact_phone'] = (isset($_SESSION['contact_phone']) ? $_SESSION['contact_phone'] : '');
			$sales_order_update['client_id'] = (isset($_SESSION['client_id']) ? $_SESSION['client_id'] :0);
			//var_dump($_SESSION);
			//exit;
		}


		FAUpdate('sales_orders' , $sales_order_where, $sales_order_update);
		$sales_order_stock_ids = array();
		$unit_tax_ar = array();
		FADelete('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER ));

		foreach($_SESSION['cart_item'] as $line) {

			if($non_detailed_sales_kit && $line['kit'] == 'yes'){
				$kit = get_item_kit($line['stock_id'], true);
				if(!empty($kit)){
					foreach($kit as $line_item){
						if(isset($line_item['stock_id'])){
							$price_calculated = get_price($line_item['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false); 

							$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line_item['stock_id'], 'description' => $line_item['comp_name'], 'qty_sent' => 0, 'unit_price' => $price_calculated, 'quantity' => $line['qty']*$line_item['quantity'], 'discount_percent' => round($line['discount'], 2), 'kit' => $line['stock_id']));
							$sales_order_stock_ids[$line_item['stock_id']] = $detailsId;
							$unit_tax_ar[$line_item['stock_id']] = $detailsId;		
							$line_taxfree_price = get_tax_free_price_for_item($line_item['stock_id'],$price_calculated * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
							$line_tax = get_full_price_for_item($line_item['stock_id'],$price_calculated * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
							$unit_tax_ar[$line_item['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0;	
						}
					}
				}

			} else {

				$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line['stock_id'], 'description' => $line['name'], 'qty_sent' => 0, 'unit_price' => $line['price'], 'quantity' => $line['qty'], 'discount_percent' => round($line['discount'], 2)));
				$sales_order_stock_ids[$line['stock_id']] = $detailsId;
				$unit_tax_ar[$line['stock_id']] = $detailsId;		
				$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
				$line_tax = get_full_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
				$unit_tax_ar[$line['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0	;	
			}
		} 

		$msg = _("Selected Order Updated Successfully");
		$res = 2;
		$tp = 1;
	} else {
		$fiscal_year_id = get_company_details('f_year');
		$tax_amt = 0;
		$branch_code = get_cust_branch($_SESSION['CustomerId']);
		$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
		$location = $sales_pos['pos_location'];
		$discount = 0;
		// Sales Orders 
		$order_no = get_next_trans_no(ST_SALESORDER);	
		$order_ref = $Refs->get_next(ST_SALESORDER);
		$token_no  = $_SESSION['token_no'];
		$del_no = $_SESSION['del_no'];

		if( $token_no === 'tokenno' && $del_no === 0 && $_SESSION['TableNo'] === 0){
			$token_no = FAGetSingleValue('sales_orders', 'MAX(`token_no`)', array('trans_type' => ST_SALESORDER, 'ord_date' => $date)) + 1;
		}else{
			$token_no = $_SESSION['token_no'];
		}

		if($del_no ===  'delivaryno' && $token_no === 0 && $_SESSION['TableNo'] === 0){
			$del_no = FAGetSingleValue('sales_orders', 'MAX(`delivery_no`)', array('trans_type' => ST_SALESORDER, 'ord_date' => $date)) + 1;
		}else{
			$del_no = $_SESSION['del_no'];
		}		
	
		$sales_order_table = array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'version' => 0, 'debtor_no' => $_SESSION['CustomerId'],'branch_code' => $branch_code['branch_code'], 'salesman' => $current_user['s_id'],  'reference' => $order_ref, 'ord_date' => $date, 'delivery_date' => $date, 'order_type' => 1, 'ship_via' => 1, 'from_stk_loc' => $location, 'payment_terms' => $_SESSION['payment_terms'], 'total' => $_SESSION['grand_total']);

		if(isset($del_no) && $del_no > 0 ){
			$sales_order_table['delivery_address'] = (isset($_SESSION['delivery_address']) ? $_SESSION['delivery_address'] : 'N/A');
			$sales_order_table['deliver_to'] = (isset($_SESSION['delivery_to']) ? $_SESSION['delivery_to'] : '');
			$sales_order_table['customer_ref'] = (isset($_SESSION['customer_ref']) ? $_SESSION['customer_ref'] : 'N/A');
			$sales_order_table['contact_phone'] = (isset($_SESSION['contact_phone']) ? $_SESSION['contact_phone'] : '');
			$sales_order_table['client_id'] = (isset($_SESSION['client_id']) ? $_SESSION['client_id'] :0);
			//var_dump($_SESSION);
			//exit;
		}

		if(isset($_SESSION['deliverID']))
			$sales_order_table['deliveryman'] = $_SESSION['deliverID'];

		if(isset($_SESSION['TableNo']))
			$sales_order_table['table_no'] = $_SESSION['TableNo'];

		if(isset($_SESSION['token_no']))
			$sales_order_table['token_no'] = $token_no;
		
		if(isset($_SESSION['del_no']))
			$sales_order_table['delivery_no'] = $del_no;

		if(isset($_SESSION['delivery_cost']))
			$sales_order_table['freight_cost'] = $_SESSION['delivery_cost'];

		FAInsert('sales_orders' , $sales_order_table);
		$sales_order_stock_ids = array();
		$unit_tax_ar = array();
		foreach($_SESSION['cart_item'] as $line) {
			if($non_detailed_sales_kit && $line['kit'] == 'yes'){
				$kit = get_item_kit($line['stock_id'], true);
				if(!empty($kit)){
					foreach($kit as $line_item){
						if(isset($line_item['stock_id'])){
							$price_calculated = get_price($line_item['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false); 

							$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line_item['stock_id'], 'description' => $line_item['comp_name'], 'qty_sent' => 0, 'kit' => $line['item_code'], 'unit_price' => $price_calculated, 'quantity' => $line['qty']*$line_item['quantity'], 'discount_percent' => round($line['discount'], 2), 'kit' => $line['stock_id']));
							$sales_order_stock_ids[$line['stock_id']] = $detailsId;
							$unit_tax_ar[$line['stock_id']] = $detailsId;

							$line_taxfree_price = get_tax_free_price_for_item($line_item['stock_id'],$price_calculated * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
							$line_tax = get_full_price_for_item($line_item['stock_id'],$price_calculated * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
							$unit_tax_ar[$line_item['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0 ;
						}
					}
				}
			} else {

				$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line['stock_id'], 'description' => $line['name'], 'qty_sent' => 0, 'unit_price' => $line['price'], 'kit' => $line['item_code'], 'quantity' => $line['qty'], 'discount_percent' => round($line['discount'], 2)));
				$sales_order_stock_ids[$line['stock_id']] = $detailsId;
				$unit_tax_ar[$line['stock_id']] = $detailsId;

				$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
				$line_tax = get_full_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
				$unit_tax_ar[$line['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0	;	
			}
		} 
		$_SESSION['token_no'] = $token_no;
		$_SESSION['del_no'] = $del_no;
		$msg = _("New Order Saved Successfully");
		$res = 1;
		$tp = 0;
	}
		
	FAInsert('audit_trail', array('type' => ST_SALESORDER, 'trans_no' => $order_no, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));	
	commit_transaction();	

	$_SESSION['order_id'] = $order_no;	
	if($_SESSION['token_no'] == 0 && $_SESSION['del_no'] == 0 && $_SESSION['TableNo'] == 0){
		return array('id' => $order_no,'reference' => $order_ref, 'msg' => $msg, 'res' => $res, 'tp' => $tp);
	}else{
		return array('id' => $order_no, 'msg' => $msg, 'token_no' =>$_SESSION['token_no'],'del_no' => $_SESSION['del_no'], 'table_no' => $_SESSION['TableNo'], 'tp' => $tp);
	}
}
function deliver_orders(){
	// $date = $_SESSION['date'];
	global $current_user, $Refs;
	$date = date("Y-m-d");
	$fa_user_id = $current_user['fa_user_id'];
	$order_no = $_SESSION['order_id'];

	if(isset($_SESSION['order_id']) && $_SESSION['order_id'] > 0 ) {
		begin_transaction();

	// if(isset($_SESSION['deliverID']) == ''){
	// 	$deliverID = 0;
	// }else{
	// 	$deliverID = $_SESSION['deliverID'];
	// }
	if(isset($_POST['trans_no']) && $_POST['trans_no'] > 0 ){
		void_sales_delivery(ST_CUSTDELIVERY, $_POST['trans_no']);
	}
	if($_SESSION['del_no'] ===  'delivaryno' && $_SESSION['token_no'] === 0 && $_SESSION['TableNo'] === 0){
		$_SESSION['del_no'] = FAGetSingleValue('sales_orders', 'delivery_no', array('trans_type' => ST_SALESORDER, 'order_no' => $order_no));
	}

	$fiscal_year_id = get_company_details('f_year');
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
	$tax_amt = 0;
	$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	$location = $sales_pos['pos_location'];
	$discount = 0;

	//Customer Delivery
	$trans_no_delivery = get_next_trans_no(ST_CUSTDELIVERY);
	$delivery_ref = $Refs->get_next(ST_CUSTDELIVERY);
	$updatesales = FAUpdate('sales_orders' , array('order_no' => $order_no, 'trans_type' => ST_SALESORDER), array('version' => "version+1"));

	FAInsert('debtor_trans', array('trans_no' => $trans_no_delivery,'table_no' => $_SESSION['TableNo'],'token_no' => $_SESSION['token_no'],'delivery_no' => $_SESSION['del_no'], 'type' => ST_CUSTDELIVERY, 'version' => 0, 'debtor_no' => $_SESSION['CustomerId'],'salesman' => $current_user['s_id'],'branch_code' => $branch_code['branch_code'], 'tran_date' => $date, 'due_date' => $date, 'reference' => $delivery_ref, 'tpe' => 1, 'order_' => $order_no, 'ov_amount' => $_SESSION['subtotal_price'],'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'], 'tax_included' => $_SESSION['tax_included'], 'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), 'ov_freight' => (isset($_SESSION['freight_cost']) ? $_SESSION['freight_cost'] : 0 ) ));
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0)
			FAInsert('trans_tax_details', array('trans_type' => ST_CUSTDELIVERY, 'trans_no' => $trans_no_delivery, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => 'auto', 'reg_type' => 0));
	}
	$delivery_details_ids = array();
	$sales_order_stock_ids = array();
	$unit_tax_ar = array();
	$order_items = FAGetAll('sales_order_details', array('order_no' => $order_no));
    foreach($order_items as $row){
    	$row['standard_cost'] = FAGetSingleValue('stock_master', 'material_cost', ['stock_id' => $row['stk_code']]);
        $sales_order_stock_ids[$row['stk_code']] = $row['id'];
        $unit_tax_ar[$row['stk_code']] = $row['id'];		
		$line_taxfree_price = get_tax_free_price_for_item($row['stk_code'],$row['unit_price'] * $row['quantity'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$line_tax = get_full_price_for_item($row['stk_code'],$row['unit_price'] * $row['quantity'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
		$unit_tax_ar[$row['stk_code']] = $row['quantity'] ? $line_tax/$row['quantity'] : 0;
   // }

	//foreach($_SESSION['cart_item'] as $line) {

		$delivery_details = array('debtor_trans_no' => $trans_no_delivery, 'debtor_trans_type' => ST_CUSTDELIVERY, 'stock_id' => $row['stk_code'], 'kit' => $row['kit'], 'description' => $row['description'], 'unit_price' => $row['unit_price'], 'unit_tax' => $unit_tax_ar[$row['stk_code']], 'quantity' => $row['quantity'], 'discount_percent' => $row['discount_percent'], 'standard_cost' => $row['standard_cost'], 'qty_done' => $row['quantity'], 'src_id' => $sales_order_stock_ids[$row['stk_code']]); 

		/*if($kv_batch || $kv_exp_date){
			$delivery_details['batch_no'] = $line['batch_no'];
			if($kv_exp_date)
				$delivery_details['exp_date'] = $line['exp_date'];
		} */

		$detailsId = FAInsert('debtor_trans_details', $delivery_details);
		$delivery_details_ids[$row['stk_code']] = $detailsId; 


		$stock_moves = array('trans_no' => $trans_no_delivery, 'type' => ST_CUSTDELIVERY, 'stock_id' => $row['stk_code'], 'loc_code' => $location, 'tran_date' => $date, 'price' => $row['unit_price'], 'reference' => 'auto', 'qty' => -$row['quantity'], 'standard_cost' => $row['standard_cost']); 

		if($kv_batch || $kv_exp_date){
			if(isset($row['batch_no']))
			$stock_moves['batch_no'] = $row['batch_no'];
			if($kv_exp_date && isset($orw['exp_date']))
				$stock_moves['exp_date'] = $row['exp_date'];
		}

		FAInsert('stock_moves', $stock_moves);
		if (is_inventory_item($row['stk_code'])) {		
			if ($row['standard_cost'] != 0) {
				$stock_gl_code = get_stock_gl_code($row['stk_code']);	
				$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
				$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);
				/*first the cost of sales entry*/
				add_gl_trans_std_cost(ST_CUSTDELIVERY, $trans_no_delivery, $date, $stock_gl_code["cogs_account"], $dim, $dim2, "",$row['standard_cost'] * $row['quantity'], PT_CUSTOMER, $_SESSION['CustomerId'],	"The cost of sales GL posting could not be inserted");

				/*now the stock entry*/
				add_gl_trans_std_cost(ST_CUSTDELIVERY, $trans_no_delivery, $date, $stock_gl_code["inventory_account"], 0, 0, "",	(-$row['standard_cost'] * $row['quantity']), PT_CUSTOMER, $_SESSION['CustomerId'],	"The stock side of the cost of sales GL posting could not be inserted");
			}
		}
	}

	}

	FAInsert('audit_trail', array('type' => ST_CUSTDELIVERY, 'trans_no' => $trans_no_delivery, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	commit_transaction();	
	$_SESSION['delivary_id'] = $trans_no_delivery;	
	return array('trans_no' => $trans_no_delivery, 'token_no' => $_SESSION['token_no'], 'del_no' =>$_SESSION['del_no'], 'table_no' => $_SESSION['TableNo'], 'deliverID' => $_SESSION['deliverID']);
}


function void_sales_delivery($type, $type_no, $transactions=true) {
	global $Refs;
	if ($transactions)
		begin_transaction();
	
	void_gl_trans($type, $type_no, true);

	// reverse all the changes in the sales order
	$items_result = Kvcodes_get_customer_trans_details($type, $type_no);


	$order = FAGetSingleValue("debtor_trans", "order_", ['type' => $type, 'trans_no' => $type_no]);

	if ($order) {
		$auto = ($Refs->get_next(ST_SALESORDER, $order) == "auto");
		foreach($items_result as $row) {
			update_parent_line(ST_CUSTDELIVERY, $row['src_id'], -$row['quantity'], $auto);
		}
	}
	
	FAUpdate('debtor_trans', ['trans_no' => $type_no, 'type' => $type], ['token_no' => 0, 'table_no' => 0, 'delivery_no' => 0, 'ov_amount' => 0, 'ov_gst' => 0, 'ov_change' => 0, 'ov_discount' => 0, 'ov_freight' => 0, 'ov_freight_tax' => 0, 'alloc' => 0, 'order_' => 0, "prep_amount"=>0 ]);

	FAUpdate('debtor_trans_details', 
		['debtor_trans_no' => $type_no, 'debtor_trans_type' => $type], 
		['quantity' => 0, 'unit_price'=>0, 'unit_tax'=>0, 'discount_percent'=>0, 'standard_cost'=>0, 'src_id'=>0]);
	// clear the stock move items
	void_stock_move($type, $type_no);


	FAUpdate("trans_tax_details", ['trans_no'=>$type_no, 'trans_type'=>$type], ['amount'=>0, 'net_amount'=>0]);

	clear_cust_alloctions($type, $type_no);

	// do this last because other voidings can depend on it
	// DO NOT MOVE THIS ABOVE VOIDING or we can end up with trans with alloc < 0
	//void_customer_trans($type, $type_no);

	//FAUpdate("debtor_trans", ['type' =>$type, "trans_no"=>$type_no], ["ov_amount"=>0, "ov_discount"=>0, "ov_gst"=>0, "ov_freight"=>0,	"ov_freight_tax"=>0, "alloc"=>0, "prep_amount"=>0, "version"=> "version+1"]);

	if ($transactions)
		commit_transaction();
}


function clear_cust_alloctions($type, $type_no, $person_id=null, $date=""){
	$sql = "UPDATE  ".TB_PREF."cust_allocations ca
				LEFT JOIN ".TB_PREF."debtor_trans paym ON ca.trans_type_from=paym.type AND ca.trans_no_from=paym.trans_no AND ca.person_id=paym.debtor_no
				LEFT JOIN ".TB_PREF."debtor_trans dt ON ca.trans_type_to=dt.type AND ca.trans_no_to=dt.trans_no AND ca.person_id=dt.debtor_no
				LEFT JOIN ".TB_PREF."sales_orders so ON ca.trans_type_to=so.trans_type AND ca.trans_no_to=so.order_no AND ca.person_id=so.debtor_no
	 		SET paym.alloc=paym.alloc - ca.amt,
	 			dt.alloc=dt.alloc -  ca.amt,
	 			so.alloc=so.alloc -  ca.amt
			WHERE  ((ca.trans_type_from=".fadb_escape($type)." AND ca.trans_no_from=".fadb_escape($type_no).")
				OR (ca.trans_type_to=".fadb_escape($type)." AND ca.trans_no_to=".fadb_escape($type_no)."))";
	if ($person_id)
		$sql .= " AND ca.person_id=".fadb_escape($person_id);
	fadb_query($sql, "could not clear allocation");

	// remove any allocations for this transaction
	$sql = "DELETE FROM ".TB_PREF."cust_allocations
			WHERE  ((trans_type_from=".fadb_escape($type)." AND trans_no_from=".fadb_escape($type_no).")
				OR (trans_type_to=".fadb_escape($type)." AND trans_no_to=".fadb_escape($type_no)."))";
	if ($person_id)
		$sql .= " AND person_id=".fadb_escape($person_id);

	fadb_query($sql, "could not void debtor transactions for type=$type and trans_no=$type_no");
// is this necessary?
//	if ($date != "")
//		exchange_variation($type, $type_no, $row['trans_type_to'], $row['trans_no_to'], $date,
//			$row['amt'], PT_CUSTOMER, true);
}


function void_stock_move($type, $type_no) {
    $sql = "SELECT move.*, supplier.supplier_id
    		FROM ".TB_PREF."stock_moves move
				LEFT JOIN ".TB_PREF."supp_trans credit ON credit.trans_no=move.trans_no AND credit.type=move.type
				LEFT JOIN ".TB_PREF."grn_batch grn ON grn.id=move.trans_no AND 25=move.type
				LEFT JOIN ".TB_PREF."suppliers supplier ON IFNULL(grn.supplier_id, credit.supplier_id)=supplier.supplier_id
			WHERE move.type=".fadb_escape($type)." AND move.trans_no=".fadb_escape($type_no);

    $result = fadb_query($sql, "Could not void stock moves");
    while ($row = fadb_fetch($result))   {
		//Skip cost averaging of service items
		if (is_inventory_item($row["stock_id"])) {
			// The cost has to be adjusted.
			// Transaction rates are stored either as price or standard_cost depending on types
			$types = array(ST_SUPPCREDIT, ST_SUPPRECEIVE);
			if (in_array($type, $types))
				$unit_cost = $row["price"];
			else
				$unit_cost = $row["standard_cost"];

			//update_average_material_cost($row["supplier_id"], $row["stock_id"],	$unit_cost, -$row["qty"], sql2date($row["tran_date"]));
		}
    }
	$sql = "DELETE FROM ".TB_PREF."stock_moves	WHERE type=".fadb_escape($type)."	AND trans_no=".fadb_escape($type_no);
	fadb_query($sql, "The stock movement cannot be delated");
}


//------------------- update average material cost ---------------------------------------------- 
function update_average_material_cost($supplier, $stock_id, $price, $qty, $date, $adj_only=false){
	// probably this function should be optimized
	// passing transaction cart as argument. This would
	// save a couple of db calls like get_supplier()
	
	$supp = get_supplier($supplier);
    if ($supplier != null) {
		$currency = $supp['curr_code'];
        if ($supp['tax_included'])
            $price = get_tax_free_price_for_item($stock_id, $price, $supp['tax_group_id'],
                $supp['tax_included']);
    } else
		$currency = null;

	if ($currency != null){
		$ex_rate = get_exchange_rate_to_home_currency($currency, $date);
		$price_in_home_currency = $price / $ex_rate;
	}	
	else
		$price_in_home_currency = $price;

	$price_in_home_currency_ = $price_in_home_currency;

	// Handle if inventory will become negative
    // Skip negative inventory adjustment for case of adjust_only
    if (is_inventory_item($stock_id) && !$adj_only) 
        handle_negative_inventory($stock_id, $qty, $price_in_home_currency, $date);
	
	$sql = "SELECT mb_flag, material_cost FROM ".TB_PREF."stock_master WHERE stock_id=".fadb_escape($stock_id);
	$result = fadb_query($sql);
	$myrow = fadb_fetch($result);
	$material_cost = $myrow['material_cost'];
	
	$cost_adjust = false;

	$qoh = get_qoh_on_date($stock_id);

	if ($adj_only)	{
		if ($qoh > 0)
			$material_cost = ($qoh * $material_cost + $qty * $price_in_home_currency) /	$qoh;
	} else	{
		if ($qoh < 0)	{
			if ($qoh + $qty >= 0)
				$cost_adjust = true;
			$qoh = 0;
		}
		if ($qoh + $qty > 0)
			$material_cost = ($qoh * $material_cost + $qty * $price_in_home_currency) /	($qoh + $qty);
	}

	//if ($cost_adjust) // Material_cost replaced with price
	//	adjust_deliveries($stock_id, $price_in_home_currency_, $date);
	$sql = "UPDATE ".TB_PREF."stock_master SET material_cost=".fadb_escape($material_cost)."WHERE stock_id=".fadb_escape($stock_id);

	fadb_query($sql,"The cost details for the inventory item could not be updated");
	return $material_cost;
}


function get_qoh_on_date($stock_id, $location=null, $date_=null){

    if ($date_ == null)
        $date_ = Today();

     $date = date2sql($date_);
     $sql = "SELECT SUM(qty) FROM ".TB_PREF."stock_moves st	LEFT JOIN ".TB_PREF."voided v ON st.type=v.type AND st.trans_no=v.id   WHERE ISNULL(v.id) AND stock_id=".fadb_escape($stock_id)."
          AND tran_date <= '$date'"; 

    if ($location != null)
        $sql .= " AND loc_code = ".fadb_escape($location);

    $result = fadb_query($sql, "QOH calculation failed");

    $myrow = fadb_fetch_row($result);

    $qoh =  $myrow[0];
		return $qoh ? $qoh : 0;
}


//--------------------------------------------------------------------------------------------------
function void_gl_trans($type, $trans_id, $nested=false){
	if (!$nested)
		begin_transaction();

	$sql = FAUpdate("gl_trans", ['type' => $type, 'type_no' => $trans_id], ['amount'=>0]);

	if (!$nested)
		commit_transaction();
}



function save_invoice_from_delivery(){
	global $current_user, $Refs;
	$order_no = $_SESSION['order_id'];
	$delivary_id = $_SESSION['delivary_id'];
	$date = date("Y-m-d");
	begin_transaction();
	$fa_user_id = $current_user['fa_user_id'];
	// if(isset($_SESSION['deliveryman'])){
	// 	$deliveryman =$_SESSION['deliveryman']
	// }
	$fiscal_year_id = get_company_details('f_year');
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
	$kv_batch = get_company_details('kv_batch');
	$kv_exp_date = get_company_details('kv_exp_date');
	$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	$location = $sales_pos['pos_location'];
	$discount = 0;
	$updatesales = FAUpdate('sales_orders' , array('order_no' => $order_no, 'trans_type' => ST_SALESORDER), array('version' => 2));
	$payment_term = FAGetRow('payment_terms', array('terms_indicator' => $_SESSION['payment_terms']));
	// Sales Invoice
	$trans_no_invoice = get_next_trans_no(ST_SALESINVOICE);
	
	$invoice_ref = $Refs->get_next(ST_SALESINVOICE);

	$invAray = array('trans_no' => $trans_no_invoice,'table_no' => $_SESSION['TableNo'],'token_no' => $_SESSION['token_no'],'delivery_no' => $_SESSION['del_no'], 'type' => ST_SALESINVOICE, 'version' => 0, 'debtor_no' => $_SESSION['CustomerId'],'deliveryman' => $_SESSION['deliverID'], 'alloc' => 0, 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'due_date' => $date, 'reference' => $invoice_ref, 'tpe' => 1, 'order_' => $order_no, 'ov_amount' => $_SESSION['subtotal_price'],'ov_gst' => $_SESSION['tax_val'],'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'],'tax_included' => $_SESSION['tax_included'],	'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ));
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0 && $_POST['pmt_type'] != 'later')
		$invAray['alloc'] = $_SESSION['grand_total']+(isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 ? $_SESSION['freight_cost'] : 0 );

	if(isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 )
		$invAray['ov_freight'] = $_SESSION['freight_cost'];

	//echo ($_POST['user_paid'].'_'.$_SESSION['grand_total'].'-'.$_SESSION['pmt_type']);	
	if($_SESSION['pmt_type'] == 'cash'){
		$invAray['ov_change'] = $_POST['user_paid']-($_SESSION['grand_total']+$_SESSION['freight_cost']);
	} else
		$invAray['ov_change'] = 0;

	FAInsert('debtor_trans', $invAray);
	
	$inv_total = 0;
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0) {
			FAInsert('trans_tax_details', array('trans_type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => '', 'reg_type' => 0));
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $tax['sales_gl_code'], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), (-$tax['Value']), $_SESSION['CustomerId'], "A tax GL posting could not be inserted");	
		}	
	}

	$delivery_details_ids = array();
	$unit_tax_ar = array();	
	$delivar_items = FAGetAll('debtor_trans_details', array('debtor_trans_no' => $delivary_id, 'debtor_trans_type' => ST_CUSTDELIVERY));
    foreach($delivar_items as $line){
        $delivery_details_ids[$line['stock_id']] = $line['id'];
        $unit_tax_ar[$line['stock_id']] = $line['unit_tax'];   	
    // }
	//foreach($_SESSION['cart_item'] as $line) {
		$delivery_details = array('debtor_trans_no' => $trans_no_invoice, 'debtor_trans_type' => ST_SALESINVOICE, 'stock_id' => $line['stock_id'], 'description' => $line['description'], 'unit_price' => $line['unit_price'], 'unit_tax' => ( $_SESSION['tax_included'] == 1 ? $unit_tax_ar[$line['stock_id']] : 0), 'quantity' => $line['quantity'], 'discount_percent' => $line['discount_percent'], 'standard_cost' => $line['standard_cost'],  'src_id' => $delivery_details_ids[$line['stock_id']], 'kit' => $line['kit']);
		if($kv_batch || $kv_exp_date){
			$delivery_details['batch_no'] = $line['batch_no'];
			if($kv_exp_date)
				$delivery_details['exp_date'] = $line['exp_date'];
		}
		FAInsert('debtor_trans_details', $delivery_details);
		$stock_gl_code = get_stock_gl_code($line['stock_id']);					
		
		$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
		$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);

		$sales_account = $stock_gl_code['sales_account'];
		 $line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['unit_price'] * $line['quantity'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $sales_account, $dim, $dim2,	-$line_taxfree_price,	$_SESSION['CustomerId'], "The sales price GL posting could not be inserted");
		if ($line['discount'] != 0) {
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["sales_discount_account"], $dim, $dim2,($line_taxfree_price * $line['discount']),	$_SESSION['CustomerId'], "The sales discount GL posting could not be inserted");
		}
	}
	//cancel_transaction();
	
	if ($_SESSION['freight_cost'] != 0) {
		$freight_act = FAGetSingleValue('sys_prefs', 'value', ['name' => 'freight_act']);
		$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $freight_act, $dim, $dim2,	-$_SESSION['freight_cost'], $_SESSION['CustomerId'], "The freight GL posting could not be inserted");
	}

	$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["receivables_account"], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ),  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ),	$_SESSION['grand_total']+(isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 ? $_SESSION['freight_cost'] : 0 ), $_SESSION['CustomerId'], "The total debtor GL posting could not be inserted");
	add_gl_balance(ST_SALESINVOICE, $trans_no_invoice, $date, -$inv_total, PT_CUSTOMER, $_SESSION['CustomerId']);	
	FAInsert('refs', array('id' => $trans_no_invoice, 'type' => ST_SALESINVOICE, 'reference' => $invoice_ref));
	FAInsert('audit_trail', array('type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	if(trim($_POST['memo']) != '')
		FAInsert('comments', ['type' => ST_SALESINVOICE, 'id' => $trans_no_invoice, 'memo_' => trim($_POST['memo'])]);
	//echo json_encode($payment_term);
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0 && $_POST['pmt_type'] != 'later') {
		//Customer Payment
		$trans_no_payment = get_next_trans_no(ST_CUSTPAYMENT);
		$payment_ref = $Refs->get_next(ST_CUSTPAYMENT);
		FAInsert('debtor_trans', array('trans_no' => $trans_no_payment,'table_no' => $_SESSION['TableNo'], 'token_no' => $_SESSION['token_no'],'delivery_no' => $_SESSION['delivery_no'], 'type' => ST_CUSTPAYMENT,  'debtor_no' => $_SESSION['CustomerId'], 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $_SESSION['grand_total']+(isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 ? $_SESSION['freight_cost'] : 0 ), 'ov_amount' => $_SESSION['subtotal_price']+(isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 ? $_SESSION['freight_cost'] : 0 ),'ov_gst' => 0, 'ov_discount' => $discount, 'rate' => 1, 'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 )));
		$call_second_part= false;
		if($_SESSION['pmt_type'] == 'cash'){
			if($current_user['cash_accounts'] != '' || $current_user['cash_accounts'] != null)
				$pos_account = $current_user['cash_accounts'];
			$amt_ = $_SESSION['grand_total'];
		}elseif($_SESSION['pmt_type'] == 'card'){
			if($current_user['bank_accounts'] != '' || $current_user['bank_accounts'] != null)
				$pos_account = $current_user['bank_accounts'];
			$amt_ = $_SESSION['grand_total'];
		} elseif($_POST['pmt_type'] == 'spiltpayment'){
			$call_second_part = true;
			$amt_ = $_POST['cashpaid'];
		}

		$amt_ += (isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 ? $_SESSION['freight_cost'] : 0 );

		if($pos_account == '')
			$pos_account = $sales_pos['pos_account'];

		$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

		$total += add_gl_trans(ST_CUSTPAYMENT, $trans_no_payment, $date,	$bank['account_code'], 0, 0, '', $amt_,  $bank['bank_curr_code'], PT_CUSTOMER, $_SESSION['CustomerId']);

		$total += add_gl_trans_customer(ST_CUSTPAYMENT, $trans_no_payment, $date,	$branch_code["receivables_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), -($amt_), $_SESSION['CustomerId'],	"Cannot insert a GL transaction for the debtors account credit");


		FAInsert('bank_trans', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => $amt_, 'person_type_id' => 2, 'person_id' => $fa_user_id));
		FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_CUSTPAYMENT, 'reference' => $payment_ref));
		FAInsert('audit_trail', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
		FAInsert('cust_allocations', array('person_id' => $_SESSION['CustomerId'], 'amt' => $amt_, 'date_alloc' => $date, 'trans_no_from' => $trans_no_payment, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $trans_no_invoice, 'trans_type_to' => ST_SALESINVOICE));

		if($_POST['pmt_type'] != 'spiltpayment'){
			$memo = 'Invoice Number'.$invoice_ref." ".($_SESSION['trans_ref'] != '' ? _("Debit/Credit Card")." ".$_SESSION['trans_ref'] : '' );
			FAInsert('comments', array('type' => ST_CUSTPAYMENT, 'id' => $trans_no_payment, 'memo_' => $memo));
		}
		if($call_second_part)
			WritePOSPayment($trans_no_invoice, $_POST['cardpaid'], 2, $_SESSION['trans_ref'], $_POST['bank_acc_id']);

	}
	FAUpdate('debtor_trans' , array('trans_no' => $delivary_id,'type'=> ST_CUSTDELIVERY), array('version' => 1));
	commit_transaction();
	if( $trans_no_invoice > 0 )
		return $trans_no_invoice;
}
function save_invoice_from_deliveryman(){
	global $current_user, $Refs;
	$order_no = $_SESSION['order_id'];
	$delivary_id = $_SESSION['delivary_id'];
	$date = date("Y-m-d");
	begin_transaction();
	$fa_user_id = $current_user['fa_user_id'];
	if(isset($_SESSION['deliveryman'])){
		$deliveryman =$_SESSION['deliveryman'];
	}
	$fiscal_year_id = get_company_details('f_year');
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
	$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	$location = $sales_pos['pos_location'];
	$discount = 0;
	$updatesales = FAUpdate('sales_orders' , array('order_no' => $order_no, 'trans_type' => ST_SALESORDER), array('version' => 2));
	$payment_term = FAGetRow('payment_terms', array('terms_indicator' => $_SESSION['payment_terms']));

	// Sales Invoice
	$trans_no_invoice = get_next_trans_no(ST_SALESINVOICE);	
	$invoice_ref = $Refs->get_next(ST_SALESINVOICE);

	$invAray = array('trans_no' => $trans_no_invoice,'delivery_no' => $_SESSION['del_no'], 'type' => ST_SALESINVOICE, 'version' => 0, 'debtor_no' => $_SESSION['CustomerId'],'deliveryman' => $current_user['ID'], 'alloc' => 0, 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'due_date' => $date, 'reference' => $invoice_ref, 'tpe' => 1, 'order_' => $order_no, 'ov_amount' => $_SESSION['subtotal_price'],'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'],'tax_included' => $_SESSION['tax_included'], 'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ));
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0)
		$invAray['alloc'] = $_SESSION['grand_total'];

	if(isset($_SESSION['freight_cost']) && $_SESSION['freight_cost'] > 0 )
		$invAray['ov_freight'] = $_SESSION['freight_cost'];

	FAInsert('debtor_trans', $invAray);
	
	$inv_total = 0;
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0){
			FAInsert('trans_tax_details', array('trans_type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => '', 'reg_type' => 0));
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $tax['sales_gl_code'], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), (-$tax['Value']), $_SESSION['CustomerId'], "A tax GL posting could not be inserted");	
		}	
	}

	$delivery_details_ids = array();
	$unit_tax_ar = array();	
	$delivar_items = FAGetAll('debtor_trans_details', array('debtor_trans_no' => $delivary_id, 'debtor_trans_type' => ST_CUSTDELIVERY));
    foreach($delivar_items as $line){
        $delivery_details_ids[$line['stock_id']] = $line['id'];
        $unit_tax_ar[$line['stock_id']] = $line['unit_tax'];   	

		$delivery_details = array('debtor_trans_no' => $trans_no_invoice, 'debtor_trans_type' => ST_SALESINVOICE, 'stock_id' => $line['stock_id'], 'description' => $line['description'], 'unit_price' => $line['unit_price'], 'unit_tax' => ( $_SESSION['tax_included'] == 1 ? $unit_tax_ar[$line['stock_id']] : 0), 'quantity' => $line['quantity'], 'discount_percent' => $line['discount_percent'], 'standard_cost' => $line['standard_cost'],  'src_id' => $delivery_details_ids[$line['stock_id']], 'kit' => $line['kit']);

		if($kv_batch || $kv_exp_date){
			$delivery_details['batch_no'] = $line['batch_no'];
			if($kv_exp_date)
				$delivery_details['exp_date'] = $line['exp_date'];
		}

		FAInsert('debtor_trans_details', $delivery_details);
		$stock_gl_code = get_stock_gl_code($line['stock_id']);					
		
		$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
		$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);

		$sales_account = $stock_gl_code['sales_account'];
		$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $sales_account, $dim, $dim2,	-$line_taxfree_price,	$_SESSION['CustomerId'], "The sales price GL posting could not be inserted");
		if ($line['discount'] != 0) {
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["sales_discount_account"], $dim, $dim2,($line_taxfree_price*$line['discount']),	$_SESSION['CustomerId'], "The sales discount GL posting could not be inserted");
		}
	}
	
	if ($_SESSION['freight_cost'] != 0) {
		$freight_act = FAGetSingleValue('sys_prefs', 'value', ['name' => 'freight_act']);
		$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $freight_act, $dim, $dim2,	-$_SESSION['freight_cost'], $_SESSION['CustomerId'], "The freight GL posting could not be inserted");
	}


	$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["receivables_account"], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ),	$_SESSION['grand_total'], $_SESSION['CustomerId'], "The total debtor GL posting could not be inserted");
	add_gl_balance(ST_SALESINVOICE, $trans_no_invoice, $date, -$inv_total, PT_CUSTOMER, $_SESSION['CustomerId']);	
	FAInsert('refs', array('id' => $trans_no_invoice, 'type' => ST_SALESINVOICE, 'reference' => $invoice_ref));
	FAInsert('audit_trail', array('type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
		
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0) {//Customer Payment

		$trans_no_payment = get_next_trans_no(ST_CUSTPAYMENT);
		$payment_ref = $Refs->get_next(ST_CUSTPAYMENT);

		$call_second_part= false;
		if($_SESSION['pmt_type'] == 'cash'){
			if($current_user['cash_accounts'] != '' || $current_user['cash_accounts'] != null)
				$pos_account = $current_user['cash_accounts'];
			$amt_ = $_SESSION['subtotal_price'];
		}elseif($_SESSION['pmt_type'] == 'card'){
			if($current_user['bank_accounts'] != '' || $current_user['bank_accounts'] != null)
				$pos_account = $current_user['bank_accounts'];
			$amt_ = $_SESSION['subtotal_price'];
		}elseif($_POST['pmt_type'] == 'spiltpayment'){
			$call_second_part = true;
			$amt_ = $_POST['cashpaid'];
		}else{
			$amt_ = $_SESSION['subtotal_price'];
		}
		FAInsert('debtor_trans', array('trans_no' => $trans_no_payment, 'type' => ST_CUSTPAYMENT,  'debtor_no' => $_SESSION['CustomerId'], 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $_SESSION['grand_total'], 'ov_amount' => $amt_,'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1));

		if($pos_account == '')
			$pos_account = $sales_pos['pos_account'];

		$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

		$total += add_gl_trans(ST_CUSTPAYMENT, $trans_no_payment, $date,	$bank['account_code'], 0, 0, '', $amt_,  $bank['bank_curr_code'], PT_CUSTOMER, $_SESSION['CustomerId']);

		$total += add_gl_trans_customer(ST_CUSTPAYMENT, $trans_no_payment, $date,	$branch_code["receivables_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), -($amt_), $_SESSION['CustomerId'],	"Cannot insert a GL transaction for the debtors account credit");


		FAInsert('bank_trans', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => $amt_, 'person_type_id' => 2, 'person_id' => $fa_user_id));
		FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_CUSTPAYMENT, 'reference' => $payment_ref));
		FAInsert('audit_trail', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment,'user'=>$fa_user_id,'fiscal_year'=> $fiscal_year_id, 'gl_date' => $date));
		FAInsert('cust_allocations', array('person_id' => $_SESSION['CustomerId'], 'amt' => $amt_, 'date_alloc' => $date, 'trans_no_from' => $trans_no_payment, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $trans_no_invoice, 'trans_type_to' => ST_SALESINVOICE));
		if($_POST['pmt_type'] != 'spiltpayment'){
			$memo = 'Invoice Number'.$invoice_ref." ".($_SESSION['trans_ref'] != '' ? _("Debit/Credit Card")." ".$_SESSION['trans_ref'] : '' );
			FAInsert('comments', array('type' => ST_CUSTPAYMENT, 'id' => $trans_no_payment, 'memo_' => $memo));
		}
		if($call_second_part)
			
			WritePOSPayment($trans_no_invoice, $_POST['cardpaid'], 2, $_SESSION['trans_ref'], $_POST['bank_acc_id']);
	}
	FAUpdate('debtor_trans' , array('trans_no' => $delivary_id,'type'=> ST_CUSTDELIVERY), array('version' => 1));
	commit_transaction();
	if( $trans_no_invoice > 0 )
		return array('deliveryman' => $current_user['username'],'payment_type' => $_SESSION['pmt_type'], 'amount' => $_SESSION['grand_total'], 'del_no' => $_SESSION['del_no']);

}
function write() {
	global $current_user, $Refs;

	$date = $_SESSION['date'];
	$fa_user_id = $current_user['fa_user_id'];
	$fiscal_year_id = get_company_details('f_year');
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
	$tax_amt = 0;
	$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	$location = $sales_pos['pos_location'];
	$discount = 0;
	$order_no = $_SESSION['order_id'];

	// Sales Orders 
	
	begin_transaction();
	fadb_query("SET NAMES UTF8", '');
	fadb_query("SET CHARACTER SET utf8;");
	fadb_query("SET collation_connection = utf8_unicode_ci;");
	if(isset($_SESSION['order_id']) && $_SESSION['order_id'] > 0 ) {
		FAUpdate('sales_orders' , array('order_no' => $order_no, 'trans_type' => ST_SALESORDER), array( 'version' => 1,'total' => $_SESSION['grand_total']));
		$sales_order_stock_ids = array();
		$unit_tax_ar = array();
		FADelete('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER ));
		foreach($_SESSION['cart_item'] as $line) {
			$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line['stock_id'], 'description' => $line['name'], 'qty_sent' => 0, 'unit_price' => $line['price'], 'quantity' => $line['qty'], 'discount_percent' => round($line['discount'], 2)));
			$sales_order_stock_ids[$line['stock_id']] = $detailsId;
			$unit_tax_ar[$line['stock_id']] = $detailsId;		
			$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
			$line_tax = get_full_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
			$unit_tax_ar[$line['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0	;	
		} 
	}else{
		$order_no = get_next_trans_no(ST_SALESORDER);	
	FAInsert('sales_orders' , array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'version' => 1, 'debtor_no' => $_SESSION['CustomerId'], 'branch_code' => $branch_code['branch_code'], 'salesman' => $current_user['s_id'],  'reference' => 'auto', 'ord_date' => $date, 'delivery_date' => $date, 'order_type' => 1, 'ship_via' => 1, 'delivery_address' => 'N/A', 'deliver_to' => '','from_stk_loc' => $location, 'payment_terms' => 4, 'total' => $_SESSION['grand_total'], 'customer_ref' => ''));
	$sales_order_stock_ids = array();
	$unit_tax_ar = array();
	foreach($_SESSION['cart_item'] as $line) {
		$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line['stock_id'], 'description' => $line['name'], 'qty_sent' => $line['qty'], 'unit_price' => $line['price'], 'quantity' => $line['qty'], 'discount_percent' => round($line['discount'], 2)));
		$sales_order_stock_ids[$line['stock_id']] = $detailsId;
		$unit_tax_ar[$line['stock_id']] = $detailsId;		
		$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$line_tax = get_full_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
		$unit_tax_ar[$line['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0	;	
		}
	}
	FAInsert('audit_trail', array('type' => ST_SALESORDER, 'trans_no' => $order_no, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));	
				
	//Customer Delivery
	$trans_no_delivery = get_next_trans_no(ST_CUSTDELIVERY);
	FAInsert('debtor_trans', array('trans_no' => $trans_no_delivery, 'type' => ST_CUSTDELIVERY, 'version' => 1, 'debtor_no' => $_SESSION['CustomerId'], 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'], 'tran_date' => $date, 'due_date' => $date, 'reference' => 'auto', 'tpe' => 1, 'order_' => $order_no,'ov_amount' => $_SESSION['subtotal_price'], 'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'], 'tax_included' => $_SESSION['tax_included'], 'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ) ));
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0)
			FAInsert('trans_tax_details', array('trans_type' => ST_CUSTDELIVERY, 'trans_no' => $trans_no_delivery, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => 'auto', 'reg_type' => 0));
	}
	$delivery_details_ids = array();
	foreach($_SESSION['cart_item'] as $line) {
		$delivery_details = array('debtor_trans_no' => $trans_no_delivery, 'debtor_trans_type' => ST_CUSTDELIVERY, 'stock_id' => $line['stock_id'], 'description' => $line['name'], 'unit_price' => $line['price'], 'unit_tax' => $unit_tax_ar[$line['stock_id']], 'quantity' => $line['qty'], 'discount_percent' => $line['discount'], 'standard_cost' => $line['standard_cost'], 'qty_done' => $line['qty'], 'src_id' => $sales_order_stock_ids[$line['stock_id']]);
		if($kv_batch || $kv_exp_date){
			$delivery_details['batch_no'] = $line['batch_no'];
			if($kv_exp_date)
				$delivery_details['exp_date'] = $line['exp_date'];
		}

		$detailsId = FAInsert('debtor_trans_details', $delivery_details);
		$delivery_details_ids[$line['stock_id']] = $detailsId; 
		
		$stock_moves = array('trans_no' => $trans_no_delivery, 'type' => ST_CUSTDELIVERY, 'stock_id' => $line['stock_id'], 'loc_code' => $location, 'tran_date' => $date, 'price' => $line['price'], 'reference' => 'auto', 'qty' => -$line['qty'], 'standard_cost' => $line['standard_cost']); 
		if($kv_batch || $kv_exp_date){
			$stock_moves['batch_no'] = $line['batch_no'];
			if($kv_exp_date)
				$stock_moves['exp_date'] = $line['exp_date'];
		}

		FAInsert('stock_moves', $stock_moves);

		if (is_inventory_item($line['stock_id'])) {		
			if ($line['standard_cost'] != 0) {
				$stock_gl_code = get_stock_gl_code($line['stock_id']);
					
				$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
				$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);
				
				/*first the cost of sales entry*/
				add_gl_trans_std_cost(ST_CUSTDELIVERY, $trans_no_delivery, $date, $stock_gl_code["cogs_account"], $dim, $dim2, "",$line['standard_cost'] * $line['qty'], PT_CUSTOMER, $_SESSION['CustomerId'],	"The cost of sales GL posting could not be inserted");

				/*now the stock entry*/
				add_gl_trans_std_cost(ST_CUSTDELIVERY, $trans_no_delivery, $date, $stock_gl_code["inventory_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), "",	(-$line['standard_cost'] * $line['qty']), PT_CUSTOMER, $_SESSION['CustomerId'],	"The stock side of the cost of sales GL posting could not be inserted");
			}
		}
	}	
	FAInsert('audit_trail', array('type' => ST_CUSTDELIVERY, 'trans_no' => $trans_no_delivery, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	
	$payment_term = FAGetRow('payment_terms', array('terms_indicator' => $_POST['payment_terms']));
	// Sales Invoice
	$trans_no_invoice = get_next_trans_no(ST_SALESINVOICE);
	$invoice_ref = $Refs->get_next(ST_SALESINVOICE);
	$invAray = array('trans_no' => $trans_no_invoice, 'type' => ST_SALESINVOICE,  'debtor_no' => $_SESSION['CustomerId'], 'alloc' => 0, 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'due_date' => $date, 'reference' => $invoice_ref, 'tpe' => 1, 'order_' => $order_no, 'ov_amount' => $_SESSION['subtotal_price'],'ov_gst' => $_SESSION['tax_val'],'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'],'tax_included' => $_SESSION['tax_included'], 'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ) );
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0 && $_POST['pmt_type'] != 'later')
		$invAray['alloc'] = $_SESSION['grand_total'];

	//echo ($_POST['user_paid'].'_'.$_SESSION['grand_total'].'-'.$_SESSION['pmt_type']);	
	if($_SESSION['pmt_type'] == 'cash'){
		$invAray['ov_change'] = $_POST['user_paid']-($_SESSION['grand_total']+$_SESSION['freight_cost']);
	} else
		$invAray['ov_change'] = 0;


	FAInsert('debtor_trans', $invAray);
	$inv_total = 0;
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0){
			FAInsert('trans_tax_details', array('trans_type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => $invoice_ref, 'reg_type' => 0));
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $tax['sales_gl_code'],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), (-$tax['Value']), $_SESSION['CustomerId'], "A tax GL posting could not be inserted");	
		}	
	}
	foreach($_SESSION['cart_item'] as $line) {
		$delivery_details = array('debtor_trans_no' => $trans_no_invoice, 'debtor_trans_type' => ST_SALESINVOICE, 'stock_id' => $line['stock_id'], 'description' => $line['name'], 'unit_price' => $line['price'], 'unit_tax' => ( $_SESSION['tax_included'] != 1 ? $unit_tax_ar[$line['stock_id']] : 0), 'quantity' => $line['qty'], 'discount_percent' => $line['discount'], 'standard_cost' => $line['standard_cost'],  'src_id' => $delivery_details_ids[$line['stock_id']]);

		if($kv_batch || $kv_exp_date){
			$delivery_details['batch_no'] = $line['batch_no'];
			if($kv_exp_date)
				$delivery_details['exp_date'] = $line['exp_date'];
		}

		FAInsert('debtor_trans_details', $delivery_details);
		$stock_gl_code = get_stock_gl_code($line['stock_id']);					
		$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
		$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);
		$sales_account = $stock_gl_code['sales_account'];
		$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $sales_account, $dim, $dim2,	-$line_taxfree_price,	$_SESSION['CustomerId'], "The sales price GL posting could not be inserted");
		if ($line['discount'] != 0) {
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["sales_discount_account"], $dim, $dim2,($line_taxfree_price * $line['discount']),
						$_SESSION['CustomerId'], "The sales discount GL posting could not be inserted");
		}
	}
	
	$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["receivables_account"], (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ),	$_SESSION['grand_total'], $_SESSION['CustomerId'], "The total debtor GL posting could not be inserted");
	add_gl_balance(ST_SALESINVOICE, $trans_no_invoice, $date, -$inv_total, PT_CUSTOMER, $_SESSION['CustomerId']);	
	FAInsert('refs', array('id' => $trans_no_invoice, 'type' => ST_SALESINVOICE, 'reference' => $invoice_ref));
	FAInsert('audit_trail', array('type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
		
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0 && $_POST['pmt_type'] != 'later') {//Customer Payment

		$trans_no_payment = get_next_trans_no(ST_CUSTPAYMENT);
		$payment_ref = $Refs->get_next(ST_CUSTPAYMENT);

		$call_second_part= false;
		if($_SESSION['pmt_type'] == 'cash'){
			if($current_user['cash_accounts'] != '' || $current_user['cash_accounts'] != null)
				$pos_account = $current_user['cash_accounts'];
			$amt_ = $_SESSION['subtotal_price'];
		}elseif($_SESSION['pmt_type'] == 'card'){
			if($current_user['bank_accounts'] != '' || $current_user['bank_accounts'] != null)
				$pos_account = $current_user['bank_accounts'];
			$amt_ = $_SESSION['subtotal_price'];
		}elseif($_POST['pmt_type'] == 'spiltpayment'){
			$call_second_part = true;
			$amt_ = $_POST['cashpaid'];
		}else{
			$amt_ = $_SESSION['subtotal_price'];
		}
		FAInsert('debtor_trans', array('trans_no' => $trans_no_payment, 'type' => ST_CUSTPAYMENT,  'debtor_no' => $_SESSION['CustomerId'], 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $amt_, 'ov_amount' => $amt_,'ov_gst' =>0, 'ov_discount' => $discount, 'rate' => 1));

		if($pos_account == '')
			$pos_account = $sales_pos['pos_account'];

		$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

		$total += add_gl_trans(ST_CUSTPAYMENT, $trans_no_payment, $date,	$bank['account_code'], 0, 0, '', $amt_,  $bank['bank_curr_code'], PT_CUSTOMER, $_SESSION['CustomerId']);

		$total += add_gl_trans_customer(ST_CUSTPAYMENT, $trans_no_payment, $date,	$branch_code["receivables_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), -($amt_), $_SESSION['CustomerId'],	"Cannot insert a GL transaction for the debtors account credit");


		FAInsert('bank_trans', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => $amt_, 'person_type_id' => 2, 'person_id' => $fa_user_id));
		FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_CUSTPAYMENT, 'reference' => $payment_ref));
		FAInsert('audit_trail', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
		FAInsert('cust_allocations', array('person_id' => $_SESSION['CustomerId'], 'amt' => $amt_, 'date_alloc' => $date, 'trans_no_from' => $trans_no_payment, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $trans_no_invoice, 'trans_type_to' => ST_SALESINVOICE));
		if($_POST['pmt_type'] != 'spiltpayment'){
			$memo = 'Invoice Number'.$invoice_ref." ".($_SESSION['trans_ref'] != '' ? _("Debit/Credit Card")." ".$_SESSION['trans_ref'] : '' );
			FAInsert('comments', array('type' => ST_CUSTPAYMENT, 'id' => $trans_no_payment, 'memo_' => $memo));
		}
		if($call_second_part)
			
			WritePOSPayment($trans_no_invoice, $_POST['cardpaid'], 2, $_SESSION['trans_ref'], $_POST['bank_acc_id']);
	}
	
	commit_transaction();
	if($order_no > 0 && $trans_no_delivery > 0 && $trans_no_invoice > 0 )
		return $trans_no_invoice;
}

function WritePOSPayment($inv_no, $amt, $pymt_mtd, $trans_ref=null, $bank_id= 0 ){
	global $current_user, $Refs;
	$date = date('Y-m-d');
	$fa_user_id = $current_user['fa_user_id'];
	$fiscal_year_id = get_company_details('f_year');
	$tax_amt = 0;
	// echo $amt.' '.$bank_id;
	$trans_no_payment = get_next_trans_no(ST_CUSTPAYMENT);
	$payment_ref = $Refs->get_next(ST_CUSTPAYMENT);
	//$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	//echo $inv_no.'-'.$amt.'-'.$pymt_mtd.'-'.$trans_ref;
	$invdetails = Kvcodes_get_customer_trans($inv_no, ST_SALESINVOICE);
	
	begin_transaction();

	FAInsert('debtor_trans', array('trans_no' => $trans_no_payment, 'type' => ST_CUSTPAYMENT,  'debtor_no' => $invdetails['debtor_no'], 'salesman' => $current_user['s_id'], 'branch_code' => $invdetails['branch_code'],  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $amt, 'ov_amount' => $amt,'ov_gst' => 0,'ov_discount' => $inv_details['ov_discount'], 'rate' => 1));

	if($bank_id == 0 ){
		if( $pymt_mtd == 0){
			if($current_user['cash_accounts'] != '' || $current_user['cash_accounts'] != null)
				$pos_account = $current_user['cash_accounts'];
		}elseif( $pymt_mtd == 1){
			if($current_user['bank_accounts'] != '' || $current_user['bank_accounts'] != null)
				$pos_account = $current_user['bank_accounts'];
		}
	} elseif($bank_id > 0 )
		$pos_account = $bank_id;

	if($pos_account == '')
		$pos_account = $sales_pos['pos_account'];

	$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

	$debtors_account = $invdetails["receivables_account"];

	$total += add_gl_trans(ST_CUSTPAYMENT, $trans_no_payment, $date,	$bank['account_code'],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), '', $amt,  $bank['bank_curr_code'], PT_CUSTOMER, $customer_id);

	$total += add_gl_trans_customer(ST_CUSTPAYMENT, $trans_no_payment, $date,	$debtors_account,  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), -($amt), $customer_id,	"Cannot insert a GL transaction for the debtors account credit");
	
	//add_gl_trans($type, $type_no, $date_, $account, $dimension, $dimension2, "", $amount, get_customer_currency($customer_id), PT_CUSTOMER, $customer_id, $err_msg, $rate);

	FAInsert('bank_trans', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => $amt, 'person_type_id' => 2, 'person_id' => $fa_user_id));
	FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_CUSTPAYMENT, 'reference' => $payment_ref));
	FAInsert('audit_trail', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	FAInsert('cust_allocations', array('person_id' => $_SESSION['CustomerId'], 'amt' => $amt, 'date_alloc' => $date, 'trans_no_from' => $trans_no_payment, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $inv_no, 'trans_type_to' => ST_SALESINVOICE));
	if($bank_id > 0 )
		$memo = 'Invoice Number '.$invdetails['reference']." - ".$bank['bank_account_name'] ." ".($trans_ref != null ? $trans_ref : '' );
	else
		$memo = 'Invoice Number '.$invdetails['reference']." ".($pymt_mtd == 0 ? _("Cash Only") : _("Debit/Credit Card"))." ".($trans_ref != null ? $trans_ref : '' );	
	FAInsert('comments', array('type' => ST_CUSTPAYMENT, 'id' => $trans_no_payment, 'memo_' => $memo));
	if($bank_id == 0 ){
		$alloc_new_amt = FAGetSingleValue('debtor_trans', 'alloc', array('trans_no' => $inv_no, 'type' => ST_SALESINVOICE))+$amt;
		FAUpdate('debtor_trans', array('trans_no' => $inv_no, 'type' => ST_SALESINVOICE), array('alloc' => $alloc_new_amt));
	}
	commit_transaction();
	return $trans_no_payment;
}

function write_kot() {
	global $current_user, $Refs;

	$date = $_SESSION['date'];
	$fa_user_id = $current_user['fa_user_id'];
	$fiscal_year_id = get_company_details('f_year');
	$tax_amt = 0;
	$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	$location = $sales_pos['pos_location'];
	$discount = 0;
	// $order_no = $_SESSION['order_id'];
	$token_no = $_SESSION['token_no'];
	begin_transaction();
	fadb_query("SET NAMES UTF8", '');
	fadb_query("SET CHARACTER SET utf8;");
	fadb_query("SET collation_connection = utf8_unicode_ci;");
	$order_no = get_next_trans_no(ST_SALESORDER);
	FAInsert('sales_orders' , array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'version' => 1, 'debtor_no' => $_SESSION['CustomerId'], 'branch_code' => $branch_code['branch_code'], 'salesman' => $current_user['s_id'],  'reference' => 'auto', 'ord_date' => $date, 'delivery_date' => $date, 'order_type' => 1, 'ship_via' => 1, 'delivery_address' => 'N/A', 'deliver_to' => '','from_stk_loc' => $location, 'payment_terms' => 4, 'total' => $_SESSION['grand_total'], 'customer_ref' => '', 'token_no' => $token_no));
	$sales_order_stock_ids = array();
	$unit_tax_ar = array();
	foreach($_SESSION['cart_item'] as $line) {
		$detailsId = FAInsert('sales_order_details', array('order_no' => $order_no, 'trans_type' => ST_SALESORDER, 'stk_code' => $line['stock_id'], 'description' => $line['name'], 'qty_sent' => $line['qty'], 'unit_price' => $line['price'], 'quantity' => $line['qty'], 'discount_percent' => round($line['discount'], 2)));
		$sales_order_stock_ids[$line['stock_id']] = $detailsId;
		$unit_tax_ar[$line['stock_id']] = $detailsId;		
		$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$line_tax = get_full_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']) - $line_taxfree_price;
		$unit_tax_ar[$line['stock_id']] = $line['qty'] ? $line_tax/$line['qty'] : 0	;	
		}
	
	FAInsert('audit_trail', array('type' => ST_SALESORDER, 'trans_no' => $order_no, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));	
				
	//Customer Delivery
	$trans_no_delivery = get_next_trans_no(ST_CUSTDELIVERY);
	FAInsert('debtor_trans', array('trans_no' => $trans_no_delivery, 'type' => ST_CUSTDELIVERY, 'version' => 1, 'debtor_no' => $_SESSION['CustomerId'], 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],'token_no' => $_SESSION['token_no'], 'tran_date' => $date, 'due_date' => $date, 'reference' => 'auto', 'tpe' => 1, 'order_' => $order_no, 'ov_amount' => $_SESSION['grand_total'],'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'], 'tax_included' => $_SESSION['tax_included']));
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0)
			FAInsert('trans_tax_details', array('trans_type' => ST_CUSTDELIVERY, 'trans_no' => $trans_no_delivery, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => 'auto', 'reg_type' => 0));
	}
	$delivery_details_ids = array();
	foreach($_SESSION['cart_item'] as $line) {
		$detailsId = FAInsert('debtor_trans_details', array('debtor_trans_no' => $trans_no_delivery, 'debtor_trans_type' => ST_CUSTDELIVERY, 'stock_id' => $line['stock_id'], 'description' => $line['name'], 'unit_price' => $line['price'], 'unit_tax' => $unit_tax_ar[$line['stock_id']], 'quantity' => $line['qty'], 'discount_percent' => $line['discount'], 'standard_cost' => $line['standard_cost'], 'qty_done' => $line['qty'], 'src_id' => $sales_order_stock_ids[$line['stock_id']]));
		$delivery_details_ids[$line['stock_id']] = $detailsId; 
		FAInsert('stock_moves', array('trans_no' => $trans_no_delivery, 'type' => ST_CUSTDELIVERY, 'stock_id' => $line['stock_id'], 'loc_code' => $location, 'tran_date' => $date, 'price' => $line['price'], 'reference' => 'auto', 'qty' => -$line['qty'], 'standard_cost' => $line['standard_cost']));
		if (is_inventory_item($line['stock_id'])) {		
			if ($line['standard_cost'] != 0) {
				$stock_gl_code = get_stock_gl_code($line['stock_id']);
					
				$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
				$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);
				/*first the cost of sales entry*/
				add_gl_trans_std_cost(ST_CUSTDELIVERY, $trans_no_delivery, $date, $stock_gl_code["cogs_account"], $dim, $dim2, "",$line['standard_cost'] * $line['qty'], PT_CUSTOMER, $_SESSION['CustomerId'],	"The cost of sales GL posting could not be inserted");

				/*now the stock entry*/
				add_gl_trans_std_cost(ST_CUSTDELIVERY, $trans_no_delivery, $date, $stock_gl_code["inventory_account"], 0, 0, "",	(-$line['standard_cost'] * $line['qty']), PT_CUSTOMER, $_SESSION['CustomerId'],	"The stock side of the cost of sales GL posting could not be inserted");
			}
		}
	}	
	FAInsert('audit_trail', array('type' => ST_CUSTDELIVERY, 'trans_no' => $trans_no_delivery, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	
	$payment_term = FAGetRow('payment_terms', array('terms_indicator' => $_SESSION['payment_terms']));
	// Sales Invoice
	$trans_no_invoice = get_next_trans_no(ST_SALESINVOICE);
	$invoice_ref = $Refs->get_next(ST_SALESINVOICE);
	$invAray = array('trans_no' => $trans_no_invoice, 'type' => ST_SALESINVOICE, 'debtor_no' => $_SESSION['CustomerId'],'token_no' => $_SESSION['token_no'], 'alloc' => 0, 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'due_date' => $date, 'reference' => $invoice_ref, 'tpe' => 1, 'order_' => $order_no, 'ov_amount' => $_SESSION['grand_total'],'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1, 'ship_via' => 1, 'payment_terms' => $_SESSION['payment_terms'],'tax_included' => $_SESSION['tax_included']);
	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0)
		$invAray['alloc'] = $_SESSION['grand_total'];

	FAInsert('debtor_trans', $invAray);
	$inv_total = 0;
	foreach($_SESSION['tax_details'] as $tax){
		if($tax['Value'] != 0) {
			FAInsert('trans_tax_details', array('trans_type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'tran_date' => $date, 'tax_type_id' => $tax['tax_type_id'], 'rate' => $tax['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $tax['Net'], 'amount' => $tax['Value'], 'memo' => $invoice_ref, 'reg_type' => 0));
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $tax['sales_gl_code'], 0, 0, (-$tax['Value']), $_SESSION['CustomerId'], "A tax GL posting could not be inserted");	
		}	
	}
	foreach($_SESSION['cart_item'] as $line) {
		FAInsert('debtor_trans_details', array('debtor_trans_no' => $trans_no_invoice, 'debtor_trans_type' => ST_SALESINVOICE, 'stock_id' => $line['stock_id'], 'description' => $line['name'], 'unit_price' => $line['price'], 'unit_tax' => ( $_SESSION['tax_included'] != 1 ? $unit_tax_ar[$line['stock_id']] : 0), 'quantity' => $line['qty'], 'discount_percent' => $line['discount'], 'standard_cost' => $line['standard_cost'],  'src_id' => $delivery_details_ids[$line['stock_id']]));
		$stock_gl_code = get_stock_gl_code($line['stock_id']);					
		$dim = (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : $stock_gl_code["dimension_id"]);
		$dim2 =  (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : $stock_gl_code["dimension2_id"]);
		$sales_account = $stock_gl_code['sales_account'];
		$line_taxfree_price = get_tax_free_price_for_item($line['stock_id'],$line['price'] * $line['qty'], $_SESSION['tax_group_id'], $_SESSION['tax_included']);
		$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $sales_account, $dim, $dim2,	-$line_taxfree_price,	$_SESSION['CustomerId'], "The sales price GL posting could not be inserted");
		if ($line['discount'] != 0) {
			$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["sales_discount_account"], $dim, $dim2,($line_taxfree_price * $line['discount']),
						$_SESSION['CustomerId'], "The sales discount GL posting could not be inserted");
		}
	}
	
	$inv_total += add_gl_trans_customer(ST_SALESINVOICE, $trans_no_invoice, $date, $branch_code["receivables_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ),	$_SESSION['grand_total'], $_SESSION['CustomerId'], "The total debtor GL posting could not be inserted");
	add_gl_balance(ST_SALESINVOICE, $trans_no_invoice, $date, -$inv_total, PT_CUSTOMER, $_SESSION['CustomerId']);	
	FAInsert('refs', array('id' => $trans_no_invoice, 'type' => ST_SALESINVOICE, 'reference' => $invoice_ref));
	FAInsert('audit_trail', array('type' => ST_SALESINVOICE, 'trans_no' => $trans_no_invoice, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	FAInsert('comments', array('type' => ST_SALESINVOICE, 'id' => $trans_no_invoice,'date_' => $date, 'memo_' => $_POST['comment']));

	if($payment_term['days_before_due'] == 0 && $payment_term['day_in_following_month'] == 0) {//Customer Payment

		$trans_no_payment = get_next_trans_no(ST_CUSTPAYMENT);
		$payment_ref = $Refs->get_next(ST_CUSTPAYMENT);

		$call_second_part= false;
		if($_SESSION['pmt_type'] == 'cash'){
			if($current_user['cash_accounts'] != '' || $current_user['cash_accounts'] != null)
				$pos_account = $current_user['cash_accounts'];
			$amt_ = $_SESSION['subtotal_price'];
		}elseif($_SESSION['pmt_type'] == 'card'){
			if($current_user['bank_accounts'] != '' || $current_user['bank_accounts'] != null)
				$pos_account = $current_user['bank_accounts'];
			$amt_ = $_SESSION['subtotal_price'];
		}elseif($_POST['pmt_type'] == 'spiltpayment'){
			$call_second_part = true;
			$amt_ = $_POST['cashpaid'];
		}
		elseif($_SESSION['pmt_type'] == 'multiple'){
			$call_second_part = true;
			if($_POST['user_paid'] != ''){
			$amt_ = $_POST['user_paid'];
			}else if($_POST['card_paid'] != ''){
				$amt_ = $_POST['card_paid'];
			 //}	// else if($_POST['user_paid'] > 0 && $_POST['card_paid'] > 0){
			// 	$val = $_POST['user_paid'] + $_POST['card_paid'];
			// 	$amt_ = number_format($val, 2);
			}else{
				$amt_ = $_SESSION['subtotal_price'];
			}
		}

		FAInsert('debtor_trans', array('trans_no' => $trans_no_payment, 'type' => ST_CUSTPAYMENT,  'debtor_no' => $_SESSION['CustomerId'], 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code['branch_code'],  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $_SESSION['grand_total'], 'ov_amount' => $amt_,'ov_gst' => $_SESSION['tax_val'], 'ov_discount' => $discount, 'rate' => 1, 'token_no' => $_SESSION['token_no'], 'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 )));

		if($pos_account == '')
			$pos_account = $sales_pos['pos_account'];

		$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

		$total += add_gl_trans(ST_CUSTPAYMENT, $trans_no_payment, $date,	$bank['account_code'],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), '', $amt_,  $bank['bank_curr_code'], PT_CUSTOMER, $_SESSION['CustomerId']);

		$total += add_gl_trans_customer(ST_CUSTPAYMENT, $trans_no_payment, $date,	$branch_code["receivables_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), -($amt_), $_SESSION['CustomerId'],	"Cannot insert a GL transaction for the debtors account credit");


		FAInsert('bank_trans', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => $amt_, 'person_type_id' => 2, 'person_id' => $fa_user_id,  'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ) ));
		FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_CUSTPAYMENT, 'reference' => $payment_ref));
		FAInsert('audit_trail', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
		FAInsert('cust_allocations', array('person_id' => $_SESSION['CustomerId'], 'amt' => $amt_, 'date_alloc' => $date, 'trans_no_from' => $trans_no_payment, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $trans_no_invoice, 'trans_type_to' => ST_SALESINVOICE));
		if($_POST['pmt_type'] != 'spiltpayment'){

			$memo = 'Invoice Number'.$invoice_ref." ".($_SESSION['trans_ref'] != '' ? _("Debit/Credit Card")." ".$_SESSION['trans_ref'] : '' );
			FAInsert('comments', array('type' => ST_CUSTPAYMENT, 'id' => $trans_no_payment,'date_'=> $date, 'memo_' => $memo));
		}
		if($call_second_part){
			if($_SESSION['bankpay']){
				foreach ($_SESSION['bankpay'] as $value) {
					WritePayment($trans_no_invoice, $value['cashpaid'], 2, $value['trans_ref'], $value['bank_id']);			
				# code...
				}
			}
		}
	}
	
	commit_transaction();
	if($order_no > 0 && $trans_no_delivery > 0 && $trans_no_invoice > 0 )
		// $_SESSION['order_id']= $order_no;
		$token_no = $_SESSION['token_no'] + 1;
		return array('order_no' => $trans_no_delivery,'token_no' => $token_no,'trans_no' => $trans_no_invoice, 'msg' => 'Payment Successfully Done');

}

function WritePayment($inv_no, $amt, $pymt_mtd, $trans_ref=null, $bank_id= 0 ){
	global $current_user, $Refs;
	$date = date('Y-m-d');
	$fa_user_id = $current_user['fa_user_id'];
	$fiscal_year_id = get_company_details('f_year');
	$tax_amt = 0;
	// echo $amt.' '.$bank_id;
	$trans_no_payment = get_next_trans_no(ST_CUSTPAYMENT);
	$payment_ref = $Refs->get_next(ST_CUSTPAYMENT);
	//$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	//echo $inv_no.'-'.$amt.'-'.$pymt_mtd.'-'.$trans_ref;
	$invdetails = Kvcodes_get_customer_trans($inv_no, ST_SALESINVOICE);
	//var_dump($invdetails);
	begin_transaction();
	FAInsert('debtor_trans', array('trans_no' => $trans_no_payment, 'type' => ST_CUSTPAYMENT,  'debtor_no' => $invdetails['debtor_no'], 'salesman' => $current_user['s_id'], 'branch_code' => $invdetails['branch_code'],  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $amt, 'ov_amount' => $amt,'ov_discount' => $inv_details['ov_discount'], 'rate' => 1,  'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 )));

	$pos_account = $bank_id;

	if($pos_account == '')
		$pos_account = $sales_pos['pos_account'];

	$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

	$debtors_account = $invdetails["receivables_account"];

	$total += add_gl_trans(ST_CUSTPAYMENT, $trans_no_payment, $date,	$bank['account_code'],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), '', $amt,  $bank['bank_curr_code'], PT_CUSTOMER, $customer_id);

	$total += add_gl_trans_customer(ST_CUSTPAYMENT, $trans_no_payment, $date,	$debtors_account,  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), -($amt), $customer_id,	"Cannot insert a GL transaction for the debtors account credit");
	
	//add_gl_trans($type, $type_no, $date_, $account, $dimension, $dimension2, "", $amount, get_customer_currency($customer_id), PT_CUSTOMER, $customer_id, $err_msg, $rate);

	FAInsert('bank_trans', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => $amt, 'person_type_id' => 2, 'person_id' => $invdetails['debtor_no'],  'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 )));
	FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_CUSTPAYMENT, 'reference' => $payment_ref));
	FAInsert('audit_trail', array('type' => ST_CUSTPAYMENT, 'trans_no' => $trans_no_payment, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	FAInsert('cust_allocations', array('person_id' => $_SESSION['CustomerId'], 'amt' => $amt, 'date_alloc' => $date, 'trans_no_from' => $trans_no_payment, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $inv_no, 'trans_type_to' => ST_SALESINVOICE));
	$memo = 'Invoice Number '.$invdetails['reference']." - ".$bank['bank_account_name'] ." ".($trans_ref != null ? $trans_ref : '' );
	
	FAInsert('comments', array('type' => ST_CUSTPAYMENT, 'id' => $trans_no_payment, 'memo_' => $memo));

	FAUpdate('debtor_trans', ['type' => ST_SALESINVOICE, 'trans_no' => $inv_no], ['alloc' => round($invdetails['alloc']+$amt, 2)]);
	commit_transaction();
	return $trans_no_payment;
}


function is_sales_kit($stock_id){
	//echo $stock_id."ASdfasd";
	$res = FAGetRow('item_codes', ['item_code' => $stock_id]);
	//var_dump($res);
	if($res['item_code'] != $res['stock_id'])
		return true;
	else
		return false;
}


function Kvcodes_Add_Sales_Return($inv_no, $amt, $details){
	global $current_user, $Refs;
	$date = date('Y-m-d');
	$fa_user_id = $current_user['fa_user_id'];
	$fiscal_year_id = get_company_details('f_year');
	$kv_batch = get_company_details('kv_batch');
   	$kv_exp_date = get_company_details('kv_exp_date');
   	$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
	$tax_amt = 0;
	$trans_no_return = get_next_trans_no(ST_CUSTCREDIT);
	$return_ref = $Refs->get_next(ST_CUSTCREDIT);	
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	$invdetails = Kvcodes_get_customer_trans($inv_no, ST_SALESINVOICE);
	$line_items_ar= [];
	$res_inv_details = Kvcodes_get_customer_trans_details(ST_SALESINVOICE, $inv_no);
	while($row = fadb_fetch($res_inv_details)){
		$line_items_ar[]=$row;
	}
	$invdetails['line_items']= $line_items_ar;
	$branch_data = get_branch_accounts($invdetails['branch_code']);
	//var_dump($invdetails);
	//echo $amt.'<br>';
	begin_transaction();
	$sales_type_id = FAGetSingleValue('debtors_master', 'sales_type', ['debtor_no' => $invdetails['debtor_no']]);

	FAInsert('debtor_trans', array('trans_no' => $trans_no_return, 'type' => ST_CUSTCREDIT, 'debtor_no' => $invdetails['debtor_no'], 'salesman' => $current_user['s_id'], 'branch_code' => $invdetails['branch_code'],  'tran_date' => $date, 'reference' => $return_ref, 'alloc' => $amt, 'ov_amount' => $amt,'ov_gst' => $invdetails['ov_gst'] ,'order_' => $invdetails['order_'], 'ov_discount'=>$inv_details['ov_discount'], 'rate' => 1, 'ship_via' => $invdetails['ship_via'], 'payment_terms' => $invdetails['payment_terms'], 'tax_included' =>$invdetails['tax_included'], 'tpe' => $invdetails['tpe'],  'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ) ));
	update_customer_trans_version(get_parent_type(ST_CUSTCREDIT), array($inv_no => $invdetails['version']));
	foreach($details as $key => $line){
		if($line[1] <= 0)
			continue;

		if($non_detailed_sales_kit && is_sales_kit($line[0])){
			unset($details[$key]);
			$kit_items = get_item_kit($line[0], true);
			foreach($kit_items as $keyy => $item){
				foreach($invdetails['line_items'] as $single){
					if($item['stock_id'] == $single['stock_id'] && $single['kit'] == $line[0]){
						$single['qty_returned'] 	= $line[1];
						$single['src_id']		= $single['id'];
						$details[] = $single;
					}
				}
			}
			
		} else {
			foreach($invdetails['line_items'] as $single){
				if($line[0] == $single['stock_id'] && !isset($details[$key]['kit'])){
					$details[$key]['stock_id']		 	= $single['stock_id'];
					$details[$key]['description'] 		= $single['description'];
					$details[$key]['unit_price'] 		= $single['unit_price'];
					$details[$key]['unit_tax'] 			= $single['unit_tax'];
					$details[$key]['qty_returned'] 		= $line[1];
					$details[$key]['qty_dispatched'] 	= $single['quantity'];
					$details[$key]['src_id'] 			= $single['id'];
					$details[$key]['standard_cost'] 	= $single['standard_cost'];
					$details[$key]['discount']			= $single['discount_percent'];
				}
			}
		}
	}

	//var_dump($details);
	foreach ($details as $line) {
		if($line['qty_returned'] != 0 ) {
			$return_details = array('debtor_trans_no' => $trans_no_return, 'debtor_trans_type' => ST_CUSTCREDIT, 'stock_id' => $line['stock_id'], 'description' => $line['description'], 'unit_price' => $line['unit_price'], 'unit_tax' => $line['unit_tax'], 'quantity' => $line['qty_returned'], 'discount_percent' => $line['discount'], 'standard_cost' => $line['standard_cost'], 'kit' => (isset($line['kit']) ? $line['kit'] : ''), 'src_id' => $line['src_id']);

			if($kv_batch || $kv_exp_date){
				$return_details['batch_no'] = $line[4];
				if($kv_exp_date)
					$return_details['exp_date'] = $line[5];
			}

			FAInsert('debtor_trans_details', $return_details);		
			update_parent_line(ST_CUSTCREDIT, $line['src_id'],$line['qty_returned']);			
			$reference = _("Return").' '._("Ex Inv:").' ' . $invdetails['trans_no'];

			$stock_moves = array('trans_no' => $trans_no_return, 'type' => ST_CUSTCREDIT, 'stock_id' => $line['stock_id'], 'loc_code' => $invdetails['default_location'], 'tran_date' => $date, 'price' => $line['unit_price'], 'reference' => $reference, 'qty' => $line['qty_returned'], 'standard_cost' => $line['standard_cost']);

			if($kv_batch || $kv_exp_date){
				$stock_moves['batch_no'] = $line['batch_no'];
				if($kv_exp_date)
					$stock_moves['exp_date'] = $line['exp_date'];
			}

			FAInsert('stock_moves', $stock_moves);
			$total += add_gl_trans_credit_costs($details, $line, $trans_no_return,  $date, 'Return', 0, $branch_data);
		}		
	}
	//cancel_transaction();
	$total += add_gl_trans_customer(ST_CUSTCREDIT, $trans_no_return, $date, $branch_data["receivables_account"],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ),
			-$amt, $invdetails['debtor_no'], "The total debtor GL posting for the credit note could not be inserted");

	$tax_details = return_get_taxes($details, $invdetails['tax_group_id'], $invdetails['tax_included']);
	$tax_total = $net_total = 0;
	//var_dump($tax_details);
	foreach ($tax_details as $taxitem) {
		$taxitem['Value'] =  round2($taxitem['Value'], user_price_dec());
		$tax_total += $taxitem['Value'];
		$net_total += $taxitem['Net'];
		if ($taxitem['Value'] != 0) {
			FAInsert('trans_tax_details', array('trans_type' => ST_CUSTCREDIT, 'trans_no' => $trans_no_return, 'tran_date' => $date, 'tax_type_id' => $taxitem['tax_type_id'], 'rate' => $taxitem['rate'], 'ex_rate' => 1, 'included_in_price' => 1, 'net_amount' => $taxitem['Net'], 'amount' => $taxitem['Value'], 'memo' => $return_ref, 'reg_type' => 0));
			$total += add_gl_trans_customer(ST_CUSTCREDIT, $trans_no_return, $date, $taxitem['sales_gl_code'],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), ($taxitem['Value']), $invdetails['debtor_no'], "A tax GL posting could not be inserted");
		}
	}

	if($net_total > 0)
		FAUpdate('debtor_trans', ['trans_no' => $trans_no_return, 'type' => ST_CUSTCREDIT], ['ov_amount' => $net_total, 'ov_gst' => $tax_total] );

	FAInsert('cust_allocations', array('person_id' => $invdetails['debtor_no'], 'amt' => $amt, 'date_alloc' => $date, 'trans_no_to' => $inv_no, 'trans_type_to' => ST_SALESINVOICE, 'trans_no_from' => $trans_no_return, 'trans_type_from' => ST_CUSTCREDIT));
	$inv_rows = FAGetAll('cust_allocations', ['trans_no_to' => $inv_no, 'trans_type_to' => ST_SALESINVOICE]);
	if(!empty($inv_rows)){
		foreach($inv_rows as $single){
			if($amt <= $single['amt']){
				if($amt == $single['amt'])
					FADelete('cust_allocations', ['id' => $single['id']]);
				else
					FAUpdate('cust_allocations', ['id' => $single['id']], ['amt' => 'amt-'.$amt]);
				CreateBankPayment($invdetails['debtor_no'], $invdetails['branch_code'], $amt, $_POST['bank_id'], $invdetails["receivables_account"], $single['trans_no_from'], $return_ref);
				break;
			}
		}
	}

	FAInsert('refs', array('id' => $trans_no_return, 'type' => ST_CUSTCREDIT, 'reference' => $return_ref));
	FAInsert('audit_trail', array('type' => ST_CUSTCREDIT, 'trans_no' => $trans_no_return, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));
	
	commit_transaction();
	return $trans_no_return;
}

function CreateBankPayment($debtor_no, $branch_code, $amt, $bank_id, $receivables_account, $customer_payment_id, $return_ref){
	global $current_user, $Refs;

	$date = date('Y-m-d');
	$fa_user_id = $current_user['fa_user_id'];
	$fiscal_year_id = get_company_details('f_year');
	$tax_amt = 0;
	// echo $amt.' '.$bank_id;
	$trans_no_payment = get_next_trans_no(ST_BANKPAYMENT);
	$payment_ref = $Refs->get_next(ST_BANKPAYMENT);
	//$branch_code = get_cust_branch($_SESSION['CustomerId']);
	$sales_pos = FAGetRow('sales_pos', array('id' => $current_user['sales_pos_id']));
	//echo $inv_no.'-'.$amt.'-'.$pymt_mtd.'-'.$trans_ref;
	//$invdetails = Kvcodes_get_customer_trans($inv_no, ST_SALESINVOICE);
	//var_dump($invdetails);

	begin_transaction();

	FAInsert('debtor_trans', array('trans_no' => $trans_no_payment, 'type' => ST_BANKPAYMENT,  'debtor_no' => $debtor_no, 'salesman' => $current_user['s_id'], 'branch_code' => $branch_code,  'tran_date' => $date, 'reference' => $payment_ref, 'alloc' => $amt, 'ov_amount' => $amt,'ov_discount' => 0, 'rate' => 1,  'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 )));

	$pos_account = $bank_id;

	if($pos_account == '')
		$pos_account = $sales_pos['pos_account'];

	$bank = FAGetRow('bank_accounts', array('id' => $pos_account));

	$total += add_gl_trans(ST_BANKPAYMENT, $trans_no_payment, $date,	$bank['account_code'],  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), '', -($amt),  $bank['bank_curr_code'], PT_CUSTOMER, $customer_id);

	$total += add_gl_trans_customer(ST_BANKPAYMENT, $trans_no_payment, $date,	$receivables_account,  (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 ), $amt, $debtor_no,	"Cannot insert a GL transaction for the debtors account credit");
	
	//add_gl_trans($type, $type_no, $date_, $account, $dimension, $dimension2, "", $amount, get_customer_currency($customer_id), PT_CUSTOMER, $customer_id, $err_msg, $rate);

	FAInsert('bank_trans', array('type' => ST_BANKPAYMENT, 'trans_no' => $trans_no_payment, 'bank_act' => $pos_account, 'ref' => $payment_ref, 'trans_date' => $date, 'amount' => -$amt, 'person_type_id' => PT_CUSTOMER, 'person_id' => $debtor_no,  'dimension_id' => (isset($_SESSION['dimension_id']) ? $_SESSION['dimension_id'] : 0 ), 'dimension2_id' => (isset($_SESSION['dimension2_id']) ? $_SESSION['dimension2_id'] : 0 )));

	FAInsert('refs', array('id' => $trans_no_payment, 'type' => ST_BANKPAYMENT, 'reference' => $payment_ref));

	FAInsert('audit_trail', array('type' => ST_BANKPAYMENT, 'trans_no' => $trans_no_payment, 'user' => $fa_user_id, 'fiscal_year' => $fiscal_year_id, 'gl_date' => $date));

	FAInsert('cust_allocations', array('person_id' => $debtor_no, 'amt' => $amt, 'date_alloc' => $date, 'trans_no_from' => $customer_payment_id, 'trans_type_from' => ST_CUSTPAYMENT, 'trans_no_to' => $trans_no_payment, 'trans_type_to' => ST_BANKPAYMENT));

	$memo = 'Credit Note Reference '.$return_ref." - ".$bank['bank_account_name'];
	
	FAInsert('comments', array('type' => ST_BANKPAYMENT, 'id' => $trans_no_payment, 'memo_' => $memo));

	FAUpdate('debtor_trans', ['type' => ST_SALESINVOICE, 'trans_no' => $inv_no], ['alloc' => round($invdetails['alloc']+$amt, 2)]);

	commit_transaction();

	return $trans_no_payment;
}


function add_gl_trans_customer($type, $type_no, $date_, $account, $dimension, $dimension2,	$amount, $customer_id, $err_msg="", $rate=0){
	if ($err_msg == "")
		$err_msg = "The customer GL transaction could not be inserted";

	return add_gl_trans($type, $type_no, $date_, $account, $dimension, $dimension2, "", $amount, get_customer_currency($customer_id), PT_CUSTOMER, $customer_id, $err_msg, $rate);
}

if(!function_exists('get_customer_currency')){
	function get_customer_currency($customer_id=null, $branch_id=null){
		$sql = "SELECT curr_code  	FROM ".TB_PREF."debtors_master cust	LEFT JOIN ".TB_PREF."cust_branch branch ON branch.debtor_no=cust.debtor_no
			WHERE " .(isset($branch_id) ? "branch_code = ".fadb_escape($branch_id) : "cust.debtor_no = ".fadb_escape($customer_id));

		$result = fadb_query($sql, "Retreive currency of customer $customer_id");
		$myrow=fadb_fetch_row($result);
		return $myrow[0];
	}
}

// Function for even out rounding problems
function add_gl_balance($type, $trans_id, $date_, $amount, $person_type_id=null, $person_id=null) {
	$amount = round2($amount, user_price_dec());

	if (floatcmp($amount, 0)){
		error_log(sprintf( _("Rounding error %s encountered for trans_type:%s,trans_no:%s"), $amount, $type, $trans_id));
		return add_gl_trans($type, $trans_id, $date_, get_company_details('exchange_diff_act'), 0, 0, "", $amount, null, $person_type_id, $person_id,
		"The balanced GL transaction could not be inserted");
	} else
		return 0;
}

//----------------------------------------------------------------------------------
function add_gl_trans($type, $trans_id, $date_, $account, $dimension, $dimension2, $memo_,$amount, $currency=null, $person_type_id=null, $person_id=null,	$err_msg="", $rate=0){
	global $current_user;

	$date = $date_;
	if ($currency != null){
		if ($rate == 0)
			$amount_in_home_currency = to_home_currency($amount, $currency, $date_);
		else
			$amount_in_home_currency = round2($amount * $rate,  user_price_dec());
	} else
		$amount_in_home_currency = round2($amount, user_price_dec());
	if ($dimension == null || $dimension < 0)
		$dimension = 0;
	if ($dimension2 == null || $dimension2 < 0)
		$dimension2 = 0;
	
	if ($memo_ == "" || $memo_ == null)
		$memo_ = $current_user["fa_user_id"];
	else
			$memo_ = $current_user["fa_user_id"]. " - " . $memo_;
	
	if (!is_subledger_account($account) || $account==get_company_details('grn_clearing_act'))
		$person_id = $person_type_id = null;
	
	$sql = "INSERT INTO ".TB_PREF."gl_trans ( type, type_no, tran_date,	account, dimension_id, dimension2_id, memo_, amount";

	if ($person_type_id != null)
		$sql .= ", person_type_id, person_id";

	$sql .= ") VALUES (".fadb_escape($type).", ".fadb_escape($trans_id).", '$date',".fadb_escape($account).", ".fadb_escape($dimension).", "
		.fadb_escape($dimension2).", ".fadb_escape($memo_).", ".fadb_escape($amount_in_home_currency);

	if ($person_type_id != null)
		$sql .= ", ".fadb_escape($person_type_id).", ". fadb_escape($person_id);

	$sql .= ") ";

	if ($err_msg == "")
		$err_msg = "The GL transaction could not be inserted";

	fadb_query($sql, $err_msg);
	return $amount_in_home_currency;
}

//----------------------------------------------------------------------------------------

function add_gl_trans_credit_costs($order, $order_line, $credit_no, $date_,	$credit_type, $write_off_gl_code, $branch_data){
	$stock_gl_codes = get_stock_gl_code($order_line['stock_id']);
	$customer = FAGetRow('debtors_master', array('debtor_no' => $order['debtor_no']));
	// If there is a Customer Dimension, then override with this,
	// else take the Item Dimension (if any)
	$dim = ($order['dimension_id'] != $customer['dimension_id'] ? $order['dimension_id'] : 
		($customer['dimension_id'] != 0 ? $customer["dimension_id"] : $stock_gl_codes["dimension_id"]));
	$dim2 = ($order['dimension2_id'] != $customer['dimension2_id'] ? $order['dimension2_id'] : 
		($customer['dimension2_id'] != 0 ? $customer["dimension2_id"] : $stock_gl_codes["dimension2_id"]));

	$total = 0;
	/* insert gl_trans to credit stock and debit cost of sales at standard cost*/
	$unit_cost = $order_line['standard_cost'];
	if ($unit_cost != 0) {
		/*first the cost of sales entry*/
		$total += add_gl_trans_std_cost(ST_CUSTCREDIT, $credit_no, $date_, $stock_gl_codes["cogs_account"],	$dim, $dim2, "", -($unit_cost * $order_line['qty_returned']),
		PT_CUSTOMER, $order['debtor_no'],"The cost of sales GL posting could not be inserted");

		/*now the stock entry*/
		if ($credit_type == "WriteOff") {
			$stock_entry_account = $write_off_gl_code;
		} else {
			$stock_gl_code = get_stock_gl_code($order_line['stock_id']);
			$stock_entry_account = $stock_gl_code["inventory_account"];
		}

		$total += add_gl_trans_std_cost(ST_CUSTCREDIT, $credit_no, $date_, $stock_entry_account, 0, 0,	"", ($unit_cost * $order_line['qty_returned']),
			PT_CUSTOMER, $order['debtor_no'], "The stock side (or write off) of the cost of sales GL posting could not be inserted");

	} /* end of if GL and stock integrated and standard cost !=0 */

	if ($order_line['unit_price'] != 0) {
		$line_taxfree_price =	get_tax_free_price_for_item($order_line['stock_id'], $order_line['unit_price'],  $order['tax_group_id'], $order['tax_included'], $order['tax_group_array']);
		//$line_tax = get_full_price_for_item($order_line['stock_id'], $order_line['price'],  $order['tax_group_id'], $order['tax_included'], $order['tax_group_array']) - $line_taxfree_price;

		//Post sales transaction to GL credit sales

		// If there is a Branch Sales Account, then override with this,
		// else take the Item Sales Account
		if ($branch_data['sales_account'] != "")
			$sales_account = $branch_data['sales_account'];
		else
			$sales_account = $stock_gl_codes['sales_account'];
		$total += add_gl_trans_customer(ST_CUSTCREDIT, $credit_no, $date_, $sales_account, $dim, $dim2,	($line_taxfree_price * $order_line['qty_returned']), $order['debtor_no'],
			"The credit note GL posting could not be inserted");

		if ($order_line['discount_percent'] != 0) {
			$total += add_gl_trans_customer(ST_CUSTCREDIT, $credit_no, $date_, $branch_data["sales_discount_account"],
				$dim, $dim2, -($line_taxfree_price * $order_line['qty_returned'] * $order_line['discount_percent']),	$order['customer_id'],
				"The credit note discount GL posting could not be inserted");

		} /*end of if discount !=0 */
	} /*if line_price!=0 */
	return $total;
}

//--------------------------------------------------------------------------------
// GL Trans for standard costing, always home currency regardless of person
// $date_ is display date (non-sql)
// $amount is in HOME currency
function add_gl_trans_std_cost($type, $trans_id, $date_, $account, $dimension, $dimension2, $memo_,	$amount, $person_type_id=null, $person_id=null, $err_msg=""){
	if ($amount != 0)
		return add_gl_trans($type, $trans_id, $date_, $account, $dimension, $dimension2, $memo_, $amount, null, $person_type_id, $person_id, $err_msg);
	else
		return 0;
}

//----------------------------------------------------------------------------------
function get_exchange_rate_to_home_currency($currency_code, $date_){
	return 1 / get_exchange_rate_from_home_currency($currency_code, $date_);
}

//----------------------------------------------------------------------------------
function to_home_currency($amount, $currency_code, $date_){
	$ex_rate = get_exchange_rate_to_home_currency($currency_code, $date_);
	$amount = (float)$amount;
	$ex_rate = (float)$ex_rate;
	return round2($amount / $ex_rate,  user_price_dec());
}

function is_subledger_account($account){
	$sql = "SELECT 1 FROM ".TB_PREF."cust_branch WHERE receivables_account=".fadb_escape($account)
	." UNION	SELECT -1 	FROM ".TB_PREF."suppliers WHERE payable_account=".fadb_escape($account);

	$result = fadb_query($sql,"Couldn't test AR/AP account");
	$myrow = fadb_fetch_row($result);
	return $myrow[0];
}

function get_cust_branch($CustomerId){
	$sql = "SELECT * FROM ".TB_PREF."cust_branch WHERE debtor_no=".fadb_escape($CustomerId)." LIMIT 1";
	$result = fadb_query($sql,"check failed");
	return fadb_fetch($result);
}

function add_audit_trail($trans_type, $trans_no, $trans_date, $descr=''){
	begin_transaction();

	$date = $trans_date;
	$sql = "INSERT INTO ".TB_PREF."audit_trail"
		. " (type, trans_no, user, gl_date, description)
			VALUES(".db_escape($trans_type).", ".db_escape($trans_no).",1 ,"
			. "'$date',". db_escape($descr). ")";

	db_query($sql, "Cannot add audit info");
	// all audit records beside just inserted one should have gl_seq set to NULL
	// to avoid need for subqueries (not existing in MySQL 3) all over the code
	$sql = "UPDATE ".TB_PREF."audit_trail audit LEFT JOIN ".TB_PREF."fiscal_year year ON year.begin<='$date' AND year.end>='$date'
		SET audit.gl_seq = IF(audit.id=".db_insert_id().", 0, NULL),"
		."audit.fiscal_year=year.id"
		. " WHERE type=".db_escape($trans_type)." AND trans_no="
		. db_escape($trans_no);

	db_query($sql, "Cannot update audit gl_seq");
	commit_transaction();
}

//----------------------------------------------------------------------------------------
// Mark changes in sales_order_details
//
function update_sales_order_version($order) {
  foreach ($order as $so_num => $so_ver) {
  $sql= 'UPDATE '.TB_PREF.'sales_orders SET version=version+1 WHERE order_no='. db_escape($so_num).
	' AND version='.$so_ver . " AND trans_type=".ST_SALESORDER;
  db_query($sql, 'Concurrent editing conflict while sales order update');
  }
}

//--------------------------------------------------------------------------------------
function get_unit_cost($stock_id) {
	$sql = "SELECT material_cost	FROM ".TB_PREF."stock_master	WHERE stock_id=".db_escape($stock_id);
	$result = db_query($sql, "The standard cost cannot be retrieved");
	$myrow = db_fetch_row($result);
	return $myrow[0];
}

//----------------------------------------------------------------------------------------
function exists_customer_trans($type, $type_no){
	$sql = "SELECT trans_no FROM ".TB_PREF."debtor_trans WHERE type=".fadb_escape($type)." AND trans_no=".fadb_escape($type_no);

	$result = fadb_query($sql, "Cannot retreive a debtor transaction");

	return (fadb_num_rows($result) > 0);
}
//----------------------------------------------------------------------------------------
function close_sales_order($order_no){
	// set the quantity of each item to the already sent quantity. this will mark item as closed.
	$sql = "UPDATE ".TB_PREF."sales_order_details	SET quantity = qty_sent WHERE order_no = ".db_escape($order_no)
		." AND trans_type=".ST_SALESORDER;

	db_query($sql, "The sales order detail record could not be updated");
}

//----------------------------------------------------------------------------------------
function get_sales_order_header($order_no, $trans_type){
	$sql = "SELECT sorder.*,
	  cust.name,
	  cust.curr_code,
	  cust.address,
	  loc.location_name,
	  cust.discount,
	  stype.sales_type,
	  stype.id AS sales_type_id,
	  stype.tax_included,
	  stype.factor,
 	  ship.shipper_name,
	  tax_group.name AS tax_group_name,
	  tax_group.id AS tax_group_id,
	  cust.tax_id,
	  sorder.alloc,
	  IFNULL(allocs.ord_allocs, 0)+IFNULL(inv.inv_allocs ,0) AS sum_paid,
	  sorder.prep_amount>0 as prepaid
	FROM ".TB_PREF."sales_orders sorder
			LEFT JOIN (SELECT trans_no_to, sum(amt) ord_allocs FROM ".TB_PREF."cust_allocations
				WHERE trans_type_to=".ST_SALESORDER." AND trans_no_to=".db_escape($order_no)." GROUP BY trans_no_to)
				 allocs ON sorder.trans_type=".ST_SALESORDER." AND allocs.trans_no_to=sorder.order_no
			LEFT JOIN (SELECT order_, sum(alloc) inv_allocs FROM ".TB_PREF."debtor_trans 
				WHERE type=".ST_SALESINVOICE." AND order_=".db_escape($order_no)."  GROUP BY order_)
				 inv ON sorder.trans_type=".ST_SALESORDER." AND inv.order_=sorder.order_no
			LEFT JOIN ".TB_PREF."shippers ship ON  ship.shipper_id = sorder.ship_via,"
	  .TB_PREF."debtors_master cust,"
	  .TB_PREF."sales_types stype, "
	  .TB_PREF."tax_groups tax_group, "
	  .TB_PREF."cust_branch branch,"
	  .TB_PREF."locations loc
	WHERE sorder.order_type=stype.id
		AND branch.branch_code = sorder.branch_code
		AND branch.tax_group_id = tax_group.id
		AND sorder.debtor_no = cust.debtor_no
		AND loc.loc_code = sorder.from_stk_loc
		AND sorder.trans_type = " . db_escape($trans_type) ."
		AND sorder.order_no = " . db_escape($order_no );

	$result = db_query($sql, "order Retreival");

	$num = db_num_rows($result);
	if ($num > 1)
	{
		echo _("You have duplicate document in database: (type:$trans_type, number:$order_no).");
	}
	else if ($num == 1)
	{
		return db_fetch($result);
	}
	else
		echo _("You have missing or invalid sales document in database (type:$trans_type, number:$order_no).");
}

//----------------------------------------------------------------------------------------
function get_sales_order_details($order_no, $trans_type) {

	$sql = "SELECT id, stk_code, unit_price,line.description,line.quantity,	discount_percent,qty_sent as qty_done,item.units,	item.mb_flag,	item.material_cost,
			line.kit FROM ".TB_PREF."sales_order_details line,".TB_PREF."stock_master item	WHERE line.stk_code = item.stock_id	AND order_no =".fadb_escape($order_no) 
				." AND trans_type = ".fadb_escape($trans_type) . " ORDER BY id";

	return fadb_query($sql, "Retreive order Line Items");
}
//----------------------------------------------------------------------------------------

function read_sales_order($order_no, &$order, $trans_type){

	$myrow = get_sales_order_header($order_no, $trans_type);

	$order['trans_type'] = $myrow['trans_type'];
	$order['so_type'] =  $myrow["type"];
	$order['trans_no'] = array($order_no=> $myrow["version"]);
	$order['customer_id']= $myrow["debtor_no"];	
	$order['sales_type'] = $myrow['sales_type'] ;
	//$order['set_location($myrow["from_stk_loc"], $myrow["location_name"]);
	$order['ship_via'] = $myrow["ship_via"];
	$order['cust_ref'] = $myrow["customer_ref"];
	$order['sales_type'] =$myrow["order_type"];
	$order['reference'] = $myrow["reference"];
	$order['Comments'] = $myrow["comments"];
	$order['due_date'] = $myrow["delivery_date"];
	$order['document_date'] = $myrow["ord_date"];
	$order['prepaid'] = $myrow["prepaid"];
	$order['alloc'] = $myrow['alloc'];
	$order['sum_paid'] = $myrow["sum_paid"]; // sum of all prepayments to so (also invoiced)
	$order['prep_amount'] = $myrow["prep_amount"];
	$order['prepayments'] = 0; //get_payments_for($order_no, $myrow['trans_type'], $myrow['debtor_no']);

	$result = get_sales_order_details($order_no, $order['trans_type']);
	if (db_num_rows($result) > 0){
		$line_no=0;
		while ($myrow = db_fetch($result)){
			$order['cart_item'] = array('id' => $line_no,'stock_id' => $myrow["stk_code"],'qty' => $myrow["quantity"], 'price'	=> $myrow["unit_price"], 'discount' => $myrow["discount_percent"],
				'qty_done' => $myrow["qty_done"], 'standard_cost' => $myrow["material_cost"], 'name' => $myrow["description"], 'src_id' => $myrow["id"] );
			$line_no++;
		}
	}

	return true;
}
//----------------------------------------------------------------------------------------
function read($type, $trans_no=0, $prepare_child=false, $cart) {

		global $SysPrefs, $Refs; 

		if (!is_array($trans_no)) $trans_no = array($trans_no);

		if ($trans_no[0]) { // read old transaction
			if ($type == ST_SALESORDER || $type == ST_SALESQUOTE) { // sales order || sales quotation
				read_sales_order($trans_no[0], $this, $type);
			} else {	// other type of sales transaction
				read_sales_trans($type, $trans_no, $this);
				$this->prepayments = get_payments_for($trans_no[0], $type, $this->customer_id);
				$this->update_payments();
				if ($this->order_no) { // free hand credit notes have no order_no
					$sodata = get_sales_order_header($this->order_no, ST_SALESORDER);
					$this->cust_ref = $sodata["customer_ref"];
				// currently currency is hard linked to debtor account
					$this->delivery_to = $sodata["deliver_to"];
					$this->delivery_address = $sodata["delivery_address"];
				// child transaction reedition - update with parent info unless it is freehand
				if (!$this->is_prepaid() && !$prepare_child) // this is read for view/reedition
					$this->set_parent_constraints($sodata, $trans_no[0]);
				}
			}
			// convert document into child and prepare qtys for entry
			if ($prepare_child)
				$this->prepare_child($prepare_child);

		} else { // new document
			$this->trans_type = $type;
			$this->trans_no = 0;
			$this->customer_currency = get_company_currency();
			// set new sales document defaults here
			if (get_global_customer() != ALL_TEXT)
			  $this->customer_id = get_global_customer();
			else
			  $this->customer_id = '';
			$this->document_date = new_doc_date();
			if (!is_date_in_fiscalyear($this->document_date))
				$this->document_date = end_fiscalyear();
			$this->reference = $Refs->get_next($this->trans_type, null, array('date' => Today(),
				'customer' => $this->customer_id));
			if ($type != ST_SALESORDER && $type != ST_SALESQUOTE) // Added 2.1 Joe Hunt 2008-11-12
			{
				$dim = get_company_pref('use_dimension');
				if ($dim > 0)
				{
					if ($this->customer_id == '')
						$this->dimension_id = 0;
					else
					{
						$cust = get_customer($this->customer_id);
						$this->dimension_id = $cust['dimension_id'];
					}	
					if ($dim > 1)
					{
						if ($this->customer_id == '')
							$this->dimension2_id = 0;
						else
							$this->dimension2_id = $cust['dimension2_id'];
					}		
				}		
			}	
			if ($type == ST_SALESINVOICE) {
				$this->due_date =
					get_invoice_duedate($this->payment, $this->document_date);
			} else
				$this->due_date =
					add_days($this->document_date, $SysPrefs->default_delivery_required_by());
		}
		$this->credit = get_current_cust_credit($this->customer_id);
	}


function update_payments()
	{
		$remainder = prepaid_invoice_remainder($this->order_no);

		// recalculate prepaid part from payments
		if ($this->payment_terms['days_before_due'] == -1)
		{	// this is partial invoice for selected prepayments made.
			$paid = 0;
			foreach($this->prepayments as $payment)
				$paid += $payment['amt'];
			$this->prep_amount = $this->trans_no ? $paid : min($remainder, $paid);
		} else	// this is final invoice
			$this->prep_amount = $remainder;
	}

?>	