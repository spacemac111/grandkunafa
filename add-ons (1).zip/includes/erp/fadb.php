<?php

global $fadb, $current_user, $selected_user, $Refs, $installed_languages, $db_connections;
require_once(FA_PATH.'config_db.php');

require_once(ABSPATH."includes/erp/fiscal_year.php"); 
require_once(ABSPATH."includes/erp/taxes/tax_calc.inc"); 
require_once(ABSPATH."includes/erp/references.inc"); 
require_once(ABSPATH."includes/erp/save_invoice.php"); 
require_once(ABSPATH."includes/erp/dashboard_additional.php"); 
require_once(ABSPATH."includes/erp/master_tables.php"); 

$Refs = new references();

$selected_user = $current_user = kv_get_current_user();
if(isset($_SESSION['Selected_User']) && $_SESSION['Selected_User'] > 0) {
	$selected_user_id = (int)$_SESSION['Selected_User'];
	$selected_user = get_user_details($selected_user_id);
}

function user_date_format(){
	global $SysPrefs;
	return isset($_SESSION["wa_current_user"]) ? $_SESSION["wa_current_user"]->prefs->date_format() : $SysPrefs->dflt_date_fmt;
}


if (!defined('TB_PREF')) {
	define('TB_PREF', '&TB_PREF&');
}

$transaction_level = 0;

function begin_transaction(){
	global $transaction_level;

	if (!$transaction_level) {
		fadb_query("BEGIN", "could not start a transaction");
	}
	$transaction_level++;
}

function commit_transaction(){
	global $transaction_level;

	$transaction_level--;

	if (!$transaction_level) {
		fadb_query("COMMIT", "could not commit a transaction");
	}
}

function count_array($array){
	return (is_array($array)) ? count($array) : (($array === NULL) ? 0 : 1);
}

/*
	This function is called on end of script execution to cancel
	all aborted transactions (if any)
*/
function cancel_transaction(){
	global $transaction_level;

	if ($transaction_level) {
		fadb_query("ROLLBACK", "could not cancel a transaction");	
	}
	$transaction_level = 0;
}

function has_company(){
	global $selected_user;
	$sql ="SELECT ID FROM ".TB_PREF."users WHERE name <> '' AND host <>'' AND dbname <> '' AND dbuser <>'' AND  ID=".$selected_user['ID'];
	$result = db_get_single_value($sql, "couldn't get all company details"); 	
	if($result > 0)
		return true;
	else
		return false;
}

if(logged_in() && has_company()){	
	$fadb = mysqli_connect(trim($selected_user['host']), trim($selected_user['dbuser']), $selected_user['dbpassword'], trim($selected_user['dbname']));
		
	if (mysqli_connect_errno()) {
		return mysqli_connect_error();
	}
	$result = mysqli_query($fadb, "SET sql_mode=''");
	mysqli_query($fadb, "SET NAMES 'utf8';");
    mysqli_query($fadb,"SET CHARACTER SET utf8");
				
	if(!$result && $err_msg != null ){       
		return $err_msg;
	}
} elseif(get_site_option('template') != 'pos' && get_site_option('template') != 'kot' && get_site_option('template') != 'poskot' ) {
	$conn = $db_connections[$def_coy];
	$fadb = mysqli_connect(trim($conn['host']), trim($conn['dbuser']), $conn['dbpassword'], trim($conn['dbname']));
		
	if (mysqli_connect_errno()) {
		return mysqli_connect_error();
	}
	$result = mysqli_query($fadb, "SET sql_mode=''");
	mysqli_query($fadb, "SET NAMES 'utf8';");
	$result = mysqli_query($fadb, "SET CHARACTER SET utf8");
				
	if(!$result && $err_msg != null ){       
		return $err_msg;
	}
	
}


function fadb_query($sql, $err_msg=null,$testing=false){
	global $fadb, $selected_user, $db_connections, $def_coy;
	if(get_site_option('template') != 'pos' && get_site_option('template') != 'kot' && get_site_option('template') != 'poskot' ) {
		$conn = $db_connections[$def_coy];
		$cur_prefix = $conn['dbname'].'.'.$conn['tbpref'];
	} else 
		$cur_prefix = $selected_user['dbname'].'.'.$selected_user['tbpref'];
	$sql = str_replace(TB_PREF, $cur_prefix, $sql);
	
	$result = mysqli_query($fadb, $sql);
	if($testing)
		echo $sql;
			
	if(!$result && $err_msg != null ){       
		echo mysqli_error($fadb);
		return false; 
	}
	return $result;	
}


function fadb_num_rows($result){	
	if($result != false)
			return mysqli_num_rows($result); }
function fadb_free_result($result){
	if ($result)
		mysqli_free_result($result);
}
function fadb_fetch_row ($result){	
	if($result != false)
		return mysqli_fetch_row($result);	}
function fadb_fetch_assoc ($result){ if($result != false)
		return mysqli_fetch_assoc($result);	}
function fadb_fetch ($result){	if($result != false)
		return mysqli_fetch_array($result, MYSQLI_ASSOC);	}
function fadb_fetch_array ($result){	if($result != false)
		return mysqli_fetch_array($result);	}
function fadb_insert_id()	{ global $fadb; return mysqli_insert_id($fadb); }
function fadb_escape($value = "", $nullify = false){	
	global $fadb;		
	$value = @html_entity_decode($value);
	$value = @htmlspecialchars($value);

		  	//reset default if second parameter is skipped
	$nullify = ($nullify === null) ? (false) : ($nullify);

		  	//check for null/unset/empty strings
	if ((!isset($value)) || (is_null($value)) || ($value === "")) {
		$value = ($nullify) ? ("NULL") : ("''");
	} else {
		if (is_string($value)) {
		      		//value is a string and should be quoted; determine best method based on available extensions
			if (function_exists('mysqli_real_escape_string')) {
				$value = "'" . mysqli_real_escape_string($fadb, $value) . "'";
			} else {
				$value = "'" . mysqli_escape_string($fadb, $value) . "'";
			}
		} else if (!is_numeric($value)) {
					//value is not a string nor numeric
			display_error("ERROR: incorrect data type send to sql query");
			echo '<br><br>';
			exit();
		}
	}
	return $value;
}



function admin_company_path() {
	global $current_user;
	$current_user = kv_get_current_user();
	$user_path = substr($current_user['tbpref'], 0, -1);
	return 'FA/company/'.$current_user['selected_id'];
}

function adminwig_company_path() {	
	return 'admin/company/0'; 
}

//if($current_user['username'] == 'kvvaradha14')
	//add_menu_item('Company Preference', 'company-preference', 'Company_preference_settings', array('Administrator'), 9);

function FAInsert($table_name, $data, $show_sql=false){
    $sql0 = "INSERT INTO ".TB_PREF.$table_name."(";
    $sql1 = " VALUES (";
    foreach($data as $key=>$value){
        $sql0 .= $key.",";
		if(is_array($value)) { 
			if($value[1] == 'date')				
				$sql1 .=  fadb_escape(date2sql($value[0])).",";
			if($value[1] == 'float')
				$sql1 .= $value.",";
            if($value[1] == 'noesc')
                $sql1 .= "'".$value[0]."',";
		}else 
			$sql1 .= fadb_escape($value).",";
    }
    $sql0 = substr($sql0, 0, -1).")";
    $sql1 = substr($sql1, 0, -1).")";
	fadb_query("SET CHARACTER SET utf8", "");
	fadb_query($sql0.$sql1, "Could not insert data to table {$table_name}", $show_sql);
	return  fadb_insert_id();
}

if(!function_exists('FADelete')) {
	function FADelete($table_name, $conditions){
		$sql0 = "DELETE FROM ".TB_PREF.$table_name." WHERE 1=1";
		foreach ($conditions as $key=>$value) {
			$sql0 .= " AND ".$key."=".$value;
		}
		$result = fadb_query($sql0, "Could not delete data from {$table_name}");
		return $result;
	}
}
if(!function_exists('FAUpdate')) {
	function FAUpdate($table_name, $primary_key, $data , $show_sql=false){

		if(kvcodesdb_Has_Data_on_Table($table_name, $primary_key)){
			$sql0 = "UPDATE ".TB_PREF.$table_name." SET ";
			foreach($data as $key=>$value){
				if(is_array($value)) { 
					if($value[1] == 'date')             
						$sql0 .= "`".$key."` = ". fadb_escape(date2sql($value[0])).",";
					if($value[1] == 'float')
						$sql0 .= "`".$key."` = ". $value.",";
					if($value[1] == 'noesc')
						$sql0 .= "`".$key."` = '". $value[0]."',";
				}else {
					$sql0 .= "`".$key."` = ".fadb_escape($value).",";
				}
			}
			$sql0 = substr($sql0, 0, -1);
			$sql0 .= " where 1=1";
			foreach($primary_key as $key=>$value){
				if(is_array($value)) { 
					if(isset($value[2]))
						$operator = $value[2];
					else
						$operator = '=';

					if($value[1] == 'date')             
						$sql0 .= " AND ".$key." ".$operator." ". fadb_escape(date2sql($value[0]));
					elseif($value[1] == 'float')
						$sql0 .= " AND ".$key." ".$operator." ". $value;
					else
						$sql0 .= " AND ".$key." ".$operator." ". fadb_escape($value[0]);
				}else{
					if(is_numeric($value)){
						$sql0 .=" AND ". $key." = ".$value;
					}else
					   $sql0 .= " AND ".$key." = ".fadb_escape($value);
				}
			}
		   return  fadb_query($sql0, "Could not update data on table {$table_name}", $show_sql);
		}else{
			foreach($primary_key as $key => $value){
				if($key != 'id')
					$data[$key] = $value;
			}
			return FAInsert($table_name, $data);
		}     
	}
}

if(!function_exists('kvcodesdb_Has_Data_on_Table')) {
	function kvcodesdb_Has_Data_on_Table($table_name, $primary_key =false){

		$sql = "SELECT COUNT(*) FROM ".TB_PREF.$table_name." WHERE 1=1";
		if($primary_key){
			foreach($primary_key as $key=>$value){
				if(is_array($value)) { 
					if($value[1] == 'date')             
						$sql .= " AND ".$key." = ". fadb_escape(date2sql($value[0])).",";
					if($value[1] == 'float')
						$sql .= " AND ".$key." = ". $value.",";
				}else{
					if(is_numeric($value)){
						$sql .=" AND ". $key." = ".$value;
					}else
					   $sql .= " AND ".$key." = ".fadb_escape($value);
				}
			}
		}
		return  kvcodes_check_empty_result($sql);
	}
}

function kvcodes_check_empty_result($sql) {
	$result = fadb_query($sql, "could not do check empty query");		
	$myrow = fadb_fetch_row($result);
	return $myrow[0] > 0;
}

if(!function_exists('FAGetSingleValue')) {
	function FAGetSingleValue($tablename, $column_single, $conditions=null, $order_by = null, $sql=false){
		$sql0 = "SELECT ".$column_single." FROM ".TB_PREF.$tablename." WHERE 1=1";
		if($conditions){
			foreach($conditions as $key=>$value){
				$sql0 .= " AND {$key} = '${value}'";
			}
		}		
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		//if($sql)
		//	return $sql0;
		$result = fadb_query($sql0, "could not get sales type", $sql);
		$row = fadb_fetch_row($result);
		return $row[0];
	}
}

if(!function_exists('FAGetAll')) {
	function FAGetAll($table_name, $conditions = null, $order_by = null, $limit=0, $page = 0){
		$sql0 = "SELECT * FROM ".TB_PREF.$table_name." WHERE 1=1";
		if($conditions != null) {
			foreach($conditions as $key=>$value){
				if(is_array($value)) { 
	                $sql0 .= " AND ".$key." ".$value[1]." ". fadb_escape($value[0]);
	            } else
	                $sql0 .= " AND {$key} =".fadb_escape($value);
				}
		}
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		if($limit>0){
			if($page > 0 ){
				$offset = ($page - 1)*$limit;				
				$sql0 .=" LIMIT ".$offset.", ".$limit;
			} else 
				$sql0 .=" LIMIT ".$limit;
		}
		$result = fadb_query($sql0, "Could not get data from {$table_name}");
		$data = array();
		while($row = fadb_fetch_assoc($result)) {
			$data[] = $row;
		}
		return $data;
	}
}


if(!function_exists('FAGetRow')) {
	function FAGetRow($table_name, $conditions = null, $order_by = null, $show_sql=false){
		$sql0 = "SELECT * FROM ".TB_PREF.$table_name." WHERE 1=1";
		if($conditions != null) {
			foreach($conditions as $key=>$value){
				$sql0 .= " AND {$key} = '${value}'";
			}
		}
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		$sql0 .= ' LIMIT 1'; 
		$result = fadb_query($sql0, "Could not get data from {$table_name}", $show_sql);
		$data = fadb_fetch($result);
		
		return $data;
	}
}

if(!function_exists('FAGetDataJoin')) {
	function FAGetDataJoin($main_table, $joins, $columns=array(), $conditions=null, $order_by = null, $single=false, $sql=false, $limit = 0, $page=0){
		$sql0 = "SELECT ";
		if(count($columns)>0){
			foreach ($columns as $value) {
				$sql0 .= $value.",";
			}
			$sql0 = substr($sql0, 0, -1);
		}else{
			$sql0 .= " *";
		}
		$sql0 .= " FROM ".TB_PREF."{$main_table} ";
		foreach ($joins as $value) {
			if(isset($value['join'])){
				$sql0 .= " {$value['join']} JOIN ".TB_PREF.$value['table_name'].' ON '.$value['conditions'];
			}else{
				$sql0 .= " INNER JOIN ".TB_PREF.$value['table_name'].' ON '.$value['conditions'];
			}
		}
		$sql0 .= " WHERE 1=1 ";
		if($conditions != null) {
			foreach($conditions as $key=>$value){
				if(is_array($value)){
					if($value[0] == 'OR')
						$sql0 .= " AND ({$key} = ".fadb_escape($value[1])." OR {$key} = ".fadb_escape($value[2])." )";
					else
						$sql0 .= " AND {$key} {$value[0]} ".fadb_escape($value[1]);
				} else 
					$sql0 .= " AND {$key} = ".fadb_escape($value);
			}
		}
		//echo $sql0;
		if($order_by != null) {
			$sql0 .=" ORDER BY ";
			foreach($order_by as $key=>$value){
				$sql0 .= " {$key} ${value}";
			}
		}
		if($single)
			$sql0 .= ' LIMIT 1'; 
		elseif($limit>0){
			if($page > 0 ){
				$offset = ($page - 1)*$limit;				
				$sql0 .=" LIMIT ".$offset.", ".$limit;
			} else 
				$sql0 .=" LIMIT ".$limit;
		}
		
		$result = fadb_query($sql0, "Could not get data!", $sql);
		if($single){
			$data = fadb_fetch($result);
		} else { 
			$data = array();
			while($row = fadb_fetch($result)) {
				$data[] = $row;
			}
		}
		
		return $data;
	}
}


require_once(ABSPATH."includes/erp/ajax.php"); 
//----------------------------------------------------------------------------------------------------
function get_tag_names($tags){
	$str = "";
	if ($tags == -1)
		return $str;
	
	if(!empty($tags) && is_array($tags)){
		foreach($tags as $id){
			$tag = get_tag_name($id);
			if ($str == "")
				$str .= $tag;
			else	
				$str .= ", ".$tag;
		}
	}
	//echo $str."srgsreg";
	return $str;
}


//--------------------------------------------------------------------------------------

function get_tag_name($id)
{
	$sql = "SELECT name FROM ".TB_PREF."tags WHERE id = ".db_escape($id);

	$result = fadb_query($sql, "could not get tag name");

	$row = fadb_fetch_assoc($result);
	return $row['name'];
}
//--------------------------------------------------------------------------------------
function is_record_in_tags($tags, $type, $recordid){
	foreach($tags as $id){
		$sql = "SELECT ta.record_id FROM ".TB_PREF."tag_associations AS ta 
				INNER JOIN ".TB_PREF."tags AS tags ON tags.id = ta.tag_id 
				WHERE tags.type = $type AND tags.id = $id AND ta.record_id = ".fadb_escape($recordid);
		$res = fadb_query($sql, "could not get tags associations for record");
		if (fadb_num_rows($res) == 0)
			return false;
	}
	return true;
}


//get invoice status
function get_invoice_status($type,$trans_no, $db=false){ 
	$today_date=sql2date(Today());	
	$type =  fadb_escape($type); 	
	$trans_no = fadb_escape($trans_no); 
	
	// $sql="SELECT 
 //  		trans.type, 
	// 	trans.trans_no, 
	// 	trans.order_,    
	// 	trans.reference,
	// 	trans.tran_date, 
	// 	trans.due_date, 
	// 	debtor.name, 
	// 	branch.br_name,
	// 	debtor.curr_code,
	// 	(trans.ov_amount + trans.ov_gst + trans.ov_freight  
	// 		+ trans.ov_freight_tax + trans.ov_discount)	AS TotalAmount, trans.alloc AS Allocated,
	// 	((trans.type = 10)
	// 		AND trans.due_date < '".$today_date."') AS OverDue ,
	// 	Sum(line.quantity-line.qty_done) AS Outstanding
	//  FROM ".TB_PREF."debtor_trans as trans
	// 		LEFT JOIN ".TB_PREF."debtor_trans_details as line
	// 			ON trans.trans_no= line.debtor_trans_no AND trans.type=line.debtor_trans_type,".TB_PREF."debtors_master as debtor, ".TB_PREF."cust_branch as branch
	//   WHERE (trans.type =".$type."  AND trans.trans_no=".$trans_no.")  GROUP BY trans.trans_no, trans.type LIMIT 1" ;
		

		$sql="SELECT trans.due_date, (trans.ov_amount + trans.ov_gst + trans.ov_freight  
			+ trans.ov_freight_tax + trans.ov_discount)	AS TotalAmount, trans.alloc AS Allocated,
		((trans.type = 10 OR trans.type = 0 )
			AND trans.due_date < '".$today_date."') AS OverDue ,
		Sum(line.quantity-line.qty_done) AS Outstanding
	 FROM ".TB_PREF."debtor_trans as trans
			LEFT JOIN ".TB_PREF."debtor_trans_details as line
				ON trans.trans_no= line.debtor_trans_no AND trans.type=line.debtor_trans_type,".TB_PREF."debtors_master as debtor, ".TB_PREF."cust_branch as branch
	  WHERE (trans.type =".$type."  AND trans.trans_no=".$trans_no.")  GROUP BY trans.trans_no, trans.type LIMIT 1" ;


	$result1 = fadb_query($sql, "cannot retrieve");
			//print_r($result);
	$status='';

	while($result=fadb_fetch($result1)){
			$total_amount=round($result['TotalAmount'], 2);
			$allo_status=round($result['Allocated'], 2);
			$date1 = $result['due_date'];
			$date2=date('Y-m-d');
			if($total_amount!=0){
				if ($date1 < $today_date){
					$left = abs($total_amount)-($allo_status);	
					if($total_amount==$allo_status || $left < 0.1){
						if(HasCreditNoteExsit($trans_no))
							$status='Credited';
						else
							$status='Received';
					}
					else
						$status='Overdue';
				}elseif($allo_status==0)
					$status='Yet To Receive'; 
				elseif($allo_status!=0){
					$left = abs($total_amount)-($allo_status);	
					if($total_amount==$allo_status || $left < 0.1){
						if(HasCreditNoteExsit($trans_no))
							$status='Credited';
						else
							$status='Received';
					} else
						$status='Partially Received';
				}
			} else
				$status='Void';	
		
	}
	return $status;
}	

function HasCreditNoteExsit($trans_no){
	$return = fadb_query("SELECT COUNT(*) AS Total FROM ".TB_PREF."cust_allocations WHERE trans_type_from = 11 AND trans_type_to = 10 AND trans_no_to = ".fadb_escape($trans_no), "can't get creditnote");
	if(fadb_num_rows($return) > 0 ){	
		$row = fadb_fetch_assoc($return);	
		if($row['Total'] > 0 )
			return 1;
		else
			return 0;
	}
	else
		return 0 ;
}


function Kvcodes_get_customer_trans($trans_id, $trans_type, $customer_id=null, $db=false) {
	
	$trans_type =  fadb_escape($trans_type); 	
	$trans_id = fadb_escape($trans_id); 		
	$customer_id = fadb_escape($customer_id); 
	
	$sql = "SELECT trans.*, trans.salesman as SalesMen, "
		."ov_amount+ov_gst+ov_freight+ov_freight_tax+ov_discount AS Total,"
		."cust.name AS DebtorName, cust.address, "
		."cust.curr_code, "
		."cust.tax_id,
		trans.prep_amount>0 as prepaid,"
		."com.memo_";

	if ($trans_type == ST_CUSTPAYMENT || $trans_type == ST_BANKDEPOSIT) {
		// it's a payment so also get the bank account
		$sql .= ",bank_act,".TB_PREF."bank_accounts.bank_name, ".TB_PREF."bank_accounts.bank_account_name,
			".TB_PREF."bank_accounts.account_type AS BankTransType,
			".TB_PREF."bank_accounts.bank_curr_code,
			".TB_PREF."bank_trans.amount as bank_amount";
	}

	if ($trans_type == ST_SALESINVOICE || $trans_type == ST_CUSTCREDIT || $trans_type == ST_CUSTDELIVERY) {
		// it's an invoice so also get the shipper and salestype
		$sql .= ", ".TB_PREF."shippers.shipper_name, "
		.TB_PREF."sales_types.sales_type, "
		.TB_PREF."sales_types.tax_included, "
		."branch.*, "
		."cust.discount, "
		.TB_PREF."tax_groups.name AS tax_group_name, "
		.TB_PREF."tax_groups.id AS tax_group_id ";
	}

	if ($trans_type == ST_JOURNAL) {
		$sql .= ", branch.*";
	}

	$sql .= " FROM ".TB_PREF."debtor_trans trans
					LEFT JOIN ".TB_PREF."comments com ON trans.type=com.type AND trans.trans_no=com.id
					LEFT JOIN ".TB_PREF."shippers ON ".TB_PREF."shippers.shipper_id=trans.ship_via, 
					".TB_PREF."debtors_master cust";

	if ($trans_type == ST_CUSTPAYMENT || $trans_type == ST_BANKDEPOSIT) {
		// it's a payment so also get the bank account
		$sql .= ", ".TB_PREF."bank_trans, ".TB_PREF."bank_accounts";
	}

	if ($trans_type == ST_SALESINVOICE || $trans_type == ST_CUSTCREDIT || $trans_type == ST_CUSTDELIVERY) {
		// it's an invoice so also get the shipper, salestypes
		$sql .= ", ".TB_PREF."sales_types, "
		.TB_PREF."cust_branch branch, "
		.TB_PREF."tax_groups ";
	}

	if ($trans_type == ST_JOURNAL) {
		$sql .= ", ".TB_PREF."cust_branch branch ";
	}
	$sql .= " WHERE trans.trans_no=".$trans_id." AND trans.type=".$trans_type." AND trans.debtor_no=cust.debtor_no";

	//if (isset($customer_id))
		//$sql .= " AND trans.debtor_no=".$customer_id;

	if ($trans_type == ST_CUSTPAYMENT || $trans_type == ST_BANKDEPOSIT) {
		// it's a payment so also get the bank account
		$sql .= " AND ".TB_PREF."bank_trans.trans_no =".$trans_id."
			AND ".TB_PREF."bank_trans.type=$trans_type
			AND ".TB_PREF."bank_trans.amount != 0
			AND ".TB_PREF."bank_accounts.id=".TB_PREF."bank_trans.bank_act ";
	}
	if ($trans_type == ST_SALESINVOICE || $trans_type == ST_CUSTCREDIT || $trans_type == ST_CUSTDELIVERY) {
		// it's an invoice so also get the shipper
		$sql .= " AND ".TB_PREF."sales_types.id = trans.tpe
			AND branch.branch_code = trans.branch_code
			AND branch.tax_group_id = ".TB_PREF."tax_groups.id ";
	}
	if ($trans_type == ST_JOURNAL) {
		$sql .= " AND branch.branch_code = trans.branch_code ";
	}
	
		$result = fadb_query($sql, "Cannot retreive a debtor transaction");
		if (fadb_num_rows($result) == 0) {
			echo "no debtor trans found for given params";
			exit;
		}
		if (fadb_num_rows($result) > 1) {
			echo "duplicate debtor transactions found for given params";
			exit;
		}
	
	return fadb_fetch($result);
}

function Kvcodes_get_default_bank_account($curr=null, $db=false){

	$home_curr = get_company_details('curr_default');
	if (!isset($curr))
		$curr = $home_curr;
	
	$curr = fadb_escape($curr);
	
	$sql = "SELECT b.*, b.bank_curr_code='$home_curr' as fall_back FROM ".TB_PREF."bank_accounts b WHERE b.bank_curr_code=".$curr." OR b.bank_curr_code='$home_curr'
		ORDER BY fall_back, dflt_curr_act desc";
	$result = fadb_query($sql, "could not retreive default bank account");
	return fadb_fetch($result);
}

function Kvcodes_get_branch($branch_id, $db=false){
	$branch_id =  fadb_escape($branch_id);
	$sql = "SELECT branch.*, salesman.salesman_name FROM ".TB_PREF."cust_branch branch,".TB_PREF."salesman salesman	WHERE branch.salesman=salesman.salesman_code 
			AND branch_code=".$branch_id;
	$result = fadb_query($sql, "Cannot retreive a customer branch");
	return fadb_fetch($result);
}

function get_supplier_total_amount($trans_no, $db=false){
	global $selected_user, $fadb;
	$sql = "SELECT (trans.ov_amount + trans.ov_gst  + trans.ov_discount) AS TotalAmount FROM ".TB_PREF."supp_trans as trans WHERE trans.trans_no=".$trans_no." AND trans.type=20"; 
	$res = fadb_query($sql);
	
	if($result = fadb_fetch($res)) {
		return $result['TotalAmount'];
	} else
		return 0;
}

function get_total_Amount($trans_no, $type=false){
	global $selected_user;
	if($type == false)
		$type = 10;
	$sql = "SELECT (trans.ov_amount + trans.ov_gst + trans.ov_freight + trans.ov_freight_tax + trans.ov_discount)	AS TotalAmount 
	FROM ".TB_PREF."debtor_trans as trans WHERE trans.trans_no=".$trans_no." AND trans.type=".$type; 
	
	$res = fadb_query($sql);
	if($result = fadb_fetch($res)) {
		return $result['TotalAmount'];
	} else
		return 0;
}

function Kvcodes_invoice_status($limit=5,$type=null,$trans_no=null){ 
	global $selected_user;
	$debtor_id  = get_user_meta($selected_user['ID'], 'admin_customer_id');
	$f_year = get_current_fiscalyear();
	$begin1 = $f_year['begin'];
	$today_date=sql2date(Today());
	$sql="SELECT 
  		trans.type, 
		trans.trans_no, 
		trans.order_, 
		trans.reference,
		trans.tran_date, 
		trans.due_date, 
		debtor.name, 
		branch.br_name,
		debtor.curr_code,
		debtor.debtor_no,
		IF(prep_amount, prep_amount, trans.ov_amount + trans.ov_gst + trans.ov_freight 
			+ trans.ov_freight_tax + trans.ov_discount)	AS TotalAmount, trans.alloc AS Allocated,
		((trans.type = 10 || trans.type = 0)
			AND trans.due_date < '".$today_date."') AS OverDue ,
		Sum(line.quantity-line.qty_done) AS Outstanding,
		Sum(line.qty_done) AS HasChild,
		prep_amount
	 FROM ".TB_PREF."debtor_trans as trans
			LEFT JOIN ".TB_PREF."debtor_trans_details as line
				ON trans.trans_no=line.debtor_trans_no AND trans.type=line.debtor_trans_type
			LEFT JOIN ".TB_PREF."voided as v
				ON trans.trans_no=v.id AND trans.type=v.type
                        LEFT JOIN ".TB_PREF."audit_trail as audit ON (trans.type=audit.type AND trans.trans_no=audit.trans_no)
                        LEFT JOIN ".TB_PREF."users as user ON (audit.user=user.id)
			LEFT JOIN ".TB_PREF."cust_branch as branch ON trans.branch_code=branch.branch_code,".TB_PREF."debtors_master as debtor
	  WHERE (debtor.debtor_no = trans.debtor_no
			AND trans.tran_date >= '".$begin1."'
			AND trans.tran_date <= '".$today_date."' AND ISNULL(v.date_) AND (trans.ov_amount + trans.ov_gst + trans.ov_freight + trans.ov_freight_tax + trans.ov_discount) != 0 AND trans.debtor_no = '".$debtor_id."') AND (trans.type = 10)  GROUP BY trans.trans_no, trans.type ORDER BY trans.trans_no DESC LIMIT ".$limit;
			//(trans.type =".db_escape($type)."  AND trans.trans_no=".db_escape($trans_no).") AND
	//$res = fadb_query($sql, "cannot retrieve");
			//print_r($result);
	
	$res = fadb_query($sql);
	$status='';
	$final_text = array();
	while($result = fadb_fetch($res)) {
		//print_r($result);
		$total_amount=round($result['TotalAmount']);
		$allo_status=round($result['Allocated']); 
		$date1 = $result['due_date'];
		$date2=date('Y-m-d');
		if($total_amount!=0){			
				if($allo_status==0){
					if ($date1 < $date2)
						$status=' Overdue';
					else
						$status='Yet to Pay'; 
				}elseif($allo_status!=0){
					if($total_amount==$allo_status)
						$status='Paid';
					elseif($total_amount>$allo_status){
						if ($date1 < $date2)
							$status=' Overdue';
						else
						$status='Partiallypaid';
					}else{
						if($total_amount == $allo_status)
							$status = 'Paid';
						else
							$status = 'Overdue';
					}
				}
			}else
				$status='Void';
		$result['status'] = $status;
		$final_text[] =  $result;
	}
	//print_r($final_text);
	return $final_text;
}

//----------------------------------------------------------------------------------------

function Kvcodes_get_customer_trans_details($debtor_trans_type, $debtor_trans_no){
if (!is_array($debtor_trans_no))
	$debtor_trans_no = array( 0=>$debtor_trans_no );
	fadb_query("SET NAMES UTF8", '');
	fadb_query("SET CHARACTER SET utf8;");
	fadb_query("SET collation_connection = utf8_unicode_ci;");
	$sql = "SELECT line.*,line.unit_price+line.unit_tax AS FullUnitPrice,line.description As StockDescription,	item.units, item.mb_flag FROM ".TB_PREF."debtor_trans_details line,".TB_PREF."stock_master item	WHERE (";

	$tr=array();
	foreach ($debtor_trans_no as $trans_no){		
			$tr[] = 'debtor_trans_no='.fadb_escape($trans_no);
	}
	$sql .= implode(' OR ', $tr);
	$sql.=	") AND debtor_trans_type=". fadb_escape($debtor_trans_type)." AND item.stock_id=line.stock_id ORDER BY id";
	
	return fadb_query($sql, "The debtor transaction detail could not be queried");
}

function Kvcodes_get_customer_order_details($debtor_trans_type, $order_no){
	
	$sql = "SELECT * FROM ".TB_PREF."sales_order_details where order_no = ".$order_no;
	// $tr=array();
	// foreach ($order_no as $ord){		
	// 		$tr[] = 'order_no='.fadb_escape($ord);
	// }
	// $sql .= $tr;
	return fadb_query($sql, "Oder details not quired");
}

function Kvcodes_get_trans_tax_details($trans_type, $trans_no,$db=false){
	$sql = "SELECT tax_details.*,
				tax_type.name AS tax_type_name,
				tax_details.rate AS effective_rate,
				tax_type.rate AS rate
		FROM ".TB_PREF."trans_tax_details tax_details,
			".TB_PREF."tax_types tax_type
		WHERE 
			trans_type = ".($db ? fadb_escape($trans_type) : fadb_escape($trans_type))."
		AND trans_no = ".($db ? fadb_escape($trans_no) : fadb_escape($trans_no) )."
		AND (net_amount != 0 OR amount != 0)
		AND tax_type.id = tax_details.tax_type_id";
		//echo $sql;
	return fadb_query($sql, "The transaction tax details could not be retrieved");
}

function Kvcodes_get_sales_order_header($order_no, $trans_type,$db=false){
	
	$order_no =  fadb_escape($order_no); 
	$trans_type = fadb_escape($trans_type);
		
	$sql = "SELECT sorder.*,
	  cust.name,
	  cust.name AS DebtorName,
	  cust.curr_code,
	  cust.address,
	  loc.location_name,
	  cust.discount,
	  stype.sales_type,
	  stype.id AS sales_type_id,
	  stype.tax_included,
	  stype.factor,
 	  ship.shipper_name,
	  tax_group.name AS tax_group_name,
	  tax_group.id AS tax_group_id,
	  cust.tax_id,
	  sorder.alloc,
	  IFNULL(allocs.ord_allocs, 0)+IFNULL(inv.inv_allocs ,0) AS sum_paid,
	  sorder.prep_amount>0 as prepaid
	FROM ".TB_PREF."sales_orders sorder
			LEFT JOIN (SELECT trans_no_to, sum(amt) ord_allocs FROM ".TB_PREF."cust_allocations
				WHERE trans_type_to=".ST_SALESORDER." AND trans_no_to=".$order_no." GROUP BY trans_no_to)
				 allocs ON sorder.trans_type=".ST_SALESORDER." AND allocs.trans_no_to=sorder.order_no
			LEFT JOIN (SELECT order_, sum(alloc) inv_allocs FROM ".TB_PREF."debtor_trans 
				WHERE type=".ST_SALESINVOICE." AND order_=".$order_no."  GROUP BY order_)
				 inv ON sorder.trans_type=".ST_SALESORDER." AND inv.order_=sorder.order_no
			LEFT JOIN ".TB_PREF."shippers ship ON  ship.shipper_id = sorder.ship_via,"
	  .TB_PREF."debtors_master cust,"
	  .TB_PREF."sales_types stype, "
	  .TB_PREF."tax_groups tax_group, "
	  .TB_PREF."cust_branch branch,"
	  .TB_PREF."locations loc
	WHERE sorder.order_type=stype.id
		AND branch.branch_code = sorder.branch_code
		AND branch.tax_group_id = tax_group.id
		AND sorder.debtor_no = cust.debtor_no
		AND loc.loc_code = sorder.from_stk_loc
		AND sorder.trans_type = " . $trans_type ."
		AND sorder.order_no = " . $order_no;
	//echo $sql;
		$result = fadb_query($sql, "order Retreival");
	
		$num = fadb_num_rows($result);
	if ($num > 1){
		display_warning("You have duplicate document in database: (type:$trans_type, number:$order_no).");
	}
	else if ($num == 1){
		return fadb_fetch($result);
	}
	else
		display_warning("You have missing or invalid sales document in database (type:$trans_type, number:$order_no).");
}

/*
	Returns array of all issued invoices to sales order $order_no, optinally up to trans_no==$up_to
*/
function Kvcodes_get_sales_order_invoices($order_no, $db=false){
	$sql = "SELECT trans_no, dt.type as type, tran_date, reference, prep_amount
	    FROM ".TB_PREF."debtor_trans dt
		LEFT JOIN ".TB_PREF."voided v ON v.type=dt.type AND v.id=dt.trans_no
		WHERE ISNULL(v.id) AND dt.type=".ST_SALESINVOICE." AND dt.order_=".($db? fadb_escape($order_no): fadb_escape($order_no))
		." ORDER BY dt.tran_date, dt.reference, dt.trans_no";
	return fadb_query($sql, "cannot retrieve sales invoices for sales order");
}


function Kvcodes_get_branch_contacts($branch_code, $action=null, $customer_id=null, $default = true, $db=false){
	$defs = array('cust_branch.'.$action, 
				'customer.'.$action,
				'cust_branch.general',
				'customer.general');

	$sql = "SELECT p.*, r.action, r.type, CONCAT(r.type,'.',r.action) as ext_type FROM ".TB_PREF."crm_persons p,".TB_PREF."crm_contacts r	WHERE r.person_id=p.id AND ((r.type='cust_branch' 
			AND r.entity_id=".($db ? fadb_escape($branch_code) : fadb_escape($branch_code)).')';
	if($customer_id) {
		$sql .= " OR (r.type='customer' AND r.entity_id=".($db ? fadb_escape($customer_id) : fadb_escape($customer_id)).")";
	}
	$sql .= ')';
	
	if ($action)
		$sql .= ' AND (r.action='.($db ? fadb_escape($action) : fadb_escape($action)).($default ? " OR r.action='general'" : '').')';
	
	$results = array();
	
	
	$res = fadb_query($sql, "can't retrieve branch contacts");
	while($contact = fadb_fetch($res))
		$results[] = $contact;
	

	if ($results && $default) {  // select first available contact in $defs order
		foreach($defs as $type) {
			if ($n = array_search_value($type, $results, 'ext_type')){
				return $n;
			}
		}
		return null;
	}
	return $results;
}

function Kvcodes_get_comments_string($type, $type_id, $db=false){
	
	$type =  fadb_escape($type); 
	$type_id = fadb_escape($type_id);	
		
	$str_return = "";
	$sql = "SELECT * FROM ".TB_PREF."comments WHERE type=".$type." AND id=".$type_id;
	
	$result = fadb_query($sql, "could not query comments transaction table");	
	while ($comment = fadb_fetch($result)){
		if (strlen($str_return))
			$str_return = $str_return . " \n";
		$str_return = $str_return . $comment["memo_"];
	}
		
	return $str_return;
}


function get_payment_terms($selected_id){
	$sql = "SELECT *, (t.days_before_due=0) AND (t.day_in_following_month=0) as cash_sale
	 FROM ".TB_PREF."payment_terms t WHERE terms_indicator=".fadb_escape($selected_id);

	$result = fadb_query($sql,"could not get payment term");
	return fadb_fetch($result);
}

function get_sales_parent_numbers($trans_type, $trans_no){
	$trans = array();
	$res = get_sales_parent_lines($trans_type, $trans_no, false);
	while ($line = fadb_fetch($res))
		$trans[] = $line[$trans_type==ST_CUSTDELIVERY ? 'order_no' : 'debtor_trans_no'];
	return $trans;
}

function get_sales_parent_lines($trans_type, $trans_no, $lines=true){
	$partype = get_parent_type($trans_type);

	if (!$partype)
		return false;

	$par_tbl = $partype == ST_SALESORDER ? "sales_order_details" : "debtor_trans_details";
	$par_no = $partype == ST_SALESORDER ? "parent.order_no" : "parent.debtor_trans_no";
	$sql = "SELECT parent.*
			FROM
				".TB_PREF."$par_tbl parent
			LEFT JOIN ".TB_PREF."debtor_trans_details trans 
				ON trans.src_id=parent.id
			WHERE
				trans.debtor_trans_type=".fadb_escape($trans_type)
				." AND trans.debtor_trans_no=".fadb_escape($trans_no);
	if (!$lines)
		$sql .= " GROUP BY $par_no";
	
	$sql .= " ORDER BY $par_no";
	
	return fadb_query($sql, "can't retrieve child trans");

}
/*
	Find oldest delivery date for sales invoice
*/
function get_oldest_delivery_date($invoice_no, $db =false){
	if($db)
		$invoice_no =  fadb_escape($invoice_no);
	else
		$invoice_no = fadb_escape($invoice_no);
	$sql = "SELECT MIN(trans.tran_date)	FROM ".TB_PREF."debtor_trans_details del LEFT JOIN ".TB_PREF."debtor_trans_details inv	ON inv.src_id=del.id
			LEFT JOIN ".TB_PREF."debtor_trans trans ON trans.type=".ST_CUSTDELIVERY." AND trans.trans_no = del.debtor_trans_no	WHERE
				inv.debtor_trans_type=".ST_SALESINVOICE	." AND inv.debtor_trans_no=".$invoice_no;
	
	$res = fadb_query($sql, 'cannot find oldest delivery date');
	$date = fadb_fetch_row($res);
	
	//print_r($date);
	return $date[0];
}

// and get_qty_dec
function get_qty_dec($stock_id=null){	
	if ($stock_id != null)
		$dec = get_unit_dec($stock_id);
	if ($stock_id == null || $dec == -1 || $dec == null)
		$dec = user_qty_dec();
	return $dec;
}

function get_unit_dec($stock_id){
	$sql = "SELECT decimals FROM ".TB_PREF."item_units,	".TB_PREF."stock_master
		WHERE abbr=units AND stock_id=".fadb_escape($stock_id)." LIMIT 1";
	$result = fadb_query($sql, "could not get unit decimals");

	$row = fadb_fetch_row($result);
	return $row[0];
}

function user_qty_dec(){
	return 2;
}
function is_service($mb_flag){
	return ($mb_flag == 'D');
}

//--------------------------------------------------------------------------------------
//
//	Simple English version of number to words conversion.
//
function _number_to_words($number) 
{ 
    $Bn = floor($number / 1000000000); /* Billions (giga) */ 
    $number -= $Bn * 1000000000; 
    $Gn = floor($number / 1000000);  /* Millions (mega) */ 
    $number -= $Gn * 1000000; 
    $kn = floor($number / 1000);     /* Thousands (kilo) */ 
    $number -= $kn * 1000; 
    $Hn = floor($number / 100);      /* Hundreds (hecto) */ 
    $number -= $Hn * 100; 
    $Dn = floor($number / 10);       /* Tens (deca) */ 
    $n = $number % 10;               /* Ones */

    $res = ""; 

    if ($Bn) 
        $res .= _number_to_words($Bn) . " Billion"; 
    if ($Gn) 
        $res .= (empty($res) ? "" : " ") . _number_to_words($Gn) . " Million"; 
    if ($kn) 
        $res .= (empty($res) ? "" : " ") . _number_to_words($kn) . " Thousand"; 
    if ($Hn) 
        $res .= (empty($res) ? "" : " ") . _number_to_words($Hn) . " Hundred"; 

    $ones = array("", "One", "Two", "Three", "Four", "Five", "Six", 
        "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", 
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", 
        "Nineteen"); 
    $tens = array("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", 
        "Seventy", "Eighty", "Ninety"); 

    if ($Dn || $n) 
    { 
        if (!empty($res)) 
            $res .= " and "; 
        if ($Dn < 2) 
            $res .= $ones[$Dn * 10 + $n]; 
        else 
        { 
            $res .= $tens[$Dn]; 
            if ($n) 
                $res .= "-" . $ones[$n]; 
        } 
    } 

    if (empty($res)) 
        $res = "zero"; 
    return $res; 
} 

function price_in_words($amount, $doc_type){
	
	// Only usefor Remittance and Receipts as default
	if (!($document == ST_SUPPAYMENT || $document == ST_CUSTPAYMENT || $document == ST_CHEQUE))
		return "";
	if ($amount < 0 || $amount > 999999999999)
		return "";
	$dec = user_price_dec();
	if ($dec > 0)
	{
		$divisor = pow(10, $dec);
        $frac = round2($amount - floor($amount), $dec) * $divisor;
		$frac = sprintf("%0{$dec}d", round2($frac, 0));
		$and = _("and");
    	$frac = " $and $frac/$divisor";
    }
    else
    	$frac = "";
    return _number_to_words(intval($amount)) . $frac;	
}
