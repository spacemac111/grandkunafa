<?php 

function Get_All_Auditors(){
	return GetAll('users', array('role' => 'Auditor'));
}
function get_company_auditors(){
	global $current_user;
	$company_auditors = array(); 
	$all_auditors = Get_All_Auditors();
	foreach($all_auditors as $auditor){
		$auditing_company = get_user_meta($auditor['ID'], 'auditing_company');
		if(in_array($current_user['ID'] , $auditing_company)){
			$company_auditors[] = $auditor['ID'];
		}
	}
	return $company_auditors;
}
		 //mysqli_query($con,"SELECT * FROM Persons");}
function get_reference($type, $trans_no=0, $ref=null){
	$db_info = get_systype_db_info($type);
		$trans_table = $db_info[0];
		$type_fld = $db_info[1];
		$tno_fld = $db_info[2];
		$ref_fld = $db_info[3];

		$type = fadb_escape($type);

		$sql = "SELECT `$ref_fld` 
				FROM `$trans_table` tbl
					LEFT JOIN ".TB_PREF."voided v ON 
				tbl.`$tno_fld`=v.id AND v.type=$type"
			." WHERE ISNULL(v.id)"
			.($type_fld ? " AND tbl.`$type_fld`=$type" : '');
		if ($ref){
			$sql .= " AND tbl.`$ref_fld`=".fadb_escape(trim($ref));
			if ($trans_no)
				$sql .= " AND tbl.`$tno_fld` != ".fadb_escape($trans_no);
		} else {
			$sql .= " AND tbl.`$tno_fld`=".fadb_escape($trans_no);
		}

		$result = fadb_query($sql, "could not test for unique reference");
		if (!$result)
			return false;

		$result = fadb_fetch_row($result);
		return $result[0];
}


function get_pdf_templates_list(){
	$list = ['A6' => 'A6', 'A6D' => 'A6 Detailed', 'A7' => 'A7','A7D' => 'A7 Detailed', 'A8' => 'A8',/* 'A4' => 'A4'*/];
	// foreach(glob(ABSPATH.'/includes/reporting/forms/*', GLOB_ONLYDIR) as $dir) {	
	// 	$dir_name = basename($dir);	
	// 	$list[$dir_name] = $dir_name; 
	// }
	return $list;
}

//Supplier Over Due Invoices
function Purchase_Overdue_invoices(){
   	$today = date('Y-m-d');

	$sql_pre = "SET sql_mode='';";
	fadb_query($sql_pre, "Can't Set Mode");
    $sql = "SELECT trans.trans_no, trans.reference, trans.tran_date, trans.due_date, s.supplier_id, 
        s.supp_name, s.curr_code,
        (trans.ov_amount + trans.ov_gst + trans.ov_discount) AS total,  
        (trans.ov_amount + trans.ov_gst + trans.ov_discount - trans.alloc) AS remainder,
        DATEDIFF('$today', trans.due_date) AS days  
        FROM ".TB_PREF."supp_trans as trans, ".TB_PREF."suppliers as s 
        WHERE s.supplier_id = trans.supplier_id
            AND trans.type = ".ST_SUPPINVOICE." AND (ABS(trans.ov_amount + trans.ov_gst + 
                trans.ov_discount) - trans.alloc) > ".FLOAT_COMP_DELTA."
            AND DATEDIFF('$today', trans.due_date) > 0 ORDER BY days DESC";
    $result = fadb_query($sql, "Transactions could not be calculated");
	//print_r($result);
	$final= array();
	$total = 0;
	while($row = fadb_fetch_assoc($result)){		
		$final[] = $row;
	}	
	return $final;
}
	
function Sales_Overdue_invoices(){
	$today = date('Y-m-d');
	$sql_pre = "SET sql_mode='';";
	fadb_query($sql_pre, "Can't Set Mode");
	$sql = "SELECT trans.trans_no, trans.reference, trans.tran_date, trans.due_date, debtor.debtor_no, 
        debtor.name, branch.br_name, debtor.curr_code,
        (trans.ov_amount + trans.ov_gst + trans.ov_freight 
            + trans.ov_freight_tax + trans.ov_discount) AS total,  
        (trans.ov_amount + trans.ov_gst + trans.ov_freight 
            + trans.ov_freight_tax + trans.ov_discount - trans.alloc) AS remainder,
        DATEDIFF('$today', trans.due_date) AS days  
        FROM ".TB_PREF."debtor_trans as trans, ".TB_PREF."debtors_master as debtor, 
            ".TB_PREF."cust_branch as branch
        WHERE debtor.debtor_no = trans.debtor_no AND trans.branch_code = branch.branch_code
            AND trans.type = ".ST_SALESINVOICE."  ORDER BY trans.trans_no DESC";  //AND (trans.ov_amount + trans.ov_gst + trans.ov_freight        + trans.ov_freight_tax + trans.ov_discount - trans.alloc) > ".FLOAT_COMP_DELTA."        AND DATEDIFF('$today', trans.due_date) > 0 ORDER BY days DESC

	$result = fadb_query($sql, "Transactions could not be calculated");
	$final= array();
	$total = 0;
	while($row = fadb_fetch_assoc($result)){
		$final[] = $row;
	}	
	return $final;
}

//Bank Account balances Table
function Bank_Account_Balance(){
	$today = date('Y-m-d');
	$sql = "SELECT bank_act, bank_account_name, bank_curr_code, SUM(amount) balance FROM ".TB_PREF."bank_trans bt 
                INNER JOIN ".TB_PREF."bank_accounts ba ON bt.bank_act = ba.id    WHERE trans_date <= '$today'  AND inactive <> 1    GROUP BY bank_act, bank_account_name    ORDER BY bank_account_name";
	$result = fadb_query($sql, "Transactions could not be calculated");

	$final= array();
	$total = 0;
	while($row = fadb_fetch_assoc($result)){		
		$final[] = $row;
	}	
	return $final;
}

function get_branch_to_order($customer_id, $branch_id) {

 	$sql = "SELECT branch.br_name,
					branch.br_address,
					branch.br_post_address,
					default_location, location_name, default_ship_via,
					tax_group.name AS tax_group_name,
					tax_group.id AS tax_group_id
				FROM ".TB_PREF."cust_branch branch,"
			  		.TB_PREF."tax_groups tax_group,"
			  		.TB_PREF."locations location
			WHERE branch.tax_group_id = tax_group.id
				AND location.loc_code=default_location
				AND branch.branch_code=".db_escape($branch_id)."
				AND branch.debtor_no=".db_escape($customer_id);

	return db_query($sql,"Customer Branch Record Retreive");
}

//-----------------------------------------------------------------------------
function get_systype_db_info($type){
	
	switch ($type)	{
        case     ST_JOURNAL      : return array(TB_PREF."journal", "type", "trans_no", "reference", "tran_date");
        case     ST_BANKPAYMENT  : return array(TB_PREF."bank_trans", "type", "trans_no", "ref", "trans_date");
        case     ST_BANKDEPOSIT  : return array(TB_PREF."bank_trans", "type", "trans_no", "ref", "trans_date");
        case     3               : return null;
        case     ST_BANKTRANSFER : return array(TB_PREF."bank_trans", "type", "trans_no", "ref", "trans_date");
        case     ST_SALESINVOICE : return array(TB_PREF."debtor_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_CUSTCREDIT   : return array(TB_PREF."debtor_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_CUSTPAYMENT  : return array(TB_PREF."debtor_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_CUSTDELIVERY : return array(TB_PREF."debtor_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_LOCTRANSFER  : return array(TB_PREF."stock_moves", "type", "trans_no", "reference", "tran_date");
        case     ST_INVADJUST    : return array(TB_PREF."stock_moves", "type", "trans_no", "reference", "tran_date");
        case     ST_PURCHORDER   : return array(TB_PREF."purch_orders", null, "order_no", "reference", "ord_date");
        case     ST_SUPPINVOICE  : return array(TB_PREF."supp_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_SUPPCREDIT   : return array(TB_PREF."supp_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_SUPPAYMENT   : return array(TB_PREF."supp_trans", "type", "trans_no", "reference", "tran_date");
        case     ST_SUPPRECEIVE  : return array(TB_PREF."grn_batch", null, "id", "reference", "delivery_date");
        case     ST_WORKORDER    : return array(TB_PREF."workorders", null, "id", "wo_ref", "released_date");
        case     ST_MANUISSUE    : return array(TB_PREF."wo_issues", null, "issue_no", "reference", "issue_date");
        case     ST_MANURECEIVE  : return array(TB_PREF."wo_manufacture", null, "id", "reference", "date_");
        case     ST_SALESORDER   : return array(TB_PREF."sales_orders", "trans_type", "order_no", "reference", "ord_date");
        case     31              : return array(TB_PREF."service_orders", null, "order_no", "cust_ref", "date");
        case     ST_SALESQUOTE   : return array(TB_PREF."sales_orders", "trans_type", "order_no", "reference", "ord_date");
        case	 ST_DIMENSION    : return array(TB_PREF."dimensions", null, "id", "reference", "date_");
        case     ST_COSTUPDATE   : return array(TB_PREF."journal", "type", "trans_no", "reference", "tran_date");
	}
	display_db_error("invalid type ($type) sent to get_systype_db_info", "", true);
}


function add_customer($CustName, $cust_ref, $address, $tax_id, $curr_code,$dimension_id, $dimension2_id, $credit_status, $payment_terms, $discount, $pymt_discount, $credit_limit, $sales_type, $notes){
	$sql = "INSERT INTO ".TB_PREF."debtors_master (name, debtor_ref, address, tax_id,
		dimension_id, dimension2_id, curr_code, credit_status, payment_terms, discount, 
		pymt_discount,credit_limit, sales_type, notes) VALUES ( " .fadb_escape($CustName) .", " .fadb_escape($cust_ref) .", "
		.fadb_escape($address) . ", " . fadb_escape($tax_id) . ","
		.fadb_escape($dimension_id) . ", " 
		.fadb_escape($dimension2_id) . ", ".fadb_escape($curr_code) . ", 
		" . fadb_escape($credit_status) . ", ".fadb_escape($payment_terms) . ", " . $discount . ", 
		" . $pymt_discount . ", " . $credit_limit 
		 .", ".fadb_escape($sales_type).", ".fadb_escape($notes) . ")";
	fadb_query($sql,"The customer could not be added");
}

function update_customer( $customer_id, $CustName, $cust_ref, $address, $tax_id, $curr_code,$dimension_id, $dimension2_id, $credit_status, $payment_terms, $discount, $pymt_discount,$credit_limit, $sales_type, $notes){
	$sql = "UPDATE ".TB_PREF."debtors_master SET name=" . fadb_escape($CustName) . ", 
		debtor_ref=" . fadb_escape($cust_ref) . ",
		address=".fadb_escape($address) . ", 
		tax_id=".fadb_escape($tax_id) . ", 
		curr_code=".fadb_escape($curr_code) . ", 
		dimension_id=".fadb_escape($dimension_id) . ", 
		dimension2_id=".fadb_escape($dimension2_id) . ", 
		credit_status=".fadb_escape($credit_status) . ", 
		payment_terms=".fadb_escape($payment_terms) . ", 
		discount=" . $discount . ", 
		pymt_discount=" . $pymt_discount . ", 
		credit_limit=" . $credit_limit . ", 
		sales_type = ".fadb_escape($sales_type) . ", 
		notes=".fadb_escape($notes) ."
		WHERE debtor_no = ".fadb_escape($customer_id);

	fadb_query($sql,"The customer could not be updated");
}

function delete_customer($customer_id){
	begin_transaction();
	$sql =" SELECT branch_code FROM ".TB_PREF."cust_branch WHERE debtor_no=".$customer_id." LIMIT 1 ";
	$debtor_row =  fadb_query($sql, "Can't get email validations");
	if($row = fadb_fetch_row($debtor_row)){	
		delete_branch($customer_id, $row[0]);
	}
	
	$sql =" SELECT person_id FROM ".TB_PREF."crm_contacts WHERE entity_id=".$customer_id." AND type='customer' LIMIT 1 ";
	$debtor_row =  fadb_query($sql, "Can't get email validations");
	if($row = fadb_fetch_row($debtor_row)){	
		delete_crm_person($row[0]);
	}
	delete_entity_contacts('customer', $customer_id);

	$sql = "DELETE FROM ".TB_PREF."debtors_master WHERE debtor_no=".fadb_escape($customer_id);;
	fadb_query($sql,"cannot delete customer");
	commit_transaction();
}

function add_branch($customer_id, $br_name, $br_ref, $br_address, $salesman, $area, $tax_group_id, $sales_account, $sales_discount_account, $receivables_account, 	$payment_discount_account, $default_location, $br_post_address, $group_no,	$default_ship_via, $notes, $bank_account){
	$sql = "INSERT INTO ".TB_PREF."cust_branch (debtor_no, br_name, branch_ref, br_address,
		salesman, area, tax_group_id, sales_account, receivables_account, payment_discount_account, 
		sales_discount_account, default_location,
		br_post_address, group_no, default_ship_via, notes, bank_account)
		VALUES (".fadb_escape($customer_id). ",".fadb_escape($br_name) . ", "
			.fadb_escape($br_ref) . ", "
			.fadb_escape($br_address) . ", ".fadb_escape($salesman) . ", "
			.fadb_escape($area) . ","
			.fadb_escape($tax_group_id) . ", "
			.fadb_escape($sales_account) . ", "
			.fadb_escape($receivables_account) . ", "
			.fadb_escape($payment_discount_account) . ", "
			.fadb_escape($sales_discount_account) . ", "
			.fadb_escape($default_location) . ", "
			.fadb_escape($br_post_address) . ","
			.fadb_escape($group_no) . ", "
			.fadb_escape($default_ship_via). ", "
			.fadb_escape($notes). ", "
			.fadb_escape($bank_account, true).")";
	fadb_query($sql,"The branch record could not be added");
}

function update_branch($customer_id, $br_name, $br_ref, $br_address,$salesman, $area, $tax_group_id, $sales_account, $sales_discount_account, $receivables_account, $payment_discount_account, $default_location, $br_post_address, $group_no,
	$default_ship_via, $notes, $bank_account){
	$sql = "UPDATE ".TB_PREF."cust_branch SET br_name = " . fadb_escape($br_name) . ",
		branch_ref = " . fadb_escape($br_ref) . ",
		br_address = ".fadb_escape($br_address). ",
		salesman= ".fadb_escape($salesman) . ",
		area=".fadb_escape($area) . ",
		tax_group_id=".fadb_escape($tax_group_id). ",
		sales_account=".fadb_escape($sales_account) . ",
		sales_discount_account=".fadb_escape($sales_discount_account) . ",
		receivables_account=".fadb_escape($receivables_account) . ",
		payment_discount_account=".fadb_escape($payment_discount_account) . ",
		default_location=".fadb_escape($default_location) . ",
		br_post_address =".fadb_escape($br_post_address) . ",
		group_no=".fadb_escape($group_no) . ", 
		default_ship_via=".fadb_escape($default_ship_via) . ",
		notes=".fadb_escape($notes) . ",
		bank_account=".fadb_escape($bank_account, true)."
		WHERE debtor_no=".fadb_escape($customer_id);
	fadb_query($sql,"The branch record could not be updated");
}

function delete_branch($customer_id, $branch_code){
	delete_entity_contacts('cust_branch', $branch_code);
	$sql="DELETE FROM ".TB_PREF."cust_branch WHERE branch_code=".fadb_escape($branch_code)." AND debtor_no=".fadb_escape($customer_id);
	fadb_query($sql,"could not delete branch");
}

function add_crm_person($ref, $name, $name2, $address, $phone, $phone2, $fax, $email, $lang, $notes,
	$cat_ids=null, $entity=null){
	$sql = "INSERT INTO ".TB_PREF."crm_persons (ref, name, name2, address, phone, phone2, fax, email, lang, notes)	VALUES ("
		  .fadb_escape($ref) . ", "
		  .fadb_escape($name) . ", "
		  .fadb_escape($name2) . ", "
		  .fadb_escape($address) . ", "
		  .fadb_escape($phone) . ", "
		  .fadb_escape($phone2) . ", "
		  .fadb_escape($fax) . ", "
		  .fadb_escape($email) . ", "
		  .fadb_escape($lang) . ", "
		  .fadb_escape($notes)
		.")";

	begin_transaction();

	$ret = fadb_query($sql, "Can't insert crm person");
	$id = fadb_insert_id();
	if ($ret && $cat_ids) {
		if(!update_person_contacts($id, $cat_ids, $entity))
			return null;
	}
	commit_transaction();
	return $id;
}

function update_crm_person($id, $ref, $name, $name2, $address, $phone, $phone2, $fax, $email, $lang, $notes){
	$sql = "UPDATE ".TB_PREF."crm_persons SET "
		  ."ref=".fadb_escape($ref) . ", "
		  ."name=".fadb_escape($name) . ", "
		  ."name2=".fadb_escape($name2) . ", "
		  ."address=".fadb_escape($address) . ", "
		  ."phone=".fadb_escape($phone) . ", "
		  ."phone2=".fadb_escape($phone2) . ", "
		  ."fax=".fadb_escape($fax) . ", "
		  ."email=".fadb_escape($email) . ", "
		  ."lang=".fadb_escape($lang) . ", "
		  ."notes=".fadb_escape($notes)
		  ." WHERE id = ".fadb_escape($id);

	begin_transaction();

	$ret = fadb_query($sql, "Can't update crm person");
	/*if ($ret) {
		if(!update_person_contacts($id, $cat_ids, $entity, $type))
			return null;
	}*/
	commit_transaction();
	return $id;
}


function delete_crm_person($person, $with_contacts=false){
	begin_transaction();

	if ($with_contacts) {
		$sql = "DELETE FROM ".TB_PREF."crm_contacts WHERE person_id=".fadb_escape($person);
		fadb_query($sql, "Can't delete crm contacts");
	}
	$sql = "DELETE FROM ".TB_PREF."crm_persons WHERE id=".fadb_escape($person);
	$ret = fadb_query($sql, "Can't delete crm person");

	commit_transaction();
	return $ret;
}

function add_crm_contact($type, $action, $entity_id, $person_id)
{
	$sql = "INSERT INTO ".TB_PREF."crm_contacts (person_id, type, action, entity_id) VALUES ("
		.fadb_escape($person_id) . ","
		.fadb_escape($type) . ","
		.fadb_escape($action) . ","
		.fadb_escape($entity_id) . ")";
	return fadb_query($sql, "Can't insert crm contact");
}

function key_in_foreign_table($id, $tables, $stdkey){

	if (!is_array($tables))
		$tables = array($tables);

	$sqls = array();
	foreach ($tables as $tbl => $key) {
		if (is_numeric($tbl)) {
			$tbl = $key;
			$key = $stdkey;
		}
		$sqls[] = "(SELECT COUNT(*) as cnt FROM ".TB_PREF."$tbl WHERE `$key`=".fadb_escape($id).")\n";
	}

	$sql = "SELECT sum(cnt) FROM (". implode(' UNION ', $sqls).") as counts";

	$result = fadb_query($sql, "check relations for ".implode(',',$tables)." failed");
	$count =  fadb_fetch_row($result);	
	return $count[0];
}

function delete_entity_contacts($class, $entity){
	delete_crm_contacts(null, $class, $entity);
	// cleanup
	$res = get_crm_persons($class, null, $entity, null, true);
	while($person = fadb_fetch($res)) {
		$rels = get_person_contacts($person['id']);
		if (count($rels) == 0) {
			delete_crm_person($person['id']);
		}
	}
}


/* Delete selected contacts for given person */
function delete_crm_contacts($person_id = null, $type = null, $entity_id=null, $action = null){
	$sql = "DELETE FROM ".TB_PREF."crm_contacts WHERE ";

	if ($person_id)
		$where[] = 'person_id='.fadb_escape($person_id);
	if ($type)
		$where[] = 'type='.fadb_escape($type);
	if ($entity_id)
		$where[] = 'entity_id='.fadb_escape($entity_id);
	if ($action)
		$where[] = 'action='.fadb_escape($action);

	return fadb_query($sql.implode(' AND ', $where), "Can't delete crm contact");
}

/*
	Returns all contacts for given person id
*/
function get_person_contacts($id){
	$sql = "SELECT t.id FROM "
		.TB_PREF."crm_categories t, "
		.TB_PREF."crm_contacts r WHERE r.type=t.type AND r.action=t.action 
			AND r.person_id=".fadb_escape($id);

	$contacts = array();
	$ret = fadb_query($sql, "Can't get crm person contacts");
	while($cont = fadb_fetch_row($ret))
		$contacts[] = $cont[0];
	return $contacts;
}



function add_to_order(&$cart, $new_item, $new_item_qty, $price, $discount, $description='')
{
	// calculate item price to sum of kit element prices factor for 
	// value distribution over all exploded kit items
	 $std_price = get_kit_price($new_item, $curr_code, 
		$sales_type,'',$date, true);

	if ($std_price == 0)
		$price_factor = 0;
	else
		$price_factor = $price/$std_price;

	$kit = get_item_kit($new_item);
	$item_num = db_num_rows($kit);

	while($item = db_fetch($kit)) {
		$std_price = get_kit_price($item['stock_id'], $order->customer_currency, 
			$order->sales_type,	$order->price_factor, get_post('OrderDate'), true);

		// rounding differences are included in last price item in kit
		$item_num--;
		if ($item_num) {
			$price -= $item['quantity']*$std_price*$price_factor;
			$item_price = $std_price*$price_factor;
		} else {
			if ($item['quantity']) 
				$price = $price/$item['quantity'];
			$item_price = $price;
		}
		$item_price = round($item_price, user_price_dec());

		if (!$item['is_foreign'] && $item['item_code'] != $item['stock_id'])
		{	// this is sales kit - recurse 
			add_to_order($order, $item['stock_id'], $new_item_qty*$item['quantity'],
				$item_price, $discount);
		}
		else
		{	// stock item record eventually with foreign code

			// check duplicate stock item
			foreach ($order->line_items as $order_item)
			{
				if (strcasecmp($order_item->stock_id, $item['stock_id']) == 0)
				{
					display_warning(_("For Part :").$item['stock_id']. " " 
						. _("This item is already on this document. You have been warned."));
					break;
				}
			}
			$order->add_to_cart (count($order->line_items),	$item['stock_id'], 
				$new_item_qty*$item['quantity'], $item_price, $discount, 0,0, $description);
		}
	}

}
	
function update_customer_trans_version($type, $versions) {

	$sql= 'UPDATE '.TB_PREF. 'debtor_trans SET version=version+1
			WHERE type='.fadb_escape($type).' AND (';

	foreach ($versions as $trans_no=>$version)
		$where[] = 	'(trans_no='.fadb_escape($trans_no).' AND version='.$version.')';

		$sql .= implode(' OR ', $where) .')';

	return  fadb_query($sql, 'Concurrent editing conflict');
}

//--------------------------------------------------------------------------------------------------
function update_parent_line($doc_type, $line_id, $qty_dispatched, $auto=false){
	$doc_type = get_parent_type($doc_type);

        $qty_dispatched = (float)$qty_dispatched;

	if ($doc_type == 0)
		return false;
	else {
		if ($doc_type==ST_SALESORDER || $doc_type==ST_SALESQUOTE){
			$sql = "UPDATE ".TB_PREF."sales_order_details
				SET qty_sent = qty_sent + $qty_dispatched";
			if ($auto)
				$sql .= ", quantity = quantity + $qty_dispatched";
			$sql .= " WHERE id=".fadb_escape($line_id);
		}
		else
			$sql = "UPDATE ".TB_PREF."debtor_trans_details
				SET qty_done = qty_done + $qty_dispatched
				WHERE id=".fadb_escape($line_id);
	}
	fadb_query($sql, "The parent document detail record could not be updated");
	return true;
}

function get_branch_accounts($branch_id){
	$sql = "SELECT receivables_account,sales_account, sales_discount_account, payment_discount_account 
		FROM ".TB_PREF."cust_branch WHERE branch_code=".fadb_escape($branch_id);
	
	$result = fadb_query($sql, "Cannot retreive a customer branch");
	
	return fadb_fetch($result);
}

function get_itemkit_byid($id){
	$sql="SELECT kit.*, kit.quantity, item.units, comp.description as comp_name 
		FROM "
		.TB_PREF."item_codes kit,"
		.TB_PREF."item_codes comp
		LEFT JOIN "
		.TB_PREF."stock_master item
		ON 
			item.stock_id=comp.item_code
		WHERE
			kit.stock_id=comp.item_code
			AND kit.id=".fadb_escape($id);

	$result = fadb_query($sql,"item kit could not be retrieved");

	return $result;
}

function return_get_taxes($cart_items, $tax_group_id, $tax_included){
	$items = array();
	$prices = array();	
	$total_tax =0;
	$dec = user_price_dec();
	
	foreach ($cart_items as $ln_itm) {
		if(isset($ln_itm['kit']) && $ln_itm['kit'] != ''){
			$kit = get_item_kit(($ln_itm['kit'] != 'yes' ? $ln_itm['kit'] : $ln_itm['stock_id']), true);
			//var_dump($kit);
			if(!empty($kit)){
				foreach($kit as $line_item){
					if(isset($line_item['stock_id'])){
						$price_calculated = get_price($line_item['stock_id'], $_SESSION['curr_code'], $_SESSION['sales_type_id'], null, null, false); 
						$items[] = $line_item['stock_id'];
						$prices[] = ($ln_itm['qty'] * $price_calculated * (1 - $ln_itm['discount']));
					}
				}
			}
		} else {
			$items[] = $ln_itm[0];
			if(!is_numeric($ln_itm[3]))
				$ln_itm[3] = 0;
			$prices[] = ($ln_itm[1] * $ln_itm[2]* (1 - $ln_itm[3]));
		}
	}
	
	return $allTaxes = get_tax_for_items($items, $prices, 0, $tax_group_id, $tax_included);
	//foreach($allTaxes as $tax)
	//	$total_tax += round($tax['Value'], $dec);
	//return $total_tax;
}
//--------------------------------------------------------------------------------------
function is_inventory_item($stock_id){
	$sql = "SELECT stock_id FROM ".TB_PREF."stock_master
		WHERE stock_id=".fadb_escape($stock_id)." AND mb_flag <> 'D'";
	$result = fadb_query($sql, "Cannot query is inventory item or not");

	return fadb_num_rows($result) > 0;
}

function get_stock_gl_code($stock_id){
	/*Gets the GL Codes relevant to the item account  */
	$sql = "SELECT mb_flag, inventory_account, cogs_account, adjustment_account, sales_account, wip_account, dimension_id, dimension2_id FROM
		".TB_PREF."stock_master WHERE stock_id = ".fadb_escape($stock_id);

	$get = fadb_query($sql,"retreive stock gl code");
	return fadb_fetch($get);
}


function sql2date($date){
	return date('Y-m-d', strtotime($date));
}

function date2ssql($date){
	return date('Y-m-d', strtotime($date));
}

function user_pagesize(){
	return 'A4';
}
function recalculate_cols(&$cols){
	$factor = (user_pagesize() == "A4" ? 1.4 : 1.3);
	foreach($cols as $key => $col)
		$cols[$key] = intval($col * $factor); 
}

function array_search_value($needle, $haystack, $valuekey=null){
	//$haystack = array('C', 'nl_NL');
	foreach($haystack as $key => $value) {
		$val = isset($valuekey) ? @$value[$valuekey] : $value;
		if ($needle == $val){
			return $value;
		}
	}
	return null;
}

function get_company_pref($detail=null){
	return get_company_details($detail);
}

function get_company_detailss($db=false){
	$sql = "SELECT name, value FROM ".TB_PREF."sys_prefs" ;
	$result = fadb_query($sql, "could not get Company Details");
	$final= array();
	while($row = fadb_fetch_assoc($result)){
		$final[$row['name']] = $row['value'];		
	}
	return $final;
}

function GetLocations($loc=null){
	
	$sql = "SELECT loc_code, location_name, inactive FROM ".TB_PREF."locations WHERE fixed_asset = '0' AND !inactive";
	if($loc){
		$sql .=" AND loc_code = ".fadb_escape($loc);
		$result = fadb_query($sql, "could not get Company Details");
		return fadb_fetch_assoc($result);
	} else{
		$result = fadb_query($sql, "could not get Company Details");
		$final= array();
		while($row = fadb_fetch_assoc($result)){
			$final[] = $row;		
		}
		
		return $final;		
	}
}