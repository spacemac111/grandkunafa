<?php 
   /*
   Template Name : KOT Clients 
   */ 
   global $Refs, $price_dec, $current_user, $pushers;
   get_header();  ?>

  <div class="container dashboard" id="bodySection">
       <div class="row" >
            <h3 class="NewClientInvoice" style="max-width: 300px;" > <span> <?php echo _("Clients"); ?> </span> 
              <button class="btn-floating btn-large primary-color " data-target="#ClientAddNew" id="AddNewClientBtn" > <i class="material-icons">group_add</i></button>


              <!--<a class="btn-floating btn-large primary-color" href="<?php //echo get_url('clients'); ?>" > <i class="material-icons">person_add</i></a>--></h3>
       </div>
       <div class="row">
		      <table class="list bordered highlight" id="ClientsDatatable">
				    <thead><tr> <th> <?php echo _("Client Name"); ?> </th> <th> <?php echo _("Phone"); ?> </th> <th> <?php echo _("Address"); ?></th> <th> <?php echo _("Location"); ?></th> <th> <?php echo _("Status"); ?></th> <th></th></tr></thead>
			     </table>
	     </div>
  </div>
      
  <!-- New message Structure -->
    <div class="modal fade" id="ClientAddNew" tabindex="-1" role="dialog" aria-labelledby="ClientDetail">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="ClientDetail"> <!--<i class="material-icons"> folder_open</i> --> <?php echo _("New Client"); ?></h4>
          </div>
                    <form action="<?php echo get_url('customers'); ?>" class="" id="NewClientAdd" enctype="multipart/form-data" method="post" accept-charset="utf-8">
              <div class="modal-body" style="min-height:200px;">
                <div id="UploadStatus"> </div> 
                <div class="row">            
                  <div class="col-sm-12"> 
           
                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Client Name"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="client_name_1" class="form-control"></div></div>                  
                     
                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Phone"); ?></label><div class="col-md-8"><input type="text" name="phone_1" class="form-control"></div></div>              
                      
                      <div class="form-group" ><label for="textArea" class="col-md-4 control-label"><?php echo _("Address"); ?></label>

                          <div class="col-md-8"><textarea class="form-control" rows="3" id="ClientAddress" name="address"></textarea></div>
                      </div>
            
                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Location"); ?></label>
                        <div class="col-md-8"><select autocomplete="off" name="location" class="form-control">
                        <?php  $sql ="SELECT id, location_name, inactive FROM ".TB_PREF."contacts_kot_location ORDER BY id";
                          $sales_typ_res= fadb_query($sql, "can't get results");
                          while($row = fadb_fetch($sales_typ_res)){
                             if(!$row['inactive'])
                            echo '<option value="'.$row['id'].'" > '. $row['location_name'].' </option>';
                          }
                          ?>
                        </select></div></div>             
                          <input type="hidden" name="clientid" id="clientid" value="0" > 
                      </div>
                 
                  <div class="col-md-12 form-group" id="errorWarning" style="display: none;background: #ffc0bb; border: 1px solid #F44336; border-radius: 2px; color: #f44336;" > 
                  <label style="color: rgb(243, 32, 17); font-weight: 300;  padding-top: 10px;" > </label>
                  </div> 
                </div>            
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
                 <input type="hidden" name="submit_customer" value="yes" > 
                <button type="submit" class="btn btn-primary" id="Submitbtn"><?php echo _("Submit"); ?></button>
              </div>
      </form>
        </div>
      </div>
    </div>

      <!-- Datatable Js --> 
<script src="<?php echo get_current_theme_uri(); ?>js/datatables.min.js"></script>
<script type="text/javascript">
 //  datatable filter redraw plugin
$(function(){
  $.fn.dataTableExt.oApi.fnStandingRedraw = function(oSettings) {

      if(oSettings.oFeatures.bServerSide === false){
          var before = oSettings._iDisplayStart;
          oSettings.oApi._fnReDraw(oSettings);       
          oSettings._iDisplayStart = before;
          oSettings.oApi._fnCalculateEnd(oSettings);
      } 
      oSettings.oApi._fnDraw(oSettings);
  };
  <?php if($current_user['role'] == 'Administrator' || $current_user['role'] == 'Auditor'){
    echo 'var customerid= "&customerId='.$selected_user['ID'].'";';
    echo 'var customer_id= "&customerID='.$selected_user['ID'].'";';
  } else {
    echo 'var customerid="";' ;
    echo 'var customer_id="";' ;
  }
  ?>
  $("#AddNewClientBtn").on("click", function(e) {
    $('input[name="client_name_1"]').val('');
     $('input[name="phone_1"]').val('');
     $('#ClientAddress').val('');
     $("#clientid").val('0');
     $("#ClientDetail").html('<?php echo _("Add New Client"); ?>');
    $("#ClientAddNew").modal('show');
  });

  $("body").on("click", "#Submitbtn", function(e){ 
    e.preventDefault();
    var allow = 1;
    if($('input[name="client_name_1"]').val()==''){
      $('input[name="client_name_1"]').focus();     
      $("#errorWarning label").html('<?php echo _("You have to input client full name"); ?>');
      $("#errorWarning").show();
      allow = 0;
    }
    if(allow == 1){
        $("#errorWarning").hide();
        $.ajax({
            type: 'post',
            url: 'ajax?submit_client=yes',
            data: $('#NewClientAdd').serialize(),
            dataType :'JSON',
            success: function (result) {
              alert_float(result.type, result.msg);
              $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
              $('#ClientAddNew').modal('hide');
              $("#ClientsDatatable").dataTable().fnStandingRedraw();        
            }
        });
      }
  });

  $("body").on("click", ".EditClient", function(e){   
    //e.preventDefault();
    var edit_customer_id = $(this).data('clientid'); 
    EdiClient(edit_customer_id); 
   });
  $("body").on("click", ".DeleteClient", function(e){ 
    var delete_customer_id = $(this).data('clientid'); 
    DeleteClient(delete_customer_id); 
   }); 

  ClientsTable = $("#ClientsDatatable").dataTable({
          "processing": true,
          "serverSide": true,
          "order": [[ 0, "desc" ]],
          "pageLength": 25,
		 // "dom": '<"FilterUploads">frtip',
          "ajax": "<?php  echo get_url(); ?>ajax?clients=yes"+customerid
  });
}); 


function EdiClient(Clientid){   
  $.ajax({
    type: "POST",
    dataType: "json",
    url: "ajax?Edit_Client="+Clientid,
    data: 0,
    success: function(data){    
      console.log(data);            
      if(data != 1){
        $("#UploadTitle").html('<?php echo _("Edit Client"); ?>');
        $('input[name="client_name_1"]').val(data.client_name);
       
        $('#ClientAddress').val(data.address);
        $('input[name="phone_1"]').val(data.phone);
        $("#clientid").val(data.id);
        $("#errorWarning").hide();
      //alert(data.name);
        $("#ClientAddNew").modal('show');
      }else{
            alert_float('failure', "Failed to Edit : "+data);
      }               
    }
  });   
}

function DeleteClient(Clientid){
  var r = confirm('<?php echo _("Are you sure to delete this Client?"); ?>');
  if (r == false) {
    return false;
  } else {   
    $.ajax({
        type: "POST",
        url: "ajax?delete_Client="+Clientid,
        data: 0,
         dataType :'JSON',
        success: function(data){        
          if(data == 1){
            alert('success', '<?php echo _("The client was deleted successfully."); ?>');
            $("#ClientsDatatable").dataTable().fnStandingRedraw();
          }else{
            alert('failure', "Failed to Delete : "+data);
          }               
        }
    });
  }
}

function alert_float(type, message, timeout) {
    var aId, el;
    aId = $("body").find('float-alert').length;
    aId++;
    aId = 'alert_float_' + aId; 
    el = $('<div id="'+aId+'" class="float-alert animated fadeInRight col-xs-11 col-sm-4 alert alert-'+type+'"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><span class="fa fa-bell-o" data-notify="icon"></span><span class="alert-title">'+message+'</span></div>');
    $("body").append(el);
    setTimeout(function() {
        $('#' + aId).hide('fast', function() { $('#' + aId).remove(); });
    }, timeout ? timeout : 3500);
}
</script>
<?php get_footer(); ?>