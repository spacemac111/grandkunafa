<?php 
global $fadb, $current_user, $selected_user, $pushers;
$pushers = get_site_option('pusher'); 
get_header(); 
$user_price_dec = user_price_dec();

// echo '<pre>';
// print_r($current_user);
//print_r(has_user_permission());
if(has_user_permission('View Overall', 'Dashboard')) {

  $top_customer = get_top_customers(); 
 $top_supplier = get_top_suppliers();
 //print_r($top_supplier);
 $weekly_sales = get_weekly_sales(); 
 $top_selling_items =  Top_selling_items(); 
 $overdue_purchase_invoices_5 = Purchase_Overdue_invoices(); //get_overdue_purchase_invoices(); 
 $Sales_invoice_5 = Sales_Overdue_invoices(); 
 $Sales_payment_5 = Top_five_invoices(12); 
 $bank_balance = Bank_Account_Balance();
 $overdue_purchase_invoice_lines = ''; 
 $ove_in = $sale_ovr = 0;
 foreach($overdue_purchase_invoices_5 as $supp){
  if( $ove_in <5 ){
    $overdue_purchase_invoice_lines .= ' <div class="inbox-item"><div class="inbox-item-img textrtl"><i class="material-icons"> account_circle </i></div><p class="inbox-item-author textrtl">'.$supp['supp_name'].'</p><p class="inbox-item-text textrtl">'._("Invoice").' ID #'.$supp['supp_reference'].'</p><p class="inbox-item-date textltr">'.$supp['due_date'].'</p><p class="inbox-item-total textltr">'.round($supp['total'],2).'</p><p class="inbox-item-amount textltr">'.round($supp['remainder'],2).'</p></div>';
    $ove_in++; 
  }
 } 
 
 $invoice_lines = ''; 
 foreach($Sales_invoice_5 as $invoice){
    if( $sale_ovr <5 ){
   $invoice_lines .= ' <div class="inbox-item"><div class="inbox-item-img textrtl"><i class="material-icons"> account_circle </i></div><p class="inbox-item-author textrtl">'.$invoice['name'].'</p><p class="inbox-item-text textrtl">'._("Invoice").' ID #'.$invoice['reference'].'</p><p class="inbox-item-date textltr">'.$invoice['due_date'].'</p><p class="inbox-item-total textltr">'.round($invoice['total'],2).'</p><p class="inbox-item-amount textltr">'.round($invoice['remainder'],2).'</p></div>';
     $sale_ovr++; 
    }
 }
 $payment_lines= '';
 foreach($Sales_payment_5 as $payment){
  $payment_lines .='<tr><th scope="row">'.$payment['reference'].'</th> <td>'.$payment['name'].'</td> <td><span class="label label-info">'.$payment['curr_code'].'</span></td> <td>'.$payment['TotalAmount'].'</td> </tr>'; 
 }
 $top_sales = ' <table><thead> <tr> <th> '._("Gross Sales").' </th><th> '._("Net sales").' </th> <th> '._("Tax").' </th> </tr> </thead><tbody>';
  foreach ($weekly_sales as $weekItem)
    $top_sales .= '<tr> <td> '.round($weekItem['Gross Sales'], 2). '</td> <td> '. round($weekItem['Net Sales'], 2).'</td> <td> '. round($weekItem['Tax'], 2). '</td> </tr>';
  $top_sales .='</tbody> </table>'; 
  
  $today_sale = today_sales_count_amount(null, $user_price_dec);
//	$yesterday_sale = today_sales_count_amount(1);
	$this_month = today_sales_count_amount(2, $user_price_dec);
  
$items_array =  array(
     1 => '<div class="col-sm-3" id="item-1"> <div class="panel panel-default top_counts"><div class="panel-body"> <div class="left" > <p class="count"> <i class="material-icons" > perm_identity </i></p> </div> <div class="right">  <p class="factor"> '.get_customers_count().' </p> <p class="small"> '._("Customers").' </p> </div></div></div></div>',
     2 => '<div class="col-sm-3" id="item-2"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > storage </i></p> </div> <div class="right">  <p class="factor"> '.get_items_count().' </p> <p class="small"> '._("Items").' </p> </div> </div> </div> </div>',
     3 => '<div class="col-sm-3" id="item-3"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div> <div class="right"> <p class="factor"> '.get_suppliers_count().'</p> <p class="small"> '._("Suppliers").' </p> </div></div></div> </div>', 
     4 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.number_format(get_opening_balance(), $user_price_dec).' </p> <p class="small"> '._("Opening Balance").' </p>  </div></div> </div> </div>',
    
     5 => '<div class="col-sm-3" id="item-5"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left " >  <p class="count"> <i class="material-icons" > backup </i></p> </div><div class="right">  <p class="factor"> '.$today_sale['count'].' </p> <p class="small"> '._("Today Invoiced").' </p>  </div></div> </div> </div>',
     6 => '<div class="col-sm-3" id="item-6"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.number_format($today_sale['amount'], $user_price_dec).' </p> <p class="small"> '._("Today Earnings").' </p>  </div></div> </div> </div>',
     7 => '<div class="col-sm-3" id="item-7"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.$this_month['amount'].' </p> <p class="small"> '._("This Month").' </p>  </div></div> </div> </div>',
     8 => '<div class="col-sm-3" id="item-8"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > card_travel </i></p> </div><div class="right">  <p class="factor"> '.number_format(get_current_balance(), $user_price_dec).' </p> <p class="small"> '._("Current Balance").' </p>  </div></div> </div> </div>',
     9 => '<div class="col-sm-6" id="item-15"> <div class="panel panel-default"><div class="panel-body pheight400">  <legend> <i class="material-icons" >account_balance </i> '._("Bank Balances").' </legend>                
                             <div class="col-md-4"> </div><div class="col-md-8" style="visibility:hidden;"> <select id="BankBalancePeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div><div id="BankBalanceAccount" style="height: 250px;"></div></div></div></div>',

   10 => '<div class="col-sm-6" id="item-9"><div class="panel panel-default"> <div class="panel-body pheight400"> <legend> <i class="material-icons"> account_balance_wallet </i>'._("Sales").'</legend><div class="row">  <div class="col-md-12">  <div class="col-md-6">  </div> <div class="col-md-6" > <select id="SalesPeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div> </div></div><div id="Area_chart" style="height: 250px;"></div></div></div> </div> ',
   11 => '<div class="col-sm-6" id="item-10"><div class="panel panel-default"> <div class="panel-body pheight400"><legend> <i class="material-icons">assignment </i>'._("Class Balances").' </legend><div class="row">  <div class="col-md-12">  <div class="col-md-6">  </div> <div class="col-md-6" > <select id="ClassPeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div> </div></div> <div id="Class_Balance_chart" style="height: 250px;"></div>  </div></div></div>',
   12 => '<div class="col-lg-6 col-md-6" id="item-13">
                            <div class="panel panel-white">
                                <div class="panel-body pheight400">
                                <legend> <i class="material-icons"> description </i> '._("Sales Invoices").' </legend>  
                                    <div class="slimScrollDiv padrl20" style="position: relative; overflow: hidden; width: auto; height: 100%;"><div class="inbox-widget slimscroll" style="overflow: hidden; width: auto; height: 100%;">
                                        '.$invoice_lines.'                               
                                    </div><div class="slimScrollBar" style="background: rgb(204, 204, 204); width: 7px; position: absolute; top: 0px; opacity: 0.3; display: none; border-radius: 0px; z-index: 99; right: 0px; height: 298.923px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 0px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 0px;"></div></div>
                                </div>
                            </div>
                        </div>',  
  13 => '<div class="col-lg-6 col-md-6" id="item-14">
                            <div class="panel panel-white">
                                <div class="panel-body pheight400">
                                <legend> <i class="material-icons"> description </i> '._("Purchase Invoices").' </legend>  
                                    <div class="slimScrollDiv padrl20" style="position: relative; overflow: hidden; width: auto; height: 100%;"><div class="inbox-widget slimscroll" style="overflow: hidden; width: auto; height: 100%;">
                                        '.$overdue_purchase_invoice_lines.'                               
                                    </div><div class="slimScrollBar" style="background: rgb(204, 204, 204); width: 7px; position: absolute; top: 0px; opacity: 0.3; display: none; border-radius: 0px; z-index: 99; right: 0px; height: 298.923px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 0px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 0px;"></div></div>
                                </div>
                            </div>
                        </div>',
   
  14 => '<div class="col-sm-6" id="item-15"> <div class="panel panel-default"><div class="panel-body pheight400">  <legend> <i class="material-icons" >people </i> '._("Customers").' </legend>                
                             <div class="col-md-4"> </div><div class="col-md-8" > <select id="CustomerPeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div><div id="donut-customer" style="height: 250px;"></div></div></div></div>',
  15 => '<div class="col-sm-6" id="item-16"><div class="panel panel-default"><div class="panel-body pheight400"><legend> <i class="material-icons" >people_outline </i> '._("Suppliers").'  </legend>
                             
              <div class="col-md-4"> </div> <div class="col-md-8"> <select id="SupplierPeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div>
               <div id="donut-supplier" style="height: 250px;"></div></div> </div></div>',
  16 => '<div class="col-sm-6" id="item-17"><div class="panel panel-default"><div class="panel-body pheight400"> <legend> <i class="material-icons"> poll</i>  '._("Expenses").' </legend>
                     <div class="row"> <div class="col-md-4"> </div> <div class="col-md-8"> <select id="ExpensesPeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div></div><div id="expenses_chart" style="height: 250px;"></div></div></div></div>',
    17 => '<div class="col-sm-6" id="item-20"><div class="panel panel-default"><div class="panel-body pheight400"><legend> <i class="material-icons" >people_outline </i> '._("Taxes").'  </legend>
                             
                            <div class="col-md-4"> </div> <div class="col-md-8"> <select id="TaxPeriods" class="form-control"> <option value="Till Now">'._("Till Now").'</option><option value="Last Week">'._("Last Week").'</option><option value="Last Month">'._("Last Month").'</option> <option value="This Month">'._("This Month").'</option> <option value="Last Quarter Year">'._("Last Quarter Year").'</option></select></div>
                             <div id="donut-Taxes" style="height:250px;" ></div>
                            <!-- <div class="row"> <div class="col-md-7 "> <p style="font-weight:500;padding-left:15px">Net Payable Tax</p></div> <div class="col-md-5 ">  <p id="GrandTaxTotal">0.00</p> </div> </div>-->  </div> </div></div>',
  18 => '<div class="col-lg-6 col-md-6" id="item-18"><div class="panel panel-white"><div class="panel-body pheight400"><legend> <i class="material-icons"> credit_card </i>'._("Payments").'</legend><div class="table-responsive project-stats padrl20">  
                                       <table class="table "><thead> <tr> <th>#</th><th>'._("Name").'</th> <th>'._("Currency").'</th> <th>'._("Total Amount").'</th></tr> </thead>
                                           <tbody>'.$payment_lines.'</tbody></table></div></div></div> </div>',
  19 => '<div class="col-sm-6" id="item-19"> <div class="panel panel-default"><div class="panel-body"><legend> <i class="material-icons"> chrome_reader_mode </i> '._("Weekly Sales").' </legend> 
                <div class="padrl20">'.$top_sales.'</div></div></div></div>',
  
    20 => '<div class="col-sm-6" id="item-11"><div class="panel panel-default"> <div class="panel-body pheight400"><legend> <i class="material-icons"> shopping_cart </i>'._("Overall Sales").'   </legend>   <div style="padding:10px;"><canvas id="chart-area" /></div> </div> </div></div> ',
    21 => '<div class="col-sm-6" id="item-12"><div class="panel panel-white browserstats"><div class="panel-body pheight400 "> <legend> <i class="material-icons"> chrome_reader_mode </i> '._("Class Balances").' </legend><ul class="list-unstyled padrl20"> '.kv_gl_top()[0] .'   </ul> </div></div></div>',

//15 =>   '<div class="col-sm-4" id="item-15"> <div class="panel panel-default"><div class="panel-body"> <div style="height: 120px;"></div></div></div></div>'
              
     );

?>
 <!--   ###########  Dashboard Section ##############  -->    
 
 <div class="container dashboard" id="bodySection">
    <?php $user_dashboard = get_user_meta($selected_user['ID'], 'user_dashboard');  
      //print_r($user_dashboard);
    if($user_dashboard){
      foreach ($user_dashboard as $key => $value) {
       echo $items_array[$key];
      }
    } else{
      foreach ($items_array as $key => $value) {
        echo $value;
      }
    } 
  //echo  date("Y-m-d", strtotime("last week monday")).'---'. date("Y-m-d", strtotime("last week sunday"));?>
 </div>

 <input type="hidden" name="current_user_ID" id="current_user_ID" value="<?php  echo $current_user['ID']; ?>" >
 <input type="hidden" name="selected_user_ID" id="selected_user_ID" value="<?php  echo $selected_user['ID']; ?>" >
 <script src="<?php echo get_current_theme_uri(); ?>js/Chart.bundle.js" > </script>
 <script type="text/javascript">

   //  ##########################################
  $(function() {
     if($("#Class_Balance_chart").length){
        var Line_Chart = Morris.Line({
          element: 'Class_Balance_chart',
          behaveLikeLine: true,
          parseTime : false,
          data: [ {"value":"","label":""} ],    
          xkey: 'class',
          ykeys: ['value'],
          labels: ['Value'],
          lineColors: ['#f26c4f', '#00a651', '#00bff3', '#0072bc', '#707f9b', '#455064', '#242d3c', '#b92527', '#d13c3e', '#ff6264', '#ffaaab'],
          redraw: true,
          pointFillColors: ['#455064']
        });

        $("#ClassPeriods").on("change", function(){
           var type = $(this).val(); 
           $.ajax({
              type: "POST",
              url: "ajax?Line_chart="+type,
              data: 0,
              dataType: 'json',
              success: function(data){    console.log(data);
                Line_Chart.setData(data);
                /* setCookie('numbers',data,3); $('.flash').show(); $('.flash').html("Template Updated")*/
              }
          });
        }); 
     }  
     if($("#BankBalanceAccount").length){//  #################  
        var Customer_Donut_Chart = Morris.Donut({
          element: 'BankBalanceAccount',
          behaveLikeLine: true,
          parseTime : false,
          data: [<?php foreach($bank_balance as $balance) { echo " { label: '".$balance['bank_account_name']."', value: ".round(abs($balance['balance']),2)." }," ; } ?>],
          colors: [ '#707f9b', '#455064', '#242d3c', '#b92527', '#d13c3e', '#ff6264','#f26c4f', '#00a651', '#00bff3', '#0072bc', '#ffaaab'],
          redraw: true,
        });
      }
      if($("#donut-customer").length){//  #################  
        var Customer_Donut_Chart = Morris.Donut({
          element: 'donut-customer',
          behaveLikeLine: true,
          parseTime : false,
          data: [{"value":"","label":""}],
          colors: ['#f26c4f', '#00a651', '#00bff3', '#0072bc', '#707f9b', '#455064', '#242d3c', '#b92527', '#d13c3e', '#ff6264', '#ffaaab'],
          redraw: true,
        });
        $("#CustomerPeriods").on("change", function(){
             var option = $(this).val(); 
             $.ajax({
                type: "POST",
                url: "ajax?Customer_chart="+option,
                data: 0,
                dataType: 'json',
                success: function(data){
                 console.log(data);
                  Customer_Donut_Chart.setData(data);
                  /* setCookie('numbers',data,3); $('.flash').show(); $('.flash').html("Template Updated")*/
                }
            });
        });                             
      }


      if($("#donut-supplier").length){ //  #################  
        var Supplier_Donut_Chart = Morris.Donut({
          element: 'donut-supplier',
          behaveLikeLine: true,
          parseTime : false,
          data: [{"value":"","label":""}],  
          colors: [  '#ff6264', '#455064', '#d13c3e', '#d13c3e',  '#ff6264', '#ffaaab', '#f26c4f', '#00a651', '#00bff3', '#0072bc', '#b92527', '#707f9b', '#b92527',  '#242d3c'],
          redraw: true,
        });
        $("#SupplierPeriods").on("change", function(){
             var option = $(this).val(); 
             $.ajax({
                type: "POST",
                url: "ajax?Supplier_chart="+option,
                data: 0,
                dataType: 'json',        
                success: function(data){
                  console.log(data);
                  Supplier_Donut_Chart.setData(data);
                  /* setCookie('numbers',data,3); $('.flash').show(); $('.flash').html("Template Updated")*/
                }
              });
          }); 
      }

      if($("#donut-Taxes").length){ //  #################  
        var Tax_Donut_Chart = Morris.Donut({
          element: 'donut-Taxes',
          behaveLikeLine: true,
          parseTime : false,
          data: [{"value":"","label":""}],  
          colors: [ '#f26c4f', '#00a651', '#00bff3', '#0072bc','#ff6264', '#455064',  '#707f9b', '#b92527',  '#242d3c', '#d13c3e', '#d13c3e',  '#ff6264', '#ffaaab', '#b92527'],
          redraw: true,
        });
        $("#TaxPeriods").on("change", function(){
             var option = $(this).val(); 
             $.ajax({
                type: "POST",
                url: "ajax?Tax_chart="+option,
                data: 0,
                dataType: 'json',
                success: function(taxdata){      
                  //var grandtotal = data.grandtotal;  // delete data.grandtotal;   //delete data[4];
                  console.log(taxdata);
                  Tax_Donut_Chart.setData(taxdata);
                  // var arr = $.parseJSON(data);  //alert(data.grandtotal);    //$("#GrandTaxTotal").html(grandtotal);
                  /* setCookie('numbers',data,3); $('.flash').show(); $('.flash').html("Template Updated")*/
                }
          });
        }); 
      }

      if($("#expenses_chart").length){ //   ######### 
       var Expenses_Bar_Chart = Morris.Bar({
        element: 'expenses_chart',
        behaveLikeLine: true,
        parseTime : false,
        data: [{ "y": "Nothing" , "a" : "0"} ],
        xkey: 'y',
        ykeys: ['a'],
        labels: ['Expenses' ],
        barColors: ['#f26c4f', '#00a651', '#00bff3', '#0072bc', '#707f9b', '#455064', '#242d3c', '#b92527', '#d13c3e', '#ff6264', '#ffaaab'],
        redraw: true
        });
       $("#ExpensesPeriods").on("change", function(){
         var option = $(this).val(); 
         $.ajax({
            type: "POST",
            url: "ajax?Expense_chart="+option,
            data: 0,
            dataType: 'json',
            success: function(data){
              console.log(data);
              Expenses_Bar_Chart.setData(data);
               /* setCookie('numbers',data,3); $('.flash').show(); $('.flash').html("Template Updated")*/
            }
          });
        }); 
      }

      if($("#Area_chart").length){//  ################   
        var Area_chart = Morris.Area({
          element: 'Area_chart',  
          behaveLikeLine: true,
          parseTime : false, 
          data: [ ],
          xkey: 'y',
          ykeys: ['a', 'b'],
          labels: ['Sales', 'Cost'],
          pointFillColors: ['#707f9b'],
          pointStrokeColors: ['#ffaaab'],
          lineColors: ['#f26c4f', '#00a651', '#00bff3'],
          redraw: true      
        });

        $("#SalesPeriods").on("change", function(){
         var selected_user_ID = $(this).val(); 
         $.ajax({
                type: "POST",
                url: "ajax?Area_chart="+selected_user_ID,
                data: 0,
                dataType: 'json',
                success: function(data){
                  console.log(data);
                  Area_chart.setData(data);
                }
              });
        }); 
      }
  });
    //  #################  
     var config = {
            type: 'pie',
            data: {
                datasets: [{
                    data: [<?php foreach($top_selling_items as $top) { echo round($top['total'], 2).',';  } ?> ],
                    backgroundColor: ['rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                    ],
                    label: 'Dataset 1'
                }],
                labels: [<?php foreach($top_selling_items as $top) { echo '"'.$top['description'] .'",';  } ?>  ]
            },
            options: {
                responsive: true
            }
        };

        window.onload = function() {
            var ctx = document.getElementById("chart-area").getContext("2d");
            ctx.canvas.height = 300;
            window.myPie = new Chart(ctx, config);
        };
        $(document).ready(function(e){
          $("#SalesPeriods").trigger("change");
          $("#ClassPeriods").trigger("change");
          $("#SupplierPeriods").trigger("change");
          $("#CustomerPeriods").trigger("change");
          $("#ExpensesPeriods").trigger("change");
          $("#TaxPeriods").trigger("change");
        });
     </script>
     <style>
     #chart-area{ max-height:350px !important; max-width:350px !important; }
     canvas#chart-area {padding-left: 0; padding-right: 0; margin-left: auto;  margin-right: auto;   display: block;}
     .warning { background : #fdd396 !important; } 
     .warning:hover { background : #f7b95e !important; } 
     .close_widget{   float:right;   font-weight: 100;    font-size: 20px; }
     .close_widget:hover{  color: #edeff5;  cursor: pointer; }
     legend{  color: #fff;   font-weight:400;  font-size:20px; padding:10px;}
     #theme-options {   position: fixed;   top: 10px;   right: -300px;   z-index: 9999;   width: 300px;   -webkit-transition: transform .5s ease;   -o-transition: transform .5s ease;   transition: transform .5s ease;}
    .btn.theme-switcher {    width: 54px;    height: 50px;    line-height: 50px;    display: block;   font-size: 27px;    border-width: 1px;    border-style: solid;    border-right: 0;    border-radius: 3px 0 0 3px;    text-align: center;    border-color: #fafbff;     background-color: #fafbff;    position: absolute;    left: -54px;    top: 125px;    z-index: 55;    padding: 0;  box-shadow: 0 5px 11px 0 rgba(35, 50, 55, 0.2), 0 4px 15px 0 rgba(35, 50, 55, 0.17);}
    .theme-switcher .glyph-icon {    width: 54px;    height: 50px;    line-height: 50px;    display: block;}
    .icon-spin {   -webkit-animation: spin 2s infinite linear;   -moz-animation: spin 2s infinite linear;    -o-animation: spin 2s infinite linear;    animation: spin 2s infinite linear;    font-size: 32px;}
    .panel > .panel-heading, .panel.panel-default > .panel-heading {  background :#fff; }
    .inbox-widget .inbox-item .inbox-item-total {    
        right: 65px; margin-top: 23px; font-weight: 500; font-size: 11px; line-height: 22px; position: absolute; top: 2px;  color: #a9a9a9;}
     </style>
 <?php


} elseif(has_user_permission('View Own', 'Dashboard')){ 
 
  $items_array =  array(
       1 => '<div class="col-sm-3" id="item-1"> <div class="panel panel-default top_counts"><div class="panel-body"> <div class="left" > <p class="count"> <i class="material-icons" > perm_identity </i></p> </div> <div class="right">  <p class="factor"> '.get_customers_count().' </p> <p class="small"> '._("Customers").' </p> </div></div></div></div>',
       2 => '<div class="col-sm-3" id="item-2"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > storage </i></p> </div> <div class="right">  <p class="factor"> '.get_items_count().' </p> <p class="small"> '._("Items").' </p> </div> </div> </div> </div>',
  ); 
  if($current_user['role'] == 'Salesman'){
  	$today_sale = today_sales_count_amount(null, $user_price_dec);
  	$yesterday_sale = today_sales_count_amount(1, $user_price_dec);
  	$month = today_sales_count_amount(2, $user_price_dec);

  	//var_dump($yesterday_sale);
    $items_array =  array(
       3 => '<div class="col-sm-3" id="item-3"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div> <div class="right"> <p class="factor"> '.$today_sale['count'].'</p> <p class="small"> '._("Today Sales Count").' </p> </div></div></div> </div>', 
       4 => '<div class="col-sm-3" id="item-3"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div> <div class="right"> <p class="factor"> '.$today_sale['amount'].'</p> <p class="small"> '._("Today Sales Amount").' </p> </div></div></div> </div>', 
       5 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div><div class="right">  <p class="factor"> '.$yesterday_sale['count'].' </p> <p class="small"> '._("Yesterday Sales Count").' </p>  </div></div> </div> </div>',
       6 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.$yesterday_sale['amount'].' </p> <p class="small"> '._("Yesterday Sales Amount").' </p>  </div></div> </div> </div>',
  	   7 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div><div class="right">  <p class="factor"> '.$month['count'].' </p> <p class="small"> '._("This month Sales Count").' </p>  </div></div> </div> </div>',
       8 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.$month['amount'].' </p> <p class="small"> '._("This month Sales Amount").' </p>  </div></div> </div> </div>',
     );	
	   ?>
     <div class="container dashboard" id="bodySection">
        <?php   foreach ($items_array as $key => $value) {
            echo $value;      
        }
 ?>
    	
    	<div class="row" >	

        <h3 class="NewCustomerInvoice" style="max-width: 300px;" > <span> <?php echo _("Sales Invoices"); ?> </span> <a  class="btn-floating btn-large primary-color" href="<?php echo get_url('pos'); ?>" > <i class="material-icons">insert_drive_file</i></a></h3>

        <label style="padding-left: 5%;margin-top: 20px;margin-bottom: -40px;line-height: 50px;"> <?php echo _("Filter Status"); ?> : <select name="FilterCustomerInvoice"  id="FilterCustomerInvoice"> 
            <option value="-1" > <?php echo _("All"); ?> </option>
            <option value="Overdue" > <?php echo _("Overdue"); ?> </option>
            <option value="Yet To Receive" > <?php echo _("Yet To Receive"); ?> </option> 
            <option value="Received" > <?php echo _("Received"); ?> </option>
          </select></label>   

        <label style="padding-left: 5%;margin-top: 20px;margin-bottom: -40px;line-height: 50px;"> <?php echo _("Date"); ?> : <select name="FilterDate"  id="FilterDate"> 
            <option value="-1" > <?php echo _("All"); ?> </option>
            <option value="ThisMonth" > <?php echo _("This Month"); ?> </option>
            <option value="LastMonth" > <?php echo _("Last Month"); ?> </option>  
            <option value="LastWeek" > <?php echo _("Last Week"); ?> </option>
            <option value="ThisWeek" > <?php echo _("This Week"); ?> </option>
            <option value="Yesterday" > <?php echo _("Yesterday"); ?> </option>
            <option value="Today" > <?php echo _("Today"); ?> </option></select></label>        
      </div>
      
    	<div class="row" >	
    		<table class="list bordered highlight" id="CustomerInvoices">
    				<thead><tr> <th> <?php echo _("Reference"); ?> </th> <th> <?php echo _("Customer Name"); ?> </th> <th> <?php echo _("Invoice Date"); ?></th> <th> <?php echo _("Due Date"); ?></th> <th> <?php echo _("Amount"); ?> </th> <th> <?php echo _("Yet To Receive"); ?></th><th> <?php echo _("Return"); ?></th><th> <?php echo _("Status"); ?></th> </tr></thead>
    		</table>
    	</div>	
    	
    	<div class="row">
    	   <h3 class="NewCustomerInvoice" style="max-width: 300px;float: left;"> <span> <?php echo _("Sales Return"); ?> </span></h3>
    		  <table class="list bordered highlight" id="ReturnInvoices">
    				<thead><tr> <th> <?php echo _("No"); ?> </th> <th> <?php echo _("Reference"); ?> </th> <th> <?php echo _("Customer Name"); ?> </th> <th> <?php echo _("Date"); ?></th> <th> <?php echo _("Amount"); ?> </th> </tr></thead>
    			</table>
    	</div>
     </div> 

 
       <!-- New message Structure -->
      <div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header" >
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
                  <h4 class="modal-title" id="PDFTitle" >
                     <i class="material-icons"> receipt</i> <?php echo _("Receipt"); ?>
                  </h4>
               </div>
               <div class="modal-body" style="min-height:500px;">
                <div style="min-height:500px;text-align: center;margin: 0 auto;vertical-align: middle;" id="PreLoaderImg">
              <img src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF" style="  padding-top: 25%;"> </div>
                  <div class="iframe-container" style="min-height:500px;">  
                     <iframe src="images/pdf/invoice.pdf">    </iframe>   
                  </div>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
               </div>
            </div>
         </div>
      </div>

       <!-- Return Modal Popup -->
      <div class="modal fade" id="SalesReturn" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
         <div class="modal-dialog" role="document">
            <div class="modal-content">
               <div class="modal-header" >
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
                  <h4 class="modal-title" id="PDFTitle" >
                     <i class="material-icons"> rotate_90_degrees_ccw</i> <?php echo _("Sales Return Record"); ?>
                  </h4>
               </div>
               <div class="modal-body" style="min-height:500px;">
                  <div class="row">
                        <div class="col-sm-12">
                           
                          <div class="col-md-6 form-group">
                              <label class="col-md-6 control-label"><?php echo _("Credit Reference"); ?></label>
                              <div class="col-md-6"><label id="CreditRef"> <?php echo $Refs->get_next(ST_CUSTCREDIT); ?></label></div>
                          </div>

                           <div class="form-group col-md-6">
                              <label class="col-md-6 control-label"><?php echo _("Invoice Reference"); ?></label>
                              <div class="col-md-6"><label id="R_invRef"> <?php echo  ''; ?></label></div>
                           </div>

                          <div class="form-group col-md-6">
                              <label class="col-md-6 control-label"><?php echo _("Credit Date"); ?></label>
                              <div class="col-md-6"><label id="R_date"> <?php echo  date('d-m-Y'); ?></label></div>
                           </div>
                          <div class="form-group col-md-6">
                              <label class="col-md-6 control-label"><?php echo _("Invoice Date"); ?></label>
                              <div class="col-md-6"><label id="R_invDate"> <?php echo ''; ?></label></div>
                           </div>

                           <div class="form-group col-md-6">
                              <label class="col-md-6 control-label"><?php echo _("Invoice No"); ?></label>
                              <div class="col-md-6"><label id="R_invNo"> <?php echo ''; ?></label></div>
                           </div>                    
                          

                           <div class="form-group col-md-6">
                              <label class="col-md-6 control-label"><?php echo _("Invoice Amount"); ?></label>
                              <div class="col-md-6"><label id="R_amt"> <?php echo ''; ?></label></div>
                           </div>
                        <input type="hidden" name="InvNumber" id="InvNumber" value="">
                        <input type="hidden" name="TotalReturnAmt" id="TotalReturnAmt" value="">
                    </div>
                    <div class="col-md-12">
                      <table id="SalesReturnCart">
                        <thead>
                          <tr> <th> <?php echo _("Item Name"); ?></th> <th> <?php echo _("Price"); ?> </th><th> <?php echo _("Qty"); ?></th> <th> <?php echo _("Return Qty"); ?></th> <th style="text-align: right;"> <?php echo _("Amount"); ?></th></tr>
                        </thead>
                        <tbody>

                        </tbody>
                      </table>
                    </div>
              </div>
                  
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal"> <?php echo _("Close"); ?></button>
                  <button type="submit" class="btn btn-primary" id="ReceiveGoods"><?php echo _("Submit"); ?></button>
               </div>
            </div>
         </div>
      </div>
       <script>
           $(function(){	 
          	var pric_Dec =  '<?php echo $user_price_dec; ?>';
          	ToReceiveTable = $("#CustomerInvoices").dataTable({
                    "processing": true,
                    "serverSide": true,
                    "order": [[ 6, "desc" ]],
                    "pageLength": 25,
          		  "dom": '<"FilterCustomerInvoice">frtip',
                    "ajax": "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes"
                });
          	  
          	  ToReceiveTable = $("#ReturnInvoices").dataTable({
                    "processing": true,
                    "serverSide": true,
                    "order": [[ 0, "desc" ]],
                    "pageLength": 25,
          		  "ajax": "<?php  echo get_url(); ?>ajax?ReturnInvoices=yes"
                });
          	  	  
          		//$("div.FilterCustomerInvoice").html('<h3 class="NewCustomerInvoice" style="max-width: 300px;float: left;" > <span> <?php echo _("Sales Invoice"); ?> </span> <a  class="btn-floating btn-large primary-color" href="<?php echo get_url('pos'); ?>" > <i class="material-icons">insert_drive_file</i></a></h3><label style="padding-left: 5%;margin-top: 20px;margin-bottom: -40px;line-height: 50px;"> <?php echo _("Filter Status"); ?> : <select name="FilterCustomerInvoice"  id="FilterCustomerInvoice"> <option value="-1" > <?php echo _("All"); ?> </option><option value="Overdue" > <?php echo _("Overdue"); ?> </option><option value="Yet To Receive" > <?php echo _("Yet To Receive"); ?> </option>	<option value="Received" > <?php echo _("Received"); ?> </option></select></label>');
          		
          		$("#FilterCustomerInvoice").on("change", function(){		
          			var FilterVal = $(this).val();		
          			var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal;
          			ToReceiveTable.api().ajax.url(newURL).load();
          		}); 

          		$("#FilterCustomerInvoice").on("change", function(){    
          			  FilterVal = $(this).val();    
          			  var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate;
          			  ToReceiveTable.api().ajax.url(newURL).load();
          			});

          		$("#FilterDate").on("change", function(){		
          			FilterDate = $(this).val();		      
          			var newURL = "<?php  echo get_url(); ?>ajax?CustomerInvoices=yes&FilterStatus="+FilterVal+"&FilterDate="+FilterDate;
          			ToReceiveTable.api().ajax.url(newURL).load();
          		}); 	
          		
          		
          		// Print the last processed invoice from the sales man
          	$("body").on("click", ".PrintReceipt", function(e){  //$('.PrintReceipt').on("click",function(e){    
          		$('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
          		$('#PayComplete').modal('hide'); 
          		$('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
          		var trans_no = $(this).data('trans_no');
          		var type = $(this).data('type');
          		if(type == 10)
          			var urll = 'ajax?PrepareReport=yes&trans_no='+trans_no;
          		else
          			var urll = 'ajax?PrepareReport=yes&trans_no='+trans_no+'&rep=113';
                  var ifrme_modal = $("#pdfModal");
                    $.ajax({
                      type: 'post',
                      url: urll,           
                      dataType: "json",
                      success: function (data) {            
                        var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();               
                        ifrme_modal.find('iframe').attr('src',ifram_url);     
                         $('#pdfModal').modal('show');
                         var title = ifrme_modal.contents().find("title").html();
                         $("#PDFTitle").html(data.actual_name+' - View');
                         $("#actual_name").val(data.actual_name);
                         $("#PreLoaderImg").hide();
                         $(".iframe-container").show();
                      }
                    });
                    $('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
          	});	
          	
          	$("body").on("keyup", ".ReturnQty", function(e){
                var max_qty = $(this).data('qty');
                var price = $(this).data('price');
                var stock_id = $(this).data('stock_id');
                var return_qty = $(this).val();
                var amt_td = $(this).parent().next();

                if(return_qty <= max_qty){
                  amt_td.html(formatMoney(price*return_qty, parseInt(pric_Dec) ));        
                } else{
                  alert('<?php echo _("You are inputting more than sold Quantity"); ?>');
                  $(this).val('');
                  amt_td.html(formatMoney(0, parseInt(pric_Dec) )); 
                }
                CalculateTotal();
              }); 

              function CalculateTotal(){
                var TotalReturnAmt = 0 ;
                $('.ReturnQty').each(function(i, obj) {
                     var qty = $(this).val();           
                    if(qty > 0 ){           
                      var price = $(this).data('price');
                      TotalReturnAmt +=price * qty;
                    }
                });
                  $(".TotalReturnAmt").html(formatMoney(TotalReturnAmt, parseInt(pric_Dec)));
                  $("#TotalReturnAmt").val(TotalReturnAmt);
              }
              $("body").on("click", "#ReceiveGoods", function(e){
                  var InvNumber = $("#InvNumber").val();
                  var TotalReturnAmt = $("#TotalReturnAmt").val();
          		var ifrme_modal = $("#pdfModal");
                  var final = [];
                  $('.ReturnQty').each(function(i, obj) {
                    var qty = $(this).val();
                    if(qty > 0 ){
                      var stock_id = $(this).data('stock_id');
                      var price = $(this).data('price');
                      var discount = $(this).data('discount');
                      final.push([stock_id, qty, price, discount]);
                    }
                  });
                  $.ajax({
                       url: 'ajax?WriteReturn=1',
                       type: 'post',
                       data: {'details':final, 'trans_no': InvNumber, 'amt' : TotalReturnAmt},             
                       success:function(response){
                          var id = parseInt(response.trim());
                          if(id > 0){
          					$('#SalesReturn').modal('hide'); 					
          					  $.ajax({
          						type: 'post',
          						url: 'ajax?PrepareReport=yes&trans_no='+id+'&rep=113',           
          						dataType: "json",
          						success: function (data) {  
          							ifrme_modal.find('iframe').attr('id','printf');
          							var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();               
          							ifrme_modal.find('iframe').attr('src',ifram_url);						       
          						   $('#pdfModal').modal('show');
          						   var title = ifrme_modal.contents().find("title").html();
          						   $("#PDFTitle").html(data.actual_name+' - View');
          						   $("#actual_name").val(data.actual_name);
          						   $("#PreLoaderImg").hide();
          						   $(".iframe-container").show();
          						}
          					  });
          					  $('.modal .modal-dialog').attr('class', 'modal-dialog  fadeInUp  animated');
          				}
                       }
                  });
                  console.log(final);
              });
          	
          	 $('body').on('load', "#printf", function() {
          		 var id = $(this).attr('src');
          		 var tabId = id.substr(id.length - 3);  		
          		 if(tabId == 'pdf')
          			document.getElementById('printf').contentWindow.print();
          	 });
          	 
              $("body").on("click", ".SalesReturn", function(e){
                var trans_no = $(this).data('trans_no');
                  $.ajax({
                    url: 'ajax?GetInvoice=yes&trans_no='+trans_no+'&return=yes',
                    type: 'POST',
                    data : {'trans_no': trans_no },  
                    dataType: 'JSON',   
                    success: function(data) {       
                      $("#CreditRef").html(); 
                      $("#R_invRef").html(data.reference);
                      $("#R_invDate").html(data.tran_date);
                      $("#R_invNo").html(data.trans_no);            
                      $("#R_amt").html(data.Total);  
                      $("#InvNumber").val(data.trans_no);
                      last_class = 'even';
                      $('#SalesReturn').find('tbody').empty();
                      $.each(data.line_items, function (key, val) {
                         if(last_class == 'odd')
                            class_name = 'even';
                         else
                            class_name ='odd';
                          if(val.quantity != val.qty_done && val.quantity > 0){
                            var price = parseFloat(val.unit_price).toFixed(3);				 
                            var qty_bal = val.quantity-val.qty_done;
          					// alert(val.quantity+'-'+val.qty_done);
                            var this_row = '<tr class="'+class_name+'" id="Cart_ID_'+val.id+'"><td>'+val.stock_id+' - '+val.description+'</td><td class="amount" >'+price+'</td><td>'+qty_bal+'</td><td class="form-group"><input type="text" class="form-control amount ReturnQty" data-stock_id="'+val.stock_id+'" data-qty="'+val.quantity+'" name="Cart_ID_'+val.id+'" data-price="'+price+'" data-discount="'+val.discount+'" value="" onkeypress="return IsNumeric(event);"> </td><td class="amt_'+val.id+' " style="text-align:right;"> 0.00</td></tr>';
                             $("#SalesReturnCart  > tbody:last-child").append(this_row);                
                            last_class = class_name;
                        }
                      }); 
                      var this_row = ' <tr> <td colspan="4" class="amount"> <?php echo _("Total"); ?></td> <td class="TotalReturnAmt amount">'+formatMoney(0, parseInt(pric_Dec) )+'</td></tr>';
                      $("#SalesReturnCart  > tbody:last-child").append(this_row);
                      $('#SalesReturn').modal('show'); 
                    } 
                  });        
              });
           });

          function formatMoney(amount, decimalCount = 2, decimal = ".", thousands = ",") {
            try {
              decimalCount = Math.abs(decimalCount);
              decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
              const negativeSign = amount < 0 ? "-" : "";
              let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
              let j = (i.length > 3) ? i.length % 3 : 0;
              return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
            } catch (e) {
              console.log(e)
            }
          }

          var specialKeys = new Array();
          specialKeys.push(8,46); //Backspace
          function IsNumeric(e) {
              var keyCode = e.which ? e.which : e.keyCode;
              console.log( keyCode );
              var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
              return ret;
          }
       </script>
       <style>
       #FilterCustomerInvoice, #FilterDate, #Salesman { border:0; padding: 7px; }
       #SalesReturn .modal-dialog { width: 700px; }
       #SalesReturn .form-group label.control-label { margin: 6px 0 0 0; }
       #SalesReturnCart tr th:first-child, #SalesReturnCart th td:first-child{ width:60%; }
       .amount { text-align: right; }
       #ReturnInvoices tr td:nth-child(5){ text-align: right; }
       </style>
      <?php  } 
  ?>

      <?php if(has_user_permission('View Deliveries', 'Dashboard')){

            $total_delivery = total_delivery_by_user($current_user['ID']);

            $today_delivery = today_deliveries_count_amount(null, $user_price_dec);
            $yesterday_delivery = today_deliveries_count_amount(1, $user_price_dec);
            $monthly_delivery = today_deliveries_count_amount(2, $user_price_dec);
            $new_delivery = get_new_delivery($current_user['ID']);

            $items_array =  array(
                 3 => '<div class="col-sm-3" id="item-3"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div> <div class="right"> <p class="factor"> '.$today_delivery['count'].'</p> <p class="small"> '._("Today Delivery Count").' </p> </div></div></div> </div>', 
                 4 => '<div class="col-sm-3" id="item-3"> <div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div> <div class="right"> <p class="factor"> '.$today_delivery['amount'].'</p> <p class="small"> '._("Today Delivery Amount").' </p> </div></div></div> </div>', 
                 5 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div><div class="right">  <p class="factor"> '.$yesterday_delivery['count'].' </p> <p class="small"> '._("Yesterday Delivery Count").' </p>  </div></div> </div> </div>',
                 6 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.$yesterday_delivery['amount'].' </p> <p class="small"> '._("Yesterday Delivery Amount").' </p>  </div></div> </div> </div>',
                 7 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div><div class="right">  <p class="factor"> '.$monthly_delivery['count'].' </p> <p class="small"> '._("This month Delivery Count").' </p>  </div></div> </div> </div>',
                 8 => '<div class="col-sm-3" id="item-4"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > account_balance_wallet </i></p> </div><div class="right">  <p class="factor"> '.$monthly_delivery['amount'].' </p> <p class="small"> '._("This month Delivery Amount").' </p>  </div></div> </div> </div>',
                 9 => '<div class="col-sm-3" id="item-5"><div class="panel panel-default top_counts"> <div class="panel-body"> <div class="left" >  <p class="count"> <i class="material-icons" > portrait </i></p> </div><div class="right">  <p class="factor" id="del_no"> '.$new_delivery.' </p> <p class="small"> '._("New Delivery").' </p>  </div></div> </div> </div>',
          ); 
     ?>
     <div class="container dashboard" id="bodySection">
        <?php   foreach ($items_array as $key => $value) {
            echo $value;      
        }

      ?>
      <input type="hidden" name="userid" value="<?php echo $current_user['ID'] ?>" id="userid"> 
                
      </div>
      <script type="text/javascript">
      $(document).ready(function(){
        var pusher;
        var channel4, notification;
        var userid = $('#userid').val();
         Pusher.logToConsole = true;
            pusher = new Pusher("<?php echo $pushers['app_id']; ?>", {
                  cluster: 'ap2',
                  forceTLS: true,
                  authEndpoint: 'ajax?pusher_auth'
                });
            notification = pusher.subscribe('channel-2');

            pusher.connection.bind('connected', function() {
              notification.bind('my-event-'+userid, addMessage);
            });

      });

       function addMessage(data) {
         var notificationsWrapper   = $('.dropdown-notifications');
          var notificationsToggle    = notificationsWrapper.find('a[data-toggle]');
          var notificationsCountElem = notificationsToggle.find('i[data-count]');
          var notificationsCount     = parseInt(notificationsCountElem.data('count'));
          var notifications          = notificationsWrapper.find('ul.dropdown-menu');
          get_new_delivery(data.id);
          if (notificationsCount <= 0) {
            notificationsWrapper.hide();
          }
          var existingNotifications = notifications.html();
          var avatar = Math.floor(Math.random() * (71 - 20 + 1)) + 20;
          var newNotificationHtml = '<li class="notification active"><div> <strong class="notification-title" style="color:#000">'+data.message+'</strong></div></li>';
          notifications.html(newNotificationHtml + existingNotifications);
          notificationsCount += 1;
          notificationsCountElem.attr('data-count', notificationsCount);
          notificationsWrapper.find('.notif-count').text(notificationsCount);
          notificationsWrapper.show();
        }
      function get_new_delivery(id){
   
     $.ajax({
            url:"ajax?numofDelivery=Yes",
            method:"POST",
            data:{'id':id},
            dataType:'JSON',
            success:function(data){   
              $('#del_no').html(data.count);
            }
        });
      }
            
      </script>
      <?php          } 
      
} 


get_footer(); ?>
