<?php 
/* Template Name :  Delivery Man 
*/ 

global $Refs, $price_dec, $current_user, $pushers;
if($current_user['role'] != 'Deliveryman') 
	kv_direct(get_url('404'));

get_header();
$price_dec =  user_price_dec();
$pushers = get_site_option('pusher'); 
$current_user = kv_get_current_user();


?>
<style type="text/css">
	.GridCategory { list-style: none; display: block; overflow: hidden; }
.GridCategory .List { width: calc(25% - 4%);   display: block; float: left; height: 130px;   text-align: center; color: #fff;  margin: 1%;  border: none; }
/* .GridCategory .List i { font-size: 40px;  width: 100%;  margin-top: 5% !important;  padding: 5%; color: #fff;  text-align: center;} */
.GridCategory .List label, .GridItemsList .List label{ color: #fff !important;  text-align: center;}
.GridItemsList { list-style: none; display: inline; }
.GridItemsList .List { width: calc(25% - 10px);   display: block; float: left; height: 130px;   text-align: center; color: #fff;  margin: 5px;  border: none; }
.GridItemsList .List i { font-size: 40px;  width: 100%;  margin-top: 5% !important;  padding: 3%; color: #fff;  text-align: center;}
.GridItemsList .List span { display: block; font-size: 18px; text-align: right;  font-style: italic;  padding-right: 10px;  line-height: 35px;}
#select2-CustomerId-container span, #select2-WaiterID-container span {  display: none; } 
#select2-CustomerId-container, #select2-WaiterID-container{ text-align: left; font-size: 15px;} 
html[dir="rtl"] #select2-CustomerId-container, html[dir="rtl"] #select2-WaiterID-container { text-align: right; font-size: 15px;}
/* Bounce In */
.GridItemsList .List, .GridItemsList .List{
  display: inline-block;
  vertical-align: middle;
  -webkit-transform: perspective(1px) translateZ(0);
  transform: perspective(1px) translateZ(0);
  box-shadow: 0 0 1px rgba(0, 0, 0, 0);
  -webkit-transition-duration: 0.5s;
  transition-duration: 0.5s;
}
.GridItemsList .List:hover, .GridItemsList .List:focus, .GridItemsList .List:active,
.GridCategory .List:hover, .GridCategory .List:focus, .GridCategory .List:active {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
  -webkit-transition-timing-function: cubic-bezier(0.47, 2.02, 0.31, -0.36);
  transition-timing-function: cubic-bezier(0.47, 2.02, 0.31, -0.36);
}
#summary_tbl { margin-top:15px; }
#BillingTable i.material-icons{ margin-right: 0 !important;padding-right: 5px;padding-left: 12px;}
tr.SideBarRow td { padding: 7px 15px; }
.Summary .PayNow{ text-align: center;padding: 13px 0; float: left; font-size: 18px;}
@media (min-width: 768px){    
  #summary_tbl tr td, #summary_tbl tr th {    padding-left: 8px;    padding-right: 8px;  }
  .GridCategory .List{  padding: 20px 0 !important; }
}
@media (min-width: 1366px){
  #summary_tbl tr td, #summary_tbl tr th { padding-left:15px; padding-right: 15px; } 
}
#summary_tbl tr td, #summary_tbl tr th {    padding: 4px 0;}
.GridCategory,.GridItemsList {  margin: 0;  padding: 0;  list-style: none;  list-style: none;  overflow: hidden;}
.GridCategory .List{  display: block;  padding: 50px 0;  text-align: center;  cursor: pointer; 
 background: #00ab64; /*#1bbc9b;*/  float: left;  color: #fff;  width: calc(16.5% - 20px);  margin: 10px;  transition-duration: 0.5s;}
.GridCategory .List {  width: calc(25% - 10px); display: block; margin: 5px; height: unset;  padding: 20px 0;}
.GridCategory .List .material-icons { font-size: 35px;}

 .GridCategory .List label{ display: block; color: #fff!important;}
 @media (max-width: 767px) {
  .GridCategory .List .material-icons {    font-size: 25px;  }
  .GridCategory .List {    padding: 15px 0;  }
}
@media (max-width: 520px) {
	.GridCategory .List ,.GridItemsList .List{ width: calc(25% - 13px); } 
}
@media screen and (max-width: 420px) {  
    .GridCategory .List .material-icons{    font-size: 19px;  }
    .GridCategory .List label, .GridItemsList .List label{  margin:3px;   font-size: 12px;    text-transform: capitalize;  }
    .GridItemsList .List i{     font-size: 30px;  }
    .GridItemsList .List span{   font-size: 16px;  }
	.GridCategory .List, .GridItemsList .list {  margin: 3px; }
  .Summary .PayNow, .PrintInvoice { font-size:13px;}
}
@media screen and (max-width: 390px) {    
	.GridCategory .List,.GridItemsList .list{  margin: 3px;     width: calc(25% - 9px);}
	
}

</style>
<!-- Username: bilal password:password -->
<div class="container" id="bodySection">
	<div class="row">
		<div class="col-md-8">
			<h3 style="margin-bottom: 40px;"> <?php echo _("Delivery List"); ?> </h3>
			
	      <div class="row">   
	      	<ul class="GridItemsList"> 
	      		
     
	      	</ul> 
	      </div> 
		</div>
		<div class="col-md-4"> 
      <div class="item_details" style="display:none">

      <style>
        #summary_tbl tr td.second{
          display: block;
          float: right;
          padding-bottom: 11px;
          padding-right: 15px;
        }
      </style>
      <table class="list highlight Summary" id="summary_tbl">
        <tbody>
          <tr class="Title">
            <td colspan="2">
             <i class="material-icons" style="line-height: 45px;float:none;margin:0">person</i> <span style="font-size: 20px; font-weight: 400; line-height: 45px; vertical-align: top;"><?php echo _("Customer"); ?></span>
            </td>
          </tr>
          <tr style="background:#fff">
            <td style="padding-left:10px"><?php echo _("Customer Name"); ?></td>
            <td>
              <div class="form-group">
                <input type="hidden" name="userid" value="<?php echo $current_user['ID'] ?>" id="userid"> 
                <input type="text" name="CustomerName" id="CustomerName" style="width: calc( 100% - 30px); float: left;" disabled>                
                <input type="hidden" name="customer_id" id="customer_id" value="<?php echo $_SESSION['CustomerId'] ?>">
                <input type="hidden" name="payment_terms" id="payment_terms" value="<?php echo $_SESSION['payment_terms']?>">
                <input type="hidden" name="sales_type_id" id="sales_type_id" value="<?php echo $sales_type_id; ?>" >
                <input type="hidden" name="tax_included" id="tax_included" value="<?php echo $_SESSION['tax_included']; ?>" >
                <input type="hidden" name="tax_group_id" id="tax_group_id" value="<?php echo $_SESSION['tax_group_id']; ?>" >
                <input type="hidden" name="curr_code" id="curr_code" value="<?php echo $_SESSION['curr_code']; ?>" >
                <input type="hidden" name="currency" id="currency" value="<?php echo $_SESSION['currency']; ?>" >
              </div>  
            </td> 
          </tr>
         
          <tr style="background:#fff">
            <td style="padding-left:10px"><?php echo _("Customer Phone"); ?></td>
            <td class="second"><span id="c_phone"></span></td>
          </tr>
          <tr style="background:#fff">
            <td style="padding-left:10px"><?php echo _("Customer Email"); ?></td>
            <td class="second"><span id="c_email"></span></td>
          </tr>
          <tr style="background:#fff">
            <td style="padding-left:10px"><?php echo _("Customer Address"); ?></td>
            <td class="second"><span id="c_address"></span></td>
          </tr>
        </tbody>
      </table>
      <!-- Items Table list  -->
      <div class="ItemsTable" style="background: #fff;" >
       
        <div class="ItemsTableTitle" style=" text-align: center; padding: 15px 0;"> 
          <h3> <?php echo _("Orders"); ?> <span class="text-center tableNumText"><span class="text_title"><?php echo $text;?></span>&nbsp;<span class="tablenum"><?php echo $textNum; ?></span></span></h3></div>
          
        <!--  Billing Table list Items -->
          <table class="list bordered highlight dataTable" id="BillingTable">  
            <thead>
              <tr>  
                <td style="width:60%"> <?php echo _("Item Name"); ?> </td>  
                <td style="width:20%"><?php echo _("Quantity"); ?></td> 
                <td style="width:20%"><?php echo _("Price"); ?></td> 
                
              </tr>                 
            </thead>                      
            <tbody> <?php                               
             
						    echo '<tr class="noItemsClass" > <td colspan="8" > <center> '._("No Items In it").' </center> </td> </tr>';
              ?>
            </tbody>
            <tfoot class="Summary">
              <tr class="GrandTotal">
                <td colspan="4">
                  <span class="small"><?php echo _("Total"); ?></span>
                  <span class="currency" ><?php echo $_SESSION['currency']; ?>
                  </span>
                  <span id="total_amount"> <?php echo (isset($_SESSION['grand_total']) ? $_SESSION['grand_total'] : number_format2(0, $price_dec)); ?></span>
                </td>
              </tr>
              <tr class="SideBarRow">
                <td><?php echo _("Payment Mtd"); ?></td>
                <td colspan="3">
                  <div class="form-group">
                     <select class="form-control" name="payment_method" id="payment_method" tabindex="6">
                     <?php  $sql ="SELECT terms_indicator, terms FROM ".TB_PREF."payment_terms WHERE days_before_due = 0 AND day_in_following_month = 0 ORDER BY terms LIMIT 1";
                        $sales_typ_res= fadb_query($sql, "can't get results");
                        if($row = fadb_fetch($sales_typ_res)){
                          echo '<option value="'.$row['terms_indicator'].'" data-id="cash"> '. _("Cash Only").' </option>';
                          echo '<option value="'.$row['terms_indicator'].'" data-id="card"> '. _("Credit/Debit Card").' </option>';
                        }
                        $sql ="SELECT terms_indicator, terms FROM ".TB_PREF."payment_terms WHERE days_before_due > 0 OR day_in_following_month > 0 ORDER BY terms LIMIT 1";
                        $sales_typ_res= fadb_query($sql, "can't get results");
                        if($row = fadb_fetch($sales_typ_res)){
                          echo '<option value="'.$row['terms_indicator'].'" data-id="later"> '. _("Pay Later").' </option>';
                        }
                        ?>
                     </select>
                  </div>
               </td>
            </tr>
            <tr class="SideBarRow TransRef">
              <td><?php echo _("Trans Ref"); ?> </td>
              <td colspan="3"><input class="form-control" type="text" id="trans_ref" name="trans_ref" tabindex="7"></td>        
            </tr>
            <tr class="SideBarRow TenderTr">
              <td><?php echo _("Tender"); ?><span class="currency" style="float: right;" ><?php echo $_SESSION['currency'] ?></span> </td>
              <td colspan="3">

                <input class="form-control" placeholder="<?php  echo $_SESSION['grand_total']; ?>" type="text" id="user_paid" name="user_paid" tabindex="8"></td>         
            </tr>
            <tr class="Balance">
              <td colspan="4"><i class="material-icons">tab_unselected</i><span class="small"><?php echo _("Balance"); ?></span>&nbsp;<span class="currency"><?php echo $_SESSION['currency'] ?></span> <span id="balance"><?php echo number_format2(0, $price_dec); ?></span></td>
            </tr>
            <tr class="Pay">
              <td colspan="4" style="padding:0;">
                <button class="btn PayNow" type="submit" id="PayNow" tabindex="9"><i class="material-icons"></i> <span class="submitText"> <?php echo _("Pay & Complete"); ?></span></button>  
               </td>
            </tr>
          </tfoot>       
        </table>          
        <input type="hidden" name="order_id" id="order_id" value="0">
        <input type="hidden" name="cart_items_count" id="CartItemsCount"  value="<?php echo (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item']) ? count($_SESSION['cart_item']) : 0 ); ?>" >
        <input type="hidden" name="total_amount" id="total_amount" value="<?php echo $_SESSION['grand_total'] ?>">         
      </div> 
      </div>
    </div> 
		
	</div>
</div>
<script>
$(document).ready(function(){
  var pusher;
  var channel4, notification;

   Pusher.logToConsole = true;
  
      var userid = $('#userid').val();
      get_numofDelivery(userid);
      
      pusher = new Pusher("<?php echo $pushers['app_id']; ?>", {
            cluster: 'ap2',
            forceTLS: true,
            authEndpoint: 'ajax?pusher_auth'
          });
      // notification = pusher.subscribe('channel-2');
      channel4 = pusher.subscribe('channel-4');

      pusher.connection.bind('connected', function() {
        // notification.bind('my-event-'+userid, addMessage);
        channel4.bind('event-'+userid, load_delivery);
      });

})
      
$(document).bind('keydown', 'shift+t', function(e){  //Barcode Scanner
   $('#user_paid').focus();
   
  });
$(document).ready(function(){
  var userid = $('#userid').val();
  get_numofDelivery(userid);
  $('.item_details').hide();
  $(".TransRef").hide();
  $('.toggle').click(function() {
    if ( !$(this).next().hasClass('in') ) {
      $(this).parent().children('.collapse.in').collapse('hide');
    }
    $(this).next().collapse('toggle');
  });

     $(document).on('click', '.GridItemsList li', function(e){
      e.preventDefault();
      var id = $(this).data('del_num');
      $('.item_details').css('display', 'block');
      load_delcart_data(id);
    });

  $('#CustomerId').change(function(e){
    e.preventDefault();
      var cid = $(this).val();
      
      $.ajax({
        url: 'ajax?GetCustomer=1',
        type: 'POST',
        data: {cid: cid},
        dataType: 'json',
        success: function(data){
          $('.currency').html(data.currency);
          $('#currency').html(data.currency);
          $('#sales_type_id').val(data.sales_type_id);
          $('#tax_group_id').val(data.tax_group_id);         
          $('#payment_terms').val(data.payment_terms);
          

      }
      })
   });
   $("#payment_method").on("change", function(){
    var data = $(this).find(':selected').data('id');
    if(data == 'card'){
      $(".TransRef").show();
      $(".TenderTr").show();
    }else {
      $(".TransRef").hide();
      if(data == 'later'){
        $(".submitText").text('<?php echo _("Complete"); ?>');
        $(".TenderTr").hide();
        $("#PayNow").focus();
      }else {
        $(".submitText").text('<?php echo _("Pay &amp; Complete"); ?>');
        $(".TenderTr").show();
      }
    }
  });
   user_paid = 0;  
   $('body').on("keyup", '#user_paid', function(){     
      var total_val = $('#total_amount').text();
      var user_input = $(this).val();
      var balance = (parseFloat(user_input) - parseFloat(total_val)).toFixed(<?php echo $price_dec; ?>);      
      if(user_input){
       $('#balance').html(balance);
      }else{
    $('#balance').html('');
      }
    if(balance >= 0 && user_paid==0){
      $('#PayNow').focus();
      user_paid = 1;
      }
   });

   $(document).on("click", "#PayNow", function(e){ 
      e.preventDefault(); 
      var cartCount = $("#CartItemsCount").val();
      
      let user_paid = $('#user_paid').val();
      let grand_total = $('#total_amount').val();
      if( user_paid == ''){
        alert('<?php echo _("Please Enter amount"); ?>');
        return false;
      }
     
      if(cartCount > 0) {       
           
        var payment_method = $('#payment_method').val();
        var payment_id = $('option:selected', '#payment_method').data('id');
               
        var trans_ref = $('#trans_ref').val();
        var userid = $('#userid').val();
        $.ajax({
          url: 'ajax?delivarypayment=completed',
          type: 'POST',  
          data : { 'payment_terms' : payment_method, 'trans_ref' : trans_ref, 'pmt_type' : payment_id, 'userid' : userid},
          dataType: "json",
          success: function(data) { 
              
          }
        }); 
      } 
    });
});
 
function load_delivery(data){
  addMessage(data);
  var user_paid = 0;
  $("#BillingTable > tbody").html('<tr class="noItemsClass" > <td colspan="8"> <center> <?php echo _("No Items In it"); ?> </center> </td> </tr> ');
  $('#total_amount').html('<?php  echo number_format2(0, $price_dec); ?>');
  $('#balance').html('<?php  echo number_format2(0, $price_dec); ?>');
  $('#user_paid').val('');    
  $("#user_paid").attr("placeholder", 0);
  $("#CartItemsCount").val(0);


}
function addMessage(data) {
 var notificationsWrapper   = $('.dropdown-notifications');
  var notificationsToggle    = notificationsWrapper.find('a[data-toggle]');
  var notificationsCountElem = notificationsToggle.find('i[data-count]');
  var notificationsCount     = parseInt(notificationsCountElem.data('count'));
  var notifications          = notificationsWrapper.find('ul.dropdown-menu');
  get_numofDelivery(data.id);
  if (notificationsCount <= 0) {
    notificationsWrapper.hide();
  }
  var existingNotifications = notifications.html();
  var avatar = Math.floor(Math.random() * (71 - 20 + 1)) + 20;
  var newNotificationHtml = '<li class="notification active"><div> <strong class="notification-title" style="color:#000">'+data.message+'</strong></div></li>';
  notifications.html(newNotificationHtml + existingNotifications);
  notificationsCount += 1;
  notificationsCountElem.attr('data-count', notificationsCount);
  notificationsWrapper.find('.notif-count').text(notificationsCount);
  notificationsWrapper.show();
}
    // Get Number of delivery by deliverd man
     function get_numofDelivery(id){
   
     $.ajax({
            url:"ajax?get_numofDelivery=Yes",
            method:"POST",
            data:{'id':id},
            dataType:'JSON',
            success:function(data){   
              content = '';
              if(data.length ==0){
                content +='<li><?php echo _("No Delivery"); ?></li>';
              }
              $.each(data, function(i, item){
		          if(parseFloat(data[i].delivery_no) > 0 && data[i].selected != 'undefined')

		          content +='<li id="delListItem'+data[i].order_no+'" class="List bg_blue_dark3 item'+data[i].selected+'" data-del_num="'+data[i].delivery_no+'"><i class="material-icons">delivery_dining</i><label><p> Delivery '+data[i].delivery_no+ '</p></label></li>';

		        });
		              
             $('.GridItemsList').html(content);
            }
        });
  }
  
  function load_delcart_data(id){
  	
  	var CustId = $("#CustomerId").val();
    $.ajax({
      url: "ajax?load_delcart_data=Yes",
      type: "POST",
      data: {del_no: id},
      dataType: 'JSON',
      success: function(data){  
      console.log(data);      
        if(data.cart_count > 0){
        var rowCount = $('#BillingTable tbody > tr.noItemsClass');
        if(rowCount.length == 1){    rowCount.remove();   }  
        var last_class = $("#BillingTable > tbody > tr:last").attr('class');
        if(last_class == 'odd')
        class_name = 'even';
         else
        class_name ='odd';
        this_row = '';
        row_val = '';
          $.each(data.cart_data, function(i, item) {
            
            this_row += '<tr class="'+class_name+'" id="Cart_ID_'+i+'"><td>'+data.cart_data[i].name+' </td><td class="qtyEdit" data-id="'+i+'">'+data.cart_data[i].qty+'</td><td>'+data.cart_data[i].price+'</td></tr>';
          
          });          
         $("#BillingTable > tbody").html(this_row);
         $(".currency").html(data.currency);
         // $("select#CustomerId").val(data.CustomerId);     
         $('#total_amount').html(data.grand_total);
         $("#user_paid").attr("placeholder", data.grand_total);
         $('#c_phone').text(data.CustomerPhone);
         $('#c_email').text(data.CustomerEmail);
         $('#c_address').text(data.CustomerAddress);

        if(CustId != data.CustomerId){
          setTimeout(function(){
            
           change_customer(data.CustomerId);

          },1000);
        }
          

			  
          $("#CartItemsCount").val(data.cart_count);
         
        }else{
          $("#BillingTable > tbody").html('<tr class="noItemsClass" > <td colspan="8" > <center> <?php echo _("No Items In it "); ?></center> </td> </tr> ');
         console.log(data.grand_total);
          $('#total_amount').html(data.grand_total);
          $("#CartItemsCount").val(data.cart_count);
         $('#order_id').val(data.order_id);

        }        
      }
    });
  }

function change_customer(customer_id){

  $.ajax({
        url: 'ajax?GetCustomer=1',
        type: 'POST',
        data: {cid: customer_id},
        dataType: 'json',
        success: function(data){
          $('.currency').html(data.currency);
          $('#currency').html(data.currency);
          $('#sales_type_id').val(data.sales_type_id);
          $('#tax_group_id').val(data.tax_group_id);  
          $('#payment_terms').val(data.payment_terms);

          $('#CustomerName').val(data.name);
          // $("#CustomerId option[value=" + data.id +"]").attr("selected","selected");
          $('#customer_id').val(data.id);

      }
      });
}
</script>

<?php get_footer(); ?>