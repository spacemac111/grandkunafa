 <?php 
   /*
   Template Name : KOT Restaurant 
   */ 
   global $Refs, $price_dec, $current_user, $pushers;
   get_header(); 
   if(has_user_permission('View Overall', 'POS & KOT')) {
   $price_dec =  user_price_dec();
   $pushers = get_site_option('pusher'); 
   //$non_detailed_sales_kit = get_company_details('non_detailed_sales_kit');
   ?>
<style type="text/css">
/* #bodySection .material-icons { float:left; margin-top:7px; margin-right:10px; } */
#col-left { background:#f5f6f7; height:100%}
#col-middle { background:#efeeee}
#col-right { background:#fff}
h3 { text-align: left; font-weight: 400;}
.GridCategory_2 .List {   width: calc(10% - 2%); display: block; float: left; height: 70px; text-align: center; color: #fff;  margin: 1%;  border: none; }
.GridCategory { list-style: none; display: block; overflow: hidden; }
.GridCategory .List { width: calc(25% - 4%);   display: block; float: left; height: 130px;   text-align: center; color: #fff;  margin: 1%;  border: none; }
/* .GridCategory .List i { font-size: 40px;  width: 100%;  margin-top: 5% !important;  padding: 5%; color: #fff;  text-align: center;} */
.GridCategory .List label, .GridItemsList .List label { color: #fff !important;  text-align: center;  min-height:50px;}
.GridItemsList { list-style: none; display: inline; }
.GridItemsList .List { width: calc(25% - 10px);   display: block; float: left; height: 130px;   text-align: center; color: #fff;  margin: 5px;  border: none; }
.GridItemsList .List i { font-size: 20px;  width: 100%;  margin-top: 5% !important;  padding: 3%; color: #fff;  text-align: center;}
.GridItemsList .List span { display: block; font-size: 12px; width: 49%;/*text-align: right; */ font-style: italic;  padding-right: 0px;  line-height: 35px;}

/* Bounce In */
.GridItemsList .List, .GridCategory .List  {
  display: inline-block;
  vertical-align: middle;
  -webkit-transform: perspective(1px) translateZ(0);
  transform: perspective(1px) translateZ(0);
  box-shadow: 0 0 1px rgba(0, 0, 0, 0);
  -webkit-transition-duration: 0.5s;
  transition-duration: 0.5s;
}
.GridItemsList .List:hover, .GridItemsList .List:focus, .GridItemsList .List:active,
.GridCategory .List:hover, .GridCategory .List:focus, .GridCategory .List:active {
  -webkit-transform: scale(1.1);
  transform: scale(1.1);
  -webkit-transition-timing-function: cubic-bezier(0.47, 2.02, 0.31, -0.36);
  transition-timing-function: cubic-bezier(0.47, 2.02, 0.31, -0.36);
}

#select2-CustomerId-container span, #select2-WaiterID-container span {  display: none; } 
#select2-CustomerId-container, #select2-WaiterID-container{ text-align: left; font-size: 15px;} 
html[dir="rtl"] #select2-CustomerId-container, html[dir="rtl"] #select2-WaiterID-container { text-align: right; font-size: 15px;}
.nav-tabs li.nav-item { width: 33.33%; text-align: center; }
.nav-tabs i.material-icons {  width: 100%;}
.ItemsHeader .form-group {    width: 50%; float: left; }
.ItemsHeader h4 {    width: 100%; float: left;  font-weight: 400;  line-height: 50px; font-size: 20px;}
.ItemsTableTitle h3 { text-align: center;  background: #fed;  margin: 0; padding: 15px 0;} 
.ItemsTable { overflow-y:  auto; }
#qtyEditTxt{width: 50px}
#summary_tbl { margin-top:15px; }
#doorList {
    display: flex;
    align-items: stretch;
}
.del_plan label{
  font-size: 13px;
}
.del_plan label p{
  margin-bottom: 2px;font-weight: 700;

}
.ItemsTable .PrintReceipt  { background: #E91E63; font-size: 20px;  text-align: center;   color: #fff;   font-weight: 400;padding: 13px 0;  width: calc( 50% - -2px); float: left; }
.ItemsTable .PrintReceipt:hover  { background: #E91E63 !important; opacity: 0.9;}
.Save_order:hover{ background: #03a9f4 !important; opacity: 0.9;}
.ItemsTable .Save_order { background: #03a9f4; font-size: 20px;  text-align: center;   color: #fff;   font-weight: 400; padding: 13px 0;    width: calc( 50% - 2px);}
.ItemsTable .PrintToken {  background: #03a9f4; font-size: 20px;  text-align: center;   color: #fff;   font-weight: 400; padding: 13px 0;    width: calc( 33% - 1px);}
.ItemsTable .small { font-size: 14px;   vertical-align: middle;text-align: left; }
#BillingTable i.material-icons{ margin-right: 0 !important;padding-right: 5px;padding-left: 5px;}

@media (min-width: 768px){    
  .ItemsTable .PrintReceipt  { font-size: 16px; width: calc( 50% - -2px);}
  .ItemsTable .Save_order {  font-size: 16px;width: calc( 50% - 2px);}
  .ItemsTable .PrintToken {  font-size: 16px;width: calc( 33% - 1px);}

  #summary_tbl tr td, #summary_tbl tr th {    padding-left: 8px;    padding-right: 8px;  }
  .tableBox li, .GridCategory .List, .token_box li, .door_box li{  padding: 12px 0 !important; }
}
@media (max-width: 768px){ 
  /* .GridCategory .List{   width: calc(23.33% - 10px) !important;  } */
}
@media (min-width: 1366px){
  .ItemsTable .btn{font-size: 18px;}
  #summary_tbl tr td, #summary_tbl tr th { padding-left:15px; padding-right: 15px; } 
}
 .GrandTotal td { background: #4caf50; font-size: 25px; text-align: center; color: #fff;  font-weight: 400;}
.ItemsTable .btn { margin: 0; }
img { max-width: 100%;}
.buttons-wrap { margin-bottom: 0;}
.buttons-wrap ul { margin: 15px 0; padding: 0; position: relative;}
.buttons-wrap ul li {  display: inline-block;}
.buttons-wrap ul a {  display: block;  background-color: #4caf50;  padding: 12px 25px;}
.table-plan-content-wrap {  overflow: hidden;  margin: 0;}
.table-plan-content-wrap .card-body {  margin-bottom: 15px;}
.table-plan-content-wrap .category {  cursor: pointer;}
.tableBox, .GridItemsList, .GridCategory, .token_box, .door_box {  margin: 0;  padding: 0;  list-style: none;  list-style: none;  overflow: hidden;}
.tableBox li, .GridCategory .List, .token_box li, .door_box li{  display: block;  padding: 50px 0;  text-align: center;  cursor: pointer; 
 background: #00ab64; /*#1bbc9b;*/  float: left;  color: #fff;  width: calc(16.5% - 20px);  margin: 10px;  transition-duration: 0.5s;}
.GridCategory .List {  width: calc(25% - 10px); display: block; margin: 5px; height: unset;  padding: 20px 0;}
.GridCategory .List .material-icons { font-size: 35px;}
.tableBox li:hover, .token_box li:hover, .door_box li:hover{ -webkit-transform: scale(1.1); transform: scale(1.1);
  -webkit-transition-timing-function: cubic-bezier(0.47, 2.02, 0.31, -0.36);
  transition-timing-function: cubic-bezier(0.47, 2.02, 0.31, -0.36);
}
.tableBox li label, .GridCategory .List label, .token_box li label, .door_box li label{ display: block; color: #fff!important;}
.tableNumText {  font-size: 16px;  color: #E91E63;  }
/*.buttons-wrap .tableNumText {display: block; position: absolute; left: 20%; top: 50%;  font-size: 20px;   color: #e91e63;   font-weight: bold; transform: translateY(-50%);}*/
.ItemsTable .PrintReceipt:hover {  color: #fff;}
#summary_tbl tr td, #summary_tbl tr th {    padding: 4px 0;}
.ItemsTableTitle h3 {    padding: 15px 0;}
.buttons-wrap { margin-bottom: 12px }
/*.buttons-wrap .btn.active  {  background-color: #9C27B0!important;} */
.buttons-wrap .btn.btn-lg  {  padding: 15px 15px;}
.buttons-wrap .btn-group  {  margin-top: 0!important;}
.buttons-wrap .btn, .buttons-wrap .btn:hover, .buttons-wrap .btn:focus { box-shadow: 0 0 0!important; }
@media (max-width: 991px) {
  .tableBox li, .token_box li, .door_box li {    width: calc(14% - 10px);    padding: 15px 0;    margin: 5px;  }
 /* .tableNumText {    position: inherit;    transform: translate(0);    text-align: center;    left: 0;  }
  .buttons-wrap .tableNumText {    display: none!important;  }*/
}
tr.SideBarRow td { padding: 7px 15px; }
.Summary .PayNow{ width: calc(50% -  -2px);padding: 13px 0; float: left; font-size: 18px;}
.PrintInvoice{ background: #eabb00; padding: 13px 0; font-size: 18px; width: calc(50% - 3px); color: #f00 !important; float: left; text-align: center; font-weight: 400;}
.PrintInvoice:hover { background-color :  #af8d07 !important; color : #fbfbfb !important;} 
@media (max-width: 767px) {
  .tableBox li, .token_box li, .door_box li {    width: calc(33.33% - 10px);    padding: 10px 0;    margin: 5px;  }
  .tableBox li label, .token_box li,.door_box li{    font-size: 14px;  }
  .buttons-wrap ul a {    padding: 8px 8px;    font-size: 14px!important;    text-transform: capitalize;  }
  .GridCategory .List .material-icons {    font-size: 25px;  }
  .GridCategory .List {    padding: 15px 0;  }
  .ItemsTable .Save_order, .ItemsTable .PrintReceipt {    font-size: 13px;    padding: 14px 0;  }
  .buttons-wrap .btn.btn-lg {   padding: 10px 20px;   font-size: 14px;  }
}
@media (max-width: 520px) {
  .buttons-wrap .btn.btn-lg {   padding: 10px 8px;   font-size: 14px;  }
  .container{ max-width: 100%; padding :0 5px;} 
  .ItemsHeader .form-group, h3 .form-group { right: 10px;}
  .GridCategory .List, .GridItemsList .List { width: calc(25% - 13px); } 
}
@media screen and (max-width: 420px) {    
    .buttons-wrap .btn.btn-lg{   font-size: 12px;    padding: 12px 10px;  }
  .Summary .PayNow, .PrintInvoice { font-size:13px;}
  .ItemsHeader .form-group, h3 .form-group {margin-top: 5px; }
  .ItemsHeader h4 {   padding-left: 15px; }
    .GridCategory .List .material-icons{    font-size: 19px;  }
    .GridCategory .List label, .GridItemsList .List label{  margin:3px;   font-size: 12px;    text-transform: capitalize; }
    .GridItemsList .List i{     font-size: 30px;  }
    .GridItemsList .List span{   font-size: 16px;  }
    #accordion .buttons-wrap .btn-group i.material-icons{font-size: 18px}
  .row { margin-left: -8px; } 
  .GridCategory .List, .GridItemsList .List {  margin: 3px; }
}
@media screen and (max-width: 390px) {    
  .buttons-wrap .btn.btn-lg{   font-size: 11px;    padding: 12px 7px;  }
  .GridCategory .List, .GridItemsList .List {  margin: 3px;     width: calc(25% - 9px);}
  .PrintInvoice {  padding:12px 0; }
  span.select2.select2-container.select2-container--material { width : 0; }
  
}
.tableBox .ordered, .token_box .ordered, .door_box .ordered{  background: #2196F3;}
.tableBox .delivered, .token_box .delivered, .door_box .delivered{  background: #fd9e13;}
.tableBox li.unslected{
 /* border: 4px solid rgba(50, 115, 220, 0.3);*/
}
/*.PrintReceipt, .PrintToken, .Save_order { width: 33.33%; }*/
.ItemsTable .PrintReceipt[disabled] { color: #fff;   background: #ff5b93; }
.checkbox label, .radio label, label { font-size: 18px;font-weight:600; }
.Customer_Data td { padding: 1px 12px; }
.Customer_Data table.bordered > tbody > tr { border-bottom: 0; }
.Customer_Data .form-control, .Customer_Data .form-group { padding:0; }
.Customer_Data .select2-container--material .select2-selection--single .select2-selection__arrow { display: none; }
#client_name_list .form-group .select2-container--material { width: calc(100% - 50px) !important; float: left;}
.ClientAddNew { margin-top:15px; }
#ClientAddNew .select2-container--material .select2-selection--single .select2-selection__arrow { margin-top:-25px !important; }
</style>
 <!--   ###########  Body Section ##############  -->     
<div class="container" id="bodySection" >
  <div class="row"> 
    <div class="col-md-8" >
      <?php //var_dump($_SESSION); ?>
      <input type="hidden" name="TableNo" id="TableNo" value="<?php echo ((isset($_SESSION['TableNo']) && $_SESSION['TableNo'] > 0 ) ? $_SESSION['TableNo'] : '' ); ?>"> 
      <input type="hidden" id="token_no" name="token_no" value="<?php echo ((isset($_SESSION['token_no']) && $_SESSION['token_no'] > 0 ) ? $_SESSION['token_no'] : '' );?>">
      <input type="hidden" id="del_no" name="del_no" value="<?php echo ((isset($_SESSION['del_no']) && $_SESSION['del_no'] > 0 ) ? $_SESSION['del_no'] : '' );?>">

      <input type="hidden" id="last_token_no" name="last_token_no" value="<?php echo FAGetSingleValue('sales_orders', 'MAX(`token_no`)', array('trans_type' => ST_SALESORDER));?>">
      <input type="hidden" id="button_status" name="button_status" value="<?php echo (isset($_SESSION['status']) ? $_SESSION['status'] : ''); ?>">
      <input type="hidden" name="token_plan_no" id="token_plan_no" value="0">
      <!--  Categories Search -->
      <div class="row"><div class="col-md-6" > <h3 style="margin-bottom: 25px;"><?php echo _("Categories"); ?> </h3> </div>
       <div class="col-md-6"><div class="form-group label-floating is-empty" id="label_search">
          <label class="control-label"><?php echo _("Search") ?></label>
          <input type="text" class="form-control typeahead" name="Search" id="CatSearch">
          <span class="material-input"></span> 
        </div>
        <div style="clear:both;"></div>
        </div>
        </div>
      
      <div class="row"> 
        <ul class="GridCategory"> </ul> 
      </div>
      <div class="row ItemsHeader"> 
        <h4>  <div class="col-sm-6"><?php echo _("Items"); ?> <button type="button" name="resetProduct" class="btn btn-raised btn-primary resetProduct">Reset Product</button> </div>
           <div class="col-sm-6">

          <div class="form-group label-floating is-empty" id="label_search" style="float:right;width: 100%;">
            <label class="control-label"><?php echo _("Search"); ?></label> 
            <input type="text" class="form-control typeahead " name="Search" id="ItemSearch">
            <span class="material-input"></span> 
          </div>
          
        </div>
        </h4>
       
       
        <!-- </h4>  -->
      </div> 
      <div class="row">   <ul class="GridItemsList">      </ul> </div> 
    </div> 
    <!-- Summary Table Customer List Section -->
    <div class="col-md-4" > 
      <div class="Customer_Data">
      <table class="list highlight Summary" id="summary_tbl">
        <tbody>
          <tr class="Title">
            <td colspan="2">
             <i class="material-icons" style="line-height: 45px;float:none;margin:0">person</i> 
             <span style="font-size: 20px; font-weight: 400; line-height: 45px; vertical-align: top;"><?php echo _("Customer"); ?></span>
            </td>
          </tr>
          <tr style="background:#fff">
            <td style="padding-left:10px"><?php echo _("Customer Name:"); ?></td>
            <td>
              <div class="form-group">
                <select class="form-control" name="CustomerId" id="CustomerId" style="width: calc( 100% - 30px); float: left;" > 
                  <?php 
                  $selected_customer = (int)(isset($_SESSION['CustomerId']) ? $_SESSION['CustomerId'] : 0 );
                  if($selected_customer > 0 )
                    echo '<option value="'.$selected_customer.'"  selected ="selected" > '. $_SESSION['CustomerName'].' </option>';
                  else {
                    $default_cust = FAGetRow('debtors_master', null, array('debtor_no' => 'ASC'));
                    $_SESSION['currency'] = FAGetSingleValue('currencies', 'curr_symbol', array('curr_abrev' => $default_cust['curr_code']));
                    echo '<option value="'.$default_cust['debtor_no'].'"  selected ="selected" > '. $default_cust['debtor_ref'].' </option>';
                     $_SESSION['CustomerId'] = $default_cust['debtor_no']; 
                     $_SESSION['CustomerName'] = $default_cust['debtor_ref']; 
                    }   ?>
                </select> 
                <input type="hidden" name="customer_id" id="customer_id" value="<?php echo $_SESSION['CustomerId']; ?>">
                <input type="hidden" name="payment_terms" id="payment_terms" value="<?php echo $_SESSION['payment_terms']?>">
                <input type="hidden" name="sales_type_id" id="sales_type_id" value="<?php echo $_SESSION['sales_type_id']; ?>">
                <input type="hidden" name="tax_included" id="tax_included" value="<?php echo $_SESSION['tax_included']; ?>" >
                <input type="hidden" name="tax_group_id" id="tax_group_id" value="<?php echo $_SESSION['tax_group_id']; ?>" >
                <input type="hidden" name="curr_code" id="curr_code" value="<?php echo $_SESSION['curr_code']; ?>" >
                <input type="hidden" name="currency" id="currency" value="<?php echo $_SESSION['currency']; ?>" >
                <i class="material-icons green" data-target="#CustomerAddNew" data-toggle="modal" style="display:inline-block; vertical-align: middle; cursor: pointer;float:none;padding-left:10px;padding-right:14px;margin-right:0">person_add</i>
              </div>  
            </td> 
            
          </tr>
           </tbody>
      </table>
        <div id="delevarman_list" style="display:<?php echo (isset($_SESSION['status']) && $_SESSION['status'] =='doordelivary' ? 'block' : 'none'); ?>">
          <table class="list bordered highlight" id="delivery_info" >
            <tbody>
          <tr style="background:#fff;" >
            <td style="padding: 0 10px;">
              <?php echo _("Delivery Man"); ?>
            </td>
            <td>
              <div class="form-group">
                <select name="deliverID" id="deliverID" class="form-control" style="width: calc( 100% - 30px); float: left;">
                <?php $delivery_man = GetAll('users', array('role' => 'Deliveryman'));
                    foreach($delivery_man as $key => $row){
                      echo '<option value="'.$row['ID'].'"> '. $row['full_name'].' </option>';
                    } ?>
                </select>               
              </div>
            </td>
          </tr>
          <tr style="background:#fff">
            <td style="padding: 0 10px;"> <?php echo _("Note"); ?></td><td> <textarea name="memo" id="memo" class="form-control"></textarea></td>
          </tr>
        </tbody>
      </table>
    </div>
      <div id="customer_information" style="display:<?php echo (isset($_SESSION['status']) && $_SESSION['status'] == 'doordelivary' ? 'block' : 'none'); ?>">
          <table class="list bordered highlight">
            <tbody>
                <tr style="background:#fff">
                  <td><?php echo _("Client Name"); ?></td>
                  <td id="client_name_list"><select class="form-control" name="customer_ref" id="customer_ref"> 
                    <?php echo (isset($_SESSION['customer_ref']) ?  '<option value="'.$_SESSION['client_id'].'" selected> '.$_SESSION['customer_ref'].'</option>' : '' ); ?></select>   <i class="material-icons green ClientAddNew" data-toggle="modal" style="display:inline-block; vertical-align: middle; cursor: pointer;float:none;padding-left:10px;padding-right:14px;margin-right:0"><?php echo (isset($_SESSION['customer_ref']) ? 'edit' : 'person_add'); ?> </i></td>
                </tr>
                <tr style="background:#fff">
                  <td><?php echo _("Phone"); ?></td>
                  <td id="contact_phone"><?php echo (isset($_SESSION['contact_phone']) ? $_SESSION['contact_phone'] : ''); ?></td>
                </tr>
                <tr style="background:#fff">
                  <td><?php echo _("Address"); ?></td>
                  <td id="delivery_address"><?php echo (isset($_SESSION['delivery_address']) ? $_SESSION['delivery_address'] : ''); ?> </td>
                </tr>
                <tr style="background:#fff">
                  <td><?php echo _("Location"); ?></td>
                  <td id="default_location_to" > 
                      <?php if(isset($_SESSION['deliver_to']) && $_SESSION['deliver_to'] > 0) {
                        echo TAGetSingleValue('contacts_kot_location', 'location_name', ['id' => $_SESSION['deliver_to']]);
                      } ?>
                  </td>
                </tr> 
                <tr style="background:#fff">
                  <td><?php echo _("Delivery Cost"); ?></td>
                  <td id="delivery_cost"> <?php echo (isset($_SESSION['freight_cost']) ? $_SESSION['freight_cost'] : 0); ?></td>
                </tr>
              </tbody>
            </table>
          </div>
      </div>

      <!-- Items Table list  -->
      <div class="ItemsTable" style="background: #fff;" >
        <?php  
        if(isset($_SESSION['TableNo']) && $_SESSION['TableNo'] > 0){
          $text = "Table ";
          $textNum = $_SESSION['TableNo'];
        } 
        if(isset($_SESSION['token_no']) && $_SESSION['token_no'] > 0 ){
          $text = "Token ";
          $textNum = $_SESSION['token_no'];
        }

         ?>
        <div class="ItemsTableTitle" style=" text-align: center; padding: 0;"> 
          <h3> <?php echo _("Orders"); ?> <span class="text-center tableNumText"><span class="text_title"><?php echo $text;?></span>&nbsp;<span class="tablenum"><?php echo $textNum; ?></span></span></h3></div>
          
        <!--  Billing Table list Items -->
        <style type="text/css">
        table.dataTable tbody td{padding: 6px 10px !important;}
        </style>
          <table class="list bordered highlight dataTable" id="BillingTable">  
            <thead>
              <tr>  
                <td style="width:60%"><?php echo _("Item Name"); ?> </td>  
                <td style="width:20%"><?php echo _("Quantity"); ?></td> 
                <td style="width:20%"><?php echo _("Price"); ?></td> 
                <td style="width:20%"><?php echo _("Total"); ?></td> 
                <td><?php echo _("Action"); ?></td> 
              </tr>                 
            </thead>                      
            <tbody> <?php                               
              if(isset($_SESSION['cart_item']) && count($_SESSION['cart_item']) > 0){                      
                $i = 0; 
                //var_dump($_SESSION['cart_item']);
                foreach($_SESSION['cart_item'] as $cart_id => $single) {
                  $row_val = '<a class="red RemoveItem" data-sessionid="'.$cart_id.'" href="javascript:void(0);"><i class="material-icons">delete_forever</i></a>';
                  echo '<tr class="'. (++$i%2 ? "odd" : "even") . '" id="Cart_ID_'.$cart_id.'"><td>'.$single['name'].'</span></td><td class="qtyEdit" data-id="'.$cart_id.'">'.$single['qty'].'</td><td>'.number_format($single['price'], $price_dec).'</td><td>'.number_format($single['line_total'], $price).'</td><td>'.$row_val.'</td></tr>';
                }  
              }else{
                echo '<tr class="noItemsClass" > <td colspan="8" > <center> '._("No Items In it").' </center> </td> </tr>';
              } ?>
            </tbody>
            <tfoot class="Summary">
              <tr class="GrandTotal">
                <td colspan="5">
                  <span class="small"><?php echo _("Total"); ?></span>
                  <span class="currency" ><?php echo $_SESSION['currency']; ?>
                  </span>
                  <span id="total_amount"> <?php echo (isset($_SESSION['grand_total']) ? $_SESSION['grand_total']+(isset($_SESSION['freight_cost'])? $_SESSION['freight_cost'] : 0 ) : number_format2(0, $price_dec)); ?></span>
                </td>
              </tr>
              <tr>
                <?php 
                $t_no = FAGetSingleValue('debtor_trans', 'trans_no', array('version' => 0, 'type' => 13, 'order_' => $_SESSION['order_id']));
                if($t_no > 0){  $trans_no = $t_no; }else{ $trans_no = 0; } ?>
                <input type="hidden" name="trans_no" id="trans_no" value="<?php echo $trans_no;  ?>">
                <input type="hidden" name="update_delivery" id="update_delivery" value="0">
                <td colspan="5" style="padding:0;margin:0;">
                  
                  <?php if(has_user_permission('Allow Delivery', 'POS & KOT')) { ?>
                  <button class="btn PrintReceipt" id="PrintReceipt" tabindex="10" value="0" data-id="<?php echo (isset($_SESSION['order_id']) ? $_SESSION['order_id'] : 0 ); ?>" <?php echo (isset($_SESSION['order_id']) >0 ? '' : 'disabled="disabled"' ); ?> >
                    <i class="material-icons">receipt</i><?php echo _("Receipt"); ?><div class="ripple-container"></div>
                  </button> <button class="btn PrintToken" id="PrintToken" tabindex="10" value="0" data-id="<?php echo (isset($_SESSION['order_id']) ? $_SESSION['order_id'] : 0 ); ?>" <?php echo (isset($_SESSION['order_id']) >0 ? '' : 'disabled="disabled"' ); ?> >
                    <i class="material-icons">print</i><?php echo _("Token"); ?><div class="ripple-container"></div>
                  </button> <?php } if(has_user_permission('Allow Order', 'POS & KOT')) { ?>
                  <button class="btn Save_order" id="saved_order" type="submit" tabindex="12" data-id="<?php echo (isset($_SESSION['order_id']) ? $_SESSION['order_id'] : 0 ); ?>"  
                    <?php echo ((isset($_SESSION['items_count']) && $_SESSION['items_count'] < $_SESSION['cart_count']) ?  '' : 'disabled="disabled"');?> >
                    <i class="material-icons">save</i> <?php echo _("Order"); ?>
                  </button>
                <?php } ?>
                </td>
              </tr>
              <?php  if(has_user_permission('Allow Cash', 'POS & KOT')) {  ?>
              <tr class="SideBarRow">
                <td style="padding: 2px 8px;" ><?php echo _("Payment Mtd"); ?></td>
                <td colspan="4">
                  <div class="form-group">
                     <select class="form-control" name="payment_method" id="payment_method" tabindex="6">
                     <?php  $sql ="SELECT terms_indicator, terms FROM ".TB_PREF."payment_terms WHERE days_before_due = 0 AND day_in_following_month = 0 ORDER BY terms LIMIT 1";
                        $sales_typ_res= fadb_query($sql, "can't get results");
                        if($row = fadb_fetch($sales_typ_res)){
                          echo '<option value="'.$row['terms_indicator'].'" data-id="cash" selected="selected"> '._("Cash Only").' </option>';
                          echo '<option value="'.$row['terms_indicator'].'" data-id="card"> '._("Credit/Debit Card").' </option>';
                          echo '<option value="'.$row['terms_indicator'].'" data-id="spiltpayment"> '._("Split Payment").'</option>';

                        }
                        $sql ="SELECT terms_indicator, terms FROM ".TB_PREF."payment_terms WHERE days_before_due > 0 OR day_in_following_month > 0 ORDER BY terms LIMIT 1";
                        $sales_typ_res= fadb_query($sql, "can't get results");
                        if($row = fadb_fetch($sales_typ_res)){
                          echo '<option value="'.$row['terms_indicator'].'" data-id="later"> '._("Pay Later").' </option>';
                        }
                        ?>
                     </select>
                  </div>
               </td>
              </tr>
              <tr class="SideBarRow TransRef">
                <td style="padding: 2px 8px;" ><?php echo _("Trans Ref"); ?> </td>
                <td style="padding: 2px 8px;" colspan="4"><input class="form-control" type="text" id="trans_ref" name="trans_ref" tabindex="7"></td>        
              </tr>
              <tr class="SideBarRow TenderTr">
                <td style="padding: 2px 8px;" ><?php echo _("Tender"); ?><span class="currency" style="float: right;" ><?php echo $_SESSION['currency'] ?></span> </td>
                <td style="padding: 2px 8px;" colspan="4">
                  <input class="form-control" placeholder="<?php  echo $_SESSION['grand_total']+(isset($_SESSION['freight_cost'])? $_SESSION['freight_cost'] : 0 ); ?>" type="text" id="user_paid" name="user_paid" tabindex="8"></td>         
              </tr>
              <tr class="SidebarRow SplitTr">
                <td style="padding: 2px 8px;" ><?php $bank_accs = FAGetAll('bank_accounts', array('inactive' => 0 )); 
                  $bnk = 'Card Payment';
                  if(is_array($bank_accs)) {
                    $bnk = '<select name="bank_acc_id" class="form-control" id="bank_acc_id" tabindex ="9" > ';
                    foreach($bank_accs as $bank ){
                      if($bank['account_type'] != 3 )
                        $bnk .= '<option value= "'.$bank['id'].'" > '.$bank['bank_account_name'].'</option>';
                    }
                    $bnk .= '</select>';
                  } echo $bnk;?></td>
                <td colspan="4"><input class="form-control" placeholder="" type="text" id="cardpaid"></input></td>
              </tr>
            
            <tr class="SidebarRow SplitTr">
              <td style="padding: 2px 8px;" colspan="1"><?php echo _("Cash Tender")?></td>
              <td style="padding: 2px 8px;" colspan="4"><div class="form-group"><input class="form-control" type="text" id="cashpaid"></div></td>
            </tr>
            <tr class="Balance">
              <td colspan="5"><i class="material-icons">tab_unselected</i><span class="small"><?php echo _("Balance"); ?></span>&nbsp;<span class="currency"><?php echo $_SESSION['currency'] ?></span> <span id="balance"><?php echo number_format2(0, $price_dec); ?></span></td>
            </tr>
            <tr class="Pay">
              <td colspan="5" style="padding:0;">
                <button class="btn PayNow" type="submit" id="PayNow" tabindex="9"><i class="material-icons"></i> <span class="submitText"> <?php echo _("Pay & Complete"); ?></span></button>  
                  <?php  if(has_user_permission('Print Receipt', 'POS & KOT')) {  ?>
                <button class="btn PrintInvoice" type="submit" tabindex="10" value="0" data-id="<?php echo (isset($_SESSION['invoice_id']) ? $_SESSION['order_id'] : 0 ); ?>">
                  <i class="material-icons">receipt</i><?php echo _("Print Invoice"); ?><div class="ripple-container"></div>
                </button> <?php } ?>
                <input type="hidden" name="last_invoice_id" id="last_invoice_id" value="<?php echo FAGetSingleValue('debtor_trans', 'MAX(`trans_no`)', array('type' => ST_SALESINVOICE)); ?>" >
              </td>
            </tr>
            <?php } ?>
          </tfoot>       
        </table>          
        <input type="hidden" name="order_id" id="order_id" value="0">
        <input type="hidden" name="cart_items_count" id="CartItemsCount"  value="<?php echo (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item']) ? count($_SESSION['cart_item']) : 0 ); ?>" >
        <input type="hidden" name="total_amount" id="total_amount" value="<?php echo $_SESSION['grand_total'] ?>">         
      </div> 
    </div> 
  </div>
</div> <!--  /container -->

<?php } else 
kv_direct(get_url('404'));
?>
<!-- New message Modal Trigger -->
<div class="modal fade" id="CustomerAddNew" tabindex="-1" role="dialog" aria-labelledby="UploadTitle">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons" >close </i></button>
        <h4 class="modal-title" id="UploadTitle">
           <!--<i class="material-icons"> folder_open</i> --> <?php echo _("New Customer"); ?>
        </h4>
      </div>
      <form action="#" class="" id="NewCustomerAdd" enctype="multipart/form-data" method="post" accept-charset="utf-8">
        <div class="modal-body" style="min-height:200px;">
          <div id="UploadStatus"> </div>
          <div class="row">
            <div class="col-sm-12">
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Full Name"); ?></label>
                <div class="col-md-8"><input type="text" name="client_name" class=" client_name form-control"></div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Short Name"); ?></label>
                <div class="col-md-8"><input type="text" name="cust_ref" class="form-control"></div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Email Address"); ?></label>
                <div class="col-md-8"><input type="text" name="client_email" class="form-control"></div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Phone"); ?></label>
                <div class="col-md-8"><input type="text" name="phone" class="form-control"></div>
              </div>
              <div class="form-group" >
                <label for="textArea" class="col-md-4 control-label"><?php echo _("Address"); ?></label>
                <div class="col-md-8">
                  <textarea class="form-control" rows="3" id="CustomerAddress" name="address"></textarea>   
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("VAT/BTW no"); ?></label>
                <div class="col-md-8"><input type="text" name="tax_id" class="form-control"></div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Bank Acc"); ?></label>
                <div class="col-md-8"><input type="text" name="bank_account" class="form-control"></div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Sales Type"); ?></label>
                <div class="col-md-8"><select autocomplete="off" name="sales_type" class="form-control">
                   <?php  $sql ="SELECT id, sales_type, inactive FROM ".TB_PREF."sales_types ORDER BY sales_type";
                      $sales_typ_res= fadb_query($sql, "can't get results");
                      while($row = fadb_fetch($sales_typ_res)){
                        echo '<option value="'.$row['id'].'" > '._($row["sales_type"]).' </option>';
                      }
                      ?>
                   </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-4 control-label"><?php echo _("Payment Terms"); ?></label>
                <div class="col-md-8"><select autocomplete="off" name="payment_terms" class="form-control">
                   <?php $sql ="SELECT terms_indicator, terms, inactive FROM ".TB_PREF."payment_terms ORDER BY terms";
                      $pmt_tm= fadb_query($sql, "can't get results");
                      while($row = fadb_fetch($pmt_tm)){
                        if($row['inactive'] == 0)
                        echo '<option value="'.$row['terms_indicator'].'" >'._($row["terms"]).'</option>';
                      }
                      ?>
                   </select>
                </div>
              </div> 
               <?php $curr_default = get_company_details('curr_default'); ?>
              <input type="hidden" name="curr_code" value="<?php echo $curr_default; ?>" > 
            </div>
            <div class="col-md-12 form-group" id="errorWarning" style="display: none;background: #ffc0bb; border: 1px solid #F44336; border-radius: 2px; color: #f44336;" > 
              <label style="color: rgb(243, 32, 17); font-weight: 300;  padding-top: 10px;" > </label>
            </div>
          </div>
        </div>
        <div class="modal-footer">               
          <input type="hidden" name="submit_customer" value="yes" > 
          <input type="hidden" name="pos_customer" value="yes" >                
          <button type="submit" class="btn btn-primary" id="Submitbtn"><?php echo _("Submit"); ?></button>
          <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--  pdf Content modal -->
<div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
       <div class="modal-header" >
          <button type="button" class="close" data-dismiss="modal" aria-label="Close" ><i class="material-icons" >close </i></button>
          <h4 class="modal-title" id="PDFTitle" >
             <i class="material-icons"> receipt</i> <?php echo _("Receipt"); ?>
          </h4>
       </div>
       <div class="modal-body" style="min-height:500px;">
        <div style="min-height:500px;text-align: center;margin: 0 auto;vertical-align: middle;" id="PreLoaderImg">
      <img src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF" style="  padding-top: 25%;"> </div>
          <div class="iframe-container" style="min-height:500px;">  
             <iframe id="printf" src="<?php echo get_current_theme_uri(); ?>images/preloader.GIF">    </iframe>   
          </div>
       </div>
       <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
       </div>
    </div>
  </div>

</div>


  <!-- New message Structure -->
    <div class="modal fade" id="ClientAddNew" tabindex="-1" role="dialog" aria-labelledby="ClientDetail">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="ClientDetail"> <!--<i class="material-icons"> folder_open</i> --> <?php echo _("New Client"); ?></h4>
          </div>
                    <form action="<?php echo get_url('customers'); ?>" class="" id="NewClientAdd" enctype="multipart/form-data" method="post" accept-charset="utf-8">
              <div class="modal-body" style="min-height:200px;">
                <div id="UploadStatus"> </div> 
                <div class="row">            
                  <div class="col-sm-12"> 

                       <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Phone"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="phone_1" id="phone_1" class="form-control"></div></div>   
           
                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Client Name"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="client_name_1" class="form-control"></div></div>

                      <div class="form-group" ><label for="textArea" class="col-md-4 control-label"><?php echo _("Address"); ?></label>
                          <div class="col-md-8"><textarea class="form-control" rows="3" id="ClientAddress" name="address"></textarea></div>
                      </div>
            
                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Location"); ?></label>
                        <div class="col-md-8"><select autocomplete="off" name="location" id="default_location" class="form-control">
                        <?php  $sql ="SELECT id, location_name, inactive FROM ".TB_PREF."contacts_kot_location ORDER BY id";
                          $sales_typ_res= fadb_query($sql, "can't get results");
                          while($row = fadb_fetch($sales_typ_res)){
                             if(!$row['inactive'])
                            echo '<option value="'.$row['id'].'" > '. $row['location_name'].' </option>';
                          }
                          ?>
                        </select></div></div>             
                          <input type="hidden" name="clientid" id="clientid" value="0" > 

                          <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Delivery Cost"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="delivery_cost" class="form-control delivery_cost"></div></div>

                      </div>
                 
                  <div class="col-md-12 form-group" id="errorWarning" style="display: none;background: #ffc0bb; border: 1px solid #F44336; border-radius: 2px; color: #f44336;" > 
                  <label style="color: rgb(243, 32, 17); font-weight: 300;  padding-top: 10px;" > </label>
                  </div> 
                </div>            
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
                 <input type="hidden" name="submit_customer" value="yes" > 
                <button type="submit" class="btn btn-primary" id="Submitbtn"><?php echo _("Submit"); ?></button>
              </div>
      </form>
        </div>
      </div>
    </div>

<script>
$(document).ready(function(){
  
    var pusher;
    var channel, notification;
    var notificationsWrapper   = $('.dropdown-notifications');
    var notificationsToggle    = notificationsWrapper.find('a[data-toggle]');
    var notificationsCountElem = notificationsToggle.find('i[data-count]');
    var notificationsCount     = parseInt(notificationsCountElem.data('count'));
    var notifications          = notificationsWrapper.find('ul.dropdown-menu');
    if (notificationsCount <= 0) {
      notificationsWrapper.hide();
    }

   Pusher.logToConsole = true;

          // if( msg.success ) {
    pusher = new Pusher("<?php echo $pushers['app_id']; ?>", {
        cluster: 'ap2',
        forceTLS: true,
        authEndpoint: 'ajax?pusher_auth'
    });
      channel = pusher.subscribe('channel-1');
      channel3 = pusher.subscribe('channel-3');
    pusher.connection.bind('connected', function() {
          channel.bind('my-event', loadsaved);
          channel3.bind('payment_done', payment_complete);
    }); 
});


  $(".ClientAddNew").on("click", function(e) {
    var cid = $("#customer_ref").val();
    if(cid > 0 ){
      $.ajax({
          url: 'ajax?GetclientDetails='+cid,
          type: 'POST',
          dataType: 'json',
          success: function(data){
             $('input[name="client_name_1"]').val(data.client_name);
             $('input[name="phone_1"]').val(data.phone);
             $('#ClientAddress').val(data.address);
             $('select[name="location"]').val(data.location);     
             $(".delivery_cost").val(data.delivery_cost);
             $("#clientid").val(data.id);
             $("#ClientDetail").html('<?php echo _("Edit Client"); ?>');        
          }
      });
    } else {
     $('input[name="client_name_1"]').val('');
     $('input[name="phone_1"]').val('');
     $('#ClientAddress').val('');
     $("#ClientDetail").html('<?php echo _("Add New Client"); ?>');     
   }
   $("#ClientAddNew").modal('show');
  });

  $("#phone_1").on("keyup", function(){
    var phone = $(this).val();
    $.ajax({
          url: 'ajax?GetclientDetails=phone',
          type: 'POST',
          data : { 'phone' : phone },
          dataType: 'json',
          success: function(data){
             $('input[name="client_name_1"]').val(data.client_name);
             $('input[name="phone_1"]').val(data.phone);
             $('#ClientAddress').val(data.address);
             $('select[name="location"]').val(data.location);             
          }
      });
  });

  $("body").on("click", "#Submitbtn", function(e){ 
    e.preventDefault();
    var allow = 1;
    if($('input[name="client_name_1"]').val()==''){
      $('input[name="client_name_1"]').focus();     
      $("#errorWarning label").html('<?php echo _("You have to input client full name"); ?>');
      $("#errorWarning").show();
      allow = 0;
    }
    var cid = $("#clientid").val();
    if(allow == 1){
        $("#errorWarning").hide();
        $.ajax({
            type: 'post',
            url: 'ajax?submit_client=yes',
            data: $('#NewClientAdd').serialize(),
            dataType :'JSON',
            success: function (result) {
              alert_float(result.type, result.msg);             
              if(cid == 0 ){
                $('#customer_ref').append($("<option></option>").attr("value",result.client_id).text(result.client_name)); 
                $("select#customer_ref").val(result.client_id);  
                $('#customer_ref').trigger('change');
              }

              $('#contact_phone').html(result.phone);
              $('#delivery_address').html(result.address);
              $('#default_location_to').html(result.location_name);             
              $('#delivery_cost').html(result.delivery_cost);  
              $(".ClientAddNew").html('edit');
              $("#clientid").val(result.id);
              $("#select2-customer_ref-container").html('<span class="select2-selection__clear">×</span> '+result.client_name);
           
              $("select2-customer_ref-container").attr('title', result.client_name);
           
              $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
              $('#ClientAddNew').modal('hide');      
            }
        });
      }
  });


  $(document).bind('keydown', 'shift+t', function(e){  //Barcode Scanner
   $('#user_paid').focus();
  });
  $(document).on('click', '.resetProduct', function(e){
    e.preventDefault;
    getProduct();
  });
$(document).ready(function(){
  $('#deliverID option:first').prop('selected',true);
    var customer_id = $('#customer_id').val();
    change_customer(customer_id);
    getCategory();
    getProduct();     
    $(".TransRef").hide();
    $(".show_date").hide();  
    
    // Date selection
    $("#select_date").click(function () {
      if ($(this).is(":checked")) {
          $("#date_show").show();
      } else {
          $("#date_show").hide();                
      }
    });
      $('.PrintToken').hide();
      var tokenNo = $('#token_no').val();
      var del_no = $('#del_no').val();

      if($('#button_status').val() == 'doordelivary' || $('#button_status').val() == 'takeaway' || (parseInt(tokenNo) > 0 || parseInt(del_no) > 0 )){
        $('.PrintToken').show();
        $("#PrintToken").attr("disabled", false);
        // $('#PrintToken').css({ "font-size": "16px"});
        $(".PrintReceipt, .Save_order").css({"width": "calc( 33% - 1px)"});
      }
    // Token Plan button  
    $('#delevarman_list').change(function(e){
      e.preventDefault();
      if($('#button_status').val() == 'doordelivary'){
        // $('#delevarman_list').attr('display', 'block');
        $('#delevarman_list').show();
        $('#customer_information').show();
      }else{
        // $('#delevarman_list').attr('display', 'none');
        $('#delevarman_list').hide();
      }
    });
    
    $(document).on('click','.token_plan', function(e){
          e.preventDefault();
          $('#TableNo').val(0);
          $('#del_no').val(0);
          
          $('#collapseTwo').collapse('toggle');
          var tokenum = $(this).data('token_num');
          $('.text_title').text('<?php echo _("Token"); ?>');
          $('.tableNumText .tablenum').text(tokenum);
          var tokenNo = $('#token_no').val(tokenum);
          $('span.tablenum.badge').text('');
          $('span.tokennum').show();
          $('#token_plan_no').val(tokenum); // Set token Plan
          $('.tokennum.badge').text(tokenum);
          $('#delevarman_list').trigger('change');
          $('#customer_information').hide();
          getProduct();
           if(tokenum > 0 && tokenum != tokenNo){
              load_cart_data('',tokenum, '');
          }
      });
      $(document).on('click','.del_plan', function(e){
          e.preventDefault();
          $('#TableNo').val(0);
          $('#token_no').val(0);
          $('#collapseThree').collapse('toggle');
          var del_no = $(this).data('del_num');
          // $('.text_title').text('Token ');
          // $('.tableNumText .tablenum').text(tokenum);
         $('#delevarman_list').trigger('change');
         $('#customer_information').show();
          var delNO = $('#del_no').val(del_no);
          $('span.tablenum.badge').text('');
          $('span.tokennum').hide();
          $('.tokennum.badge').text('');
          getProduct();
          if(del_no > 0 && del_no != delNO){
              load_cart_data('','',del_no);
          }
        });
       
        //  Table Plan button 
        $('#tableList li.table_plan').on('click', function(e){
          e.preventDefault();
          $('#token_no').val(0);
          $('#delevarman_list').trigger('change');
          $('#customer_information').hide();
          $('#collapseOne').collapse('toggle');
          var tablenum = $(this).data('tablenum');
          // console.log(tablenum);
          var tblNo = $('#TableNo').val();     
          $(".tablenum").text(tablenum);
          $('.tablenum').show();
          $('.tokennum.badge').hide();
          $('#TableNo').val(tablenum); 
          $('.text_title').html('<?php echo _("Table"); ?>');
          $('.tableNumText .tablenum').text(tablenum);        
          $('.table-plan-content').fadeOut();
          $('#token_plan_no').val(0);
          
          getProduct();
          // if(tablenum > 0 && tblNo != tablenum){
                load_cart_data(tablenum,'', '');
          // }
        });
        // Table plan button selection
        $('.tableplanbtn').on('click', function(){
          $('#button_status').val('table');
          $('.text_name').html('<?php echo _("Table") ?>');
          $('.tablenum.budge').hide();
          $('tokennum').text('');
          $('.tokennum.badge').hide();
          $('#delevarman_list').trigger('change');
          $('#customer_information').hide();
          $('.PrintToken').hide();
          $("#balance").html(formatMoney(0));
          $(".PrintReceipt, .Save_order").css({"width": "calc( 50% - 2px)"});
          ClearCart();
        });
        // Takeaway button selection
        $(document).on('click','.takeaway_btn', function(e){
          e.preventDefault();
          $('.text_title').html('');
          $('.tableNumText .tablenum').html('');   
          $('#collapseTwo').collapse('toggle');
          var clean_cart = ClearCart();
          // $('.show_date').show();
          load_takeaway_item();
          $('#button_status').val('takeaway');
          $('.PrintToken').show();
          $(".PrintReceipt, .Save_order").css({"width": "calc( 33% - 2px)"});
          $('#customer_information').hide();
          $('#TableNo').val('');
          $('#del_no').val('');
          $('#token_no').val(0);
          $('.tokennum.badge').hide();
          $('.tablenum.budge').hide();
          $('.tablenum').text('');
          $("#balance").html(formatMoney(0));
          $('#delevarman_list').trigger('change');
                     
        });


        $(document).on('click', '.door_delivary', function(){
          $('#button_status').val('doordelivary');
          $('#del_no').val(0);
          $('#token_no').val(0);
          $('#TableNo').val(0);
          $('#delevarman_list').trigger('change');
           ClearCart();
          load_door_item();
          $('.tablenum.budge').hide();
          $('.tokennum.badge').hide();
          $('.tableNumText').hide();
          $('.PrintToken').show();
          $("#balance").html(formatMoney(0));
          $(".PrintReceipt, .Save_order").css({"width": "calc( 33% - 2px)"});
          
        });
    
    $("body").on("keyup", "#ItemSearch", function (){
        var id = $(".Selectedcategory").data('id');
        var qu = $(this).val();
        if(qu.length> 0 ){
            getProduct(id, qu);
        }else{
          getProduct();
        }
    });
    $('#printf').on('load', function() {
     var id = $(this).attr('src');
     var tabId = id.substr(id.length - 3);      
     if(tabId == 'pdf')
      document.getElementById('printf').contentWindow.print();
   });
  setInputFilter(document.getElementById("user_paid"), function(value) {
  return /^-?\d*[.,]?\d*$/.test(value); });
    $("body").on("keyup", "#CatSearch", function (){
        var name = $('#CatSearch').val();        
        if(name.length> 0 ){
            getCategory(name);
        }else{
          getCategory();
        }
    });
    $('body').on("keyup", '#cardpaid', function(){    
      var total_val = $('#total_amount').text();
      var user_input = $(this).val();
      var balance = (parseFloat(user_input) - parseFloat(total_val)).toFixed(<?php echo $price_dec; ?>);      
      if(user_input){
       $('#cashpaid').val(Math.abs(balance));
      }
   });


 $('body').on("keyup", '#cashpaid', function(){     
      var total_val = $('#total_amount').text();
      var user_input = $(this).val();
      var balance = (parseFloat(user_input) - parseFloat(total_val)).toFixed(<?php echo $price_dec; ?>);      
      if(user_input){
       $('#cardpaid').val(Math.abs(balance)); 
      }
   });
    //  Iteam Add List
    $('body').on('click', '.item', function(e){
      e.preventDefault();

      let id =  $(this).data('id');
      let price = $(this).data('price');
      let qty = $(this).data('qty');
      let line_total = price * qty;
       let tax_group_id = $('#tax_group_id').val();
       let CustomerId = $('#CustomerId').val();
       let deliverID = $('#deliverID').val();
       let currency = $('#currency').val();
       let TableNo = $("#TableNo").val();
       let order_id = $('#order_id').val();
       let status = $('#button_status').val();
       let token_no= $('#token_no').val();
       let t_no = '';
       let token_plan_no = $('#token_plan_no').val();
       let del_no = $('#del_no').val();
       //alert(parseInt(CustomerId));
       if(parseInt(CustomerId) <= 0 || CustomerId == ''){
        alert('<?php echo _("Select a Customer to continue"); ?>');
        $("#CustomerId").toggle();
        return false;
      }

       if( status == 'table' && parseInt(TableNo) > 0 ){
        TableNo = TableNo;         
      }


      else if(status == 'takeaway'){
          // TableNo = $("#TableNo").val(0);
          // del_no = $('#del_no').val(0);
          if(token_plan_no == 0){
            t_no = token_no;
          }else{
            t_no= token_plan_no;
          }
          $("#PrintToken").attr("disabled", false);

        }else if(status == 'doordelivary'){
          // TableNo = $("#TableNo").val(0);
          // t_no= $('#token_no').val(0)
          $("#PrintToken").attr("disabled", false);

            del_no = del_no;
        }else{
          alert('<?php echo _("You have not Selected any table"); ?>');
          return false;
        }
      
      $.ajax({
        url: "ajax?AddPOSItemToCart=Yes",
        type: "POST",
        data: {'stock_id':id, 'TableNo' : TableNo,'token_no': token_no,'del_no' : del_no, 'status': status ,'price':price, 'qty':qty, 'tax_group_id': tax_group_id, 'CustomerId' : CustomerId, 'deliverID' : deliverID,'currency':currency, 'line_total':line_total, 'order_id':order_id},
        dataType: 'JSON',
        success: function(data){
          // return false;
          if(data.exist == 'yes'){
            AppendCartTable(data);
          } else {
            AddItemToTable(data.details); 
          }
          // console.log(data);
          $(".currency").html(data.currency);
          var total_amount_wth_freight = parseFloat(data.grand_total)+parseFloat(data.freight_cost);
         $('#total_amount').html(formatMoney(total_amount_wth_freight));   
         $("#user_paid").attr("placeholder", data.grand_total);
         $("#CartItemsCount").val(data.cart_count);
         $(".Save_order").attr('disabled', false);
         $(".Save_order").attr('data-id', 0);
        
      } 
    });
    });
    $(document).on('click','.GridCategory li', function(e){
      e.preventDefault();
      var id = $(this).data("id");
      $(".Selectedcategory").removeClass("Selectedcategory");
      $(this).addClass("Selectedcategory");
      getProduct(id, '');
    });
    
   // Add Newcustomer Popup submit
  $("body").on("click", "#Submitbtn", function(e){ 
    e.preventDefault();
    var emailaddress = $('input[name="client_email"]').val();
    if($('input[name="client_name"]').val()==''){
      $('input[name="client_name"]').focus();     
      $("#errorWarning label").html('<?php echo _("You have to input client full name"); ?>');
      $("#errorWarning").show();
    }else if( !isEmail(emailaddress) && emailaddress.length>0) { 
      $('input[name="client_email"]').focus();
      $("#errorWarning label").html('<?php echo _("You have to input valid client email"); ?>');
      $("#errorWarning").show();
    }else if($('input[name="cust_ref"]').val() == ''){
      $('input[name="cust_ref"]').focus();
      $("#errorWarning label").html('<?php echo _("You have to input client Short name"); ?>');
      $("#errorWarning").show();
    }else  {     
      $("#errorWarning").hide();
      $.ajax({
        type: 'POST',
        dataType: "json",
        url: 'ajax?submit_customer=yes',
        data: $('#NewCustomerAdd').serialize(),
        success: function (result) {
          $('#CustomerId').append($("<option></option>").attr("value",result.id).text(result.name)); 
          $("select#CustomerId").val(result.id);
          $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
          
          $('#CustomerId').trigger('change');
          $('input[name="client_name"]').val('');  
          $('input[name="client_email"]').val('');  
          $('input[name="phone"]').val('');  
          $('input[name="cust_ref"]').val('');  
          $('input[name="tax_id"]').val('');  
          $('input[name="bank_account"]').val('');  
          $('#CustomerAddress').val('');  
          $('#CustomerAddNew').modal('hide');    
        }
      });       
    }
  });
  <?php if(!isset($_SESSION['TableNo']) > 0 || !isset($_SESSION['token_no']) > 0 || !isset($_SESSION['del_no']) > 0){ ?>
  $("#PrintReceipt").attr("disabled", true);
  $("#PrintToken").attr("disabled", true);
  $('.Save_order').attr('data-id', '0');
  <?php } else { ?>
    $('.Save_order').attr('disabled', false);
    $('#PrintReceipt').attr('data-id', <?php echo $_SESSION['order_id']; ?>);
    $('#PrintToken').attr('data-id', <?php echo $_SESSION['order_id']; ?>);
    $('.Save_order').attr('data-id', <?php echo $_SESSION['order_id']; ?> );
  <?php } ?>

  // Save order button
  // $('.Save_order').click(function(e){
$(document).on('click', '.Save_order', function(e){
  e.preventDefault();
  console.log(e);
  var order_id = $(this).data('id');
  var cartCount = $("#CartItemsCount").val();
  var ifrme_modal = $("#pdfModal");
  var token_val = '';var del_val = '';
  var deliverID = ''; 

  if($('#button_status').val() == 'doordelivary'){
    if ($('select#deliverID').val() == "") {
      alert('<?php echo _("Please select a selection"); ?>');
      return false;
    }
    deliverID = $('#deliverID').val();
  }else{
    deliverID = 0;
  }
  
  if(cartCount > 0 ) {
    var TableNo = $("#TableNo").val();
    $.ajax({
        url: 'ajax?saveorder=completed',
        type: 'POST',  
        data : { 'deliverID': deliverID},
        dataType: "json",
        success: function(data) {
          // console.log(data); 
          $("#update_delivery").val(data.tp);

          if(data.pusher === 0){
            loadsaved(data);
          }
         
          // SaveDelivery();
        }
    });
   
  }
});
//  Print Token
$('#PrintToken').click(function(e){ 
// $(document).on("click",'#PrintReceipt', function(e){  
    e.preventDefault;   
    var ifrme_modal = $("#pdfModal");    
    //var trans_no = $('#trans_no').val();  
    var order_no = $(this).attr('data-id');

   // if(parseInt(trans_no) == 0 )
     // SaveDelivery();  
    PrintToken(order_no, ifrme_modal);
    
  });

function SaveDelivery(){

  var order_no = $('#PrintReceipt').data('id');
    var order_id = $('#saved_order').data('id');    
    var table_no = $("#TableNo").val();   
    var total_amount = $('#total_amount').text();
    var status = $('#button_status').val();
    var token_val = $('#token_plan_no').val();
    var trans_no = $('#trans_no').val();

   $.ajax({
        url: 'ajax?delivaryorder=completed',
        type: 'POST',
        data: {'status': status, 'trans_no' : trans_no},
        dataType: 'json',
        success: function(data){
          $('#trans_no').val(data.trans_no);
          $("#tableListItem"+table_no).removeClass('ordered').addClass('delivered');
          $("#user_paid").attr("placeholder", total_amount);    
           $("#update_delivery").val('0');
          var ifrme_modal = $("#pdfModal");      
          if(data.table_no > 0){
            $('.tablenum').show();
            $('.tablenum').text(data.table_no);
            load_cart_data(data.table_no);
          }
          if(data.token_no > 0){
            // ClearCart();
            $('.tokennum').hide();
            $('.text_title').text('');
            $('.tableNumText .tablenum').text('');
          }
          if(data.del_no > 0){
            // $('#collapseThree').collapse('toggle');
            $('.tablenum').text('');
            $('.text_title').text('');
            if(status != 'doordelivary'){
              $('#delevarman_list').hide();
              $('#customer_information').hide();
            }
            // ClearCart();
          }           
           PrintReceipt(data.trans_no, ifrme_modal);
        }
    });
}
  
  //  Print Receipt
$('#PrintReceipt').click(function(e){ 
// $(document).on("click",'#PrintReceipt', function(e){  
    e.preventDefault;  
    var ifrme_modal = $("#pdfModal");
   
    var trans_no = $('#trans_no').val(); 
    var update_delivery = parseInt($('#update_delivery').val()); 
    if(trans_no == 0 || update_delivery == 1)
        SaveDelivery();
    else
        PrintReceipt(trans_no, ifrme_modal);
  });
    
 // Remove Items button
  $('body').on('click', '.RemoveItem', function(e){
  e.preventDefault();     
    var cart_id = $(this).data('sessionid');
    if(cart_id >= 0){  
      $.ajax({
        url: 'ajax?RemovePOSItemFromCart=Yes',
        type: 'POST',
        data : {'cart_id': cart_id},  
        dataType: 'JSON',   
        success: function(data) {           
          $("tr#Cart_ID_"+data.last_id).remove();
          var rowCount = $('#BillingTable tbody tr').length;
          if(rowCount == 0){
            $("#BillingTable > tbody").html('<tr class="noItemsClass" > <td colspan="5" > <center> <?php echo _("No Items In it"); ?> </center> </td> </tr> ');
             $(".Save_order").attr('disabled', true);
             $('#total_amount').html('0.00');
             $("#CartItemsCount").val(0);
             $("#user_paid").attr("placeholder", '0.00');
          } else {
             $(".Save_order").attr('disabled', false);
             $('#total_amount').html(data.grand_total);
             $("#CartItemsCount").val(data.cart_count);
             $("#user_paid").attr("placeholder", data.grand_total);
           }
        }
      });
    }
  });
  qtyedit = 1;
  $("#BillingTable").on("click", ".qtyEdit", function(e){
    if(qtyedit == 1) {
      var cart_id = $(this).data('id');
      var qty = $(this).text();
      $(this).html('');
      $(this).append('<input type="text" name="qtyEdit" data-cart_id="'+cart_id+'" data-prev_qty="'+qty.trim()+'" id="qtyEditTxt" value="'+qty.trim()+'">');
      qtyedit = 0;
    } else {
      qtyedit = 1;
    }
  });

  $("#BillingTable").on("change", "#qtyEditTxt", function(e){
    var cart_id = $(this).data('cart_id');
    var qty = $(this).val();
    if(qty == 0 )
        qty = $(this).data('prev_qty');
    UpdateQuantity(cart_id, qty);
  });

  $('#customer_ref').select2({     // var itemName = $('select[name="itemName"]').val();
        placeholder: "<?php echo _("Select an Client"); ?>",
        theme: "material",
        allowClear: true,
        ajax: {
          url: 'ajax?get_customers_client=1',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {            
            return {
              results: data
            };           
          },
        },
        cache: false
  });

  $('#customer_ref').change(function(e){
      e.preventDefault();
      var cid = $(this).val();   
      if(cid > 0){   
        $.ajax({
            url: 'ajax?GetclientDetails='+cid,
            type: 'POST',
            dataType: 'json',
            success: function(data){
              $('#contact_phone').html(data.phone);
              $('#delivery_address').html(data.address);
              $('#default_location_to').html(data.location_name);             
              $('#delivery_cost').html(data.delivery_cost);  
              $(".ClientAddNew").html('edit');   
               $('#delivery_cost').html(data.delivery_cost);  
              $(".delivery_cost").val(data.delivery_cost); 
              var overall = parseFloat(data.grand_total)+parseFloat(data.delivery_cost);          
              $('#total_amount').html(formatMoney(overall));
              $("#user_paid").attr("placeholder", overall);

            }
        });
      } else {
          $('#contact_phone').html('');
          $('#delivery_address').html('');
          $('#default_location_to').html('');             
          $('#delivery_cost').html(''); 
          $(".ClientAddNew").html('person_add');
      }
  });

  $("#default_location").change(function(e) {
     var cid = $(this).val();     
     let status = $('#button_status').val(); 
      $.ajax({
          url: 'ajax?GetclientDetailsRate='+cid+'&type='+status,
          type: 'POST',
          dataType: 'json',
          success: function(data){
            $('#delivery_cost').html(data.delivery_cost);  
            $(".delivery_cost").val(data.delivery_cost); 
            var overall = parseFloat(data.grand_total)+parseFloat(data.delivery_cost);          
            $('#total_amount').html(formatMoney(overall));             
          }
      });

  });

   $('#CustomerId').change(function(e){
    e.preventDefault();
      var cid = $(this).val();      
      $.ajax({
        url: 'ajax?GetCustomer=1',
        type: 'POST',
        data: {cid: cid},
        dataType: 'json',
        success: function(data){
          $('.currency').html(data.currency);
          $('#currency').val(data.currency);
          $('#sales_type_id').val(data.sales_type_id);
          $('#tax_group_id').val(data.tax_group_id);         
          $('#payment_terms').val(data.payment_terms);
          $('#customer_id').val(data.id);
          $('#tax_included').val(data.tax_included);
          $("#customer_ref").val('0').trigger('change');
          getProduct();

        }
      })
   });
   $("#payment_method").trigger('change');
    $('.SplitTr').hide();
    $("#payment_method").on("change", function(){
      var data = $(this).find(':selected').data('id');
      if(data == 'card'){
        $(".TransRef").show();
        $(".TenderTr").show();
        $('.SplitTr').hide();
      }else if(data == 'spiltpayment'){
        $('.TransRef').show();
        $('.TenderTr').hide();
        $('.SplitTr').show();

      }else {
        $(".TransRef").hide();
        $(".SplitTr").hide();
        if(data == 'later'){
          $(".submitText").text('<?php echo _("Complete"); ?>');
          $(".TenderTr").hide();
          $('.SplitTr').hide();
          $("#PayNow").focus();
        }else {
          $(".submitText").text('<?php echo _("Pay & Complete"); ?>');
          $(".TenderTr").show();

        }
      }
    });
   user_paid = 0;  
   $('body').on("keyup", '#user_paid', function(){     
      var total_val = $('#total_amount').text();
      var user_input = $(this).val();
      var balance = (parseFloat(user_input) - parseFloat(total_val)).toFixed(<?php echo $price_dec; ?>);      
      if(user_input){
       $('#balance').html(balance);
      }else{
    $('#balance').html('');
      }
    if(balance >= 0 && user_paid==0){
      $('#PayNow').focus();
      user_paid = 1;
      }
   });
   // Paynow button to complete the sales
 
  $(document).on("click", "#PayNow", function(e){ 
      e.preventDefault(); 
      
      let status = $('#button_status').val();
      var cartCount = $("#CartItemsCount").val();
      var cardpaid = $('#cardpaid').val();
      var cashpaid = $('#cashpaid').val();
      var user_paid = $('#user_paid').val();
      let total_val = $('#total_amount').text();
      var delivery_no = $("#trans_no").val();
      var order_no = $("#saved_order").data('id');
      var payment_id = $('option:selected', '#payment_method').data('id');
      var table_no = $('#TableNo').val();
      allow =false;
      if(payment_id == 'cash'){
        if( user_paid == ''){
          alert('<?php echo _("Please Enter amount"); ?>');
          return false;
        }
          if(parseFloat(user_paid) >= parseFloat(total_val))
            allow = true;
        }else if(payment_id == 'spiltpayment'){

          if(cardpaid && cashpaid){
            if(parseFloat(cardpaid) + parseFloat(cashpaid) >= parseFloat(total_val))
              allow = true;
          }
        }else if(payment_id == 'card'){
          allow = true;
        }
      if(status == 'table'){
        check_table_condition();
      }
      check_cart_count();
      
      if(order_no === 0) {
        $('.Save_order').trigger('click');
      } 

     // if($("#trans_no").val() == 0 ){
        //SaveDelivery();
      //}
      if((cartCount > 0 && allow) || payment_id == 'later') {
        var payment_method = $('#payment_method').val();
        var bank_acc_id = $('#bank_acc_id').val();      
        
        var payment_id = $('option:selected', '#payment_method').data('id');
        
        var trans_ref = $('#trans_ref').val();
        var memo = $('#memo').val();
        
        $.ajax({
          url: 'ajax?paymentnow=completed',
          type: 'POST',
          data : { 'payment_terms' : payment_method, 'trans_ref' : trans_ref, 'pmt_type' : payment_id, 'user_paid' : user_paid, 'cashpaid' : cashpaid, 'cardpaid' : cardpaid, 'bank_acc_id' : bank_acc_id, 'memo' : memo},
          dataType: "json",
          success: function(data) { 
            user_paid = 0;
            $.notify(data.msg, {
                newest_on_top: true
            });
            $("#last_invoice_id").val(data.id); 
            $('#PrintInvoice').attr('data-id', data.id);    
            $("#BillingTable > tbody").html('<tr class="noItemsClass" > <td colspan="8"> <center> <?php echo _("No Items In it"); ?> </center> </td> </tr> ');
            $('#total_amount').html('<?php  echo number_format2(0, $price_dec); ?>');
            $('#balance').html('<?php  echo number_format2(0, $price_dec); ?>');
            $('#user_paid').val('');    
            $("#user_paid").attr("placeholder", 0);
            var default_payment = $('#payment_method').attr('data-id', 'cash').val();
            $("#payment_method").val(default_payment).trigger('change');
            $('#cardpaid').val('');    
            $('#cashpaid').val('');    
            $('#bank_acc_id').val('');    
          // $('#payment_method').val('');    

            $("#CartItemsCount").val(0);  
          
            $("#tableListItem"+table_no).removeClass('delivered').removeClass('ordered').addClass('unslected');
            $(".tablenum").html('');
            $(".text_title").text('');
            $(".tokennum.badge").hide();
            $('.tokennum').text('');
            $(".tablenum").hide();
            $(".PrintReceipt").attr("disabled", true);
            $(".PrintReceipt").attr('data-id', '0');
            $(".PrintToken").attr("disabled", true);
            $(".PrintToken").attr('data-id', '0');
            $('#trans_no').val(0);
            $('#TableNo').val(0);
            $('#token_no').val(0);
           $('.Save_order').attr('data-id', 0);
           $('#order_id').val(0);
           $(".Save_order").attr("disabled", true);
           $('.tableNumText span').html('');
           $("#customer_ref").val('0');
           $("#contact_phone").html('');
           $("#address").html('');
           $("#delivery_cost_").html('0');
           $("#default_cust").val('0');

           $(".PrintInvoice").trigger('click');
        }
        }); 
      } 
    });
    $('.PrintInvoice').on("click",function(e){    
        var trans_no = $("#last_invoice_id").val();        
        var ifrme_modal = $("#pdfModal");
        PrintInvoice(trans_no,ifrme_modal);
      });
  });
 function check_cart_count(){
    var cartCount = $("#CartItemsCount").val();
    if(cartCount == 0){
        alert('<?php echo _("Please Select Item First") ?>');
        return false;
      }
      else{
        return true;
      }
  }
  function check_table_condition(){
    var table_no = $("#TableNo").val(); 
    if(table_no == ''){
      alert('<?php echo _("Table No is not Selected"); ?>'); 
      return false;
    }    
  }
  function load_door_item(){
    $.ajax({
      url: "ajax?load_door_item=Yes",
      type: "POST", 
      dataType: 'JSON',
      success: function(data){
        content = '';
        if(data.length == 0){
          content += '<li><?php echo _("No Items In it"); ?></li>';
        }
        $.each(data, function(i, item){
          if(parseFloat(data[i].delivery_no) > 0 && data[i].selected != 'undefined')
          content +='<li id="delListItem'+data[i].delivery_no+'" class="del_plan '+data[i].selected+'" data-del_num="'+data[i].delivery_no+'"><i class="material-icons">delivery_dining</i><label><p>'+data[i].name+ '</p><p>'+data[i].address+'</p></label></li>';

        });
        $("#trans_no").val('0');
        $("#save_order").attr('data-id', '0');
        $("#PrintToken").attr('data-id', '0');
        $("#PrintReceipt").attr('data-id', '0');
        // $("#deliverID option[value=" + data.del_man +"]").attr("selected","selected");
        //$("#deliverID").val(data.del_man).change();
        // $('.id_100 option[value=val2]').attr('selected','selected');
        $('.door_box').html(content);
        $(".Save_order").attr("disabled", false);


      }
    });
   
  } 
function load_takeaway_item(){
  $.ajax({
    url: "ajax?load_takeaway_item=Yes",
    type: "POST",
    dataType: 'JSON', 
    success: function(data){
      content = '';
          if(data.length ==0){
            content +='<li><?php echo _("No Items In it"); ?></li>';
          }
          $.each(data, function(i, item) {
            if(parseFloat(data[i].token_no) > 0 && data[i].selected != 'undefined')
              content +='<li id="tokenListItem'+data[i].token_no+'" class="token_plan '+data[i].selected+'" data-token_num="'+data[i].token_no+'"><i class="material-icons">takeout_dining</i><label>Token '+data[i].token_no+'</label></li>';
          });
          $('.token_box').html(content);
    }
  })
}

function load_cart_data(tablenum, token_no, del_no){
  var CustId = $("#CustomerId").val();
    $.ajax({
      url: "ajax?load_cart_data=Yes",
      type: "POST",
      data: {tablenum: tablenum, token_no: token_no, del_no: del_no},
      dataType: 'JSON',
      success: function(data){  
          
        if(data.cart_count > 0){
            var rowCount = $('#BillingTable tbody > tr.noItemsClass');
          if(rowCount.length == 1){    rowCount.remove();   }  
              var last_class = $("#BillingTable > tbody > tr:last").attr('class');
          if(last_class == 'odd')
              class_name = 'even';
          else
              class_name ='odd';
          this_row = '';
          row_val = '';
          $.each(data.cart_data, function(i, item) {
              row_val = '<a class="red RemoveItem" data-sessionid="'+parseInt(i)+'" href="javascript:void(0);"><i class="material-icons">delete_forever</i></a>';
              this_row += '<tr class="'+class_name+'" id="Cart_ID_'+i+'"><td>'+data.cart_data[i].name+' </td><td class="qtyEdit" data-id="'+i+'">'+data.cart_data[i].qty+'</td><td>'+data.cart_data[i].price+'</td><td>'+formatMoney(data.cart_data[i].line_total)+'</td><td>'+row_val+'</td></tr>';          
          });          
          $("#BillingTable > tbody").html(this_row);
          $(".currency").html(data.currency);
           // $("select#CustomerId").val(data.CustomerId);     
          $('#total_amount').html(formatMoney(parseFloat(data.grand_total)+parseFloat(data.freight_cost)));
          $("#user_paid").attr("placeholder", formatMoney(parseFloat(data.grand_total)+parseFloat(data.freight_cost)));
          $('#tax_included').val(data.tax_included);

          if(CustId != data.CustomerId){
            setTimeout(function(){            
             change_customer(data.CustomerId);
            },1000);
          } 
          
          if(data.del_no > 0){
            $("select#deliverID").val(data.del_num);
            $(".Save_order").attr("disabled", false);
          }
          $("#CartItemsCount").val(data.cart_count);
          $("#PrintReceipt").attr("disabled", false);
          $("#PrintToken").attr("disabled", false);
          $('#PrintReceipt').attr('data-id', data.order_id);         
          $('#PrintToken').attr('data-id', data.order_id);         
          $('#trans_no').val(data.delivery_no);

          var option = $("<option selected></option>").val(data.client_id).text(data.customer_ref);
          $('#customer_ref').append(option);
          $('#customer_ref').val(data.client_id).select2({theme: "material", ajax: {
              url: 'ajax?get_customers_client=1',
              dataType: 'json',
              delay: 250,
              processResults: function (data) {            
                return {
                  results: data
                };           
              },
            },
          cache: false});
          $('#contact_phone').html(data.contact_phone);
        //  alert(data.deliver_to);
          $('#default_location_to').html(data.deliver_to); 
          $('#delivery_cost').html(data.freight_cost);
          $('#delivery_address').html(data.delivery_address);

        // if(data.delivery_no > 0){
         // $('#trans_no').val(data.delivery_no);
           $('.Save_order').attr('data-id', data.order_id);
           $('#order_id').val(data.order_id);
           $(".Save_order").attr("disabled", true);
        // }
        }else{
          $("#BillingTable > tbody").html('<tr class="noItemsClass" > <td colspan="8" > <center><?php echo _("No Items In it") ?> </center> </td> </tr> ');
          $('#total_amount').html(data.grand_total);
          $("#CartItemsCount").val(data.cart_count);
          $(".PrintReceipt").attr("disabled", true);
          $(".PrintToken").attr("disabled", true);
          // $(".PrintReceipt").attr('data-trans_no', '0');
          // $('#trans_no').val(0);

          $('#PrintReceipt').attr('data-id', data.order_id);
          $('#PrintToken').attr('data-id', data.order_id);
          $('#save_order').attr('data-id', data.order_id);
          $('#order_id').val(data.order_id);
          $(".Save_order").attr("disabled", true);

        }        
      }
    });
  
}
function load_data_trans(order_id){
  $.ajax({
    url: "ajax?fetch_trans_no=Yes",
    method: "POST",
    data: {order_id: order_id},
    dataType: 'JSON',
    success: function(data){
      // $('#PrintReceipt').attr('data-trans_no', data.id);
      $('#trans_no').val(data.id);
    }
  })
}
function load_delivary_cart(trans_no){
  if(!trans_no){
    $.ajax({
      url: "ajax?fetchDelivaryDara=Yes",
      method: "POST",
      data: {trans_no: trans_no},
      dataType: "JSON",
      success: function(data){
          $("#tableListItem"+data.tablenum).removeClass('unselected').addClass('selectedDelivary');        
      }
      
    });
  }
}
function getCategory(q=''){
    if(q != '' )
      var qq = '&q='+q;
    else
      var qq = '';
      $.ajax({
        url: "ajax?fetchCategory=Yes"+qq,
        method: "POST",
        dataType: 'JSON',
        success: function(data){
          content = '';
          if(data.length ==0){
            content +='<li><?php echo _("No Items In it");?></li>';
          }
          $.each(data, function(i, item) {
            if(parseFloat(data[i].category_id) > 0 && data[i].name!= 'undefined')
              content += '<li class="List bg_green category" data-id='+data[i].category_id+'> <i class="material-icons"> menu_book </i> <label> '+data[i].name+' </label> </li>';            
          });
          $('.GridCategory').html(content);
        }
      }); 
  }
  function getProduct(id = '', q=''){
    // var cat_id = id;
   if(q != '' )
      var qu = '&q='+q;
    else
      var qu = '';

    if(id != '')
      var id = '&cat_id='+id
    else 
      var id = '';
    var sales_type_id = $('#sales_type_id').val();
     $.ajax({
            url:"ajax?fetchData=Yes"+qu+id,
            method:"POST",
            data: {sales_type_id: sales_type_id},
            // data:{'cat_id':cat_id},
            dataType:'JSON',
            success:function(data){   
              content = '';
              if(data.length ==0){
                content +='<li><?php echo _("No Items In it"); ?></li>';
              }
              $.each(data, function(i, item) {                
                if(data[i].stock_id != 'undefined' && data[i].name!= 'undefined')
                  content += '<li class="List '+data[i].color+' item" data-name="'+decodeURIComponent(data[i].name)+'" data-id='+data[i].stock_id+' data-price='+formatMoney(data[i].price)+' data-qty="1"> <i class="material-icons"> class </i> <label> '+data[i].name+' </label><div><span style="text-align: left;float:left;padding-left:3px;padding-top:20px!impotant;"> '+formatMoney(data[i].qty)+' '+data[i].unit+'</span><span style="text-align: right; float:right;padding-top:20px!impotant;"> '+data[i].curr+' '+formatMoney(data[i].price)+'</span> </div></li>';
              });
             $('.GridItemsList').html(content);
            }
        });
  }
  function AddItemToTable(data){
         var rowCount = $('#BillingTable tbody > tr.noItemsClass');
         if(rowCount.length == 1){    rowCount.remove();   }      
         $.each(data, function(i, item){     

        if(data[i].exist == 'yes'){
            if(data[i].stock_quantity > 0 )
                sign = false;
            else 
              sign = true;
            AppendCartTable(data[i], sign);
          } else {
            if(data[i].stock_quantity != '') {
              var stock_quantity = data[i].stock_quantity;
            }else{
              var stock_quantity = '&nbsp;';
            } 
            var last_class = $("#BillingTable tr:last").attr('class');
            if(last_class == 'odd')
                class_name = 'even';
            else
                class_name ='odd';
            if(stock_quantity < 0 )
              class_name += ' redbg';
            // console.log(data[i]);
            var row_val = '<a class="red RemoveItem" data-sessionid="'+data[i].last_id+'" href="javascript:void(0);"><i class="material-icons">delete_forever</i></a>';
            var this_row = '<tr class="'+class_name+'" id="Cart_ID_'+data[i].last_id+'"><td><span class="p_name">'+data[i].name+'</span></td><td class="qtyEdit" data-id="'+data[i].last_id+'">'+data[i].qty+'</td><td>'+data[i].price+'</td><td>'+formatMoney(data[i].amount)+'</td><td>'+row_val+'</td></tr>';
            $("#BillingTable  > tbody").append(this_row);
          }
          
        });  

         // var row_val = '<a class="red RemoveItem" data-sessionid="'+parseInt(data.last_id)+'" href="javascript:void(0);"><i class="material-icons">delete_forever</i></a>';
         // var this_row = '<tr class="'+class_name+'" id="Cart_ID_'+data.last_id+'"><td>'+data.name+' </span></td><td class="qtyEdit" data-id="'+data.last_id+'">'+data.qty+'</td><td>'+data.price+'</td><td>'+row_val+'</td></tr>';
         // $("#BillingTable > tbody").append(this_row);
         
  }
  function AppendCartTable(data){ 
    $("#Cart_ID_"+data.last_id).addClass('redbg');
       $("#Cart_ID_"+data.last_id+" > td:nth-child(2)").html(data.qty);
       $("#Cart_ID_"+data.last_id+" > td:nth-child(3)").html(data.price); 
       $("#Cart_ID_"+data.last_id+" > td:nth-child(4)").html(data.amount); 
       $("#total_amount").html(data.grand_total);
       $("#user_paid").attr("placeholder", data.grand_total);
  }
  function RemoveRItem(cart_id) {
    
  if(cart_id >= 0){  
      $.ajax({
        url: 'ajax?RemovePOSItemFromCart=Yes',
        type: 'POST',
        data : {'cart_id': cart_id},  
        dataType: 'JSON',   
        success: function(data) { 
          $("tr#Cart_ID_"+data.last_id).remove();
          var rowCount = $('#BillingTable tbody tr').length;
          if(rowCount == 0){
            $("#BillingTable > tbody").html('<tr class="noItemsClass" > <td colspan="8" > <center> <?php echo _("No Items In it"); ?> </center> </td> </tr>');
          }
         $('#total_amount').html(data.grand_total);
          // $('span.SubTotal').html(data.subtotal_price);
          // $(".tax_amount").html(data.tax_val);
          // $('span#grand_total').html(data.grand_total);
          $("#user_paid").attr("placeholder", data.grand_total);
          $("#CartItemsCount").val(data.cart_count);
        }
      });
    }
}
function UpdateQuantity(last_row_id, qty_cel){
    $.ajax({
        url: 'ajax?UpdateCartQuantity=Yes',
        type: 'POST',
        data : {'cart_id': last_row_id, 'qty' : qty_cel  },  
        dataType: 'JSON',   
        success: function(data) { 
          $("#Cart_ID_"+data.last_id+" > td:nth-child(2)").html(data.qty);
           $("#Cart_ID_"+data.last_id+" > td:nth-child(3)").html(data.price); 
           $("#Cart_ID_"+data.last_id+" > td:nth-child(4)").html(data.amount); 
           $("#total_amount").html(data.grand_total);
           $("#user_paid").attr("placeholder", data.grand_total);
           $(".Save_order").attr('disabled', false);
          
        } 
      });
  }
function isEmail(email) {
     var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     return regex.test(email);
}

/* formate money into comma seperator */
function formatMoney(amount, decimalCount = 2, decimal = ".", thousands = ",") {
  try {
    decimalCount = Math.abs(decimalCount);
    decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
    const negativeSign = amount < 0 ? "-" : "";
    let i = parseInt(amount = Math.abs(Number(amount) || 0).toFixed(decimalCount)).toString();
    let j = (i.length > 3) ? i.length % 3 : 0;
    return negativeSign + (j ? i.substr(0, j) + thousands : '') + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) + (decimalCount ? decimal + Math.abs(amount - i).toFixed(decimalCount).slice(2) : "");
  } catch (e) {
    console.log(e)
  }
}
function setInputFilter(textbox, inputFilter) {
  if(textbox.length){
    ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
      textbox.addEventListener(event, function() {
        if (inputFilter(this.value)) {
          this.oldValue = this.value;
          this.oldSelectionStart = this.selectionStart;
          this.oldSelectionEnd = this.selectionEnd;
        } else if (this.hasOwnProperty("oldValue")) {
          this.value = this.oldValue;
          this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
        }
        else {
          this.value = "";
        }
      });
    });
  }
}
function PrintReceipt(trans_no,ifrme_modal){
  
  $.ajax({
    type: 'post',
    url: 'ajax?PreparePosReport=yes&trans_no='+trans_no+'&Rep=110',           
    dataType: "json",
    success: function (data) {          
      var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();  
      ifrme_modal.find('iframe').attr('src',ifram_url); 
      //document.getElementById('printf').onload = function() {  document.getElementById('printf').contentWindow.print(); };
    }
  });
} 

function PrintToken(order_no,ifrme_modal){
  
  $.ajax({
    type: 'post',
    url: 'ajax?PreparePosReport=yes&order_no='+order_no+'&Rep=114',           
    dataType: "json",
    success: function (data) {          
      var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();  
      ifrme_modal.find('iframe').attr('src',ifram_url); 
      //document.getElementById('printf').onload = function() {  document.getElementById('printf').contentWindow.print(); };
    }
  });
}
function PrintInvoice(trans_no, ifrme_modal){
  var tblNo = $('#TableNo').val();
  $.ajax({
    type: 'post',
    url: 'ajax?PreparePosReport=yes&trans_no='+trans_no,           
    dataType: "json",
    success: function (data) {            
      var ifram_url = '<?php  echo get_url().'pdftmp/'.substr($current_user['tbpref'],0,-1).'/pdf_files/'; ?>'+data.file.trim();  
      ifrme_modal.find('iframe').attr('src',ifram_url);  
           
      //document.getElementById('printf').onload = function() {  document.getElementById('printf').contentWindow.print(); };
    }
  });
}

function change_customer(customer_id){

  $.ajax({
        url: 'ajax?GetCustomer=1',
        type: 'POST',
        data: {cid: customer_id},
        dataType: 'json',
        success: function(data){
          $('.currency').html(data.currency);
          $('#currency').val(data.currency);
          $('#curr_code').val(data.curr_code);
          $('#sales_type_id').val(data.sales_type_id);
          $('#tax_group_id').val(data.tax_group_id);  
          $('#payment_terms').val(data.payment_terms);
          var $option = $("<option selected></option>").val(data.id).text(data.name);
          $('#CustomerId').append($option);
          $('#customer_id').val(data.id);

      }
  });
}
// Generate float alert
function alert_float(type, message, timeout) {
    var aId, el;
    aId = $("body").find('float-alert').length;
    aId++;
    aId = 'alert_float_' + aId; 
    el = $('<div id="'+aId+'" class="float-alert animated fadeInRight col-xs-11 col-sm-4 alert alert-'+type+'"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><span class="fa fa-bell-o" data-notify="icon"></span><span class="alert-title">'+message+'</span></div>');
    $("body").append(el);
    setTimeout(function() {
        $('#' + aId).hide('fast', function() { $('#' + aId).remove(); });
    }, timeout ? timeout : 3500);
}
function ClearCart(){
  $.ajax({
       url:"ajax?ClearAllFromCart=Yes",
       success:function(data){
        $("#BillingTable > tbody").html('<tr class="noItemsClass"><td colspan="8"><center><?php echo _("No Items In it"); ?></center></td></tr> ');
        $('#total_amount').html('<?php  echo number_format2(0, $price_dec); ?>');
        $('#user_paid').val('');    
        $("#user_paid").attr("placeholder", 0);
        $("#CartItemsCount").val(0);  
        $("#trans_no").val(0);  
       }
  });
}
function loadsaved(data){

    $.notify(data.msg, {
      newest_on_top: true
    });
    load_data_trans(data.id);
    $('#PrintReceipt').trigger('click');
    $("#PrintReceipt").attr("disabled", false);
    $("#PrintToken").attr("disabled", false);
    $('#PrintReceipt').attr('data-id', data.id);
    $('#PrintToken').attr('data-id', data.id);
    $(".Save_order").attr('disabled', true);
    $('.Save_order').attr('data-id', data.id);
    $('.order_id').val(data.id);
    if(data.table_no > 0){
      $("#tableListItem"+data.table_no).removeClass('unselected').addClass('ordered');
      
    }
    if(data.token_no > 0){
      $('.tokennum').text(data.token_no);
      $('.text_title').text('Token');
      $('.tableNumText .tablenum').text(data.token_no);
       $('#collapseTwo').collapse('toggle');
       // $('#PrintToken').trigger('click');
      load_takeaway_item();
    }

    if(data.del_no > 0){
       // $('#collapseThree').collapse('toggle');
       $('#collapseThree').collapse('hide');
      // load_door_item();
      // ClearCart();
      // $('#PrintToken').trigger('click');
      // load_cart_data('', '', data.del_no);
    }
    $('#deliverID option:first').prop('selected',true);
    

    $('.PrintReceipt').attr('data-trans_no', '0');
              
}

function payment_complete(data){
  console.log(data);
  var notificationsWrapper   = $('.dropdown-notifications');
  var notificationsToggle    = notificationsWrapper.find('a[data-toggle]');
  var notificationsCountElem = notificationsToggle.find('i[data-count]');
  var notificationsCount     = parseInt(notificationsCountElem.data('count'));
  var notifications          = notificationsWrapper.find('ul.dropdown-menu');
  if (notificationsCount <= 0) {
    notificationsWrapper.hide();
  }
  var existingNotifications = notifications.html();
  var avatar = Math.floor(Math.random() * (71 - 20 + 1)) + 20;
  var newNotificationHtml = '<li class="notification active"><div> <strong class="notification-title" style="color:#000">'+data.msg+'</strong></div></li>';
  notifications.html(newNotificationHtml + existingNotifications);
  notificationsCount += 1;
  notificationsCountElem.attr('data-count', notificationsCount);
  notificationsWrapper.find('.notif-count').text(notificationsCount);
  notificationsWrapper.show();
   $.notify(data.msg, {
                newest_on_top: true
  });
   ClearCart();
   load_door_item();
}
</script>
<?php 
get_footer();
?>
<style>

</style>