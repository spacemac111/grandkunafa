<?php 
//session_start();
global $fadb, $current_user, $selected_user, $Refs, $installed_languages, $db_connections;

$installed_languages = array('C', 'nl_NL', 'ar_EG');

//add_menu_item('Roles', 'roles_page', 'roles_page', array('Administrator'),$position=4);

function roles_page() {
	$edit_arr['role'] =  ''; 
	if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['submit'])) {
		$role_id = $_POST['role_id'];
		$page_id = $_POST['page_id'];
		$values = array();
		foreach($_POST['page_permit'] as $content){
            $values[] = $content;
        }
        $new_content = serialize($values);
		$query = Insert('roles', array("role_id" => $role_id,"page_id" => $page_id, "content" => $new_content )  );
		if($query){
			echo 'Inserted successfully';
		}	
	}
	?>
	<div class="container">
		<div class="12u 12u$(mobile)">
			<form method="post" action="">
				<div class="row">
					<div class="4u 12u$(mobile)"><label> <?php echo _("Role"); ?> </label></div>
					<div class="8u 12u$(mobile)" >
						<select name="role_id" id="UserRole">
							<?php $userRoles = get_user_roles(); 
								foreach($userRoles as $role){ 
									echo '<option value="'.$role.'" '.($edit_arr['role'] == $role ? "selected" : '').' > '.$role.' </option>'; 										
								} ?>
						</select>
					</div>	
				</div>
				<style>
				#page_contents input{
					margin-right: 10px;text-transform: capitalize;
				}
				</style>
				<div class="row">
					<div class="4u 12u$(mobile)"><label style="float: left; line-height: 3;  padding-right: 8px;"><?php echo _("Select Page Name"); ?> </label></div>
					<div class="8u 12u$(mobile)"> 
						<?php
						$page_name = array();

						 $sql = "SELECT * FROM `kv_pages` as pg INNER JOIN `kv_permission` as pm on pg.ID = pm.page_id Group by pg.ID";
						$array_list = db_query($sql, "can't get results");	
						// $array_list = GetDataFilter('pages', array('ID', 'pageTitle'), array('page_type' => 'neem_menu'));
						foreach ($array_list as $value) { 
							$page_name[$value['ID']] = $value['pageTitle'];
						}
						 ?>
						<?php echo select_options_list('page_id', $page_name, null, 'no', null, null, 'page_id'); ?>
					</div>
				</div>
				<div class="row">
					<div class="4u 12u$(mobile)"><label style="float: left; line-height: 3;  padding-right: 8px;"><?php echo _("Page control Name"); ?> </label></div>
					<div class="8u 12u$(mobile)" id="page_contents">
						
					</div>					
				</div>
				
				
				<div class="row" > 
				<div class="4u 12u$(mobile)" > 
					<input type="submit" name="submit" value="Submit" >
				</div>
				</div>
				</form>
		</div>	
	</div>
	<script type="text/javascript">
	 $(function(){
	 	$("#page_id").change(function(){
			let c_id = $(this).val();

			$.ajax({
	            url: '<?php  echo get_url(); ?>ajax?get_pageContent=Yes',
	            type: 'post',
	            data: {c_id:c_id},
	            dataType: 'json',
	            success:function(data){

	                // $('#table_count').val(response.table_count);
						// $('#tbl_id').val(response.id);
					content = '';
		          $.each(data, function(i, item) {
		          	content += '<label class="checkbox-inline"><input type="checkbox" name="page_permit[]" id='+data[i].page_id+' value="'+data[i].page_permit+'" class="form-control">'+data[i].page_permit+'</label>';
		          });
		          $('#page_contents').html(content);
	            }
	        });
	    });
 		$('#page_id').trigger('change');
	});

	 </script>
<?php }

//add_menu_item('Roles and Permission', 'permit_page', 'permit_page', array('Administrator'),$position=5);

function permit_page() {
	$page_name = array();
	$kv_errors= array();
	$edit_arr = 0;
	if(isset($_GET['edit_id']) ){
		$edit_arr = GetRow("permission", array("id" => $_GET['edit_id']));

	}
	$array_list = GetDataFilter('pages', array('ID', 'pageTitle'), array('page_type' => 'neem_menu'));
	foreach ($array_list as $value) {				
		$page_name[$value['ID']] = $value['pageTitle'];
	}
	if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['page_submit'])) {

		$fields = array('page_id', 'page_permit');
		foreach ($fields as $field) {
			if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
		}

		if ($posted['page_permit'] == '')
		array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter content.', 'neem'));

		$errors = array_filter($kv_errors);
		if (empty($errors)) {

			if(isset($_POST['page_permit']) && $edit_arr > 0 ) {
				// echo 'updating';
				Update('permission',array('id' => $edit_arr), array('page_id' => $posted['page_id'], 'page_permit' => $posted['page_permit']) );
				kv_direct(get_url("admin").'admin.php?page=permit_page');
			}else{

				$query = Insert('permission', array("page_id" => $posted['page_id'], "page_permit" => $posted['page_permit'] )  );
				if($query){
					echo 'Inserted successfully';
				}	
			}
		}
	}
	if(!empty($errors)) {
		echo '<div class="error">';
		foreach ($kv_errors as $error) {
			echo '<p>'.$error.'</p>';
		}
		echo '</div>';
	} 
	?>
	<div class="container">
		<div class="12u 12u$(mobile)">
			<form method="post" action="">
				<div class="row">
					<div class="4u 12u$(mobile)"><label style="float: left; line-height: 3;  padding-right: 8px;"><?php echo _("Select Page Name"); ?> </label></div>
					<div class="8u 12u$(mobile)"> 
						<?php echo select_options_list('page_id', $page_name, null, 'no', null, null, 'Page List'); ?>
					</div>
				</div>
				<div class = "row">
					<div class="4u 12u$(mobile)"><label style="float: left; line-height: 3;  padding-right: 8px;"><?php echo _("Enter Content"); ?> </label></div>
					<div class = "8u 12u$(mobile)">
						<input type="text" name="page_permit" class="form-control" placeholder="Permission content">
					</div>			
				</div>
				<div class="row" > 
				<div class="4u 12u$(mobile)" > 
					<input type="hidden" name="p_id" id="p_id" value="<?php echo $edit_arr['id'] ?>" >
					<input type="submit" name="page_submit" value="Submit" >
				</div>
				</div>
				</form>
		</div>
		<div class="12u 12u$(mobile)">
			<table id="neem_table_permission" class="list bordered highlight">
				<thead> 
					<tr>
						<th width="40%"><strong>Page Name</strong></th>
						<th width="25%"><strong>Permission Content </strong></th>	
						
					</tr>
				</thead><tbody></tbody>
			</table>
		</div>		
	</div>
	<script type="text/javascript">
 //  datatable filter redraw plugin
 $(function(){
  $("#neem_table_permission").dataTable({
          "processing": true,
          "serverSide": true,
          "order": [[ 0, "desc" ]],
          "pageLength": 25,
		 // "dom": '<"FilterUploads">frtip',
          "ajax": "<?php  echo get_url(); ?>ajax?table_permission=yes",
      });
 
	});

 </script>
	<?php 
}

function Company_preference_settings(){ 
	if('POST' == $_SERVER['REQUEST_METHOD'] && isset($_POST['user_submit'])) {
		//echo "form submited"; 
		if (isset($_POST['max_upload_limit'])){ $posted['max_upload_limit'] = stripslashes(trim($_POST['max_upload_limit'])); }
		else{ $posted['max_upload_limit'] = '';}
		
		$current_option_id = get_site_option_id('max_upload_limit');
		if($current_option_id)
			Update('settings', array("ID" => $current_option_id), array("option_value" => $posted['max_upload_limit'] )  );	
		else
			Insert('settings', array("option_name" => 'max_upload_limit', "option_value" => $posted['max_upload_limit'] )  );
		
		$Company_name_id = get_site_option_id('Company_name');
		$Company_name = serialize($_POST['Company_name']);
		if($Company_name_id)
			Update('settings', array("ID" => $Company_name_id), array("option_value" => array($Company_name, 'noesc') )  );	
		else
			Insert('settings', array("option_name" => 'Company_name', "option_value" => array($Company_name, 'noesc') )  );
		//var_dump($_POST['Company_name']);
		echo '<div class="success" > '._('Company Options Updated'). ' </div>';
	} 
	$max_upload = get_site_option('max_upload_limit');  
	$max_upload_companies = get_site_option('Company_name');  
	//print_r($max_upload_companies); ?>
	<style>
		#Company_name { width: 100%; max-width:300px; min-height:300px;}
		#Company_name option, #max_upload { padding: 5px; width: 300px; }
	</style>
	<form method="post" action="">
	<div class="row">
			<div class="4u 12u$(mobile)"><label> Max Upload Limit </label></div>
			<div class="8u 12u$(mobile)"><input type="number" id="max_upload" name="max_upload_limit" value="<?php if($max_upload) { echo $max_upload; }  else { echo 1; } ?>"></div>
	</div>	
	<?php echo '<div class="row">
			<div class="4u 12u$(mobile)"><label style="float: left; line-height: 3;  padding-right: 8px;"> '._('Select Companies').' : </label></div><div class="8u 12u$(mobile)"> '. Get_Company_list(false, $max_upload_companies, null, true, false) .'</div>
	</div>
	<div class="row" > <div class="4u 12u$(mobile)" > <input type="submit" name="user_submit" value="Save Changes" >
	</form>'; 
 }