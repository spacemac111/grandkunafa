	<div id="footer">
		<div class="container"> 
		   <div class="copyright"> &copy 2014-<?php echo date('y'); ?> POS - <?php echo _("All right reserved."); ?>  </div>
		</div>
	</div>
</div>

<!-- Wrapper -->

<!-- Twitter Bootstrap -->
<script src="<?php  echo get_current_theme_uri(); ?>js/datatables.min.js"></script>

<!-- Material Design for Bootstrap -->
<script src="<?php  echo get_current_theme_uri(); ?>js/material.js"></script>

<script src="<?php  echo get_current_theme_uri(); ?>js/ripples.min.js"></script>
<script src="<?php  echo get_current_theme_uri(); ?>js/bootstrap.min.js"></script>
<!--<script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" type="text/javascript"></script> -->

<script src="<?php  echo get_current_theme_uri(); ?>js/moment-with-locales.min.js"></script>
<script src="<?php  echo get_current_theme_uri(); ?>js/bootstrap-material-datetimepicker.js"></script>

<script>
  $.material.init();
</script>

<!-- Dropdown.js -->

<script src="<?php  echo get_current_theme_uri(); ?>js/jquery.dropdown.js"></script>
<script src="<?php  echo get_current_theme_uri(); ?>js/select2.full.js"></script>

<script>
  $(document).bind('keydown', 'alt+h', function(e){  // Home Page
    window.location.href = "<?php echo get_url(); ?>";
  });

  $(document).bind('keydown', 'alt+p', function(e){  // POS Page
    window.location.href = "<?php echo get_url('pos'); ?>";
  });

  $(document).bind('keydown', 'alt+c', function(e){ //Customer Page
    window.location.href = "<?php echo get_url('customers'); ?>";  
  });

  $(document).bind('keydown', 'alt+s', function(e){ // Sales Transactions page
    window.location.href = "<?php echo get_url('sales'); ?>";
  });

  $(document).bind('keydown', 'alt+r', function(e){ // Profile page
    window.location.href = "<?php echo get_url('profile'); ?>";
  });
	
  $(document).bind('keydown', 'alt+e', function(e){ // Sales Return page
    window.location.href = "<?php echo get_url('return'); ?>";
  });
  $(document).bind('keydown', 'ctrl+q', function(e){ // Sales Transactions page
    window.location.href = "<?php echo get_url().'?logout=yes'; ?>";
  });

$("#dropdown-menu select").dropdown();

if($(".StartDate").length){
  $('.StartDate').bootstrapMaterialDatePicker({ weekStart : 0, time: false });
}

if($(".EndDate").length){
  $('.EndDate').bootstrapMaterialDatePicker({ weekStart : 0, time: false });
}


if($("#default_location").length){
  $("#default_location").select2({
    placeholder: "<?php echo _("Select a location"); ?>",
        theme: "material",
  });
}
$(document).ready(function domReady() {
    $(".js-select2").select2({
        placeholder: "Pick states",
        theme: "material"
    });
    
    $(".select2-selection__arrow").addClass("material-icons").html("arrow_drop_down");
    // var data = "<?php echo get_url().'ajax?get_itemredy=1'; ?>";
    // var p=JSON.parse(data);
    $('.itemName').select2({     // var itemName = $('select[name="itemName"]').val();
        placeholder: "<?php echo _("Select an item"); ?>",
        theme: "material",
        allowClear: true,
        ajax: {
          url: 'ajax?get_items=1',
          // url: 'ajax?get_itemredy=1',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {   
            console.log(data);         
            return {
              results: data
            };           
          },
        }
    }); 

    $('.OnlyitemName').select2({     // var itemName = $('select[name="itemName"]').val();
        placeholder: "<?php echo _("Select an item"); ?>",
        theme: "material",
        allowClear: true,
        ajax: {
          url: 'ajax?get_items_only=1',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {            
            return {
              results: data
            };           
          },
        }
    });
	
	$('#CustomerId').select2({     // var itemName = $('select[name="itemName"]').val();
        placeholder: "<?php echo _("Select an Customer"); ?>",
        theme: "material",
        allowClear: true,
        ajax: {
          url: 'ajax?get_customers=1',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {            
            return {
              results: data
            };           
          },
        },
        cache: false
    });
    

    $('.itemName').on('select2:select', function (e) {
      $(this).focus();
    });
});

setTimeout(function() {
    location.reload();
}, <?php $time_out = get_site_option('login_timeout'); echo $time_out*1000; ?> );
</script>
</body>
</html>
