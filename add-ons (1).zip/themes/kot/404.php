<?php 
/*
* Template Name : 404
*/
get_header(); ?>

			<h1><?php echo _("Sorry!, The Page not Found.");?>  </h1>
</div> 
</div>
<?php get_footer(); ?>