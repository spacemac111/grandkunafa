<?php 
   /*
   Template Name : KOT Clients Location 
   */ 
   global $Refs, $price_dec, $current_user, $pushers;
   get_header();  ?>

  <div class="container dashboard" id="bodySection">
       <div class="row" >
            <h3 class="NewLocationInvoice" style="max-width: 300px;" > <span> <?php echo _("Locations"); ?> </span> 
              <button class="btn-floating btn-large primary-color " data-target="#LocationAddNew" id="AddNewLocationBtn" > <i class="material-icons">group_add</i></button>


              <!--<a class="btn-floating btn-large primary-color" href="<?php //echo get_url('locations'); ?>" > <i class="material-icons">person_add</i></a>--></h3>
       </div>
       <div class="row">
		      <table class="list bordered highlight" id="LocationsDatatable">
				    <thead><tr> <th> <?php echo _("Location Name"); ?> </th>  <th> <?php echo _("Rate"); ?></th> <th> <?php echo _("Status"); ?></th> <th></th></tr></thead>
			     </table>
	     </div>
  </div>
      
  <!-- New message Structure -->
    <div class="modal fade" id="LocationAddNew" tabindex="-1" role="dialog" aria-labelledby="LocationDetail">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="material-icons" >close </i></button>
            <h4 class="modal-title" id="LocationDetail"> <!--<i class="material-icons"> folder_open</i> --> <?php echo _("New Location"); ?></h4>
          </div>
                    <form action="<?php echo get_url('customers'); ?>" class="" id="NewLocationAdd" enctype="multipart/form-data" method="post" accept-charset="utf-8">
              <div class="modal-body" style="min-height:200px;">
                <div id="UploadStatus"> </div> 
                <div class="row">            
                  <div class="col-sm-12"> 
           
                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Location Name"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="location_name" class="form-control"></div></div>  

                      <div class="form-group"><label class="col-md-4 control-label"><?php echo _("Rate"); ?><span style="color:#fb2e18;" > * </span></label><div class="col-md-8"><input type="text" name="rate" class="form-control"></div></div>  

                      <input type="hidden" name="locationid" id="locationid" value="0" > 
                  </div>
                 
                  <div class="col-md-12 form-group" id="errorWarning" style="display: none;background: #ffc0bb; border: 1px solid #F44336; border-radius: 2px; color: #f44336;" > 
                  <label style="color: rgb(243, 32, 17); font-weight: 300;  padding-top: 10px;" > </label>
                  </div> 
                </div>            
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo _("Close"); ?></button>
                 <input type="hidden" name="submit_customer" value="yes" > 
                <button type="submit" class="btn btn-primary" id="Submitbtn"><?php echo _("Submit"); ?></button>
              </div>
      </form>
        </div>
      </div>
    </div>

      <!-- Datatable Js --> 
<script src="<?php echo get_current_theme_uri(); ?>js/datatables.min.js"></script>
<script type="text/javascript">
 //  datatable filter redraw plugin
$(function(){
  $.fn.dataTableExt.oApi.fnStandingRedraw = function(oSettings) {

      if(oSettings.oFeatures.bServerSide === false){
          var before = oSettings._iDisplayStart;
          oSettings.oApi._fnReDraw(oSettings);       
          oSettings._iDisplayStart = before;
          oSettings.oApi._fnCalculateEnd(oSettings);
      } 
      oSettings.oApi._fnDraw(oSettings);
  };
  <?php if($current_user['role'] == 'Administrator' || $current_user['role'] == 'Auditor'){
    echo 'var customerid= "&customerId='.$selected_user['ID'].'";';
    echo 'var customer_id= "&customerID='.$selected_user['ID'].'";';
  } else {
    echo 'var customerid="";' ;
    echo 'var customer_id="";' ;
  }
  ?>
  $("#AddNewLocationBtn").on("click", function(e) {
    $('input[name="location_name"]').val('');
     $('input[name="phone"]').val('');
     $('#LocationAddress').val('');
     $("#locationid").val('0');
     $("#LocationDetail").html('<?php echo _("Add New Location"); ?>');
    $("#LocationAddNew").modal('show');
  });

  $("body").on("click", "#Submitbtn", function(e){ 
    e.preventDefault();
    var allow = 1;
    if($('input[name="location_name"]').val()==''){
      $('input[name="location_name"]').focus();     
      $("#errorWarning label").html('<?php echo _("You have to input location Name"); ?>');
      $("#errorWarning").show();
      allow = 0;
    }if($('input[name="rate"]').val()==''){
      $('input[name="rate"]').focus();     
      $("#errorWarning label").html('<?php echo _("You have to input location Rate"); ?>');
      $("#errorWarning").show();
      allow = 0;
    }
    if(allow == 1){
      var name = $('input[name="location_name"]').val();
      var rate = $('input[name="rate"]').val();
      var locationid = $('input[name="locationid"]').val();
        $("#errorWarning").hide();
        $.ajax({
            type: 'post',
            url: 'ajax?submit_Location=yes',
            data: {'locationid' : locationid, 'rate' : rate, 'location_name' : name },
            dataType :'JSON',
            success: function (result) {
              alert_float(result.type,result.msg);
              $('.modal .modal-dialog').attr('class', 'modal-dialog fadeOutDown animated');
              $('#LocationAddNew').modal('hide');
              $("#LocationsDatatable").dataTable().fnStandingRedraw();        
            }
        });
      }
  });

  $("body").on("click", ".EditLocation", function(e){   
    //e.preventDefault();
    var edit_customer_id = $(this).data('locationid'); 
    EdiLocation(edit_customer_id); 
   });
  $("body").on("click", ".DeleteLocation", function(e){ 
    var delete_customer_id = $(this).data('locationid'); 
    DeleteLocation(delete_customer_id); 
   }); 

  LocationsTable = $("#LocationsDatatable").dataTable({
          "processing": true,
          "serverSide": true,
          "order": [[ 0, "desc" ]],
          "pageLength": 25,
		 // "dom": '<"FilterUploads">frtip',
          "ajax": "<?php  echo get_url(); ?>ajax?clients_location=yes"+customerid
  });
}); 


function EdiLocation(Locationid){   
  $.ajax({
    type: "POST",
    dataType: "json",
    url: "ajax?Edit_Location="+Locationid,
    data: 0,
    success: function(data){    
      console.log(data);            
      if(data != 1){
        $("#LocationDetail").html('<?php echo _("Edit Location"); ?>');
        $('input[name="location_name"]').val(data.location_name);
        $('input[name="rate"]').val(data.rate);
       
        $("#locationid").val(data.id);
        $("#errorWarning").hide();
      //alert(data.name);
        $("#LocationAddNew").modal('show');
      }else{
          alert('failure', "Failed to Edit : "+data);
      }               
    }
  });   
}

function DeleteLocation(Locationid){
  var r = confirm('<?php echo _("Are you sure to delete this Location?"); ?>');
  if (r == false) {
    return false;
  } else {   
    $.ajax({
        type: "POST",
        url: "ajax?delete_Location="+Locationid,
        data: 0,
         dataType :'JSON',
        success: function(data){        
          if(data == 1){
            alert_float('success', '<?php echo _("The location was deleted successfully."); ?>');
            $("#LocationsDatatable").dataTable().fnStandingRedraw();
          }else{
            alert('failure', "Failed to Delete : "+data);
          }               
        }
    });
  }
}

function alert_float(type, message, timeout) {
    var aId, el;
    aId = $("body").find('float-alert').length;
    aId++;
    aId = 'alert_float_' + aId; 
    el = $('<div id="'+aId+'" class="float-alert animated fadeInRight col-xs-11 col-sm-4 alert alert-'+type+'"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button><span class="fa fa-bell-o" data-notify="icon"></span><span class="alert-title">'+message+'</span></div>');
    $("body").append(el);
    setTimeout(function() {
        $('#' + aId).hide('fast', function() { $('#' + aId).remove(); });
    }, timeout ? timeout : 3500);
}
</script>
<?php get_footer(); ?>