<?php 
if(isset($_GET['logout']) && $_GET['logout'] == 'yes'){
  logout();
}
if(!logged_in()) {
  kv_direct(get_url('flogin'));
}else{
  $selected_user = $current_user = kv_get_current_user();
  if(isset($_SESSION['Selected_User']) && $_SESSION['Selected_User'] > 0) {
    $selected_user_id = (int)$_SESSION['Selected_User'];
    $selected_user = get_user_details($selected_user_id);
  }
}

$favicon = get_site_option('favicon');
?>
<!DOCTYPE html>
<html <?php  echo ($selected_user['language'] == 'ar_EG' ? "dir='rtl'" : ''); ?> >
<head>

  <title><?php  echo  get_page_title(); ?></title>
  <meta charset="<?php echo get_encoding(); ?>">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

<!-- Mobile support -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href='//fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>

<!-- Material Design fonts -->
  <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:300,400,500,700" type="text/css">
 <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">-->
  <link href="<?php echo get_url('admin'); ?>assets/theme/font/material-icons.css" rel="stylesheet">

<!-- Bootstrap -->
  <link href="<?php  echo get_current_theme_uri(); ?>css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>css/select2.css" rel="stylesheet" type="text/css">
  
<!--  Datatable Style --> 
  <link href="<?php  echo get_current_theme_uri(); ?>css/datatables.min.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>css/animate.min.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>style.css" rel="stylesheet" type="text/css">

<!-- Bootstrap Material Design -->
  <link href="<?php  echo get_current_theme_uri(); ?>css/bootstrap-material-design.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>css/bootstrap-material-datetimepicker.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>css/ripples.min.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>css/custom.css" rel="stylesheet" type="text/css">
  <link href="<?php  echo get_current_theme_uri(); ?>css/kv-tables.css" rel="stylesheet" type="text/css">	
  <link href="<?php  echo get_current_theme_uri(); ?>style.css" rel="stylesheet" type="text/css">

<link href="<?php echo get_url('admin'); ?>assets/theme/css/bootstrap-colorpicker.min.css" type="text/css" rel="stylesheet">
<!-- Dropdown.js -->
<link href="<?php  echo get_current_theme_uri(); ?>css/jquery.dropdown.css" rel="stylesheet" type="text/css">

<!-- jQuery -->
<script src="<?php  echo get_current_theme_uri(); ?>js/jquery.min.js"></script>

<!-- Morris -->  
<link rel="stylesheet" href="<?php  echo get_current_theme_uri(); ?>css/morris.css">
<script src="<?php  echo get_current_theme_uri(); ?>js/jquery.hotkeys.js"></script>
<script src="<?php  echo get_current_theme_uri(); ?>js/raphael-min.js"></script>
<script src="<?php  echo get_current_theme_uri(); ?>js/morris.min.js"></script>
<!-- Bootstrap Notify - Optional -->
  <link rel="stylesheet" href="<?php echo get_url('admin'); ?>assets/theme/css/bootstrap-notify.min.css" >
  <script src="<?php echo get_url('admin'); ?>assets/theme/js/bootstrap-notify.min.js" ></script>
  <script src="<?php echo get_url('admin'); ?>assets/theme/js/bootstrap-colorpicker.js" type="text/javascript"></script>

<script src="<?php echo get_url('admin'); ?>assets/theme/js/pusher.min.js"></script>
<?php if($favicon && file_exists(ABSPATH.'themes/pos/images/'.$favicon)) { ?>
			<link rel="shortcut icon" type="image/png" href="<?php echo get_url();?>themes/pos/images/<?php echo $favicon; ?>"/>
		<?php } else { ?>
			<link rel="shortcut icon" type="image/png" href="<?php echo get_url("admin");?>assets/css/images/icon.png"/>
		<?php } ?>
		
<?php $ColorScheme = get_user_meta($current_user['ID'], 'ColorScheme'); 
if($ColorScheme){
  echo '<link href="'.get_current_theme_uri().'css/ColorSchemes/'.$ColorScheme.'.css" rel="stylesheet">';
}else {
  echo '<link href="'.get_current_theme_uri().'css/ColorSchemes/kvcodes.css" rel="stylesheet">';
} ?>

<style type="text/css">
#bodySection { position:relative}
#client-company-info a { text-decoration: none}
.ItemsTable { /*height: 90vh; */   overflow-y: scroll;   overflow-x: hidden; }
.success { color:#39c558 }
.processed { color:#00b4ff  }
.duplicate {color:#937fc7 }
.pending { color:#ffbe41}
.rejected { color:#ff3e43 }
.modal-content .modal-header { color:#fff; }
.modal-content .modal-header .close { color:#fff; opacity: 0.8;}
.modal-content .modal-footer {   border-top: none;   padding: 7px; }
.modal-content .modal-footer button {  margin-top:5px; }
.fixed-action-btn {   position:relative;  padding-top: 15px;  margin-bottom: 0;  z-index: 1001;}
#BillingTable tr th:nth-child(2), #BillingTable tr td:nth-child(2) { text-align: center; }
#BillingTable i.material-icons { font-size:20px; cursor : pointer; }
.Summary tr td:nth-child(2) { text-align: right; } 
.Summary .GrandTotal td, .Summary .saveOrdertr td{ background: #4caf50; font-size: 25px;  text-align: center;   color: #fff;   font-weight: 400; }
.Summary .Balance td { background: #e67f22; font-size: 25px;  text-align: center;   color: #fff;   font-weight: 400; }
.Summary .PayNow, .Summary .saveOrderTr .Save_order{ background: #9C27B0; font-size: 20px;  text-align: center;   color: #fff;   font-weight: 400; width: 100%; padding: 15px;}
.Summary .PayNow:hover, .Summary .saveOrderTr .Save_order:hover{ background-color: #9c27b0 !important; opacity: 0.9;}
.Summary .btn { margin: 0; }
.Summary .PrintReceipt  { background: #E91E63; font-size: 20px;  text-align: center;   color: #fff;   font-weight: 400;padding: 13px 0;  width: calc( 50% - -2px); float: left; }
.Summary .PrintReceipt:hover  { background: #E91E63 !important; opacity: 0.9;}
.Summary .NewSales:hover  { background: #03a9f4 !important; opacity: 0.9;}
.Summary .NewSales { background: #03a9f4; font-size: 20px;  text-align: center;   color: #fff;   font-weight: 400; padding: 13px 0;    width: calc( 50% - 2px);}
.Summary .small { font-size: 14px;   vertical-align: middle;text-align: left; }
.Summary .Title td { background: #4caf50;    text-align: center; color: #fff; }
.Summary .Title h4 { font-weight:400; }
.btn:not(.btn-raised):not(.btn-link):hove { background: inherit; } 
table.dataTable.Summary tbody td { padding:10px; }
.form-group {margin: 7px 0 0 0;}
span.form-group { width: 45%; float: left; } 

/* responsive iFrame style */
.iframe-container {position: relative;height: 0; overflow: hidden;} 

/* 16x9 Aspect Ratio */
.iframe-container { padding-bottom: 46.25%;}
 
/* 4x3 Aspect Ratio */
.iframe-container-4x3 { padding-bottom: 75%;} 
.iframe-container iframe {position: absolute; top:0; left: 0; width: 100%; height: 100%;}
#date_selection {
  float: left;
  display: inline-block;
  padding: 18px 0 0px 0;
}
/*  ###  Modal PDF style ####  */
@media (min-width: 768px) {
	.modal-dialog {   width: 450px;   margin: 30px auto;}
	#pdfModal .modal-dialog {  width: 500px;  margin: 30px auto; height: 100%; }	
}
.preloaderImg  {  width: 100%;  height: 100%;  position: fixed;  background-color: #fff;  z-index: 1; }
  .preImg{  width: 150px;  height: 150px;  position: fixed;  left: 50%;  top: 50%;  
  background-image:url(<?php echo get_current_theme_uri(); ?>images/preloader.GIF);  background-repeat: no-repeat;  background-position: center;  margin: -100px 0 0 -100px; }
.float-alert {   display: inline-block;   margin: 0px auto;   position: fixed;  -webkit-transition: all 0.5s ease-in-out;  transition: all 0.5s ease-in-out;  z-index: 1031;   top: 20px;  right: 20px;}
.alert:not(.float-alert) span[data-notify="icon"] {  float: left;   font-size: 18px;  margin-top: 0px;}
.float-alert.alert span[data-notify="icon"] {  font-size: 20px;  display: block;  left: 13px;  position: absolute;   top: 50%;   margin-top: -11px;}
.alert.float-alert .alert-title {  margin-left: 30px;   font-weight: 500;}
[dir="rtl"] .alert.float-alert .alert-title {   float: left;}
.alert:not(.float-alert) .alert-title {  margin-left: 10px;}
.alert.float-alert button.close {  position: absolute;  right: 10px;  top: 50%;  margin-top: -13px;
    z-index: 1033;  background-color: #FFFFFF;  display: block;  border-radius: 50%;   opacity: .4;  line-height: 11px;  width: 25px;  height: 25px;
    outline: 0 !important;  text-align: center;  padding: 3px;   font-weight: 400;
}
.alert.float-alert button.close:hover {   opacity: .55;}
.alert.float-alert .close~span {   display: block;   max-width: 89%;}
/*[dir="rtl"] .textltr{direction: ltr;}
[dir="rtl"] .textrtl {direction: ltr;}*/

[dir="rtl"] .inbox-widget .inbox-item .inbox-item-date{
  right: unset;left: 7px;
}
[dir="rtl"] .inbox-widget .inbox-item .inbox-item-img{float: right;}
[dir="rtl"] .inbox-widget .inbox-item .inbox-item-total{left: 65px;right: unset;}
[dir="rtl"] .inbox-widget .inbox-item .inbox-item-amount{ left: 5px; right: unset;}
</style>
</head>

<body>
<?php 
  $date = date("Y-m-d");
 ?>
<div class="preloaderImg">
  <div class="preImg"> </div>
</div> 
<script type="text/javascript">
  // preloader
  $(window).load(function() {
    $(".preloaderImg").delay(1000).fadeOut(1000);
    });
</script>
<div class="main-wrapper" id="main_wrapper"> 
  <div class="bs-component">
          <div class="navbar navbar-info">
            <div class="container-fluid">
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                 <i class="material-icons"> apps </i>
                </button>
                <a class="navbar-brand hidden-xs" href="<?php echo get_url(); ?>">
				<?php 

				$logo = get_site_option('logo');
				if($logo && file_exists(ABSPATH."themes/pos/images/".$logo)) { ?>
					<img src="<?php echo get_current_theme_uri();?>images/<?php echo $logo; ?>" width="150"></a>
				<?php } else { ?>
					<img src="<?php echo get_current_theme_uri();?>images/logo.png" width="150"></a>
				<?php } ?>
                <a class="navbar-brand hidden-lg hidden-md hidden-sm" href="<?php echo get_url(); ?>"><img src="<?php echo get_current_theme_uri();?>images/logo.png" width="160"></a>
              </div>
              <div class="navbar-collapse collapse navbar-responsive-collapse">
				  <?php $options_arr =  array(		
					'nav'			=> false, 	
					'out_nav_id'	=> '',			
					'out_nav_class' => '',		
					'menu_class'	=> array('nav navbar-nav', 	'sub_items'), 	
					'menu_id'		=> array('', '')
				);
          if($current_user['role'] == 'Deliveryman') {
              kv_nav_menu('Delivery man', $options_arr);
          }
           else {
    				kv_nav_menu('KOT', $options_arr);					
    				if($current_user['role'] == 'Administrator' ){
    					kv_nav_menu('Top2', $options_arr); 
    				} 
            
        }
        if($current_user['role'] != 'Administrator'){ ?>
              <style>
              li.admin_login {
                     /* display: none;*/
                  }
              </style>
                      <?php 
        }
				  //var_dump($current_user);
				?>	
				
               <ul class="nav navbar-nav navbar-right">
                  <li class="dropdown dropdown-notifications">
                    <a href="#notifications-panel" class="dropdown-toggle" data-toggle="dropdown">
                      <i data-count="0" class="material-icons notification-icon">add_alert</i>
                    </a>
                      <ul class="dropdown-menu">
                       
                      </ul>
                  </li>
                    <li class="dropdown">
                    <a href="#" data-target="#" class="dropdown-toggle" data-toggle="dropdown">
                      <span class="desktop-oly" > <?php echo $current_user['full_name']; ?></span> <i class="material-icons">account_circle</i> <span class="mobile-oly" > <?php echo $current_user['full_name']; ?></span> 
                      <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                    <?php if(is_admin() || is_auditor()){
                      echo '<li> <a href="'.get_url('admin').'" > '._('Admin Dashboard').' </a> </li>';
                      } else{
                        echo '<li><a href="'.get_url().'">'._('Dashboard').'</a></li>';
                      } ?>
                      <li><a href="profile"><?php echo _('Profile'); ?></a></li>
                      <!--<li><a href="javascript:void(0)"><?php //echo _('Appearance'); ?></a></li>  -->
                      <li><a href="?logout=yes"><?php echo _('Logout'); ?></a></li>
                    </ul>
                  </li>
                 <li class="admin_login"><a href="?logout=yes"> <i class="material-icons">power_settings_new</i> <span class="mobile-oly" > <?php echo _('Logout'); ?></span> </a>
                  </ul>
              </div>
            </div>
          </div>
        </div>       
       <!--   ###########  Section 2 Panel ##############  -->   
       
    
    <?php  if(Current_page_slug() == 'kot' ) { ?>
    <!-- Accordion .panel -->
    <div class="panel panel-default" style="margin-bottom:0;">
      <!-- .container -->
      <div class="container">
        <!-- #accordion -->
        <!-- <div class="show_date">
            <table class="list bordered highlight dataTable quotation-table-2 style-2 table-responsive">
               <tbody>
                  <tr>  
                  <td>
                    <div class="custom-control custom-checkbox mr-sm-2" id="date_selection">
                        <input type="checkbox" class="custom-control-input" id="select_date">
                        <label class="custom-control-label" for="select_date">Future Selection</label>
                      </div>
                  </td>                   
                     <td>
                      
                      <span style="display:none" id="date_show">
                        <input type="text" id="date" class="form-control StartDate" name="date" value="<?php echo date('Y-m-d'); ?>"> 
                      </span> 
                    </td>
               </tbody>
            </table>
         </div> -->
        <div id="accordion">
          <div class="buttons-wrap panel panel-default">
            <div class="panel-body text-center">
              <div class="btn-group table_group" role="group" aria-label="Basic example">
                <button type="button" class="btn btn-raised btn-primary btn-lg tableplanbtn" data-parent="#accordion" data-toggle="collapse" data-target="#collapseOne" aria-controls="collapseOne"><i class="material-icons">local_dining</i> <?php echo _("Table Plan"); ?> <span class="tablenum badge"><?php echo ((isset($_SESSION['TableNo']) && $_SESSION['TableNo'] > 0 ) ? $_SESSION['TableNo'] : ''); ?></span><?php if(isset($_SESSION['TableNo']) > 0) { echo '<div class="ripple-container"></div>' ; } ?></button>
                <button type="button" class="btn btn-raised btn-danger btn-lg takeaway_btn" data-id="takeaway" data-toggle="collapse" data-target="#collapseTwo" aria-controls="collapseTwo"><i class="material-icons">takeout_dining</i><?php echo _("Takeaway"); ?>  <span class="tokennum badge"><?php echo ((isset($_SESSION['token_no']) && $_SESSION['token_no'] > 0 ) ? $_SESSION['token_no'] : ''); ?></span></button>
                <button type="button" class="btn btn-raised btn-info btn-lg door_delivary" data-toggle="collapse" data-target="#collapseThree" aria-controls="collapseThree"><i class="material-icons" style="padding-right:5px;">delivery_dining</i><?php echo _("Door Delivery"); ?></button>
              </div>
            </div> 
          </div>
  
          <!-- .table-plan-content-wrap -->
          <div class="table-plan-content-wrap panel panel-default">
            <!-- #collapseOne -->
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne">
              <div class="card-body">
                <ul id="tableList" class="tableBox">
                  <?php 

                    $sql = "SELECT * FROM ".TB_PREF."sales_orders WHERE trans_type =30 AND (version = 0 OR version = 1) AND table_no > 0 AND ord_date = '".$date."' GROUP BY table_no ORDER BY order_no DESC";
                    $result= fadb_query($sql, "can't get results");
					$table_no = [];
                    if(fadb_num_rows($result) >0 ){
          						while($row = fadb_fetch($result)){
          							$table_no[$row['table_no']] = $row['version'];   
          						}                    
                    }     

                    $t_num = FAGetSingleValue('sys_prefs', 'value',array('name' => 'table_no'));
                    if($t_num > 0){               
                    
                    } else
                      $t_num = 18;
                    for($i = 1; $i<=$t_num; $i++) {
						          $table_no_only = array_keys($table_no);
                      if (in_array($i, $table_no_only)){
          							if($table_no[$i] == 1)
          								$selected = 'delivered';
          							else
          								$selected = 'ordered';
                      }else{
                        $selected = 'unslected'; 
                      }
                    ?>
                    <li id="tableListItem<?php echo $i;?>" class="table_plan <?php echo $selected; ?>" data-tablenum="<?php echo $i; ?>"><i class="material-icons">table_chart</i><label>Table <?php echo $i;?></label></li>
                  <?php }
                /*}else{ ?>

                  <li id="tableListItem" class="table_plan" data-targettable="tableContent"><i class="material-icons">table_chart</i><label><?php echo _("No Table count found"); ?></label></li>

                <?php }*/
                   ?>
                  </ul>
              </div>
            </div>
            <!-- /#collapseOne -->

            <!-- #collapseTwo -->
            
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
              <div class="card-body">
               <ul id="tokenList" class="token_box">
                 <?php
                 

                  $sql = "SELECT * FROM ".TB_PREF."sales_orders WHERE trans_type =30 AND (version = 0 OR version = 1) AND token_no > 0 and ord_date =".$date." GROUP BY token_no  ORDER BY order_no DESC";
               $result= fadb_query($sql, "can't get results");
               $row_count = fadb_num_rows($result);
                    
                    if($row_count >0 ){
                      while($row = fadb_fetch($result)){
                        $token_no[] = $row['version'];   
                        if($row['version'] == 1){
                          $selected = 'delivered';
                        }else{
                          $selected = 'ordered';
                        }
                        echo '<li id="tokenListItem'.$row['token_no'].'" class="token_plan '.$selected.'" data-token_num="'.$row['token_no'].'"><i class="material-icons">table_chart</i><label>Token '.$row['token_no'].'</label></li>';
                      }                    
                    }     
                
                 ?>
               </ul>
              </div>
            </div>
            <!-- /#collapseTwo -->

            <!-- #collapseThree -->
            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
              <div class="card-body">
                <ul class="door_box" id="doorList">
                  <p><?php echo _("Door Delivery"); ?></p>
                 <?php
                  // $sql = "SELECT deb.debtor_no,deb.name,deb.address,so.delivery_no FROM ".TB_PREF."debtors_master as deb, ".TB_PREF."sales_orders as so WHERE so.trans_type =30 AND (so.version = 0 OR so.version = 1) AND so.delivery_no > 0 and so.ord_date =".$date." and  so.debtor_no=deb.debtor_no GROUP BY so.delivery_no  ORDER BY so.order_no DESC";
                  // $result= fadb_query($sql, "can't get results");
                  // $row_count = fadb_num_rows($result);
                    
                  //   if($row_count >0 ){
                  //     while($row = fadb_fetch($result)){
                  //       $token_no[] = $row['version'];   
                  //       if($row['version'] == 1){
                  //         $selected = 'delivered';
                  //       }else{
                  //         $selected = 'ordered';
                  //       }
                  //       echo '<li id="delListItem'.$row['delivery_no'].'" class="del_plan '.$selected.'" data-del_num="'.$row['delivery_no'].'"><i class="material-icons">table_chart</i><label>Name '.$row['name']. '</br> Address '.$row['address'].'</label></li>';
                  //     }                    
                  //   }     
                
                 ?>
                </ul>
              </div>
            </div>
            <!-- /#collapseThree -->
          </div>
          <!-- End of .table-plan-content-wrap -->
        </div><!-- /#accordion -->
      </div><!-- /.container -->
    </div><!-- Accordion /.panel -->
    <?php } else { ?>
    <div id="client-company-info" class="panel panel-default">
      <div class="panel-body">
        <a href="javascript:void(0)">
        <div class="col-sm-3 mblpad10 form-group cinfo"><i class="material-icons" style="" >account_balance</i>
                      <?php /*if($current_user['role'] == 'Administrator' ) { echo Get_Company_list(false, $selected_user['ID']); } else {   */      
                  echo get_company_details(); 
                  // / } /
                   ?> 
                </div>
        <div class="col-sm-4 mblpad10 form-group cinfo"><i class="material-icons">place</i><?php echo get_company_details('postal_address'); ?> </div>
        <?php if($company_phone = get_company_details('phone')){ ?>
        <div class="col-sm-2 mblpad10 form-group cinfo"><i class="material-icons">local_phone</i> <?php echo $company_phone; ?>  </div><?php }?>
          <?php if($company_email = get_company_details('email')){ ?>
        <div class="col-sm-3 mblpad10 form-group cinfo"><i class="material-icons">local_post_office</i> <?php echo $company_email; ?>  </div><?php }?>
          <!-- <div class="col-sm-1" align="right"><a href="<?php //echo  get_url('profile'); ?>"><i class="material-icons">mode_edit</i></a></div>  -->   
          </a>
        </div>      
    </div>
    <?php } ?>    
    
