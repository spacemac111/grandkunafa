<?php 

get_header(); ?>
 <!--   ###########  Dashboard Section ##############  -->    
 
 <div class="container dashboard" id="bodySection">
 
  <div class="row"> 

<?php get_page_content(); ?>
          
          </div>
 
 <?php get_footer(); ?>