<?php 

ini_set('display_errors', 1);

if ( file_exists('config.php') && filesize('config.php')> 40) {
  header("location: index.php");
}


function encrypt_decrypt($action, $string) {
    $output = false;

    $encrypt_method = "AES-256-CBC";
    $secret_key = 'This is my secret key';
    $secret_iv = 'This is my secret iv';

    // hash
    $key = hash('sha256', $secret_key);
    
    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    $iv = substr(hash('sha256', $secret_iv), 0, 16);

    if( $action == 'encrypt' ) {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' ){
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}
if(file_exists(dirname(__FILE__).'/FA/config_db.php'))
  include_once(dirname(__FILE__).'/FA/config_db.php');
else 
  header("location: FA/index.php");
global $db_connections;


function write_config_db(){
  
  $msg = "<?php \n
/*-------------------------------------------------------+
| Kvcodes POS 
| http://www.spacemac.us/
+--------------------------------------------------------+
| Author: Kvvaradha  
| Email: admin@spacemac.us
+--------------------------------------------------------+*/

ob_start();
session_start();

// db properties

    define('DBHOST','" . $_POST['dbhost'] . "');
    define('DBUSER','" . $_POST['usr_name'] . "');
    define('DBPASS','" . $_POST['db_pass'] . "');
    define('DBNAME','" . $_POST['db_name'] . "');
    define('TB_PREF','". $_POST['prefix']. "');

    define('ABSPATH', dirname(__FILE__) . '/' );

    define('FA_PATH', ABSPATH.'FA/');

    define('NEEM_UPLOADS', 'files');
    
    define('included', 1); //define include checker

    define('DEBUGGING', 0);   // 0-Normal Mode, 1- Debugging Mode

    define('ENCODING', 'UTF-8');    //site encoding

    define('DEFAULT_LANG', '".$_POST['default_language']."');  // Site Translation Purpose

?>";

  $filename = dirname(__FILE__). "/config.php";
  // Check if the file exists and is writable first.
  if (!file_exists($filename) || is_writable($filename)){
    if (!$zp = fopen($filename, 'w')){
      return -1;
    }
    else{
      if (!fwrite($zp, $msg)){
        fclose($zp);
        return -2;
      }
      // Close file
      fclose($zp);
      cache_invalidate($filename);
    }
  } else {
    return -3;
  }
    write_htaccess();
  return 0;
}


function write_htaccess(){

    $directory = dirname($_SERVER['PHP_SELF']);

 if(strlen($directory) > 1)
    $directory = $directory.'/';

    $content = '<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase '.$directory;

if($_SERVER['REQUEST_SCHEME'] == 'https') {
$content .= '
RewriteCond %{HTTPS} off
RewriteRule (.*) https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]';
}
$content .= '
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php?p=$1 [QSA,L]
</IfModule>';

    $filename = dirname(__FILE__). "/.htaccess";
    // Check if the file exists and is writable first.
    if (!file_exists($filename) || is_writable($filename)){
        if (!$zp = fopen($filename, 'w')){
            return -1;
        }
        else{
            if (!fwrite($zp, $content)){
                fclose($zp);
                return -2;
            }
            chmod($filename, 0644);
            // Close file
            fclose($zp);
            //cache_invalidate($filename);
        }
    } else {
        return -3;
    }
    return 0;
}
/*
 Ensure file is re-read on next request if php caching is active
*/
function cache_invalidate($filename)
{
    if (function_exists('opcache_invalidate')) // OpCode extension
        opcache_invalidate($filename);
}

$posted['host_name']=$posted['db_usr_name']=$posted['db_pas_name']=$posted['db_name']='';
$posted['site_title']=$posted['username']=$posted['user_email']= $posted['site_pas']= '';
$protocol = $_SERVER['REQUEST_SCHEME'];
$domain_name= $protocol.'://'.$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF']);
$last_string_url = substr($domain_name, -1);

if($last_string_url == '/')
    $posted['domain_name']= $domain_name;
else
    $posted['domain_name'] = $domain_name.'/';

$kv_errors= array();
$posted['prefix'] = 'kv_';
if( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['site_details']) && $_POST['site_details'] == 'yes') {
  
  $fields = array(
                    'site_title',
                    'domain_name',
                    'username',
                    'user_email',
                    'site_pas', 'module_to_be_installed'
    );
    foreach ($fields as $field) {
        if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
    }
    if ($posted['site_title'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Site Title.', 'neem'));

    if ($posted['domain_name'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Domain Name.', 'neem'));

    if ($posted['username'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Username.', 'neem'));

    if ($posted['user_email'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your E-mail.', 'neem'));
    if ($posted['site_pas'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Password.', 'neem'));
  if ($posted['prefix'] == $db_connections[0]['tbpref'])
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please Different Prefix, You already used it for FA.', 'neem'));

    $db = mysqli_connect($_POST['dbhost'], $_POST['usr_name'] , $_POST['db_pass'], $_POST['db_name']);
  if(!$db){        
    array_push($kv_errors,  sprintf('<strong>Notice</strong>:Sorry! There seems to be a problem connecting to our database. Error '.mysqli_connect_error(), 'neem'));   
  }

    
        
        // if ($err == -1) {
        //     array_push($kv_errors,  sprintf("Cannot Create 'config.php' file Due to Prevented Permission.Change Folder Permission and try Again."));             
        // } else if ($err == -2) {
        //     array_push($kv_errors,  sprintf("Cannot write to the 'config.php' configuration file."));
        // } else if ($err == -3) {
        //     array_push($kv_errors, sprintf("'config.php' is not writable. Change its permissions so it is, then re-run installation step."));
        // }    
    $reg_errors = array_filter($kv_errors);

    if (empty($reg_errors)) { 
  
    $err = write_config_db();
        require_once("includes/class-phpass.php");
        $wp_hasher = new PasswordHash(16, true);
        $password = $wp_hasher->HashPassword( trim( $posted['site_pas'] ) );
    
        $create_page_table = "CREATE TABLE IF NOT EXISTS `{$_POST['prefix']}pages` (
          `ID` int(11) NOT NULL AUTO_INCREMENT,
          `authorID` int(10) NOT NULL,
          `pageTitle` varchar(255) DEFAULT NULL,
          `isRoot` int(11) NOT NULL DEFAULT '0',
          `pageContent` text,
          `slug` varchar(250) NOT NULL,
          `page_type` varchar(20) NOT NULL,
          `template` varchar(300) DEFAULT NULL,
          `parentID` int(10) DEFAULT NULL,
          `pDate` date NOT NULL,
          `status` varchar(20) NOT NULL,
          PRIMARY KEY (`ID`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;";

        mysqli_query($db, $create_page_table);


        $module_name = ($posted['module_to_be_installed'] == 'pos' ? 'POS' : ($posted['module_to_be_installed'] == 'kot' ? 'KOT' : 'eShop'));

        $sql_page = "INSERT INTO `{$_POST['prefix']}pages` (`ID`, `authorID`, `pageTitle`, `isRoot`, `pageContent`, `slug`, `page_type`, `template`, `parentID`, `pDate`, `status`) VALUES
(1, 1, 'Home', 1, '<h1>Welcome to Kvcodes POS </h1> <p> This is your first Page. <br/>Edit or delete it, then start Creating it!</p>', 'home', 'page', NULL, NULL, '2018-11-02', 'Published'), ".
($posted['module_to_be_installed'] == 'kot' ?  
      "(2, 1, 'KOT', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">pos</span></p>', 'kot', 'page', 'Restaurant.php', 0, '2018-11-05', 'Published')," : 

      ($posted['module_to_be_installed'] == 'pos' ? "(2, 1, 'POS', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">pos</span></p>', 'pos', 'page', 'BillingPOS.php', 0, '2018-11-05', 'Published')," : "" ) )."
(3, 1, 'Ajax', 0, '<p>Ajax</p>', 'ajax', 'page', 'ajax.php', 0, '2018-11-05', 'Published'),
(4, 1, 'Customers', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">Customers</span></p>', 'customers', 'page', 'customers.php', 0, '2018-11-05', 'Published'),
(5, 1, '404', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">404</span></p>', '404', 'page', '404.php', 0, '2018-11-05', 'Published'),
(6, 1, 'Home', 0, '{$posted['domain_name']}', '', 'neem_menu', '".$module_name."', 0, '2018-11-11', 'Published'),

(7, 1, 'Customers', 0, '{$posted['domain_name']}customers', '', 'neem_menu', '".$module_name."', 0, '2018-11-11', 'Published'), ".
($posted['module_to_be_installed'] == 'kot' ?  
"(8, 1, 'KOT', 0, '{$posted['domain_name']}kot', '', 'neem_menu', 'KOT', 0, '2018-11-11', 'Published')," : 

      ($posted['module_to_be_installed'] == 'pos' ? "(8, 1, 'POS', 0, '{$posted['domain_name']}pos', '', 'neem_menu', '".$module_name."', 0, '2018-11-11', 'Published')," : "" ) )."

(9, 1, 'Profile', 0, '<p>Profile</p>', 'profile', 'page', 'profile.php', 0, '2018-11-05', 'Published'),
(10, 1, 'Login', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">Login</span></p>', 'login', 'page', 'login.php', 0, '2018-11-05', 'Published'),
(11, 1, 'Sales', 0, '<p>Sales</p>', 'sales', 'page', 'sales.php', 0, '2018-11-26', 'Published'),
(12, 1, 'Return', 0, '<p>Return</p>', 'return', 'page', 'return.php', 0, '2018-11-26', 'Published'),
(13, 1, 'Return', 0, '{$posted['domain_name']}return', '', 'neem_menu', '".$module_name."', 0, '2018-11-26', 'Published'),
(14, 1, 'Sales', 0, '{$posted['domain_name']}sales', '', 'neem_menu', '".$module_name."', 0, '2018-11-26', 'Published'),

(15, 1, 'FA', 0, '{$posted['domain_name']}FA', '', 'neem_menu', 'Top2', 0, '2018-11-11', 'Published'),
(16, 1, 'Inventory', 0, '<p>Inventory</p>', 'inventory', 'page', 'Inventory.php', 0, '2019-12-19', 'Published'),
(17, 1, 'Inventory', 0, '{$posted['domain_name']}inventory', '', 'neem_menu', '".$module_name."', 0, '2019-12-19', 'Published'),
(18, 1, 'Reports', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">Reports</span></p>', 'reports', 'page', 'reports.php', 0, '2019-12-19', 'Published'),
(19, 1, 'Report Preview', 0, '<p><span style=\"font-family: Verdana; font-size: 13pt;\">Preview</span></p>', 'report-preview', 'page', 'report-preview.php', 0, '2019-12-19', 'Published'),
(20, 1, 'Reports', 0, '{$posted['domain_name']}reports', '', 'neem_menu', '".$module_name."', 0, '2019-12-19', 'Published');";

if($posted['module_to_be_installed'] == 'kot')
  $sql_page .= "INSERT INTO `kot1_pages` (`ID`, `authorID`, `pageTitle`, `isRoot`, `pageContent`, `slug`, `page_type`, `template`, `parentID`, `pDate`, `status`) VALUES (NULL, '1', 'Deliveries', '0', 'Deliveries list', 'deliveries', 'page', 'delivery_man.php', '0', '2018-11-05', 'Published'),(NULL, '1', 'Deliveries', '0', '{$posted['domain_name']}deliveries', 'deliveries', 'neem_menu', 'Delivery man', '0', '2018-11-05', 'Published');";

        mysqli_query($db, $sql_page);

        $pageMetaQuery = "CREATE TABLE IF NOT EXISTS `{$_POST['prefix']}pagemeta` (
          `ID` int(11) NOT NULL AUTO_INCREMENT,
          `pageID` int(10) NOT NULL,
          `meta_key` varchar(255) DEFAULT NULL,         
          `meta_value` text,
          PRIMARY KEY (`ID`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;";

         mysqli_query($db, $pageMetaQuery);
     

        $create_users_table = "CREATE TABLE IF NOT EXISTS `{$_POST['prefix']}users` (
          `ID` int(11) NOT NULL AUTO_INCREMENT,
          `s_id` int(11) NOT NULL DEFAULT '1' COMMENT 'salesman ID',
          `fa_user_id` int(11) DEFAULT '1',
          `sales_pos_id` int(11) NOT NULL DEFAULT '1',
          `strict_dimension` tinyint(1) NOT NULL DEFAULT '0',
          `dimension_id` int(11) NOT NULL DEFAULT '0',
          `dimension2_id` int(11) NOT NULL DEFAULT '0',
          `username` varchar(255) NOT NULL DEFAULT '',
          `password` varchar(60) NOT NULL DEFAULT '',
          `full_name` varchar(250) NOT NULL,
          `activation` varchar(30) DEFAULT NULL,
          `email` varchar(255) NOT NULL DEFAULT '',
          `role` varchar(30) NOT NULL,
          `theme` varchar(60) NOT NULL DEFAULT '".$posted['module_to_be_installed']."',
          `pdf_template` varchar(60) NOT NULL DEFAULT 'A6',
          `provision` double NOT NULL DEFAULT '5',
          `provision2` double NOT NULL DEFAULT '4',
          `break_pt` double NOT NULL DEFAULT '1000',
          `language` varchar(6) NOT NULL,
          `bank_accounts` varchar(15) NOT NULL DEFAULT '1',
          `cash_accounts` varchar(15) NOT NULL DEFAULT '2',
          `status` varchar(30) NOT NULL,
          `host` varchar(250) NOT NULL,
          `dbname` varchar(250) NOT NULL,
          `dbpassword` varchar(250) NOT NULL,
          `dbuser` varchar(250) NOT NULL,
          `tbpref` varchar(250) NOT NULL,
          `name` varchar(250) NOT NULL,
          `permissions` MEDIUMTEXT NULL ,
          `selected_id` int(5) NOT NULL DEFAULT 0,
          PRIMARY KEY (`ID`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=latin1;";

         mysqli_query($db, $create_users_table);

        $userMetaQuery = "CREATE TABLE IF NOT EXISTS `{$_POST['prefix']}usermeta` (
          `ID` int(11) NOT NULL AUTO_INCREMENT,
          `userID` int(10) NOT NULL,
          `meta_key` varchar(255) DEFAULT NULL,         
          `meta_value` text,
          PRIMARY KEY (`ID`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4;";

         mysqli_query($db, $userMetaQuery);

       $create_settings_table ="CREATE TABLE IF NOT EXISTS `{$_POST['prefix']}settings` (
          `ID` int(11) NOT NULL AUTO_INCREMENT,
          `option_name` varchar(500) NOT NULL DEFAULT '',
          `option_value` longtext NOT NULL,
          PRIMARY KEY (`ID`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=latin1;"; 

        mysqli_query($db, $create_settings_table);

         $default_user_query = "INSERT INTO `".$_POST['prefix']."users` ( full_name, username, password, email, role, language, status, host, dbname, dbpassword, dbuser, tbpref, name, selected_id) VALUES ('{$posted['username']}', '{$posted['username']}', '{$password}', '{$posted['user_email']}', 'Administrator', 'en_US', 'Active', '".$db_connections[0]['host']."', '".$db_connections[0]['dbname']."', '".$db_connections[0]['dbpassword']."', '".$db_connections[0]['dbuser']."', '".$db_connections[0]['tbpref']."', '".$db_connections[0]['name']."', '0' ) ";
       
        mysqli_query($db, $default_user_query);

        if($posted['module_to_be_installed'] == 'kot') {

          if(!empty($db_connections)){
            foreach($db_connections as $conn){

              $sql = "SHOW COLUMNS FROM ".$db_connections[0]['dbname'].".".$db_connections[0]['tbpref']."debtor_trans LIKE 'deliveryman';";

               $result = mysqli_query($db, $sql);

               if(mysqli_num_rows($result)<=0){
                 $default_user_query = "ALTER TABLE ".$db_connections[0]['dbname'].".".$db_connections[0]['tbpref']."debtor_trans ADD `deliveryman` INT(11) NOT NULL DEFAULT '0' AFTER `salesman`, ADD `token_no` INT(11) NOT NULL DEFAULT '0' AFTER `deliveryman`, ADD `table_no` INT(11) NOT NULL DEFAULT '0' AFTER `token_no`, ADD `delivery_no` INT(11) NOT NULL DEFAULT '0' AFTER `table_no`";
                  mysqli_query($db, $default_user_query);


                 $default_user_query = "ALTER TABLE ".$db_connections[0]['dbname'].".".$db_connections[0]['tbpref']."sales_orders ADD `deliveryman` INT(11) NOT NULL DEFAULT '0' AFTER `salesman`, ADD `token_no` INT(11) NOT NULL DEFAULT '0' AFTER `deliveryman`, ADD `table_no` INT(11) NOT NULL DEFAULT '0' AFTER `token_no`, ADD `delivery_no` INT(11) NOT NULL DEFAULT '0' AFTER `table_no`";
                  mysqli_query($db, $default_user_query);
                }
            }
          }
        }


        $kv_modulepage_Tbl ="CREATE TABLE `{$_POST['prefix']}modulepage` (
          `id` int(30) NOT NULL AUTO_INCREMENT,
          `pageName` varchar(100) CHARACTER SET utf8 NOT NULL,
          PRIMARY KEY (`id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci, AUTO_INCREMENT=9;";


        mysqli_query($db, $kv_modulepage_Tbl);

        if($posted['module_to_be_installed'] == 'kot' && false){
          $kv_table_plan_Tbl ="CREATE TABLE `{$_POST['prefix']}table_plan` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `table_count` varchar(11) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
            `company_id` varchar(11) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
            PRIMARY KEY (`id`)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci, AUTO_INCREMENT=2;";

          mysqli_query($db, $kv_table_plan_Tbl);


          $kv_table_plan_Tbl_data = "INSERT INTO `{$_POST['prefix']}table_plan` (`id`, `table_count`, `company_id`) VALUES (1, '20', '0');";
          mysqli_query($db, $kv_table_plan_Tbl_data);

        }


         $kv_modulepage_Tbl_data = "INSERT INTO `{$_POST['prefix']}modulepage` (`id`, `pageName`) VALUES
          (1, 'Dashboard'),
          (2, 'POS & KOT'),
          (3, 'Customers'),
          (4, 'Sales'),
          (5, 'Backend'),
          (6, 'KOT'),
          (7, 'Inventory'),
          (8, 'Reports');";
       
        mysqli_query($db, $kv_modulepage_Tbl_data);
        $userRoles = array( 'Administrator', 'Author', 'Customer', 'Salesman');

        if($posted['module_to_be_installed'] == 'kot')
          $userRoles[] = 'Deliveryman';
        $userRoles = serialize($userRoles);
        $default_settings_query = "INSERT INTO `".$_POST['prefix']."settings` (`option_name`, `option_value`) VALUES
            ('site_title', '{$posted['site_title']}'),
            ('site_url', '{$posted['domain_name']}'),
            ('admin_email', '{$posted['user_email']}'),
            ('permalink', ''),
            ('logo', ''),
            ('favicon', ''),
            ('template', '".$posted['module_to_be_installed']."'),
            ('allow_user_registration', '0'),
            ('upload_path', 'files/'),
            ('login_timeout', '3600'),
            ('captcha_login', 'no'),
            ('isRoot', 1),
            ('language', 'en_US'),
            ('login_retries_allowed', '5'),
            ('System_Roles', '{$userRoles}'),
            ('active_plugins', ''); ";

        mysqli_query($db, $default_settings_query);


    $permissions ="CREATE TABLE `{$_POST['prefix']}permission` (
      `ID` int(11) NOT NULL AUTO_INCREMENT,
      `page_permit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
      `module` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
      `module_no` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
      `description` text COLLATE utf8_unicode_ci,
      PRIMARY KEY (`ID`)
    ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;"; 

        mysqli_query($db, $permissions);



   $sql_page = "INSERT INTO `{$_POST['prefix']}permission` (`ID`, `page_permit`, `module`, `module_no`, `description`) VALUES
  (1, 'View Overall', 'Dashboard', '1', ''),
  (2, 'View Own', 'Dashboard', '1', ''),
  (3, 'View Overall', 'POS & KOT', '2', ''),
  (4, 'Use Barcode', 'POS & KOT', '2', ''),
  (5, 'Add Items', 'POS & KOT', '2', ''),
  (6, 'Edit Items', 'POS & KOT', '2', ''),
  (7, 'Allow Order', 'POS & KOT', '2', ''),
  (8, 'Allow Delivery', 'POS & KOT', '2', ''),
  (9, 'Allow Cash', 'POS & KOT', '2', ''),
  (10, 'Print Receipt', 'POS & KOT', '2', ''),
  (11, 'View Customers', 'Customers', '3', ''),
  (12, 'Add/Edit Customer', 'Customers', '3', ''),
  (13, 'View Overall', 'Sales', '4', ''),
  (14, 'View Own', 'Sales', '4', ''),
  (15, 'Refund', 'Sales', '4', ''),
  (16, 'Collect Payment', 'Sales', '4', ''),
  (17, 'Create Users', 'Backend', '5', ''),
  (18, 'Edit/Delete', 'Backend', '5', ''),
  (22, 'View Deliveries', 'Dashboard', '1', 'It Will View Delivery in Delivary man Dashboard'),
  (27, 'Delete Inventory', 'Inventory', '7', 'Delete Inventory permission'),
  (24, 'View', 'Inventory', '7', 'Allowed to view full page'),
  (25, 'Add Inventory', 'Inventory', '7', 'Add New Inventory Allowed'),
  (26, 'Edit Inventory', 'Inventory', '7', 'Edit Inventory allowed'),
  (30, 'View All', 'Reports', '8', 'To Access all the reports in the POS'),
  (31, 'Annual Expenses Breakdown', 'Reports', '8', 'To Access Annual Expenses Breakdown report in the POS'),
  (32, 'Balance Sheet', 'Reports', '8', 'To Access Balance Sheet report in the POS'),
  (33, 'Profit and Loss Statement', 'Reports', '8', 'To Access Profit and Loss Statement report in the POS'),
  (34, 'Trail Balance', 'Reports', '8', 'To Access Trail Balance report in the POS'),
  (35, 'Tax Report', 'Reports', '8', 'To Access Tax Report report in the POS'),
  (36, 'Customer Balance', 'Reports', '8', 'To Access Customer Balance report in the POS'),
  (37, 'Aged Customer Analysis', 'Reports', '8', 'To Access Aged Customer Analysis report in the POS'),
  (38, 'Customer Detail Listing', 'Reports', '8', 'To Access Customer Detail Listing report in the POS'),
  (39, 'Supplier Balance', 'Reports', '8', 'To Access Supplier Balance report in the POS'),
  (40, 'Aged Supplier Analysis', 'Reports', '8', 'To Access Aged Supplier Analysis report in the POS'),
  (41, 'Supplier Detail Listing', 'Reports', '8', 'To Access Supplier Detail Listing report in the POS');";

     mysqli_query($db, $sql_page);

        mysqli_close($db);  
    }
    $reg_errors = array_filter($kv_errors);
    if(empty($reg_errors)){
        header("location: {$posted['domain_name']}kv-admin/?action=login&first=yes");
    }
}

if( 'POST' == $_SERVER['REQUEST_METHOD'] && !empty( $_POST['db_details']) && $_POST['db_details'] == 'yes') {
  
    $fields = array(
                    'host_name',
                    'db_name',
                    'prefix',
                    'db_usr_name',
                    'db_pas_name'
    );

    foreach ($fields as $field) {
        if (isset($_POST[$field])) $posted[$field] = stripslashes(trim($_POST[$field])); else $posted[$field] = '';
    }
    if ($posted['host_name'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Host Name.', 'neem'));

    if ($posted['db_name'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Database Name.', 'neem'));

    if ($posted['db_usr_name'] == null)
        array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Database Username.', 'neem'));

   // if ($posted['db_pas_name'] == null)
       // array_push($kv_errors,  sprintf('<strong>Notice</strong>: Please enter Your Database Password.', 'neem'));
    $reg_errors = array_filter($kv_errors);
    if (empty($reg_errors)) { 
      $db = mysqli_connect($posted['host_name'], $posted['db_usr_name'] , $posted['db_pas_name'], $posted['db_name']);
    if(!$db){
      array_push($kv_errors,  sprintf('<strong>Notice</strong>:Sorry! There seems to be a problem connecting to your database.-'.mysqli_connect_error(), 'neem'));
    }else{         
      $encryString = serialize( array( "DBHOST" => $posted['host_name'],
          "DBUSR" => $posted['db_usr_name'], 
          "DBPASS" => $posted['db_pas_name'],
          "DBNME" => $posted['db_name'],
          "PREF" => $posted['prefix']));    
      $postString = encrypt_decrypt('encrypt', $encryString);
      header("location: install.php?sndParam=".$postString);
    }
        $reg_errors = array_filter($kv_errors);
    }
} 

if ( false ) {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Error: PHP is not running</title>
</head>
<body class="wp-core-ui">
  <p id="logo"><a href="https://www.spacemac.us/">POS POS</a></p>
  <h1>Error: PHP is not running</h1>
  <p>Kvcodes POS requires that your web server is running PHP. Your server does not have PHP installed, or PHP is turned off.</p>
</body>
</html>
<?php
}?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<META NAME="ROBOTS" CONTENT="NOINDEX, FOLLOW">
<title>Neem Install</title>
<link rel="stylesheet" href="kv-admin/assets/css/login.css" type="text/css" />
<script type="text/javascript" src="kv-admin/assets/js/jquery.min.js"></script>
</head>
<body>
<div class="lwidth">
  <div class="page-wrap">
    <div class="content"> 
  
<?php if(isset($_GET['sndParam'])){  ?>

  <div id="login">
        <?php if(!empty($reg_errors)) {
                    echo '<div class="error">';
                    foreach ($reg_errors as $error) {
                        echo '<p>'.$error.'</p>';
                    }
                    echo '</div>';
                }else { ?>  
           <div class="success" > 
           <p> <b> Success: </b> Database is connected Successfully! Next </p>
           </div>  
           <?php } ?>   
      <form method="post" action="">
          <div class="login-block">
      <?php if(isset($_GET['sndParam'])) {      
        $decrypted_txt = encrypt_decrypt('decrypt', $_GET['sndParam']);
        $host_details = unserialize($decrypted_txt);
      } ?>
          <input type="hidden" name="dbhost" value="<?php echo $host_details['DBHOST']; ?>" >
          <input type="hidden" name="usr_name" value="<?php echo $host_details['DBUSR'];?>" >
          <input type="hidden" name="db_pass" value="<?php echo $host_details['DBPASS']; ?>" >
          <input type="hidden" name="db_name" value="<?php echo $host_details['DBNME']; ?>" >
          <input type="hidden" name="prefix" value="<?php echo $host_details['PREF']; ?>" >
                <h1> <img src="kv-admin/assets/css/images/logo.png" width="250px;" >
                <br> 
                 Site Details</h1> 
                <input type="text"   value="<?php echo $posted['site_title']; ?>" name="site_title" placeholder="Site Name" id="sitename" />
                <input type="text"   value="<?php echo $posted['domain_name']; ?>" name="domain_name"  placeholder="Your Website Url" id="url" />
                <input type="text"   value="<?php echo $posted['username']; ?>" name="username"  placeholder="Admin Username" id="user_name" />
                <input type="email"  value="<?php echo $posted['user_email']; ?>" name="user_email"  placeholder="Admin E-Mail" id="user_email" />

                <input type="text"   value="<?php echo $posted['site_pas']; ?>" name="site_pas"  placeholder="Password" id="password" />
                <?php $themes =[];

                foreach(glob('./themes/*', GLOB_ONLYDIR) as $dir) {
                  $dirname = basename($dir);
                  foreach(glob('./themes/'.$dirname, GLOB_ONLYDIR) as $single) {
                    $theme_folder = basename($single);
                   // echo './themes/'.$theme_folder.'/index.php'; 
                    if(file_exists('./themes/'.$theme_folder.'/index.php') && file_exists('./themes/'.$theme_folder.'/functions.php') && file_exists('./themes/'.$theme_folder.'/style.css')){
                      $myFile = './themes/'.$theme_folder.'/style.css';
                      $lines = file($myFile);//file in to an array
                      $theme_name = 'Theme Name';
                      $theme_n = array_filter($lines, function($var) use ($theme_name){ return preg_match("/\b$theme_name\b/i", $var); });

                      $theme_nam=  implode('', $theme_n);
                      $positio = strpos($theme_nam, ':');
                      $theme_fullname =trim(substr($theme_nam, $positio+1)); 

                      $themes[$theme_folder] = $theme_fullname;
                    } 
                  }
                } 
                if(!empty($themes)) {
                  echo '<select name="module_to_be_installed" >';
                  foreach($themes as $theme => $name){
                    echo '<option value="'.$theme.'" > '.$name.' </option>';

                  } ?>
                </select>
              <?php } ?>

                 <select name="default_language" >
                  <option value="en_US" > English </option>
                  <option value="ta_IN"> Tamil </option>
                  <option value="nl_BE" > Dutch </option>
                </select>
               
                <input type="hidden" name="site_details" value="yes" >
                <input type="submit" name="submit" class="button" value="Install" />
                                    
            </div>  

      </form>       
    </div> 
<?php 
} else { ?>
    <div id="login">
        <?php if(!empty($reg_errors)) {
                    echo '<div class="error"><ul>';
                    foreach ($reg_errors as $error) {
                        echo '<li>'.$error.'</li>';
                    }
                    echo '</ul></div>';
                } ?>       
      <form method="post" action="">
          <div class="login-block">
                <h1> <img src="kv-admin/assets/css/images/logo.png" width="250px;" >
                <br> 
                 Database Details</h1>
                <input type="text"   value="<?php echo $posted['host_name']; ?>" name="host_name" placeholder="Hostname" id="host" />
                <input type="text"   value="<?php echo $posted['db_name']; ?>" name="db_name"  placeholder="Database Name" id="db_name" />
                <input type="text"   value="<?php echo $posted['prefix']; ?>" name="prefix"  placeholder="Database Prefix" id="prefix" />
                <input type="text"   value="<?php echo $posted['db_usr_name']; ?>" name="db_usr_name"  placeholder="Database User Name" id="db_name" />
                <input type="text"   value="<?php echo $posted['db_pas_name']; ?>" name="db_pas_name"  placeholder="Database Password" id="db_name" />               
                <input type="hidden" name="db_details" value="yes" >
                <input type="submit" name="submit" class="button" value="Next" />
                                    
            </div>  

      </form>       
    </div> 
    <?php } ?>

    </div>  
    <div class="clear"></div>   
  </div>
</div>
<style>
body {   font-family: Montserrat;}
.logo {   width: 213px;   height: 36px;   background: url('kv-admin/images/fd8Lcso.png') no-repeat;    margin: 30px auto;}
.login-block {    width: 320px;    padding: 20px;    background: #fff;    border: 1px solid #ff656c;    border-radius: 5px;    border-top: 5px solid #ff656c;    margin: 0 auto;}
.login-block h1 {    text-align: center;    color: #000;    font-size: 18px;    text-transform: uppercase;    margin-top: 0;    margin-bottom: 20px;}
.login-block input, .login-block select {    width: 100%;    height: 42px;    box-sizing: border-box;    border-radius: 5px;    border: 1px solid #ccc;    margin-bottom: 20px;    font-size: 14px;    font-family: Montserrat;    padding: 0 20px 0 50px;    outline: none;}
.login-block input.rememberme{    height: auto ;    width: auto;}
.login-block input:active, .login-block input:focus {    border: 1px solid #ff656c;}
.login-block .button {    width: 100%;    height: 40px;    background: #ff656c;    box-sizing: border-box;    border-radius: 5px;    border: 1px solid #e15960;    color: #fff;    font-weight: bold;    text-transform: uppercase;    font-size: 14px;    font-family: Montserrat;    outline: none;    cursor: pointer;    margin-bottom: 0px;}
.login-block .sbutton:hover {    background: #ff7b81;}
</style>
</body>
</html>