<?php 
/*
Addon Name : SEO
Addon URI : http://www.spacemac.us
Author : Varadha
Description : A Simple plugin for testing the plugin functionality. You can select and modify your website current and active themes. Glad to provide you few more themes. You can select and modify your website current and active themes. Glad to provide you few more themes.
Version : 1.0
*/

add_menu_item('Bookisdvsvdngs', 'booking', 'test_booking', array('Administrator'));

?>