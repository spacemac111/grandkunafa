<?php 
/*
Addon Name : Customer Uploads Handler 
Addon URI : http://www.spacemac.us
Description : A plugin to handle the customer uploaded files and create access to auditors and allow admin to moderate any customer uploads and assign autior to a company.
Version : 1.0
*/



//add_action('Neem-ajax', 'ClientUploadsAjax');
?>