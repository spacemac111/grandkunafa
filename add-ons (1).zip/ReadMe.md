ReadMe

Requirement:

* PHP 5.5  and Above

* MySQL 5.6 And Above

* Apache 2.4 

* Mysqli required

Installation : 

	1. First install FA inside POS directory by opening it. your domainname.com/POS/FA and install the frontaccounting by continue it.
	2. Next open the url your domainname.com/POS and install POS module.
	3. After Successfull installation. You will be prompted to login to the admin.  There you can connect and create sales mans as users. 
	4. The inventory import and adding items will be done through FA, you can see a import module in it to handle multiple items import.
	5. incase of doubt or issues, check http://docs.spacemac.us/pos
	

Thank you. 
